package dynamo;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.amazonaws.regions.Regions;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.dynamodbv2.model.ScanRequest;
import com.amazonaws.services.dynamodbv2.model.ScanResult;

/**
 * Main Class
 */
public class Main {
	/** process id (pid). */
	static final String PID = java.lang.management.ManagementFactory.getRuntimeMXBean().getName().split("@")[0];

	static Logger logger = LogManager.getLogger(Main.class);

	private static AmazonDynamoDB client;

	private static final String TABLE_NAME = "Updtest";
	private static final String KEY_ID = "KeyId";
	private static final String VERSION = "version";

	/**
	 * main method
	 */
	public static void main(String[] args)
	{
		// 開始ログ出力
		logger.info("START - main");

		// This client will default to
		client = AmazonDynamoDBClientBuilder.standard()
							.withRegion(Regions.AP_NORTHEAST_1)
							.build();

		// 全件取得
		scan();
		// 条件検索サンプル
		//scan("Price", ComparisonOperator.LT, "100");

    	// 終了ログ出力
        logger.info("END - main");
	}

	/*
	 * 全件検索
	 */
    private static void scan()
    {
		ScanRequest scanRequest = new ScanRequest().withTableName(TABLE_NAME);
		ScanResult result = client.scan(scanRequest);
		String keyId;
		int ver = 0;

		// 取得レコード単位
		for (Map<String, AttributeValue> rowItem : result.getItems()) {
			keyId = "";
			ver = 0;
			//outputItem(rowItem);

        	// 取得レコードの項目単位（keyIDとversionの値を取得）
            for (Map.Entry<String, AttributeValue> colItem : rowItem.entrySet()) {
                String attributeName = colItem.getKey();
            	AttributeValue value = colItem.getValue();

            	// keyId
                if(KEY_ID.equals(attributeName))
                {
                	keyId = value.getS();
                }

                // version
                if(VERSION.equals(attributeName))
                {
                	ver = Integer.parseInt(value.getN());
                }
            }

            // 未更新データを更新（versionが１の場合）
            if(ver == 1)
            {
                // 更新対象のログ出力
                logger.info("TARGET - " + keyId + ":" + ver);

                updTable(keyId);
            }
    	}
    }

    /*
     * 更新処理
     */
    private static void updTable(String keyId)
    {
        DynamoDBMapper mapper = new DynamoDBMapper(client);
        Updtest updTest= new Updtest();

		try {
	        updTest.setKeyId(keyId);
	        updTest.setProcessID(PID);
	        // 現在日時を取得
	        LocalDateTime d = LocalDateTime.now();
			DateTimeFormatter df = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss.SSS");
			updTest.setLastUpdate(df.format(d));

	        mapper.save(updTest);
            // 更新ログ出力
            logger.info("UPDATA - " + updTest.getKeyId() + ":" + updTest.getProcessID() + ":" + updTest.getLastUpdate() + ":" + updTest.getVersion());
        } catch (Exception e) {
            logger.info("SYSTEM ERROR - " + e.getMessage());
        }
    }

    /*
     * 条件指定検索
    private static void scan(String condName, ComparisonOperator ope, String val) {
        Condition scanFilterCondition = new Condition()
        			.withComparisonOperator(ope)
    				.withAttributeValueList(new AttributeValue()
            		.withN(val));

        Map<String, Condition> conditions = new HashMap<String, Condition>();
        conditions.put(condName, scanFilterCondition);
        ScanRequest scanRequest = new ScanRequest().withTableName(TABLE_NAME).withScanFilter(conditions);
        ScanResult result = client.scan(scanRequest);

        for (Map<String, AttributeValue> item : result.getItems()) {
            //printItem(item);
        }
    }
*/

    /*
     * 取得データをログ出力
	private static void outputItem(Map<String, AttributeValue> attributeList) {
        //System.out.println("ITEM:");
        for (Map.Entry<String, AttributeValue> item : attributeList.entrySet()) {
            String attributeName = item.getKey();
            AttributeValue value = item.getValue();

            logger.info(new StringBuilder("DATA - ").append(attributeName + " "
                    + (value.getS() == null ? "" : "S=[" + value.getS() + "]")
                    + (value.getN() == null ? "" : "N=[" + value.getN() + "]")
                    + (value.getB() == null ? "" : "B=[" + value.getB() + "]")
                    + (value.getSS() == null ? "" : "SS=[" + value.getSS() + "]")
                    + (value.getNS() == null ? "" : "NS=[" + value.getNS() + "]")
                    + (value.getBS() == null ? "" : "BS=[" + value.getBS() + "] n"))
            		.toString());
        }
    }
*/
}
