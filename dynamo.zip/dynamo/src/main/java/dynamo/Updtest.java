package dynamo;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBAttribute;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBVersionAttribute;

@DynamoDBTable(tableName="Updtest")
public class Updtest {
    private String keyId;
    private String processID;
    private String lastUpdate;
    private Long version;

    @DynamoDBHashKey(attributeName="KeyId")
    public String getKeyId() { return keyId;}
    public void setKeyId(String keyId) {this.keyId = keyId;}

    @DynamoDBAttribute(attributeName = "ProcessID")
    public String getProcessID() { return processID;}
    public void setProcessID(String processID) {this.processID = processID;}

    @DynamoDBAttribute(attributeName = "LastUpdate")
    public String getLastUpdate() { return lastUpdate;}
    public void setLastUpdate(String lastUpdate) {this.lastUpdate = lastUpdate;}

    @DynamoDBVersionAttribute
    public Long getVersion() { return version; }
    public void setVersion(Long version) { this.version = version;}
}
