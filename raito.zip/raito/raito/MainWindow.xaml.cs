﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
using System.IO.Compression;

namespace raito
{
    /// <summary>MainWindow.xaml の相互作用ロジック</summary>
    public partial class MainWindow : Window
    {
        static object lockObject = new object();

        public MainWindow()
        {
            InitializeComponent();
        }

        private int eventCount = 0;
        private static readonly ManualResetEvent waitEvent = new ManualResetEvent(true);
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.eventCount += 1;
            //try
            //{
            //    //Monitor.Enter(sender, ref lockTaken); // ロック取得
            //    //if(!flg)
            //    //lock (e)
            //    //{
            //        Console.WriteLine(this.eventCount + ":EventsBegin");
            //        //waitEvent.WaitOne();
            //        //waitEvent.Reset();
            //    //}
            //    Console.WriteLine(this.eventCount + ":EventsLock");
            //    lock_test(this.eventCount, lockObject);
            //    Console.WriteLine(this.eventCount + ":WaitEnd");


            //}
            //finally
            //{
            //    Console.WriteLine(this.eventCount + ":Finally");
            //    //if (lockTaken)
            //    //Monitor.Exit(sender); // ロック解放
            //}


            Thread thdA = new Thread(new ParameterizedThreadStart(threadFunc));
            Thread thdB = new Thread(new ParameterizedThreadStart(threadFunc));

            thdA.Start((Object)"スレッドA");
            thdB.Start((Object)"スレッドB");
        }

        private void lock_test(int cnt, object obj)
        {

            //flg = true;
            //lock (lockObject)
            //{
            //    waitEvent.WaitOne();
            //    waitEvent.Reset();
            //}

            //    Console.WriteLine(cnt + ":Begin");
            //    for (int i = 0; i < 2000; i++)
            //    {
            //        DoEvents();
            //    }
            //    Console.WriteLine(cnt + ":End");
            ////}
            //flg = false;
            //waitEvent.Set();
        }

        private int count = 0;
        private void threadFunc(Object param)
        {
            String thdName = (String)param;
            Console.WriteLine(thdName + ":thdName1");

            lock (lockObject)
            {
                Console.WriteLine(thdName + ":thdName2");
                waitEvent.WaitOne();//シグナル状態になるまで待機
                waitEvent.Reset();//非シグナル状態にセット。他のスレッドがWaitOne()で待機になる。
            }
            Console.WriteLine(thdName + ":thdName3");

            for (int i = 0; i < 1000; i++)
            {
                Console.WriteLine("スレッド：{0}、カウント値：{1}", thdName, count);
                count++;
            }

            waitEvent.Set();//他スレッドの待機状態を解除。シグナル状態にセットする。
        }
    }
}
