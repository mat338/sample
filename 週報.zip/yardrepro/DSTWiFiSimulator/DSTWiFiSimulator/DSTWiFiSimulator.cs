﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DSTWiFiSimulator
{
    public partial class DSTWiFiSimulator : Form
    {

        Dictionary<string, Task> taskList = new Dictionary<string, Task>();

        IniFile ini;

        /// <summary>
        /// Simulator設定リクエスト構造体
        /// </summary>
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
        public struct SimulatorSettingRequest
        {
            /// <summary>
            /// 機能 0:IPアドレスリスト取得 1:InIの更新　2:サーバ開始 3:サーバ停止
            /// </summary>
            public byte function;
            /// <summary>
            /// セクション64バイト
            /// </summary>
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 64)]
            public string section;
            /// <summary>
            /// パラメータキー64バイト
            /// </summary>
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 64)]
            public string key;
            /// <summary>
            /// パラメータ値データ2048バイト
            /// </summary>
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 5120)]
            public string value;
        }

        /// <summary>
        /// Simulator設定レスポンス構造体
        /// </summary>
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
        public struct SimulatorSettingResponse
        {
            /// <summary>
            /// 実行結果 0:正常
            /// </summary>
            public byte status;
            /// <summary>
            /// アドレスリスト128バイト
            /// </summary>
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)]
            public string addressList;
        }

        [System.Runtime.InteropServices.DllImport("kernel32.dll")] // この行を追加
        private static extern bool AllocConsole();                 // この行を追加  

        private int statusbar = 0;

        public DSTWiFiSimulator()
        {
            InitializeComponent();

            trackBar1.Minimum = 0;
            trackBar1.Maximum = 100;

            ini = new IniFile("./DSTWiFiSimulator.ini");
            foreach (string dst in ini["DST_LIST", "DST"].Split(','))
            {
                cnbDSTSelect.Items.Add(dst);
                //    ini["DST_" + dst, "Status"] = textStatus.Text;
                //    ini["DST_" + dst, "Vin"] = textVin.Text;
                //    ini["DST_" + dst, "SoftBefore"] = textSoftBefore.Text;
                //    ini["DST_" + dst, "SoftAfter"] = textSoftAfter.Text;
                //    ini["DST_" + dst, "Retry"] = textRetry.Text;
                //    ini["DST_" + dst, "DtcExec"] = textDtcExec.Text;
                //    ini["DST_" + dst, "DtcExecSleep"] = textDtcExecSleep.Text;
                //    int s = textDtcExecLog.Text.Length;
                //    ini["DST_" + dst, "DtcExecLog"] = textDtcExecLog.Text;
            }
            cnbDSTSelect.SelectedIndex = 0;

            comboBox1.SelectedIndex = 0;
            AllocConsole();

            // UDPサーバ開始
            foreach (string dst in ini["DST_LIST", "DST"].Split(','))
            {
                var task = Task.Run(() =>
                {
                    UpdServer(dst);
                });
                taskList.Add(dst, task);
            }

            var iniUpdateServerTask = Task.Run(() =>
            {
                UpdIniUpdateServer();
            });
        }

        private void cnbDSTSelect_SelectedIndexChanged(object sender, EventArgs e)
        {
            textSerialNo.Text = ini["DST_" + cnbDSTSelect.SelectedItem, "SerialNo"];
            textWifiinfo.Text = ini["DST_" + cnbDSTSelect.SelectedItem, "Wifiinfo"];
            textStatus.Text = ini["DST_" + cnbDSTSelect.SelectedItem, "Status"];
            textVin.Text = ini["DST_" + cnbDSTSelect.SelectedItem, "Vin"];
            textSoftBefore.Text = ini["DST_" + cnbDSTSelect.SelectedItem, "SoftBefore"];
            textSoftAfter.Text = ini["DST_" + cnbDSTSelect.SelectedItem, "SoftAfter"];
            textRetry.Text = ini["DST_" + cnbDSTSelect.SelectedItem, "Retry"];
            textSeed.Text = ini["DST_" + cnbDSTSelect.SelectedItem, "Seed"];
            textKeySend.Text = ini["DST_" + cnbDSTSelect.SelectedItem, "KeySend"];
            textDtcExec.Text = ini["DST_" + cnbDSTSelect.SelectedItem, "DtcExec"];
            textDtcExecSleep.Text = ini["DST_" + cnbDSTSelect.SelectedItem, "DtcExecSleep"];
            textDtcExecLog.Text = ini["DST_" + cnbDSTSelect.SelectedItem, "DtcExecLog"];
        }

        private void textSerialNo_TextChanged(object sender, EventArgs e)
        {
            byte[] data = System.Text.Encoding.ASCII.GetBytes(textSerialNo.Text);
            string serialNoDump = BitConverter.ToString(data).Replace("-", string.Empty).PadRight(33).Replace(" ", "0");
            textWifiinfo.Text = "03A40000000000000450FF50" + serialNoDump + "0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000";
            ini["DST_" + cnbDSTSelect.SelectedItem, "SerialNo"] = textSerialNo.Text;
        }

        private void textWifiinfo_TextChanged(object sender, EventArgs e)
        {
            ini["DST_" + cnbDSTSelect.SelectedItem, "Wifiinfo"] = textWifiinfo.Text;
        }

        private void textStatus_TextChanged(object sender, EventArgs e)
        {
            ini["DST_" + cnbDSTSelect.SelectedItem, "Status"] = textStatus.Text;
        }

        private void textVin_TextChanged(object sender, EventArgs e)
        {
            ini["DST_" + cnbDSTSelect.SelectedItem, "Vin"] = textVin.Text;
        }

        private void textSoftBefore_TextChanged(object sender, EventArgs e)
        {
            ini["DST_" + cnbDSTSelect.SelectedItem, "SoftBefore"] = textSoftBefore.Text;
        }

        private void textSoftAfter_TextChanged(object sender, EventArgs e)
        {
            ini["DST_" + cnbDSTSelect.SelectedItem, "SoftAfter"] = textSoftAfter.Text;
        }

        private void textRetry_TextChanged(object sender, EventArgs e)
        {
            ini["DST_" + cnbDSTSelect.SelectedItem, "Retry"] = textRetry.Text;
        }

        private void textSeed_TextChanged(object sender, EventArgs e)
        {
            ini["DST_" + cnbDSTSelect.SelectedItem, "Seed"] = textSeed.Text;
        }

        private void textKeySend_TextChanged(object sender, EventArgs e)
        {
            ini["DST_" + cnbDSTSelect.SelectedItem, "KeySend"] = textKeySend.Text;
        }

        private void textDtcExec_TextChanged(object sender, EventArgs e)
        {
            ini["DST_" + cnbDSTSelect.SelectedItem, "DtcExec"] = textDtcExec.Text;
        }

        private void textDtcExecSleep_TextChanged(object sender, EventArgs e)
        {
            ini["DST_" + cnbDSTSelect.SelectedItem, "DtcExecSleep"] = textDtcExecSleep.Text;
        }

        private void textDtcExecLog_TextChanged(object sender, EventArgs e)
        {
            ini["DST_" + cnbDSTSelect.SelectedItem, "DtcExecLog"] = textDtcExecLog.Text;
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            statusbar = trackBar1.Value;
            lblStatus.Text = trackBar1.Value.ToString() + "%";
            textStatus.Text = "11040000000000" + BitConverter.ToString(BitConverter.GetBytes(trackBar1.Value)).Replace("-", string.Empty);
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string resultcode = BitConverter.ToString(BitConverter.GetBytes(comboBox1.SelectedIndex)).Replace("-", string.Empty);
            textStatus.Text = "110400" + resultcode + "00000000";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string selectip = (string)cnbDSTSelect.SelectedItem;
            Task task = taskList[selectip];
            if(task == null)
            {
                var newtask = Task.Run(() =>
                {
                    UpdServer(selectip);
                });
                taskList[selectip] = newtask;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Task task = taskList[(string)cnbDSTSelect.SelectedItem];
            UpdServerStop((string)cnbDSTSelect.SelectedItem);
            task.Wait();
            taskList[(string)cnbDSTSelect.SelectedItem] = null;
        }


        private void UpdServer(string ipadd)
        {
            //バインドするローカルIPとポート番号
            int localPort = 60701;
            //int localPort = 60703;

            //UdpClientを作成し、ローカルエンドポイントにバインドする
            System.Net.IPEndPoint localEP =
                new System.Net.IPEndPoint(System.Net.IPAddress.Parse(ipadd), localPort);
            System.Net.Sockets.UdpClient udp =
                new System.Net.Sockets.UdpClient(localEP);

            string log;
            int cnt = 0;
            int cntSend = 0;

            Console.WriteLine("サーバ開始:" + ipadd);
            for (;;)
            {
                try
                {
                    //データを受信する
                    System.Net.IPEndPoint remoteEP = null;
                    byte[] rcvBytes = udp.Receive(ref remoteEP);

                    //データを文字列に変換する
                    string rcvMsg = BitConverter.ToString(rcvBytes).Replace("-", string.Empty);

                    //受信したデータと送信者の情報を表示する
                    Console.WriteLine("送信元アドレス:{0}/ポート番号:{1} 受信したデータ:{2}", remoteEP.Address, remoteEP.Port, rcvMsg);

                    //レスポンス
                    byte[] response;
                    switch (rcvBytes[0])
                    {
                        // 2.1. WiFi接続情報読出し
                        case 0x03:
                            Console.WriteLine("WiFi接続情報読出し");
                            Console.WriteLine("rcvBytes size:" + rcvBytes.Length);
                            Console.WriteLine("rcvBytes:" + rcvBytes[0].ToString("X2") + ":" + rcvBytes[1].ToString("X2") + ":" + rcvBytes[2].ToString("X2"));
                            response = FromHexString(ini["DST_" + ipadd, "Wifiinfo"]);
                            break;
                        // 2.2. ステータス取得
                        case 0x11:
                            Console.WriteLine("ステータス取得");
                            Console.WriteLine("rcvBytes size:" + rcvBytes.Length);
                            Console.WriteLine("rcvBytes:" + rcvBytes[0].ToString("X2") + ":" + rcvBytes[1].ToString("X2") + ":" + rcvBytes[2].ToString("X2"));
                            if (ini["DST_" + ipadd, "Status"] == "1104000000000064000000")
                            {
                                statusbar = 100;
                            }
                            response = FromHexString(ini["DST_" + ipadd, "Status"]);
                            //statusbar = trackBar1.Value;//1104000000000064000000
                            Console.WriteLine("response(0x11):" + BitConverter.ToString(response).Replace("-", string.Empty));
                            break;
                        // 2.3. VIN取得
                        case 0x12:
                            Console.WriteLine("VIN取得");
                            Console.WriteLine("rcvBytes size:" + rcvBytes.Length);
                            Console.WriteLine("rcvBytes:" + rcvBytes[0].ToString("X2") + ":" + rcvBytes[1].ToString("X2") + ":" + rcvBytes[2].ToString("X2"));
                            response = FromHexString(ini["DST_" + ipadd, "Vin"]);
                            break;
                        // 2.4. ソフト品番取得
                        case 0x13:
                            Console.WriteLine("ソフト品番取得");
                            Console.WriteLine("rcvBytes size:" + rcvBytes.Length);
                            Console.WriteLine("rcvBytes:" + rcvBytes[0].ToString("X2") + ":" + rcvBytes[1].ToString("X2") + ":" + rcvBytes[2].ToString("X2"));
                            string softNo;
                            if (statusbar != 100)
                            {
                                softNo = ini["DST_" + ipadd, "SoftBefore"];
                            }
                            else
                            {
                                softNo = ini["DST_" + ipadd, "SoftAfter"];
                            }

                            //byte[] res = FromHexString(softNo);
                            if ((softNo.Length / 2) > 512)
                            {
                                response = FromHexString(softNo.Substring(0, 512 * 2));
                                Console.WriteLine("SoftNo_512_Over");
                                Console.WriteLine("送信先アドレス:{0}/ポート番号:{1} 送信するデータ:{2}", 
                                    remoteEP.Address, remoteEP.Port, BitConverter.ToString(response).Replace("-", string.Empty));
                                udp.Send(response, response.Length, remoteEP.Address.ToString(), remoteEP.Port);
                                response = FromHexString(softNo.Substring(512 * 2));
                                Console.WriteLine("response:" + BitConverter.ToString(response).Replace("-", string.Empty));
                            }
                            else
                            {
                                response = FromHexString(softNo);
                            }
                            //response = FromHexString(softNo);

                            break;
                        // 2.5. リトライ要求
                        case 0x14:
                            Console.WriteLine("リトライ要求");
                            Console.WriteLine("rcvBytes size:" + rcvBytes.Length);
                            Console.WriteLine("rcvBytes:" + rcvBytes[0].ToString("X2") + ":" + rcvBytes[1].ToString("X2") + ":" + rcvBytes[2].ToString("X2"));
                            response = FromHexString(ini["DST_" + ipadd, "Retry"]);
                            break;
                        // 2.6. 後処理開始
                        case 0x15:
                            Console.WriteLine("後処理開始");
                            Console.WriteLine("rcvBytes size:" + rcvBytes.Length);
                            Console.WriteLine("rcvBytes:" + rcvBytes[0].ToString("X2") + ":" + rcvBytes[1].ToString("X2") + ":" + rcvBytes[2].ToString("X2"));
                            response = FromHexString(ini["DST_" + ipadd, "DtcExec"]);
                            System.Threading.Thread.Sleep(5000);
                            int sleepTime = 0;
                            if(int.TryParse(ini["DST_" + ipadd, "DtcExecSleep"], out sleepTime))
                            {
                                System.Threading.Thread.Sleep(sleepTime);
                            }

                            cnt = 0;
                            Console.WriteLine("response(0x15):" + BitConverter.ToString(response).Replace("-", string.Empty));
                            break;
                        // 2.7. ログファイル取得
                        case 0x16:
                            Console.WriteLine("ログファイル取得");
                            Console.WriteLine("rcvBytes size:" + rcvBytes.Length);
                            Console.WriteLine("rcvBytes:" + rcvBytes[0].ToString("X2") + ":" + rcvBytes[1].ToString("X2") + ":" + rcvBytes[2].ToString("X2") + ":" + rcvBytes[3].ToString("X2"));
                            log = ini["DST_" + ipadd, "DtcExecLog"];
                            if (rcvBytes[3] != 0x00)
                            {
                                cnt = 0;
                            }
                            cntSend = Convert.ToInt32(Math.Ceiling((double)log.Length / (512 * 2)));
                            Console.WriteLine("log.Length:" + log.Length);
                            Console.WriteLine("DTC_LOG_cntSend:" + cntSend);

                            Console.WriteLine("DTC_LOG_cnt:" + cnt);
                            if (cntSend - 1 > cnt)
                            {
                                response = FromHexString(log.Substring(cnt * (512 * 2), (512 * 2)));
                            }
                            else
                            {
                                response = FromHexString(log.Substring(cnt * (512 * 2)));
                            }

                            if (cntSend == cnt)
                            {
                                cnt = 0;
                            }
                            else
                            {
                                cnt++;
                            }
                            System.Threading.Thread.Sleep(900);
                            break;
                        // 2.8. 後処理ステータス取得
                        case 0x17:
                            Console.WriteLine("後処理ステータス取得");
                            Console.WriteLine("rcvBytes size:" + rcvBytes.Length);
                            Console.WriteLine("rcvBytes:" + rcvBytes[0].ToString("X2") + ":" + rcvBytes[1].ToString("X2") + ":" + rcvBytes[2].ToString("X2"));
                            response = FromHexString(ini["DST_" + ipadd, "DtcExecStatus"]);
                            break;
                        // 2.9. Seed取得
                        case 0x18:
                            Console.WriteLine("Seed取得");
                            Console.WriteLine("rcvBytes size:" + rcvBytes.Length);
                            Console.WriteLine("rcvBytes:" + rcvBytes[0].ToString("X2") + ":" + rcvBytes[1].ToString("X2") + ":" + rcvBytes[2].ToString("X2"));
                            response = FromHexString(ini["DST_" + ipadd, "Seed"]);
                            break;
                        // 2.10. Key送信
                        case 0x19:
                            Console.WriteLine("Key送信");
                            Console.WriteLine("rcvBytes size:" + rcvBytes.Length);
                            Console.WriteLine("rcvBytes:" + rcvBytes[0].ToString("X2") + ":" + rcvBytes[1].ToString("X2") + ":" + rcvBytes[2].ToString("X2") + ":" + rcvBytes[3].ToString("X2"));
                            response = FromHexString(ini["DST_" + ipadd, "KeySend"]);
                            break;
                        // その他
                        default:
                            Console.WriteLine("その他");
                            response = new byte[] { 0x00 };
                            break;

                    }
                    Console.WriteLine("送信先アドレス:{0}/ポート番号:{1} 送信するデータ:{2}", 
                        remoteEP.Address, remoteEP.Port, BitConverter.ToString(response).Replace("-", string.Empty));
                    udp.Send(response, response.Length, remoteEP.Address.ToString(), remoteEP.Port);

                    //"cancel"を受信したら終了
                    if (rcvMsg.Equals("65786974"))
                    {
                        break;
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
                finally
                {
                }
            }

            //UdpClientを閉じる
            udp.Close();

            Console.WriteLine("サーバ停止:" + ipadd);
        }

        private void UpdServerStop(string ipadd)
        {
            //データを送信するリモートホストとポート番号
            string remoteHost = ipadd;
            int remotePort = 60701;

            //UdpClientオブジェクトを作成する
            System.Net.Sockets.UdpClient udp =
                new System.Net.Sockets.UdpClient();

            //送信するデータを作成する
            string sendMsg = "exit";
            byte[] sendBytes = System.Text.Encoding.UTF8.GetBytes(sendMsg);

            //リモートホストを指定してデータを送信する
            udp.Send(sendBytes, sendBytes.Length, remoteHost, remotePort);

            System.IO.MemoryStream memory = new System.IO.MemoryStream();

            byte[] buffBytes;

            // 受信
            // UDPではアプリが意図的に分割しない限りデータは分割されない
            System.Net.IPEndPoint remoteEP = null;
            buffBytes = udp.Receive(ref remoteEP);
            memory.Write(buffBytes, 0, buffBytes.Length);
            //UdpClientを閉じる
            udp.Close();
        }

        /// <summary>
        /// 16進数の文字列からバイト配列を生成します。
        /// </summary>
        /// <param name="str">16進数文字列</param>
        /// <returns>バイト配列</returns>
        public static byte[] FromHexString(string str)
        {
//Console.WriteLine("str:" + str);
//Console.WriteLine("str.Length:" + str.Length);

            int length = str.Length / 2;
//Console.WriteLine("length:" + length);
            byte[] bytes = new byte[length];
            int j = 0;
            for (int i = 0; i < length; i++)
            {
                bytes[i] = Convert.ToByte(str.Substring(j, 2), 16);
                j += 2;
            }
//Console.WriteLine("bytes:" + bytes.Length);
            return bytes;
        }



        private void UpdIniUpdateServer()
        {
            //バインドするローカルIPとポート番号
            int localPort = 60801;

            //UdpClientを作成し、ローカルエンドポイントにバインドする
            System.Net.IPEndPoint localEP =
                new System.Net.IPEndPoint(System.Net.IPAddress.Any, localPort);
            System.Net.Sockets.UdpClient udp =
                new System.Net.Sockets.UdpClient(localEP);

            Console.WriteLine("IniUPdateサーバ開始:" + localEP.Address);
            for (;;)
            {
                //データを受信する
                System.Net.IPEndPoint remoteEP = null;
                byte[] rcvBytes = udp.Receive(ref remoteEP);

                SimulatorSettingRequest ret = new SimulatorSettingRequest();
                GCHandle gch = GCHandle.Alloc(rcvBytes, GCHandleType.Pinned);
                ret = (SimulatorSettingRequest)Marshal.PtrToStructure(gch.AddrOfPinnedObject(), typeof(SimulatorSettingRequest));
                gch.Free();

                //受信したデータと送信者の情報を表示する
                Console.WriteLine("送信元アドレス:{0}/ポート番号:{1} 受信したデータ:[func:{2} section:{3} key:{4} value:{5}]", remoteEP.Address, remoteEP.Port, ret.function, ret.section, ret.key, ret.value);

                //"cancel"を受信したら終了
                if (ret.section.Equals("cancel"))
                {
                    break;
                }

                SimulatorSettingResponse res = new SimulatorSettingResponse();
                res.status = 1;
                res.addressList = "";

                switch (rcvBytes[0])
                {
                    case 0:
                        // IPアドレスリストを返却
                        res.status = 0;
                        res.addressList = ini["DST_LIST", "DST"];
                        break;

                    case 1:
                        // INIファイル更新
                        res.status = 0;
                        ini["DST_" + ret.section, ret.key] = ret.value;
                        break;

                    case 2:
                        // 開始
                        string selectip = ret.section;
                        Task task = taskList[selectip];
                        if (task == null)
                        {
                            var newtask = Task.Run(() =>
                            {
                                UpdServer(selectip);
                            });
                            taskList[selectip] = newtask;
                        }
                        res.status = 0;
                        break;

                    case 3:
                        // 停止
                        Task taskstop = taskList[ret.section];
                        UpdServerStop(ret.section);
                        taskstop.Wait();
                        taskList[ret.section] = null;
                        res.status = 0;
                        break;

                    default:
                        break;
                }

                byte[] response = new byte[Marshal.SizeOf(res)];
                GCHandle gchres = GCHandle.Alloc(response, GCHandleType.Pinned);
                Marshal.StructureToPtr(res, gchres.AddrOfPinnedObject(), false);
                gchres.Free();


                //レスポンス
                Console.WriteLine("送信先アドレス:{0}/ポート番号:{1} 送信するデータ:{2}", remoteEP.Address, remoteEP.Port, BitConverter.ToString(response).Replace("-", string.Empty));
                udp.Send(response, response.Length, remoteEP.Address.ToString(), remoteEP.Port);

            }

            //UdpClientを閉じる
            udp.Close();

            Console.WriteLine("IniUPdateサーバ停止:" + localEP.Address);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            udpIniUpdateSend("localhost", byte.Parse(textBox4.Text), textBox1.Text, textBox2.Text, textBox3.Text);
        }

        private void udpIniUpdateSend(string sendAddres, byte func, string section, string key, string value)
        {
            SimulatorSettingRequest senddata = new SimulatorSettingRequest();
            senddata.function = func;
            senddata.section = section;
            senddata.key = key;
            senddata.value = value;

            byte[] bytes = new byte[Marshal.SizeOf(senddata)];
            GCHandle gch = GCHandle.Alloc(bytes, GCHandleType.Pinned);
            Marshal.StructureToPtr(senddata, gch.AddrOfPinnedObject(), false);
            gch.Free();

            //UdpClientオブジェクトを作成する
            using (System.Net.Sockets.UdpClient udp = new System.Net.Sockets.UdpClient())
            {
                //リモートホストを指定してデータを送信する
                udp.Send(bytes, bytes.Length, sendAddres, 60801);
                // 受信
                System.Net.IPEndPoint remoteEP = null;
                byte[] buffBytes = udp.Receive(ref remoteEP);
            }
        }
    }
}
