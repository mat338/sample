﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using NLog;
using System.Collections;
using System.Threading;
using YardRepro.dto;
using System.Threading.Tasks;
using System.IO;
using System.Text;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Reflection;
using SHDocVw;

namespace YardRepro
{
    /// <summary>
    /// DSTステータスリストユーザコントロールクラス
    /// </summary>
    public partial class DSTStatusList : UserControl
    {

        /// <summary>
        /// ログ出力クラス
        /// </summary>
        private static readonly Logger log = LogManager.GetCurrentClassLogger();

        /// <summary>
        /// 定期リフレッシュ停止フラグ
        /// </summary>
        public bool isStop { get; set; }

        /// <summary>
        /// トライアルフラグ
        /// </summary>
        public bool isTrial { get; set; }

        /// <summary>
        /// iniファイル定義タイムアウト値
        /// </summary>
        public int iniTimeout { get; set; }

        /// <summary>
        /// iniファイル定義ログファイル保存先
        /// </summary>
        public string iniSaveFolder { get; set; }

        /// <summary>
        /// iniファイル定義認証URL
        /// </summary>
        public string iniAuthURL { get; set; }

        /// <summary>
        /// WlanClient
        /// </summary>
        private WLANClient client = null;

        /// <summary>
        /// タスクリスト
        /// </summary>
        private List<StatusTask> tasks;

        /// <summary>
        /// タスクファクトリ
        /// </summary>
        private TaskFactory factory;

        /// <summary>
        /// DSTステータスリストデータ
        /// </summary>
        public DSTDtoList list
        {
            get { return dsTiListWPF1.DstiList; }
            set { dsTiListWPF1.DstiList = value; }
        }

        /// <summary>
        /// リスト更新イベント
        /// </summary>
        public event EventHandler OnRefreshList;

        /// <summary>
        /// コンストラクタ
        /// </summary>
        /// ### 機能説明 #######
        /// -# 画面コンポーネントの初期処理
        /// -# DSTステータスリストコントロールのリトライ押下イベントにリトライ押下イベントメソッドを追加
        /// -# DSTステータスリストコントロールのDTC消去押下イベントにDTC消去押下イベントメソッドを追加
        /// -# ステータスタスクリストを初期化
        /// -# タスクファクトリを初期化
        public DSTStatusList()
        {
            InitializeComponent();
            dsTiListWPF1.RetryClick += new EventHandler(dsTiListWPF1_RetryClick);
            dsTiListWPF1.DtcExecClick += new EventHandler(dsTiListWPF1_DtcExecClick);

            tasks = new List<StatusTask>();
            factory = new TaskFactory();
        }

        /// <summary>
        /// リプロ鍵署名要求タスクキャンセルオブジェクト
        /// </summary>
        private CancellationTokenSource cancelSignature;

        /// <summary>
        /// リプロ鍵署名要求タスク
        /// </summary>
        private Task taskSignature;

        private SHDocVw.InternetExplorer IELow;
        private SHDocVw.InternetExplorerMedium IEMed;

        /// <summary>
        /// 初期処理
        /// </summary>
        /// <returns>エラー情報</returns>
        /// ### 機能説明 #######
        /// -# WLANClientのLAN AutoConfigサービス起動チェックがFalseの場合
        ///     -# エラーメッセージを表示
        ///         項目         | 設定値
        ///         -------------| -------------
        ///         メッセージ   | WLAN AutoConfigが起動されていません。\n設定を確認して再度実行してください。
        ///         ウィンドウ名 | ヤードリプロ
        ///         ボタン       | OKのみ
        ///         アイコン     | エラーアイコン
        ///         
        ///     -# Falseを返却
        /// -# WLANClientを生成
        /// -# WLANClientのWiFiモジュール有無をチェックがFalseの場合
        ///     -# エラーメッセージを表示
        ///         項目         | 設定値
        ///         -------------| -------------
        ///         メッセージ   | ワイヤレスLANが使用できません。\n設定確認して再度実行してください。
        ///         ウィンドウ名 | ヤードリプロ
        ///         ボタン       | OKのみ
        ///         アイコン     | エラーアイコン
        ///         
        ///     -# Falseを返却
        /// -# キャンセルオブジェクトのインスタンス生成
        /// -# リプロ鍵署名要求タスクを生成し実行
        /// -# Trueを返却
        public bool init()
        {
            // LAN AutoConfigサービスが起動している
            if (!WLANClient.IsWLanAutoConfigAlive())
            {
                // エラーメッセージを表示
                MessageBox.Show(Consts.MESSAGE_ERROR_WLAN_SERVICE,
                                this.Text,
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
                return false;
            }

            // WLANClientを生成
            client = new WLANClient();

            // WiFiモジュール有無をチェック
            if (!client.IsWLanInterfaces())
            {
                // エラーメッセージを表示
                MessageBox.Show(Consts.MESSAGE_ERROR_WLAN_NOT,
                               this.Text,
                               MessageBoxButtons.OK,
                               MessageBoxIcon.Error);
                return false;
            }

            // リプロ鍵署名要求処理
            cancelSignature = new CancellationTokenSource();
            taskSignature = Task.Factory.StartNew(() =>
            {
                log.Debug(string.Format("taskStart"));
                taskRequestSignature(cancelSignature.Token);
            });

            return true;
        }

        /// <summary>
        /// DSTDTOリストを全て設定する。
        /// </summary>
        /// <param name="souceList">選択画面で選択したDST情報リスト</param>
        /// ### 機能説明 #######
        /// -# 現在表示しているDSTリストのIP削除
        ///     -# 差替え済みではないIPの場合
        ///         -# 現在表示しているDSTリストのIPが選択画面で選択が外された場合はDSTリストから削除
        /// -# 現在表示しているDSTリストのIP追加
        ///     -# 現在表示しているDSTリストにないIPが選択画面で選択された場合はDSTリストに追加
        public void addAll(DSTDtoList souceList)
        {
            List<string> ipList = list.Select(d => d.ipAddress).ToList();
            //List<string> chkDTCList = new List<string>();

            foreach (string ipaddress in ipList)
            {
                // DTCチェック済みの状態を保持
                //if (list.Cast<DSTDto>().Any(d => d.ipAddress.Equals(ipaddress) && d.isDtcDeleteChecked))
                //{
                //    chkDTCList.Add(ipaddress);
                //}

                // 差替え済みの表示情報は削除対象外
                if (list.Cast<DSTDto>().Any(d => d.ipAddress.Equals(ipaddress) && d.status != DSTDto.StatusMode.Replaced))
                {
                    // 現在表示しているDSTリストのIPが選択画面で選択が外された場合はDSTリストから削除
                    if (!souceList.Cast<DSTDto>().Any(d => d.ipAddress.Equals(ipaddress) && d.isSelected))
                    {
                        // 対象IPのリストを削除
                        delete(ipaddress);
                    }
                }
            }
            // 選択されたDSTを追加する。
            foreach (DSTDto dto in souceList)
            {
                // DTCチェック済みの状態を反映
                //if (chkDTCList.Any(d => d.Equals(dto.ipAddress)))
                //{
                //    dto.isDtcDeleteChecked = true;
                //}

                // 現在表示しているDSTリストにないIPが選択画面で選択された場合はDSTリストに追加
                if (!list.Cast<DSTDto>().Any(d => d.ipAddress.Equals(dto.ipAddress) && d.status != DSTDto.StatusMode.Replaced))
                {
                    // 現表示リストに無い選択IPを追加
                    add(dto);
                    //System.Threading.Thread.Sleep(1000);
                }
            }
        }

        /// <summary>
        /// DSTステータスリストに追加する。（デリゲートメソッド)
        /// </summary>
        /// <param name="dto">追加対象のDST情報</param>
        delegate void DelegateAdd(DSTDto dto);

        /// <summary>
        /// DSTステータスリストに追加する。
        /// </summary>
        /// <param name="dto">追加対象のDST情報</param>
        /// -# 追加対象のDST情報.ソート順に「1：リプロ中＋リプロ開始時刻」
        /// -# DST接続ステータスリストデータに引数.追加対象のDST情報を追加
        /// -# DST接続ステータスリストデータをシリアルNo昇順にソート
        /// -# リスト更新イベントを発生させる
        /// -# リスト表示を更新
        private void add(DSTDto dto)
        {
            // ソート順設定（1：リプロ中＋リプロ開始時刻）
            dto.sortNo = Consts.REPRO_EXEC + DateTime.Now.ToString("yyyyMMddHHmmssfff");
            //log.Debug(string.Format("ソート順:{0}", dto.sortNo));
            // リストに追加
            list.Add(dto);
            // リストをシリアルNo昇順にソート
            ArrayList.Adapter(list).Sort(new DSTListSorter());
            // ステータス更新スレッド開始
            if (!isTrial) taskStart(dto);
            // リスト更新イベントを発生させる
            if (OnRefreshList != null) OnRefreshList(this, EventArgs.Empty);
            // リスト表示を更新
            ItemsRefresh();
        }

        /// <summary>
        /// DSTステータスリストから削除する（デリゲートメソッド）。
        /// </summary>
        /// <param name="ipAddress">削除対象のIPアドレス</param>
        delegate void DelegateDelete(string ipAddress);

        /// <summary>
        /// DSTステータスリストから削除する。
        /// </summary>
        /// <param name="ipAddress">削除対象のIPアドレス</param>
        /// ### 機能説明 #######
        /// -# DSTステータスリスト内の引数と同じIPのDST情報を取得
        /// -# DST情報が取得出来た場合
        ///     -# リストから削除
        ///     -# リスト更新イベントを発生させる
        ///     -# リスト表示を更新
        private void delete(string ipAddress)
        {
            // DSTiリスト中の同じIPのデータを取得
            DSTDto targetDto = (DSTDto)list.Select(d => d).Where(d => d.ipAddress == ipAddress).FirstOrDefault();
            // 取得できた場合
            if (targetDto != null)
            {
                // ステータス更新スレッド停止
                if (!isTrial) taskStop(targetDto);
                // リストから削除
                list.Remove(targetDto);
                // リスト更新イベントを発生させる
                if (OnRefreshList != null) OnRefreshList(this, EventArgs.Empty);
                // リスト表示を更新
                ItemsRefresh();
            }
        }

        /// <summary>
        /// リトライボタンクリックイベント
        /// </summary>
        /// <param name="sender">発生元オブジェクト</param>
        /// <param name="e">イベント引数</param>
        /// ### 機能説明 #######
        /// -# リスト表示を更新
        private void dsTiListWPF1_RetryClick(object sender, EventArgs e)
        {
            ItemsRefresh();
        }

        /// <summary>
        /// DTC実行ボタンクリックイベント
        /// </summary>
        /// <param name="sender">発生元オブジェクト</param>
        /// <param name="e">イベント引数</param>
        /// ### 機能説明 #######
        /// -# リスト表示を更新
        private void dsTiListWPF1_DtcExecClick(object sender, EventArgs e)
        {
            ItemsRefresh();
        }

        /// <summary>
        /// DSTステータスリストコントロールのビューを再作成（デリゲートメソッド）
        /// </summary>
        delegate void DelegateItemsRefresh();

        /// <summary>
        /// DSTステータスリストコントロールのビューを再作成
        /// </summary>
        /// ### 機能説明 #######
        /// -# DSTステータスリストコントロールのビューを再作成
        private void dItemsRefresh()
        {
            dsTiListWPF1.listBox1.Items.Refresh();
        }
        /// <summary>
        /// DSTステータスリストコントロールのビューを再作成
        /// </summary>
        /// ### 機能説明 #######
        /// -# DST接続リストコントロールのビューを再作成をデリゲート実行
        public void ItemsRefresh()
        {
            Invoke((DelegateItemsRefresh)dItemsRefresh);
        }

        /// <summary>
        /// 署名応答取込ダイアログの表示（デリゲートメソッド）
        /// </summary>
        delegate string DelegateOpenFile(string vin);

        /// <summary>
        /// 署名応答取込ダイアログの表示
        /// </summary>
        /// <param name="vin">VIN番号</param>
        /// <returns>署名XMLファイル名</returns>
        /// ### 機能説明 #######
        /// -# OpenFileDialogクラスのインスタンスを生成
        /// 項目                       | 設定値
        /// -------------              | -------------
        /// 初期フォルダ               | ダウンロード
        /// ファイルの種類の選択肢     | XMLファイル(*.xml) *.xml,すべてのファイル(*.*) *.*
        /// ファイルの種類の初期選択   | XMLファイル(*.xml)
        /// ウィンドウタイトル         | VIN番号
        /// フォルダ復元設定           | True
        /// ファイル確認               | True
        /// フォルダ確認               | True
        /// 
        /// -# 取込ダイアログを表示する
        /// -# OKボタンがクリックされた場合
        ///     -# 指定ファイル名を取得
        /// -# ファイル名を返却
        ///
        private string dOpenFile(string vin)
        {
            string fileName = "";

            // OpenFileDialogクラスのインスタンスを生成
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                // OpenFileDialogクラスのインスタンスを設定
                ofd.InitialDirectory = Environment.ExpandEnvironmentVariables(Consts.SIGNATURE_DOWNLOADS_FILEPATH);
                ofd.Filter = Consts.SIGNATURE_XML_FILTER;
                ofd.FilterIndex = 1;
                ofd.Title = vin;
                ofd.RestoreDirectory = true;
                ofd.CheckFileExists = true;
                ofd.CheckPathExists = true;

                Form mainForm = YardReproMain.ActiveForm;
                // ダイアログを表示する
                if (ofd.ShowDialog(mainForm) == DialogResult.OK)
                {
                    // OKボタンがクリックされた場合
                    fileName = ofd.FileName;
                }
            }

            return fileName;
        }

        /// <summary>
        /// 署名応答取込ダイアログの表示
        /// </summary>
        /// ### 機能説明 #######
        /// -# 署名応答取込ダイアログの表示をデリゲート実行
        private void OpenFile(DSTDto dto)
        {
            string fileName = (string)Invoke((DelegateOpenFile)dOpenFile, dto.vinNo);
            dto.signatureFileName = fileName;
        }

        #region "更新スレッド"
        /// <summary>
        /// 更新スレッドタスククラス
        /// </summary>
        private class StatusTask
        {
            /// <summary>
            /// DST情報
            /// </summary>
            public DSTDto dstdto { get; set; }

            /// <summary>
            /// スレッドタスク
            /// </summary>
            public Task task { get; set; }

            /// <summary>
            /// スレッドキャンセルオブジェクト
            /// </summary>
            public CancellationTokenSource cancel { get; set; }
        }

        /// <summary>
        /// スレッドを作成し、更新処理を実行
        /// </summary>
        /// <param name="dto">DST情報</param>
        /// ### 機能説明 #######
        /// -# キャンセルオブジェクトのインスタンス生成
        /// -# タスクを生成し実行
        ///     -# 更新スレッド処理呼び出し
        /// -# 更新スレッドタスククラスのインスタンス生成
        ///         項目            | 設定値
        ///         ----------------| -------------
        ///         DST情報         | 引数.DST情報
        ///         スレッドタスク  | 生成したタスク
        ///         キャンセル      | 生成したキャンセルオブジェクト
        /// 
        /// -# 更新スレッドタスクリストに更新スレッドタスクインスタンスを追加
        private void taskStart(DSTDto dto)
        {
            CancellationTokenSource cts = new CancellationTokenSource();
            StatusTask statusTask = new StatusTask();
            statusTask.dstdto = dto;
            statusTask.cancel = cts;
            Task t = factory.StartNew(obj =>
            {
                this.dtoUpdateStatus((StatusTask)obj);
            }, statusTask, cts.Token);
            statusTask.task = t;
            tasks.Add(statusTask);
        }

        /// <summary>
        /// 指定されたDST情報のスレッドを停止する。
        /// </summary>
        /// <param name="dto">DST情報</param>
        /// ### 機能説明 #######
        /// -# 更新スレッドタスクリストの中から引数.DST情報と同じインスタンスを持っている更新スレッドタスクを取得
        /// -# 更新スレッドタスクのキャンセルオブジェクトのキャンセルを呼ぶ
        /// -# タスクが完了するまで待機
        private void taskStop(DSTDto dto)
        {
            StatusTask task = (StatusTask)tasks.Where(d => d.dstdto.Equals(dto)).FirstOrDefault();
            task.cancel.Cancel();
            task.task.Wait(3000);
        }

        /// <summary>
        /// 全てのスレッドを停止させる。
        /// </summary>
        /// ### 機能説明 #######
        /// -# タスクリストを新規作成
        /// -# 更新スレッドタスクリスト分ループ
        ///     -# 更新スレッドタスクのキャンセルオブジェクトのキャンセルを呼ぶ
        ///     -# タスクリストに更新スレッドタスクのタスクを追加
        /// -# タスクリストのタスクが全て完了するまで待機
        public void taskAllStop()
        {
            List<Task> tasklist = new List<Task>();
            foreach (StatusTask task in tasks)
            {
                task.cancel.Cancel();
                tasklist.Add(task.task);
            }
            Task.WaitAll(tasklist.ToArray(), 3000);
        }

        /// <summary>
        /// 排他ロック用object
        /// </summary>
        private static readonly object _syncLock = new object();
        /// <summary>
        /// 署名要求リスト
        /// </summary>
        private Dictionary<string, DSTDto> requestSignature = new Dictionary<string, DSTDto>();
        /// <summary>
        /// 署名応答リスト
        /// </summary>
        private Dictionary<string, DSTDto> resultSignature = new Dictionary<string, DSTDto>();

        /// <summary>
        /// リプロ鍵署名要求処理
        /// </summary>
        /// <param name="cancelToken">リプロ鍵署名要求スレッドタスクキャンセルオブジェクト</param>
        /// ### 機能説明 #######
        /// -# 接続エラー回数を初期化
        /// -# リプロ鍵署名要求スレッドタスクのキャンセルオブジェクトがキャンセルされるまでループ
        ///     -# リプロ鍵署名要求処理を排他ロック
        ///         -# 署名要求リストに署名要求データが登録されている場合
        ///             -# 署名要求リストに先頭から登録データを抽出
        ///             -# 登録データのステータスを変更
        ///                 項目                | 設定値
        ///                 --------------------| -------------
        ///                 ステータス          | 署名取得実施中
        ///                 
        ///             -# 署名要求リストから署名応答リストに登録データを移動
        ///             
        ///             -# 署名要求HTML生成
        ///             
        ///             -# 署名取得（ブラウザ起動）
        ///             
        ///             -# 取込エラーの回数が3回以上になるまでループ
        ///                 -# 取込ダイアログを表示
        ///                 -# 署名XMLファイルの取込選択がキャンセルされた場合
        ///                     -# ステータスを署名取得キャンセルエラーに変更してループ処理を抜ける
        ///                         項目                | 設定値
        ///                         --------------------| -------------------------
        ///                         ステータス          | 署名取得キャンセルエラー
        ///                         
        ///                 -# 署名XMLファイルの取込選択がされた場合
        ///                     -# 署名XMLファイルから署名の取得
        ///                     -# 署名の取得ができなかった場合
        ///                         -# エラーメッセージを表示
        ///                         -# エラー回数をインクリメント
        ///                         -# エラー回数が３回以上の場合
        ///                             -# ステータスを署名取得キャンセルエラーに変更してループ処理を抜ける
        ///                                 項目                | 設定値
        ///                                 --------------------| -------------------------
        ///                                 ステータス          | 署名取得キャンセルエラー
        ///                     -# 署名の取得ができた場合
        ///                         -# ステータスを署名取得成功に変更してループ処理を抜ける
        ///                             項目                | 設定値
        ///                             --------------------| -------------------------
        ///                             ステータス          | 署名取得キャンセルエラー
        ///                             
        ///             -# 生成した署名要求HTMLの削除
        ///             
        ///             -# 更新したDST情報を署名応答リストに反映
        ///             
        ///             -# API呼び出しで例外が発生した場合
        ///                 -# ステータスを署名取得キャンセルエラーに変更する
        ///                     項目                | 設定値
        ///                     --------------------| -------------------------
        ///                     ステータス          | 署名取得キャンセルエラー
        ///                     
        ///     -# 更新スレッドタスク.キャンセルオブジェクトのスリープ処理を呼ぶ(3000ミリ秒)
        private void taskRequestSignature(CancellationToken cancelToken)
        {
            while (!cancelToken.IsCancellationRequested)
            {
                lock (_syncLock)
                {
                    if (requestSignature.Count > 0)
                    {
                        string vin = "";

                        // 処理対象のVIN取得
                        KeyValuePair<string, DSTDto> dicFirst = requestSignature.First();
                        vin = dicFirst.Key;
                        DSTDto dto = dicFirst.Value;

                        try
                        {
                            // 処理中VIN登録（ステータス変更：署名取得実施中）
                            DSTDtoUtil.updateSignatureExec(dto);
                            resultSignature.Add(vin, dto);
                            // 署名取得処理に入った為、署名要求リストから削除
                            requestSignature.Remove(vin);

                            // 署名要求
                            bool ret = replacementSignatureXML(dto);
                            if (ret)
                            {
                                // 署名応答取込
                                int importErrorCount = 0;
                                while (importErrorCount < 3)
                                {
                                    // 取込ダイアログ表示
                                    OpenFile(dto);

                                    // 署名XML取込
                                    if (string.IsNullOrEmpty(dto.signatureFileName))
                                    {
                                        // キャンセル
                                        DSTDtoUtil.updateSignatureError(dto);
                                        break;
                                    }
                                    else
                                    {
                                        // 署名XML取込
                                        if (!readSignatureXMLFile(dto))
                                        {
                                            // NG
                                            // エラーメッセージを表示
                                            MessageBox.Show(Consts.MESSAGE_ERROR_XML_INPUT,
                                                            Consts.SCREEN_MAIN_TITLE,
                                                            MessageBoxButtons.OK,
                                                            MessageBoxIcon.Error);

                                            importErrorCount++;
                                            if (importErrorCount >= 3)
                                            {
                                                DSTDtoUtil.updateSignatureError(dto);
                                                break;
                                            }
                                        }
                                        else
                                        {
                                            // OK
                                            DSTDtoUtil.updateSignatureSuccess(dto);
                                            break;
                                        }
                                    }
                                }
                            }
                            else
                            {
                                DSTDtoUtil.updateSignatureError(dto);
                            }

                            resultSignature[vin] = dto;
                        }
                        catch (System.ComponentModel.Win32Exception noBrowser)
                        {
                            DSTDtoUtil.updateSignatureError(dto);
                            resultSignature[vin] = dto;
                            if (noBrowser.ErrorCode == -2147467259)
                            {
                                log.Error(string.Format(noBrowser.Message));
                            }
                        }
                        catch (Exception e)
                        {
                            DSTDtoUtil.updateSignatureError(dto);
                            resultSignature[vin] = dto;
                            log.Error(string.Format(e.Message));
                        }
                    }

                    Thread.Sleep(Consts.STATUS_REFRESH_TIME);
                }
            }
        }


        /// <summary>
        /// 指定されたDST情報のスレッドを停止する。
        /// </summary>
        /// <param name="dto">DST情報</param>
        /// ### 機能説明 #######
        /// -# 更新スレッドタスクリストの中から引数.DST情報と同じインスタンスを持っている更新スレッドタスクを取得
        /// -# 更新スレッドタスクのキャンセルオブジェクトのキャンセルを呼ぶ
        /// -# タスクが完了するまで待機
        public void taskRequestSignatureStop()
        {
            cancelSignature.Cancel();
            taskSignature.Wait(3000);
        }

        /// <summary>
        /// 更新スレッド処理
        /// </summary>
        /// <param name="task">更新スレッドタスクインスタンス</param>
        /// ### 機能説明 #######
        /// -# 接続エラー回数を初期化
        /// -# 更新スレッドタスクのキャンセルオブジェクトがキャンセルされるまでループ
        ///     -# 更新スレッドタスク.DST情報.ステータスがエラー以外の場合
        ///     	-# VIN取得処理の呼び出し（更新スレッドタスク）
        ///             -# VINが取得済みかつ前回取得時とは別のVINナンバーの場合
        ///                 -# Wifi接続情報の取得
        ///                 -# 差替え前の情報更新
        ///                     項目                | 設定値
        ///                     --------------------| -------------
        ///                     ステータス          | 差替え済み状態
        ///                     ソート順            | 0：リプロ終了＋リプロ開始時刻
        ///                     活性・非活性フラグ  | False
        ///                 -# 差替え後の情報生成
        ///                     項目                                    | 設定値
        ///                     ----------------------------------------| -------------
        ///                     ステータス                              | アイドル状態
        ///                     電波強度                                | 引数.WIFI接続情報応答データ.電波強度
        ///                     色情報                                  | 引数.WIFI接続情報応答データ.色情報
        ///                     シリアルNo                              | 引数.WIFI接続情報応答データ.シリアルNo
        ///                     ホスト名                                | 引数.WIFI接続情報応答データ.ホスト名
        ///                     IPアドレス                              | 引数.IPアドレス
        ///                     進捗情報                                | 0
        ///                     プログレスバーの色                      | 緑
        ///                     活性・非活性フラグ                      | True
        ///                     選択フラグ                              | False
        ///                     リトライ可能フラグ                      | False
        ///                     DTCステータス                           | DTC未実施
        ///                     VinNo取得済みフラグ                     | False
        ///                     リプロ前ソフトウェア品番取得済みフラグ  | False
        ///                     リプロ後ソフトウェア品番取得済みフラグ  | False
        ///                     DTC消去操作可能フラグ                   | False
        ///                     DTC消去実行チェックフラグ               | False
        ///                     ソート順                                | 1：リプロ実行中＋リプロ開始時刻
        ///                     VIN                                     | VIN取得処理で取得したVIN
        ///                 -# 差替え後のスレッド生成
        ///                 -# 差替え前のスレッド終了
        ///                 
        ///     	-# 更新スレッドタスク.DST情報.リプロ前ソフト品番取得済みフラグが未取得の場合
        ///             -# リプロ前ソフト品番取得処理の呼び出し（更新スレッドタスク）
        ///                 
        ///         -# ステータス取得APIの呼び出し（更新スレッドタスク.DST情報.IPアドレス）
        ///         -# 接続エラー回数を0回に設定
        ///         -# 更新スレッドタスク.DST情報.ステータスがアイドル中またはリプロ実施中、通信切断の場合
        ///             -# 処理結果が正常の場合
        ///                 -# 更新中状態にDST情報を更新する。(ステータス取得API結果.リプロ処理の進捗率)
        ///                     項目                | 設定値
        ///                     --------------------| -------------
        ///                     ステータス          | 更新中状態
        ///                     進捗情報            | ステータス取得API結果.リプロ処理の進捗率
        ///                     メッセージ          | ステータス取得API結果.リプロ処理の進捗率 + "%"
        ///                     活性・非活性フラグ  | True
        ///                     リトライ可能フラグ  | False
        ///                     プログレスバーの色  | 緑
        ///                 
        ///                 -# ステータス取得API結果.リプロ処理の進捗率が100の場合
        ///                     -# リプロ完了状態にDST情報を更新する。
        ///                         項目                  | 設定値
        ///                         ----------------------| -------------
        ///                         ステータス            | 成功状態
        ///                         メッセージ            | 100%
        ///                         リトライ可能フラグ    | False
        ///                         DTC消去操作可能フラグ | True
        ///                 
        ///     	        -# 更新スレッドタスク.DST情報.リプロ後ソフト品番取得済みフラグが未取得かつ更新スレッドタスク.DST情報.ステータスが成功の場合
        ///                     -# リプロ後ソフト品番取得処理の呼び出し（更新スレッドタスク）
        ///                         
        ///             -# 処理結果が正常以外の場合
        ///                 -# エラー状態にDST情報を更新する。(ステータス取得API結果.処理結果)
        ///                      項目                | 設定値
        ///                     --------------------| -------------
        ///                     ステータス          | エラー状態
        ///                     メッセージ          | 下記表の通り
        ///                     リトライ可能フラグ  | 下記表の通り
        ///                     活性・非活性フラグ  | True
        ///         
        ///             -# エラーコードによってリトライ可能フラグとメッセージを設定する
        ///                     エラーコード        | リトライ可能フラグ |メッセージ
        ///                     --------------------| -------------------|--------------
        ///                     1                   | False              |VIN読出し不可
        ///                     2                   | False              |ソフト品番読出し不可
        ///                     3                   | False              |読み出したソフト品番から引きあたるリプロデータがDST-WiFi内に存在しない
        ///                     4                   | True               |リプロ書換え中のエラー
        ///                     5                   | True               |リプロ後のベリファイ時のエラー
        ///                     6                   | True               |バッテリ電圧が11.8V未満
        ///                     8                   | False              |読み出したソフト品番がリプロ後のソフト品番と同一
        ///                     上記以外            | False              |定義されないエラー
        ///         
        ///         -# 更新スレッドタスク.DST情報.DTCステータスがDTC実行中の場合
        ///             -# 後処理開始処理の呼び出し（更新スレッドタスク）
        ///         
        ///         -# 更新スレッドタスク.DST情報.DTCステータスがログファイル取得中の場合
        ///             -# ログファイル取得処理の呼び出し（更新スレッドタスク）
        ///         
        ///         -# API呼び出しで例外が発生した場合
        ///             -# 接続エラー回数をインクリメント
        ///             -# 接続エラー回数が３回以上で更新スレッドタスクのキャンセルオブジェクトがキャンセルされてない場合
        ///                 -# 切断状態にDST情報を更新する。
        ///                     項目                | 設定値
        ///                     --------------------| -------------
        ///                     ステータス          | 未接続状態
        ///                     進捗情報            | 100
        ///                     メッセージ          | 切断されました
        ///                     活性・非活性フラグ  | False
        ///                     リトライ可能フラグ  | False
        ///                     プログレスバーの色  | 赤
        ///                 
        ///                 -# 更新スレッドタスク.DST情報.DTCステータスがDTC実行中の場合
        ///                     -# DTC実行エラー状態にDST情報.DTCステータスを更新する。
        ///                         項目                  | 設定値
        ///                         ----------------------| -------------
        ///                         DTCステータス         | DTC実行エラー状態
        ///                         DTC消去操作可能フラグ | True
        ///                         DTCメッセージ         | DTC実行エラー
        ///                 
        ///                 -# 更新スレッドタスク.DST情報.DTCステータスがログファイル取得中の場合
        ///                     -# ログファイル取得エラー状態にDST情報.DTCステータスを更新する。
        ///                         項目                  | 設定値
        ///                         ----------------------| -------------
        ///                         DTCステータス         | DTC実行エラー状態
        ///                         DTC消去操作可能フラグ | False
        ///                         DTCメッセージ         | DTC実行エラー
        ///                 
        ///     -# 更新スレッドタスクのキャンセルオブジェクトがキャンセルされてない場合
        ///         -# DSTステータスリストコントロールのビューを再作成
        ///         -# 更新スレッドタスク.キャンセルオブジェクトのスリープ処理を呼ぶ(3000ミリ秒)
        private void dtoUpdateStatus(StatusTask task)
        {
            log.Debug(string.Format("start dtoUpdateStatus:SerialNo:{0}", task.dstdto.serialNo));
            // 接続エラー回数初期化
            int connectErrorCount = 0;
            //bool xmlAuthentication = false;    // 認証済み
            while (!task.cancel.IsCancellationRequested)
            {
                try
                {
                    // VIN情報取得
                    // VINを取得することで通信の切断確認とツールの車両差替えが行われたかを判断する
                    string vinNo = getVIN(task);
                    // 接続エラー回数をリセット
                    connectErrorCount = 0;
                    // 取得したvinNoが空の場合は実行結果がエラー
                    if (!string.IsNullOrEmpty(vinNo))
                    {
                        // VINが取得済みかつ前回取得時とは別のVINナンバーの場合はツールの差替え有りと判断する
                        if (!string.IsNullOrEmpty(task.dstdto.vinNo) && task.dstdto.vinNo != vinNo)
                        {
                            // Wifi接続情報取得
                            DSTUtil.WifiConnect wifiConnectInfo = DSTUtil.SendSocketUDPWifiConnectInfo(task.dstdto.ipAddress);
                            if (DSTUtil.ByteToInt(wifiConnectInfo.result) == 0)
                            {
                                // ソート順再設定（0：リプロ終了＋リプロ開始時刻）
                                task.dstdto.sortNo = Consts.REPRO_REPLACED + task.dstdto.sortNo.Substring(1);
                                task.dstdto.isEnabled = false;
                                // リプロツール差替え済みに更新する
                                DSTDtoUtil.updateDtcReplaced(task.dstdto);

                                // 差替え後の情報を初期化
                                DSTDto dto = DSTDtoUtil.createDstiDto(task.dstdto.ipAddress, wifiConnectInfo);
                                dto.vinNo = vinNo;
                                // ソート順設定（1：リプロ中＋リプロ開始時刻）
                                dto.sortNo = Consts.REPRO_EXEC + DateTime.Now.ToString("yyyyMMddHHmmssfff");
                                Invoke((DelegateAdd)add, dto);

                                // 差替え前のスレッドは終了する
                                break;
                            }
                        }
                        else
                        {
                            task.dstdto.vinNo = vinNo;
                        }
                    }

                    // ステータスがエラー以外の場合、ステータス取得処理を行う
                    if (task.dstdto.status != DSTDto.StatusMode.Error)
                    {
                        // リプロ前ソフト品番未取得の場合（リプロが実施されるまでは再取得）
                        if (!task.dstdto.getSoftNoBefore && task.dstdto.status == DSTDto.StatusMode.Idle)
                        {
                            getSoftNoBefore(task);
                        }

                        // ステータスがアイドル中またはリプロ実施中、通信切断の場合は処理を行う
                        if (task.dstdto.status == DSTDto.StatusMode.Idle || task.dstdto.status == DSTDto.StatusMode.Exec
                            || task.dstdto.status == DSTDto.StatusMode.Notconnect)
                        {
                            // ステータス取得
                            DSTUtil.StatusInfo status = DSTUtil.SendSocketUDPStatusInfo(task.dstdto.ipAddress);
                            int result = DSTUtil.ByteToInt(status.result);
                            if (result == 0)
                            {
                                int progress = DSTUtil.ByteToInt(status.progress);
                                // リストを実行中で更新
                                DSTDtoUtil.updateExec(task.dstdto, progress);

                                // リプロ完了
                                if (progress == 100)
                                {
                                    // リストを完了で更新
                                    DSTDtoUtil.updateSuccess(task.dstdto);
                                }

                                // リプロ完了かつリプロ後ソフト品番未取得の場合
                                if (!task.dstdto.getSoftNoAfter && task.dstdto.status == DSTDto.StatusMode.Success)
                                {
                                    getSoftNoAfter(task);
                                }
                            }
                            // ステータス取得時にリプロ鍵認証待ちが発生した場合
                            else if (result == 9)
                            {
                                // Seed取得
                                getSeed(task);
                                if (task.dstdto.getSeedValue)
                                {
                                    if (!requestSignature.ContainsKey(vinNo))
                                    {
                                        // 署名要求リスト登録
                                        requestSignature.Add(vinNo, task.dstdto);
                                    }

                                    // リプロ鍵署名要求処理 完了待機
                                    while (requestSignature.ContainsKey(vinNo) || resultSignature.ContainsKey(vinNo))
                                    {
                                        // リプロ鍵署名要求の処理に入った場合
                                        if (resultSignature.ContainsKey(vinNo))
                                        {
                                            // リプロ鍵署名応答取得成功
                                            if (resultSignature[vinNo].statusSignature == DSTDto.StatusModeSignature.SignatureSuccess)
                                            {
                                                // リプロ鍵署名要求成功
                                                resultSignature.Remove(vinNo);

                                                // 署名送信
                                                DSTUtil.KeySendInfo keySend = DSTUtil.SendSocketUDPKeySendInfo(task.dstdto.ipAddress, task.dstdto.signature);
                                                int resultKeySend = DSTUtil.ByteToInt(keySend.result);
                                                if (resultKeySend == 0)
                                                {
                                                    // 署名認証成功状態にDST情報を更新する
                                                    DSTDtoUtil.updateAuthenticationSuccess(task.dstdto);
                                                }
                                                else
                                                {
                                                    // 署名認証エラー状態にDST情報を更新する
                                                    DSTDtoUtil.updateAuthenticationError(task.dstdto);
                                                }
                                                //log.Debug(task.dstdto.statusSignature);
                                                break;
                                            }
                                            else if (resultSignature[vinNo].statusSignature == DSTDto.StatusModeSignature.SignatureError)
                                            {
                                                // リプロ鍵署名要求エラー
                                                resultSignature.Remove(vinNo);
                                                break;
                                            }
                                            else
                                            {
                                                // 署名取得実施中の場合は何もしない
                                            }
                                        }

                                        Thread.Sleep(100);
                                    }
                                }
                                else
                                {
                                    // Seed取得失敗（成功するまで再取得）
                                }
                            }
                            // 認証エラー以外のエラー
                            else
                            {
                                // ステータスエラー
                                DSTDtoUtil.updateError(task.dstdto, result.ToString());
                            }
                        }

                        // DTC実行中の場合
                        if (task.dstdto.statusDtc == DSTDto.StatusModeDTC.DtcExec)
                        {
                            execDTC(task);
                        }

                        // ログファイル取得中の場合
                        if (task.dstdto.statusDtc == DSTDto.StatusModeDTC.DtcExecLog)
                        {
                            getLogFile(task);
                        }
                    }
                }
                catch (Exception e)
                {
                    log.Error("Error:" + string.Format(e.Message));
                    // 接続エラー回数をインクリメント
                    connectErrorCount++;
                    log.Debug(string.Format("ConnectErrorCount:{0}", connectErrorCount));

                    if (!task.cancel.IsCancellationRequested && (connectErrorCount >= 3))
                    {
                        // 通信切断で更新
                        DSTDtoUtil.updateNotConnect(task.dstdto);

                        // DTC実行中の場合
                        if (task.dstdto.statusDtc == DSTDto.StatusModeDTC.DtcExec)
                        {
                            // DTC実行エラーで更新
                            DSTDtoUtil.updateDtcError(task.dstdto);
                        }

                        // ログファイル取得中の場合
                        if (task.dstdto.statusDtc == DSTDto.StatusModeDTC.DtcExecLog)
                        {
                            // ログファイル取得エラーで更新
                            DSTDtoUtil.updateDtcErrorLog(task.dstdto);
                        }
                    }
                }

                // キャンセルされてない場合
                if (!task.cancel.IsCancellationRequested)
                {
                    // リスト更新
                    ItemsRefresh();
                    // スリープ
                    task.cancel.Token.WaitHandle.WaitOne(Consts.STATUS_REFRESH_TIME);
                }
            }
            log.Debug(string.Format("stop dtoUpdateStatus:SerialNo:{0}", task.dstdto.serialNo));
        }

        /// <summary>
        /// VIN取得処理
        /// </summary>
        /// <param name="task">更新スレッドタスクインスタンス</param>
        /// ### 機能説明 #######
        /// -# VIN取得APIを呼び出し（更新スレッドタスク.DST情報.IPアドレス）
        /// -# 処理結果が正常の場合
        ///     -# 更新スレッドタスク.DST情報.VinNoにVIN取得API.VinNoを設定
        ///         項目                | 設定値
        ///         --------------------| -------------
        ///         VinNo               | VIN取得API.VinNo
        private string getVIN(StatusTask task)
        {
            // VIN取得（ECUからVINを読み出す前に本機能を実施した場合はエラーが返る。）
            DSTUtil.VinInfo vininfo = DSTUtil.SendSocketUDPVinInfo(task.dstdto.ipAddress);
            if (DSTUtil.ByteToInt(vininfo.result) == 0)
            {
                return DSTUtil.ByteToString(vininfo.vin);
            }
            return "";
        }

        /// <summary>
        /// リプロ前ソフト品番取得処理
        /// </summary>
        /// <param name="task">更新スレッドタスクインスタンス</param>
        /// ### 機能説明 #######
        /// -# ソフト品番取得APIを呼び出し（更新スレッドタスク.DST情報.IPアドレス）
        /// -# 処理結果が正常の場合
        ///     -# リプロ前ソフト品番リストを生成
        ///     -# ソフト品番取得API.ソフト品番の数分ループ
        ///         -# リプロ前ソフト品番リストにソフト品番取得API.ソフト品番を追加
        ///     -# 更新スレッドタスク.DST情報.リプロ前ソフト品番リストにソフト品番リストを設定
        ///         項目                             | 設定値
        ///         ---------------------------------| -------------
        ///         リプロ前ソフト品番リスト         | 生成したソフト品番リスト
        ///         
        ///     -# 更新スレッドタスク.DST情報.リプロ前ソフト品番取得済みフラグを取得済みに設定
        ///         項目                             | 設定値
        ///         ---------------------------------| -------------
        ///         リプロ前ソフト品番取得済みフラグ | True
        private void getSoftNoBefore(StatusTask task)
        {
            DSTUtil.SoftNoInfo softnoinfoBefore = DSTUtil.SendSocketUDPSoftNoInfo(task.dstdto.ipAddress);
            if (DSTUtil.ByteToInt(softnoinfoBefore.result) == 0)
            {
                List<string> softNoListBefore = new List<string>();
                for (int i = 0; i < DSTUtil.ByteToInt(softnoinfoBefore.numOfId); i++)
                {
                    softNoListBefore.Add(DSTUtil.ByteToString(softnoinfoBefore.softnoList[i].Softno));
                }
                task.dstdto.softNoBefore = softNoListBefore;
                task.dstdto.getSoftNoBefore = true;
            }
        }

        /// <summary>
        /// リプロ後ソフト品番取得処理
        /// </summary>
        /// <param name="task">更新スレッドタスクインスタンス</param>
        /// ### 機能説明 #######
        /// -# ソフト品番取得APIを呼び出し（更新スレッドタスク.DST情報.IPアドレス）
        /// -# 処理結果が正常の場合
        ///     -# リプロ後ソフト品番リストを生成
        ///     -# ソフト品番取得API.ソフト品番の数分ループ
        ///         -# リプロ後ソフト品番リストにソフト品番取得API.ソフト品番を追加
        ///     -# 更新スレッドタスク.DST情報.リプロ後ソフト品番リストにソフト品番リストを設定
        ///         項目                             | 設定値
        ///         ---------------------------------| -------------
        ///         リプロ後ソフト品番リスト         | 生成したソフト品番リスト
        ///         
        ///     -# 更新スレッドタスク.DST情報.リプロ後ソフト品番取得済みフラグを取得済みに設定
        ///         項目                             | 設定値
        ///         ---------------------------------| -------------
        ///         リプロ後ソフト品番取得済みフラグ | True
        private void getSoftNoAfter(StatusTask task)
        {
            DSTUtil.SoftNoInfo softnoinfoAfter = DSTUtil.SendSocketUDPSoftNoInfo(task.dstdto.ipAddress);
            if (DSTUtil.ByteToInt(softnoinfoAfter.result) == 0)
            {
                List<string> softNoListAfter = new List<string>();
                for (int i = 0; i < DSTUtil.ByteToInt(softnoinfoAfter.numOfId); i++)
                {
                    softNoListAfter.Add(DSTUtil.ByteToString(softnoinfoAfter.softnoList[i].Softno));
                }
                task.dstdto.softNoAfter = softNoListAfter;
            }
            task.dstdto.getSoftNoAfter = true;
        }

        /// <summary>
        /// 後処理開始処理
        /// </summary>
        /// <param name="task">更新スレッドタスクインスタンス</param>
        /// ### 機能説明 #######
        /// -# 後処理開始APIを呼び出し（更新スレッドタスク.DST情報.IPアドレス）
        /// -# 処理結果がエラーの場合
        ///     -# エラーメッセージを表示（DTC消去要求に失敗しました。\nDSTのLEDが全点灯しているか確認してください。）
        ///     -# DTC実行エラー状態にDTC情報を更新する。
        ///         項目                  | 設定値
        ///         ----------------------| -------------
        ///         DTCステータス         | DTC実行エラー状態
        ///         DTC消去操作可能フラグ | True
        ///         DTCメッセージ         | DTC実行エラー
        ///         
        ///     -# ログファイル取得中状態にDTC情報を更新する。
        ///         項目                  | 設定値
        ///         ----------------------| -------------
        ///         DTCステータス         | ログファイル取得中状態
        ///         DTC消去操作可能フラグ | False
        ///         DTCメッセージ         | ログ取得中
        private void execDTC(StatusTask task)
        {
            try
            {
                // DTC消去要求を送信
                DSTUtil.DtcExec dtcExec = DSTUtil.SendSocketUDPDtcExec(task.dstdto.ipAddress, iniTimeout);
                // 実行結果がエラーの場合
                if (DSTUtil.ByteToInt(dtcExec.result) != 0)
                {
                    // エラーメッセージを表示
                    System.Windows.Forms.MessageBox.Show(Consts.MESSAGE_ERROR_DTC_EXEC,
                                    Consts.SCREEN_MAIN_TITLE,
                                    System.Windows.Forms.MessageBoxButtons.OK,
                                    System.Windows.Forms.MessageBoxIcon.Error);
                    // DTC実行エラーで更新
                    DSTDtoUtil.updateDtcError(task.dstdto);
                }
                else
                {
                    // ログファイル取得中状態にDST情報を更新する。
                    DSTDtoUtil.updateDtcExecLog(task.dstdto);
                }
            }
            catch(Exception)
            {
                // DTC実行エラーで更新
                DSTDtoUtil.updateDtcError(task.dstdto);
            }
        }

        /// <summary>
        /// ログファイル取得処理
        /// </summary>
        /// <param name="task">更新スレッドタスクインスタンス</param>
        /// ### 機能説明 #######
        /// -# 取得完了するまでループ
        ///     -# ログファイル取得APIを呼び出し（更新スレッドタスク.DST情報.IPアドレス）
        ///     -# 処理結果がエラーの場合
        ///         -# ログファイル取得エラー状態にDTC情報を更新する。
        ///             項目                  | 設定値
        ///             ----------------------| -------------
        ///             DTCステータス         | ログファイル取得エラー状態
        ///             DTC消去操作可能フラグ | True
        ///             DTCメッセージ         | ログファイル取得エラー
        ///                 
        ///     -# ログファイル取得API.通信ログデータを文字列に変換後、ログデータ文字列に連結して格納
        ///     
        ///     -# ログファイル取得API.残りデータサイズを取得
        ///     -# 残りデータサイズが0の場合
        ///         -# DTC完了で更新状態にDTC情報を更新する。
        ///             項目                  | 設定値
        ///             ----------------------| -------------
        ///             DTCステータス         | DTC完了状態
        ///             DTC消去操作可能フラグ | false
        ///             DTCメッセージ         | DTC完了
        ///         -# 取得完了のためループを抜ける
        ///     
        ///     -# 取得したログファイルのデータを出力する
        ///         項目                  | 設定値
        ///         ----------------------| -------------
        ///         出力先                | 定義ファイル.SAVE_FOLDER \ YardRepro_DTC.log
        private void getLogFile(StatusTask task)
        {
            string logData = "";
            int remainSize = 0;
            bool first = true;
            byte[] paramContinue = { 0x00 };
            byte[] paramFirst = { 0x01 };
            DSTUtil.DtcExecLog dtcExecLog;

            while (true)
            {
                // ログファイル取得要求を送信
                // ログデータを最初から取得
                if(first)
                {
                    dtcExecLog = DSTUtil.SendSocketUDPDtcExecLog(task.dstdto.ipAddress, paramFirst);
                    first = false;
                }
                // ログデータを続きから取得
                else
                {
                    dtcExecLog = DSTUtil.SendSocketUDPDtcExecLog(task.dstdto.ipAddress, paramContinue);
                }
                // 実行結果がエラーの場合
                if (DSTUtil.ByteToInt(dtcExecLog.result) != 0)
                {
                    // ログファイル取得エラーで更新
                    DSTDtoUtil.updateDtcErrorLog(task.dstdto);
                    break;
                }

                // ログデータ格納
                logData += DSTUtil.ByteToString(dtcExecLog.logFileData);

                // 残りデータサイズ
                remainSize = DSTUtil.ByteToInt(dtcExecLog.remainDataSize);
                log.Debug("DTC LOG Remain Data Size: " + remainSize.ToString());

                // 取得完了の場合
                if (remainSize == 0)
                {
                    break;
                }

            }

            try
            {
                if (task.dstdto.statusDtc == DSTDto.StatusModeDTC.DtcExecLog)
                {
                    // ログファイルを保存
                    using (var sw = new System.IO.StreamWriter(iniSaveFolder + Consts.DTC_LOG_FILE_NAME + "_" + task.dstdto.serialNo + "_" +
                                                               DateTime.Now.ToString("yyyyMMddHHmmss") + ".log", false))
                    {
                        // 取得したログデータをそのまま出力
                        sw.WriteLine(logData);
                    }
                    // DTC完了で更新
                    DSTDtoUtil.updateDtcSuccess(task.dstdto);
                }
            }
            catch (Exception e)
            {
                // ログファイル取得エラーで更新
                DSTDtoUtil.updateDtcErrorLog(task.dstdto);
                log.Debug("DTC LOG ERROR: " + e.ToString());
            }
        }

        /// <summary>
        /// Seed取得処理
        /// </summary>
        /// <param name="task">更新スレッドタスクインスタンス</param>
        /// ### 機能説明 #######
        /// -# Seed取得APIを呼び出し（更新スレッドタスク.DST情報.IPアドレス）
        /// -# 処理結果が正常の場合
        ///     -# 更新スレッドタスク.DST情報.seedValueにSeed取得API.seedを設定
        ///         項目                | 設定値
        ///         --------------------| -------------
        ///         seedValue           | Seed取得API.seed
        ///         getSeedValue        | True
        private void getSeed(StatusTask task)
        {
            // Seed取得（ECUからSeedを読み出す前に本機能を実施した場合はエラーが返る。）
            DSTUtil.SeedInfo SeedInfo = DSTUtil.SendSocketUDPSeedInfo(task.dstdto.ipAddress);
            if (DSTUtil.ByteToInt(SeedInfo.result) == 0)
            {
                task.dstdto.seedValue = SeedInfo.seed;
                task.dstdto.getSeedValue = true;
            }
        }

        /// <summary>
        /// 署名要求XML生成処理
        /// </summary>
        /// <param name="task">更新スレッドタスクインスタンス</param>
        /// ### 機能説明 #######
        /// -# 署名要求XML生成
        /// -# IE保護モード判別起動
        /// -# 署名要求XML出力
        /// -# 署名要求XML出力に失敗した場合
        ///     -# エラーメッセージを表示
        private bool replacementSignatureXML(DSTDto dto)
        {
            bool ret = false;
            try
            {
                // IE保護モード判別起動
                IESafeCheckStartup();

                // XML生成
                string xmlData = createSignatureXMLFile(dto);

                // 署名要求XML出力
                ret = writeXML(xmlData, dto.serialNo);

                if (!ret)
                {
                    // エラーメッセージを表示
                    System.Windows.Forms.MessageBox.Show(Consts.MESSAGE_ERROR_XML_OUTPUT,
                                    Consts.SCREEN_MAIN_TITLE,
                                    System.Windows.Forms.MessageBoxButtons.OK,
                                    System.Windows.Forms.MessageBoxIcon.Error);
                }
            }
            catch (Exception e)
            {
                log.Error("Error:" + string.Format(e.Message));
            }

            return ret;
        }

        /// <summary>
        /// IE保護モード判別起動
        /// </summary>
        /// ### 機能説明 #######
        /// -# 保護モードオン用のIEオブジェクトを生成
        /// -# IE読み込み完了まで待機
        ///     -# 指定URLでIE起動
        ///     -# IE読み込み完了の場合
        ///         -# 処理終了
        /// -# 保護モードオン用のIE読み込みチェックで例外が発生した場合
        ///     -# 起動したIEが存在する場合
        ///         -# IEの表示完了の場合
        ///             -# 処理終了
        ///     -# 起動したIEが存在しない場合
        ///         -# 保護モードオフ用のIEオブジェクトを解放
        private void IESafeCheckStartup()
        {
            IELow = new SHDocVw.InternetExplorer(); // 保護モードがオン： 整合性レベルは低(LowIL)
            // IELow用に起動したIEのハンドルを取得
            Int32 IELowHandle = IELow.HWND;

            // URLからインターネット/イントラネットを判別し、IEの保護モード設定から「InternetExplorer/InternetExplorerMedium」のアクセスタイプを判別する
            IELow.Navigate(iniAuthURL);
            IELow.Visible = true;

            try
            {
                // IEの状態監視
                while (true)
                {
                    // 監視は100ms毎
                    Thread.Sleep(100);

                    // 読み込み完了まで待機（保護モードがオフの場合はExceptionが発生しcatch内の処理を行う）
                    if (IELow.ReadyState == SHDocVw.tagREADYSTATE.READYSTATE_COMPLETE && IELow.Busy == false)
                    {
                        // 保護モードがオン
                        return;
                    }
                }
            }
            catch
            {
                // 例外時COMオブジェクトを解放
                System.Runtime.InteropServices.Marshal.ReleaseComObject(IELow);
                IELow = null;

                try
                {
                    // 保護モードがオンの前提でIEを起動したが、保護モードがオフであったためIEMedでIEにアクセスし直す
                    Type ShellAppType = Type.GetTypeFromProgID("Shell.Application");
                    object shell = Activator.CreateInstance(ShellAppType);
                    Object windows = ShellAppType.InvokeMember("Windows", BindingFlags.InvokeMethod, null, shell, null);
                    var varWindows = (SHDocVw.IShellWindows)windows;

                    // 上記で起動したIEが存在するかをチェック
                    foreach (object objWindow in varWindows)
                    {
                        // キャストできない場合はnullを返す
                        object objIE = objWindow;
                        IEMed = objIE as SHDocVw.InternetExplorerMedium;    // 保護モードがオフ：整合性レベルは中(MediumIL)
                        // 「InternetExplorerMedium」にキャスト成功の場合
                        if (IEMed != null)
                        {
                            // IELowチェック時に起動したIEの場合
                            if (string.Equals(Path.GetFileName(IEMed.FullName), "iexplore.exe", StringComparison.CurrentCultureIgnoreCase) &&
                                IEMed.HWND == IELowHandle)
                            {
                                // IEの状態監視
                                while (true)
                                {
                                    // 監視は100ms毎
                                    Thread.Sleep(100);
                                    // 読み込み完了まで待機
                                    if (IEMed.ReadyState == SHDocVw.tagREADYSTATE.READYSTATE_COMPLETE && IEMed.Busy == false)
                                    {
                                        // 保護モードがオフ
                                        return;
                                    }
                                }
                            }
                        }
                    }

                    // 起動ウィンドウのチェックで起動したIEを確認できなかった場合（ユーザーにIEを閉じられてしまった場合）
                    if (IEMed != null)
                    {
                        // 例外時COMオブジェクトを解放
                        System.Runtime.InteropServices.Marshal.ReleaseComObject(IEMed);
                        IEMed = null;
                    }
                }
                catch
                {
                    // 例外時COMオブジェクトを解放
                    if (IEMed != null)
                    {
                        System.Runtime.InteropServices.Marshal.ReleaseComObject(IEMed);
                        IEMed = null;
                    }
                }
            }
        }

        /// <summary>
        /// 署名要求XML生成処理
        /// </summary>
        /// <param name="task">更新スレッドタスクインスタンス</param>
        /// ### 機能説明 #######
        /// -# 署名要求XMLフォーマットファイルの取得
        /// -# 不正ファイルチェック
        ///     チェック項目           | 内容
        ///     -----------------------| -------------
        ///     バージョン             | 項目有無
        ///     ソフトウェアID         | 項目有無
        ///     バージョン             | 項目有無
        ///     ソフトウェアバージョン | 項目有無
        ///     ライセンスキー         | 項目有無
        ///     VIN                    | 項目有無
        ///     要求元種別             | 項目有無
        ///     有線リプロ鍵ID         | 項目有無
        ///     Seed値                 | 項目有無
        /// -# ソフトウェアバージョンの取得
        /// -# ソフトウェアバージョンの差替え
        /// -# VIN値の差替え
        /// -# Seed値を16進数のASCII文字列に変換
        /// -# Seed値差替え
        private string createSignatureXMLFile(DSTDto dto)
        {
            string xmlData = "";

            try
            {
                // 署名要求XMLフォーマットファイルの読込
                using (var sr = new StreamReader(Consts.SIGNATURE_REQUEST_FILEPATH, Encoding.UTF8))
                {
                    xmlData = sr.ReadToEnd();

                    // 不正ファイルチェック
                    if (xmlData.IndexOf("<" + Consts.SIGNATURE_X_VERSION + ">") == -1 ||
                        xmlData.IndexOf("<" + Consts.SIGNATURE_SOFTWARE_ID + ">") == -1 ||
                        xmlData.IndexOf("<" + Consts.SIGNATURE_SOFTWARE_VERSION + ">") == -1 ||
                        xmlData.IndexOf("<" + Consts.SIGNATURE_LICENSE_KEY + ">") == -1 ||
                        xmlData.IndexOf("<" + Consts.SIGNATURE_VIN + ">") == -1 ||
                        xmlData.IndexOf("<" + Consts.SIGNATURE_REQUESTER_KIND + ">") == -1 ||
                        xmlData.IndexOf("<" + Consts.SIGNATURE_KEYPAIR_ID + ">") == -1 ||
                        xmlData.IndexOf("<" + Consts.SIGNATURE_SEED_VALUE + ">") == -1)
                    {
                        return "";
                    }

                    // ソフトウェアバージョン
                    FileVersionInfo ver = FileVersionInfo.GetVersionInfo(Assembly.GetExecutingAssembly().Location);
                    string version = String.Format("{0:00}", ver.ProductMajorPart) + "." + String.Format("{0:00}", ver.ProductMinorPart) + "."
                                   + String.Format("{0:000}", ver.ProductBuildPart);
                    // ソフトウェアバージョン差替え
                    xmlData = xmlData.Replace("[" + Consts.SIGNATURE_SOFTWARE_VERSION + "]", version);

                    // VIN値差替え
                    xmlData = xmlData.Replace("[" + Consts.SIGNATURE_VIN + "]", dto.vinNo);

                    // 取得したSeed値を16進数のASCII文字列に変換
                    string seed = "";
                    byte[] data = dto.seedValue;
                    for (int i = 0; i < data.Length; i++)
                    {
                        // 0x00～0x09までは１桁で変換＆文字列に連結されてしまう為、２桁指定で前0で埋める
                        seed += Convert.ToString(data[i], 16).PadLeft(2, '0');
                    }
                    // Seed値差替え
                    xmlData = xmlData.Replace("[" + Consts.SIGNATURE_SEED_VALUE + "]", seed);
                }
            }
            catch (Exception e)
            {
                log.Error("XML Create ERROR: " + e.ToString());
            }

            log.Debug(xmlData);
            return xmlData;
        }

        /// <summary>
        /// 署名要求XML出力処理
        /// </summary>
        /// <param name="xmlData">XML</param>
        /// <param name="serialNo">シリアルNo</param>
        /// ### 機能説明 #######
        /// -# HTMLドキュメントの読込
        /// -# HTMLドキュメントの読込
        /// -# HTMLドキュメントの読込
        /// -# 「ECUExchangeKey」項目の取得
        /// -# 「ECUExchangeKey」項目が１件も取得できなかった場合
        ///     -# 警告ログの出力（本来は発生しない）
        /// -# 「ECUExchangeKey」項目が取得できた場合
        ///     -# 取得した「ECUExchangeKey」項目数文ループ
        ///         -# 要素の名前が出力対象の場合
        ///             -# HTMLのHidden項目「ECUExchangeKey」にXMLを出力
        ///             -# 出力したXMLを取得
        ///             -# 出力したXMが空の場合（出力失敗の場合）
        ///                 -# エラーログの出力
        private bool writeXML(string xmlData, string serialNo)
        {
            Type mshtml = Type.GetTypeFromProgID("mhtmlfile");
            Object htmlDoc = null;

            // 保護モード別に取得
            if (IELow != null)
            {
                // HTMLドキュメントの取得：保護モードがオン
                htmlDoc = mshtml.InvokeMember("document", BindingFlags.GetProperty, null, IELow, null);
            }
            else if (IEMed != null)
            {
                // HTMLドキュメントの取得：保護モードがオフ
                htmlDoc = mshtml.InvokeMember("document", BindingFlags.GetProperty, null, IEMed, null);
            }
            else
            {
                // 起動したIEがユーザにより閉じられた場合等
                log.Warn(string.Format("Internet Explorer not started:SerialNo:{0}", serialNo));
                return false;
            }

            // 経過時間の計測
            DateTime startDt = DateTime.Now;
            while (true)
            {
                // 要素を取得
                object elementECUExchangeKey = mshtml.InvokeMember("getElementsByName", BindingFlags.InvokeMethod, null, htmlDoc,
                                                                    new object[] { Consts.XML_ELEMENT_NAME });
                int cnt = (int)mshtml.InvokeMember("length", BindingFlags.GetProperty, null, elementECUExchangeKey, null);
                if (cnt == 0)
                {
                    // まだ対象ページが開けていない

                    // 5分経過後エラー
                    DateTime endDt = DateTime.Now;
                    TimeSpan ts = endDt - startDt;      // 時間の差分を取得
                    if (ts.TotalMinutes > 5)
                    {
                        log.Error(string.Format("XML writing failed:SerialNo:{0} - {1}", serialNo, ts.TotalMinutes.ToString()));
                        return false;
                    }
                    // 1秒待機
                    System.Threading.Thread.Sleep(1000);
                }
                else
                {
                    // 要素数分ループする（同じ要素名が複数ないはず：１回だけ処理）
                    for (int i = 0; i < cnt; i++)
                    {
                        // 要素の名前が出力対象の場合
                        object element = mshtml.InvokeMember("item", BindingFlags.InvokeMethod, null, elementECUExchangeKey, new object[] { i });
                        if ((string)mshtml.InvokeMember("name", BindingFlags.GetProperty, null, element, null) == Consts.XML_ELEMENT_NAME)
                        {
                            // HTMLの「ReproKeyRequest」項目にXMLを出力
                            mshtml.InvokeMember("value", BindingFlags.SetProperty, null, element, new object[] { xmlData });

                            // 出力データ取得
                            object WriteObjData = mshtml.InvokeMember("value", BindingFlags.GetProperty, null, element, null);
                            // 取得データが空であれば出力失敗
                            if (WriteObjData.ToString() == string.Empty)
                            {
                                log.Error(string.Format("XML writing failed:SerialNo:{0}", serialNo));
                                return false;
                            }
                            else
                            {
                                log.Debug(string.Format("XML writing success:SerialNo:{0} - " + WriteObjData.ToString(), serialNo));
                            }
                        }
                    }

                    break;
                }
            }

            return true;
        }

        /// <summary>
        /// 署名応答XML取込処理
        /// </summary>
        /// <param name="task">更新スレッドタスクインスタンス</param>
        /// ### 機能説明 #######
        /// -# 署名応答XMLファイルの読込
        ///     -# 抽出開始位置の算出
        ///     -# 抽出終了位置の算出
        ///     
        ///     -# 要素「Signature」が応答XMLファイルに含まれていない場合
        ///         -# 更新スレッドタスク.DST情報.署名ステータスに署名要求エラーを設定
        ///         項目                  | 設定値
        ///         ----------------------| -------------
        ///         署名ステータス        | 署名要求エラー
        ///
        ///     -# 要素「Signature」が応答XMLファイルに含まれている場合
        ///         -# 要素「Signature」の設定値を抽出して更新スレッドタスク.DST情報.署名に設定する
        ///         項目                  | 設定値
        ///         ----------------------| -------------
        ///         署名                  | 署名応答XMLファイルの署名項目設定値
        private Boolean readSignatureXMLFile(DSTDto dto)
        {
            try
            {
                // 署名要求XMLフォーマットファイルの読込
                using (var sr = new StreamReader(dto.signatureFileName, Encoding.UTF8))
                {
                    string xmlData = sr.ReadToEnd();

                    // 応答署名データ抽出
                    int start = xmlData.IndexOf("<" + Consts.SIGNATURE_SIGNATURE + ">") + ("<" + Consts.SIGNATURE_SIGNATURE + ">").Length;
                    int end = xmlData.IndexOf("</" + Consts.SIGNATURE_SIGNATURE + ">");

                    if(start < ("<" + Consts.SIGNATURE_SIGNATURE + ">").Length || end < 0)
                    {
                        return false;
                    }

                    string signasture = xmlData.Substring(start, end - start);
                    var bs = new List<byte>();
                    for (int i = 0; i < signasture.Length; i += 2)
                    {
                        string w = signasture.Substring(i, 2);
                        bs.Add(Convert.ToByte(w, 16));
                    }
                    dto.signature = bs.ToArray();
                }
            }
            catch (Exception e)
            {
                log.Error("Signature XML Read ERROR: " + e.ToString());
                return false;
            }

            return true;
        }
        #endregion

        #region "ダミーデータ"
        /// <summary>
        /// DSTステータスリストの情報（ダミー）を一覧に登録する
        /// </summary>
        public void AddDstiItemForTrial()
        {
            DSTDtoList dstiDtoList = new DSTDtoList();
            for (int i = 0; i < 3; i++)
            {
                DSTDto dto = createDstiDtoDummyData(i);
                Invoke((DelegateAdd)add, dto);
            }
        }

        /// <summary>
        /// DSTステータスリストの情報（ダミー）を作成する
        /// </summary>
        /// <returns>情報（ダミー）</returns>
        private DSTDto createDstiDtoDummyData(int index)
        {
            DSTDto dstiDto = new DSTDto();

            dstiDto.ipAddress = "192.168.11." + index;
            dstiDto.serialNo = "5D11100" + index;
            dstiDto.progresValue = 0;
            dstiDto.isEnabled = true;
            dstiDto.isSelectEnabled = true;
            dstiDto.isSelected = false;
            dstiDto.message = "0%";
            dstiDto.progressColorForeground = DSTDto.ProgresColor.Green.Name();
            return dstiDto;
        }
        #endregion "ダミーデータ"

    }
}
