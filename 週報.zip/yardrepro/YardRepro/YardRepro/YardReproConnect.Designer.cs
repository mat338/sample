﻿namespace YardRepro
{
    partial class YardReproConnect
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(YardReproConnect));
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblSearching = new System.Windows.Forms.Label();
            this.btnNext = new System.Windows.Forms.Button();
            this.btnTrialF1 = new System.Windows.Forms.Button();
            this.dstConnectList1 = new YardRepro.DSTConnectList();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.lblSearching);
            this.panel1.Controls.Add(this.dstConnectList1);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(342, 293);
            this.panel1.TabIndex = 0;
            // 
            // lblSearching
            // 
            this.lblSearching.BackColor = System.Drawing.Color.Gray;
            this.lblSearching.Font = new System.Drawing.Font("Meiryo UI", 16F, System.Drawing.FontStyle.Bold);
            this.lblSearching.ForeColor = System.Drawing.Color.White;
            this.lblSearching.Location = new System.Drawing.Point(18, 125);
            this.lblSearching.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSearching.Name = "lblSearching";
            this.lblSearching.Size = new System.Drawing.Size(305, 41);
            this.lblSearching.TabIndex = 1;
            this.lblSearching.Text = "(検出中)";
            this.lblSearching.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btnNext
            // 
            this.btnNext.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnNext.Font = new System.Drawing.Font("Meiryo UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnNext.ForeColor = System.Drawing.Color.Gray;
            this.btnNext.Location = new System.Drawing.Point(221, 311);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(133, 36);
            this.btnNext.TabIndex = 1;
            this.btnNext.Text = "次へ";
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // btnTrialF1
            // 
            this.btnTrialF1.Location = new System.Drawing.Point(13, 354);
            this.btnTrialF1.Name = "btnTrialF1";
            this.btnTrialF1.Size = new System.Drawing.Size(27, 23);
            this.btnTrialF1.TabIndex = 2;
            this.btnTrialF1.Text = "F1";
            this.btnTrialF1.UseVisualStyleBackColor = true;
            this.btnTrialF1.Click += new System.EventHandler(this.btnTrialF1_Click);
            // 
            // dstConnectList1
            // 
            this.dstConnectList1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dstConnectList1.isStop = false;
            this.dstConnectList1.Location = new System.Drawing.Point(0, 0);
            this.dstConnectList1.Margin = new System.Windows.Forms.Padding(0);
            this.dstConnectList1.Name = "dstConnectList1";
            this.dstConnectList1.Size = new System.Drawing.Size(340, 291);
            this.dstConnectList1.TabIndex = 0;
            this.dstConnectList1.OnRefreshList += new System.EventHandler(this.dstConnectList1_OnRefreshList);
            this.dstConnectList1.OnSelectedChange += new System.EventHandler(this.dstConnectList1_OnSelectedChange);
            // 
            // YardReproConnect
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DimGray;
            this.ClientSize = new System.Drawing.Size(363, 351);
            this.Controls.Add(this.btnTrialF1);
            this.Controls.Add(this.btnNext);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "YardReproConnect";
            this.Text = "YardReproConnect";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.YardReproConnect_FormClosed);
            this.Shown += new System.EventHandler(this.YardReproConnect_Shown);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnNext;
        private DSTConnectList dstConnectList1;
        private System.Windows.Forms.Button btnTrialF1;
        private System.Windows.Forms.Label lblSearching;
    }
}