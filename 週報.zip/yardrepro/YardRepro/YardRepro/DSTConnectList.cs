﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Windows.Forms;
using NLog;
using System.Collections;
using System.Threading;
using YardRepro.dto;

namespace YardRepro
{
    /// <summary>
    /// DST接続リストユーザコントロールクラス
    /// </summary>
    public partial class DSTConnectList : UserControl
    {

        /// <summary>
        /// ログ出力クラス
        /// </summary>
        private static readonly Logger log = LogManager.GetCurrentClassLogger();

        /// <summary>
        /// キャンセルスリープ
        /// </summary>
        private CancellationTokenSource CancellableSleep = null;

        /// <summary>
        /// 定期リフレッシュ停止フラグ
        /// </summary>
        public bool isStop { get; set; }

        /// <summary>
        /// DST接続リストデータ
        /// </summary>
        public DSTDtoList list
        {
            get { return dstConnectListWPF1.DstiList; }
            set { dstConnectListWPF1.DstiList = value; }
        }

        /// <summary>
        /// リスト更新イベント
        /// </summary>
        public event EventHandler OnRefreshList;

        /// <summary>
        /// 選択チェンジイベント
        /// </summary>
        public event EventHandler OnSelectedChange;

        /// <summary>
        /// 接続エラー回数テーブル
        /// </summary>
        private Hashtable connectErrorCount = new Hashtable();

        /// <summary>
        /// コンストラクタ
        /// </summary>
        /// ### 機能説明 #######
        /// -# 画面コンポーネントの初期処理
        /// -# DST接続リストコントロールの選択チェックイベントに選択チェック変更イベントメソッドを追加
        public DSTConnectList()
        {
            InitializeComponent();
            dstConnectListWPF1.OnSelectedChange +=new EventHandler(dsTConnectListWPF1_OnSelectedChange);
        }

        /// <summary>
        /// DSTi更新スタート
        /// </summary>
        /// ### 機能説明 #######
        /// -# Stopフラグをfalseに設定
        /// -# キャンセルスリープオブジェクトのインスタンス生成
        /// -# 非同期更新処理を開始
        public void Start()
        {
            log.Debug("START");
            // Stopフラグをfalseに設定
            this.isStop = false;
            // キャンセルスリープを初期化
            CancellableSleep = new CancellationTokenSource();
            // 非同期更新処理を開始
            if (!bgwRefresh.IsBusy) bgwRefresh.RunWorkerAsync();
        }

        /// <summary>
        /// スキャン停止
        /// </summary>
        /// ### 機能説明 #######
        /// -# Stopフラグをtrueに設定
        /// -# キャンセルスリープオブジェクトがnull以外の場合、キャンセルする。
        public void Stop()
        {
            log.Debug("START");
            // Stopフラグをtrueに設定
            this.isStop = true;
            // スリープをキャンセル
            if (CancellableSleep != null) CancellableSleep.Cancel();
        }

        /// <summary>
        /// スキャン中フラグ
        /// </summary>
        /// <returns>スキャン中の場合True</returns>
        /// ### 機能説明 #######
        /// -# 非同期更新処理の処理中フラグを返却
        public bool IsScanBusy()
        {
            return bgwRefresh.IsBusy;
        }

        /// <summary>
        /// リスト中の選択チェックの有無
        /// </summary>
        /// <returns>リスト中の選択チェックの有無</returns>
        /// ### 機能説明 #######
        /// -# DST接続リストデータ中の選択が１つでも選択している場合Trueを返却、それ以外はFalseを返却
        public bool isSelectedItem()
        {
            return list.Any(d => d.isSelected);
        }

        /// <summary>
        /// スキャン非同期処理
        /// </summary>
        /// ### 機能説明 #######
        /// -# StopフラグがFalseの間、ループする
        ///     -# WiFi接続情報読出しコマンドをブロードキャスト送信
        ///     -# キャンセルされている場合は、ループを抜ける
        ///     -# DST接続リストデータのIPアドレス分ループする
        ///         -# WiFi接続情報返却リストのIPにDST接続リストデータのIPが存在しない場合
        ///             -# 接続エラー回数マップをDST接続リストデータのIPをキーにして接続エラー回数をインクリメント
        ///             -# 接続エラー回数が３回以上の場合
        ///                 -# DST接続リストデータからDST接続リストデータのIPのデータを削除
        ///         -# WiFi接続情報返却リストのIPにDST接続リストデータのIPが存在する場合
        ///             -# 接続エラー回数マップをDST接続リストデータのIPをキーに0を設定
        ///     -# WiFi接続情報読出しの返却されたIPアドレス分ループする
        ///         -# DST接続リストのIPにWiFi接続情報読出しのIPが存在しない場合
        ///             -# DST接続リストデータにWiFi接続情報読出しのIPのデータを追加
        ///             -# 接続エラー回数マップをWiFi接続情報読出しのIPをキーに0を設定
        ///     -# キャンセルされていない場合は、一覧リフレッシュ時間スリープする
        private void bgwReflesh_DoWork(object sender, DoWorkEventArgs e)
        {
            log.Debug("START");

            while(!this.isStop)
            {
                // WiFi接続情報読出しコマンドをブロードキャスト送信
                ArrayList responseWifiConnectList = DSTUtil.sendWifiConnectBroadcast();
                if (CancellableSleep.IsCancellationRequested) break;

                // 現表示リストのIPがのWiFi接続情報読出しの返却されたIPにない場合はリストから削除
                List<string> ipList = list.Select(d => d.ipAddress).ToList();
                foreach (string ipaddress in ipList)
                {
                    if (!responseWifiConnectList.Cast<DSTUtil.WifiConnectBroadcastReply>().Any(d => d.ip.Equals(ipaddress))) {
                        // 接続エラー回数をインクリメント
                        connectErrorCount[ipaddress] = (int)connectErrorCount[ipaddress] + 1;
                        if ((int)connectErrorCount[ipaddress] >= 3)
                        {
                            // リストから削除
                            Invoke((DelegateDelete)delete, ipaddress);
                        }
                    } else
                    {
                        // 接続エラー回数を0に設定
                        connectErrorCount[ipaddress] = 0;
                    }
                }
                // 追加
                foreach (DSTUtil.WifiConnectBroadcastReply reply in responseWifiConnectList)
                {
                    // 現表示リストのIPにない場合
                    if (!ipList.Any(d => d.Equals(reply.ip)))
                    {
                        DSTDto dstiDto = DSTDtoUtil.createDstiDto(reply.ip, reply.reply);
                        Invoke((DelegateAdd)add, dstiDto);
                        // 接続エラー回数を0に設定
                        connectErrorCount[reply.ip] = 0;
                    }
                }
                // 現在表示リスト分ループ
                if (!CancellableSleep.IsCancellationRequested) {
                    CancellableSleep.Token.WaitHandle.WaitOne(Consts.REFRESH_TIME);
                }
            }
            log.Debug("END");
        }

        /// <summary>
        /// DST接続リストに追加する（デリゲートメソッド）。
        /// </summary>
        /// <param name="dto">削除対象のDST情報</param>
        delegate void DelegateAdd(DSTDto dto);

        /// <summary>
        /// DST接続リストに追加する。
        /// </summary>
        /// <param name="dto">追加対象のDST情報</param>
        /// ### 機能説明 #######
        /// -# DST接続リストデータに引数.追加対象のDST情報を追加
        /// -# DST接続リストデータをシリアルNo昇順にソート
        /// -# リスト更新イベントを発生させる
        /// -# リスト表示を更新
        private void add(DSTDto dto)
        {
            // リストに追加
            list.Add(dto);
            // リストをシリアルNo昇順にソート
            ArrayList.Adapter(list).Sort(new DSTSorter());
            // リスト更新イベントを発生させる
            if (OnRefreshList != null) OnRefreshList(this, EventArgs.Empty);
            // リスト表示を更新
            ItemsRefresh();
        }

        /// <summary>
        /// DST接続リストから削除する（デリゲートメソッド）。
        /// </summary>
        /// <param name="ipAddress">削除対象のIPアドレス</param>
        delegate void DelegateDelete(string ipAddress);

        /// <summary>
        /// DST接続リストから削除する。
        /// </summary>
        /// <param name="ipAddress">削除対象のIPアドレス</param>
        /// ### 機能説明 #######
        /// -# DST接続リスト内の引数と同じIPのDST情報を取得
        /// -# DST情報が取得出来た場合
        ///     -# リストから削除
        ///     -# リスト更新イベントを発生させる
        ///     -# リスト表示を更新
        private void delete(string ipAddress)
        {
            // リスト中の同じIPのデータを取得
            DSTDto targetDto = (DSTDto)list.Select(d => d).Where(d => d.ipAddress == ipAddress).FirstOrDefault();
            // 取得できた場合
            if (targetDto != null)
            {
                // リストから削除
                list.Remove(targetDto);
                // リスト更新イベントを発生させる
                if (OnRefreshList != null) OnRefreshList(this, EventArgs.Empty);
                // リスト表示を更新
                ItemsRefresh();
            }
        }

        /// <summary>
        /// DST接続リストコントロールのビューを再作成（デリゲートメソッド）
        /// </summary>
        delegate void DelegateItemsRefresh();

        /// <summary>
        /// DST接続リストコントロールのビューを再作成
        /// </summary>
        /// ### 機能説明 #######
        /// -# DST接続リストコントロールのビューを再作成
        private void dItemsRefresh()
        {
            dstConnectListWPF1.listBox1.Items.Refresh();
        }

        /// <summary>
        /// DST接続リストコントロールのビューを再作成
        /// </summary>
        /// ### 機能説明 #######
        /// -# DST接続リストコントロールのビューを再作成をデリゲート実行
        public void ItemsRefresh()
        {
            Invoke((DelegateItemsRefresh)dItemsRefresh);
        }

        /// <summary>
        /// DST接続リストデータの選択チェックが変更された場合
        /// </summary>
        /// <param name="sender">発生元オブジェクト</param>
        /// <param name="e">イベント引数</param>
        /// ### 機能説明 #######
        /// -# 選択チェック変更イベントを発生させる。
        private void dsTConnectListWPF1_OnSelectedChange(object sender, EventArgs e)
        {
            if (OnSelectedChange != null) OnSelectedChange(this, EventArgs.Empty);
        }

        #region "ダミーデータ"
        /// <summary>
        /// DST接続リストの情報（ダミー）を一覧に登録する
        /// </summary>
        public void AddDstiItemForTrial(int size)
        {
            List<string> ipList = list.Select(d => d.ipAddress).ToList();
            foreach (string ipaddress in ipList)
            {
                Invoke((DelegateDelete)delete, ipaddress);
            }
            for (int i = 0; i < size; i++)
            {
                DSTDto dto = createDstiDtoDummyData(i);
                Invoke((DelegateAdd)add, dto);
            }
        }

        /// <summary>
        /// DST接続リストの情報（ダミー）を作成する
        /// </summary>
        /// <returns>DSTDTOダミーデータ</returns>
        private DSTDto createDstiDtoDummyData(int index)
        {
            DSTDto dstiDto = new DSTDto();

            dstiDto.ipAddress = "192.168.11." + index;
            dstiDto.serialNo = "5D11100" + index;
            dstiDto.progresValue = 0;
            dstiDto.isEnabled = true;
            dstiDto.isSelectEnabled = true;
            dstiDto.isSelected = false;
            dstiDto.progressColorForeground = DSTDto.ProgresColor.Green.Name();
            return dstiDto;
        }
        #endregion "ダミーデータ"

    }
}
