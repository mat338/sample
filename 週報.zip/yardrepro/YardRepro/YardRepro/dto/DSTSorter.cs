﻿using System;

namespace YardRepro.dto
{
    /// <summary>
    /// DSTソートクラス（選択画面）
    /// </summary>
    class DSTSorter : System.Collections.IComparer, System.Collections.Generic.IComparer<DSTDto>
    {
        /// <summary>
        /// DSTDTOのシリアルNo.を比較して並べ替え順序の位置を返却
        /// </summary>
        /// <param name="x">DST情報</param>
        /// <param name="y">DST情報</param>
        /// <returns>位置を示す整数</returns>
        /// ### 機能説明 #######
        /// -# 指定した 2 つの DST情報.シリアルNoを比較し、並べ替え順序におけるそれらの相対位置を示す整数を返します。
        public int Compare(DSTDto x, DSTDto y)
        {
            //return String.Compare(x.sortNo, y.sortNo);
            return String.Compare(x.serialNo, y.serialNo);
        }

        /// <summary>
        /// DSTDTOのオブジェクトを比較して並べ替え順序の位置を返却
        /// </summary>
        /// <param name="x">DST情報</param>
        /// <param name="y">DST情報</param>
        /// <returns>位置を示す整数</returns>
        /// ### 機能説明 #######
        /// -# DSTDTOのシリアルNo.を比較して並べ替え順序の位置を返却を呼出し返却値を返却
        public int Compare(object x, object y)
        {
            return Compare((DSTDto)x, (DSTDto)y);
        }
    }


    /// <summary>
    /// DSTListソートクラス（リプロ状況）
    /// </summary>
    class DSTListSorter : System.Collections.IComparer, System.Collections.Generic.IComparer<DSTDto>
    {
        /// <summary>
        /// DSTDTOのソートNo.を比較して並べ替え順序の位置を返却（降順）
        /// </summary>
        /// <param name="x">DST情報</param>
        /// <param name="y">DST情報</param>
        /// <returns>位置を示す整数</returns>
        /// ### 機能説明 #######
        /// -# 指定した 2 つの DST情報.ソートNoを比較し、並べ替え順序におけるそれらの相対位置を示す整数を返します。
        public int Compare(DSTDto x, DSTDto y)
        {
            return - String.Compare(x.sortNo, y.sortNo);
        }

        /// <summary>
        /// DSTDTOのオブジェクトを比較して並べ替え順序の位置を返却
        /// </summary>
        /// <param name="x">DST情報</param>
        /// <param name="y">DST情報</param>
        /// <returns>位置を示す整数</returns>
        /// ### 機能説明 #######
        /// -# DSTDTOのシリアルNo.を比較して並べ替え順序の位置を返却を呼出し返却値を返却
        public int Compare(object x, object y)
        {
            return Compare((DSTDto)x, (DSTDto)y);
        }
    }
}
