﻿
using System.Collections.Generic;
using System.Collections.ObjectModel;
namespace YardRepro.dto
{
    /// <summary>
    /// DST情報リストクラス
    /// </summary>
    public class DSTDtoList : ObservableCollection<DSTDto>
    {
    }

    /// <summary>
    /// プログレスバー色列挙型拡張クラス
    /// </summary>
    public static class ProgresColorExt
    {
        /// <summary>
        /// 色情報
        /// </summary>
        /// <param name="color">プログレスバー色</param>
        /// <returns>色情報</returns>
        public static string Name(this DSTDto.ProgresColor color)
        {
            // Green, Fuchsia, Yellow
            string[] colorStr = { "#FF01D328", "#ffff0000", "#ffffd700" };
            return colorStr[(int)color];
        }
    }

    /// <summary>
    /// DST情報クラス
    /// </summary>
    public class DSTDto
    {

        /// <summary>
        /// DSTの状態
        /// </summary>
        public enum StatusMode : int
        {
            /// <summary>
            /// アイドル中
            /// </summary>
            Idle = 0,

            /// <summary>
            /// 実行中
            /// </summary>
            Exec,

            /// <summary>
            /// リプロ完了
            /// </summary>
            Success,

            /// <summary>
            /// リプロツール差替え済み
            /// </summary>
            Replaced,

            /// <summary>
            /// エラー
            /// </summary>
            Error,

            /// <summary>
            /// 未接続
            /// </summary>
            Notconnect
        };

        /// <summary>
        /// プログレスバーの色
        /// </summary>
        public enum ProgresColor : int
        {
            /// <summary>
            /// 緑
            /// </summary>
            Green,

            /// <summary>
            /// 赤
            /// </summary>
            Fuchsia,

            /// <summary>
            /// 黄
            /// </summary>
            Yellow
        };

        /// <summary>
        /// 現在の状態
        /// </summary>
        public StatusMode status { get; set; }

        /// <summary>
        /// シリアルNo.
        /// </summary>
        public string serialNo { get; set; }

        /// <summary>
        /// VinNo.
        /// </summary>
        public string vinNo { get; set; }

        /// <summary>
        /// VinNo取得済みフラグ. 2019.02
        /// </summary>
        //public bool getVinNo { get; set; }

        /// <summary>
        /// ソフトウェア品番リスト（リプロ前）. 2019.02
        /// </summary>
        public List<string> softNoBefore { get; set; }

        /// <summary>
        /// リプロ前ソフトウェア品番取得済みフラグ. 2019.02
        /// </summary>
        public bool getSoftNoBefore { get; set; }

        /// <summary>
        /// ソフトウェア品番リスト（リプロ後） 2019.02
        /// </summary>
        public List<string> softNoAfter { get; set; }

        /// <summary>
        /// リプロ後ソフトウェア品番取得済みフラグ. 2019.02
        /// </summary>
        public bool getSoftNoAfter { get; set; }

        /// <summary>
        /// IPアドレス
        /// </summary>
        public string ipAddress { get; set; }

        /// <summary>
        /// 電波強度
        /// </summary>
        public int signalStrength { get; set; }

        /// <summary>
        /// 使用中ホスト名
        /// </summary>
        public string hostName { get; set; }
        
        /// <summary>
        /// 色情報
        /// </summary>
        public byte[] color { get; set; }

        /// <summary>
        /// 進捗情報
        /// </summary>
        public int progresValue { get; set; }

        /// <summary>
        /// プログレスバーの色
        /// </summary>
        public string progressColorForeground { get; set; }

        /// <summary>
        /// エラーコード
        /// </summary>
        public string errorCode { get; set; }

        /// <summary>
        /// 活性・非活性フラグ
        /// </summary>
        public bool isEnabled { get; set; }

        /// <summary>
        /// 選択フラグ活性・非活性フラグ
        /// </summary>
        public bool isSelectEnabled { get; set; }

        /// <summary>
        /// 選択フラグ
        /// </summary>
        public bool isSelected { get; set; }

        /// <summary>
        /// リトライ可能
        /// </summary>
        public bool isRetryEnabled { get; set; }

        /// <summary>
        /// メッセージ
        /// </summary>
        public string message { get; set; }

        /// <summary>
        /// DST情報をテキスト出力
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return "serialNo[" + serialNo + "]";
        }

        /// <summary>
        /// DTC実行の状態 2019.02
        /// </summary>
        public enum StatusModeDTC : int
        {
            /// <summary>
            /// DTC未実施
            /// </summary>
            DtcNotExec = 0,

            /// <summary>
            /// DTC消去実施中
            /// </summary>
            DtcExec,

            /// <summary>
            /// ログファイル取得中
            /// </summary>
            DtcExecLog,

            /// <summary>
            /// DTC消去完了
            /// </summary>
            DtcSuccess,

            /// <summary>
            /// DTC消去エラー
            /// </summary>
            DtcError,

            /// <summary>
            /// ログファイル取得エラー
            /// </summary>
            DtcErrorLog
        };

        /// <summary>
        /// 現在のDTC状態 2019.02
        /// </summary>
        public StatusModeDTC statusDtc { get; set; }

        /// <summary>
        /// リストのソート順 2019.02
        /// </summary>
        public string sortNo { get; set; }

        /// <summary>
        /// DTC消去操作可能 2019.02
        /// </summary>
        public bool isDtcEnabled { get; set; }

        /// <summary>
        /// DTC消去実行チェック 2019.02
        /// </summary>
        public bool isDtcDeleteChecked { get; set; }

        /// <summary>
        /// メッセージ（DTC） 2019.02
        /// </summary>
        public string messageDTC { get; set; }

        /// <summary>
        /// リプロ鍵認証の状態 2019.12
        /// </summary>
        public enum StatusModeSignature : int
        {
            /// <summary>
            /// 署名取得開始前
            /// </summary>
            SignatureNotExec = 0,

            /// <summary>
            /// 署名取得実施中
            /// </summary>
            SignatureExec = 1,

            /// <summary>
            /// 署名XML取込成功
            /// </summary>
            SignatureSuccess = 2,

            /// <summary>
            /// 署名取得キャンセルエラー
            /// </summary>
            SignatureError = 3,

            /// <summary>
            /// 署名認証成功
            /// </summary>
            AuthenticationSuccess = 4,

            /// <summary>
            /// 署名認証エラー
            /// </summary>
            AuthenticationError = 5
        };

        /// <summary>
        /// 現在のリプロ鍵認証状態 2019.12
        /// </summary>
        public StatusModeSignature statusSignature { get; set; }

        /// <summary>
        /// リクエストする際に車載機で採番されたseed値 2019.12
        /// </summary>
        public byte[] seedValue { get; set; }

        /// <summary>
        /// Seed取得済みフラグ. 2019.12
        /// </summary>
        public bool getSeedValue { get; set; }

        /// <summary>
        /// リプロ認証システムが応答する署名データファイル名 2019.12
        /// </summary>
        public string signatureFileName { get; set; }

        /// <summary>
        /// リプロ認証システムが応答する署名データ 2019.12
        /// </summary>
        public byte[] signature { get; set; }

        /// <summary>
        /// リトライ上限カウンター 2020.01
        /// ・認証失敗回数の上限4回まで
        /// ・上限を超えたら10秒後にリトライ可能
        /// ・10秒待てば失敗カウンタリセット
        /// </summary>
        public int retryUpperLimitCounter { get; set; }
    }
}
