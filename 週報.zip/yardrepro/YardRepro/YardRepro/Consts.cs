﻿namespace YardRepro
{
    /// <summary>
    /// 定数クラス
    /// </summary>
    public class Consts
    {
        //インスタンス生成禁止
        private Consts(){ }

        /// <summary>
        /// WLAN AutoConfigのサービス名
        /// </summary>
        public const string WLAN_AUTOCONFIG_SERVICE = "Wlansvc";

        /// <summary>
        /// Wireless Zero Configurationのサービス名
        /// </summary>
        public const string WIRELESS_ZERO_CONFIGURATION = "WZCSVC";

        // -------------------------------------------------------------------------------
        // 画面文言
        // -------------------------------------------------------------------------------
        /// <summary>
        /// タイトルバーの文言
        /// </summary>
        public const string SCREEN_MAIN_TITLE = "ヤードリプロ";

        /// <summary>
        /// 選択リストなし時のメッセージ
        /// </summary>
        public const string SCREEN_MAIN_LBL_SEARCHING = "選択されていません。";

        /// <summary>
        /// 閉じるボタン文言
        /// </summary>
        public const string SCREEN_MAIN_BTN_CLOSE = "閉じる";

        /// <summary>
        /// DST選択ボタン文言
        /// </summary>
        public const string SCREEN_MAIN_BTN_DSTSELECT = "DST選択";

        /// <summary>
        /// CSV出力ボタン文言
        /// </summary>
        public const string SCREEN_MAIN_BTN_CSV = "CSV出力";

        /// <summary>
        /// タイトルバーの文言
        /// </summary>
        public const string SCREEN_CONNECT_TITLE = "DST選択";

        /// <summary>
        /// 次へボタン文言
        /// </summary>
        public const string SCREEN_CONNECT_BTN_NEXT = "次へ";

        /// <summary>
        /// リスト表示なし時のメッセージ
        /// </summary>
        public const string SCREEN_CONNECT_LBL_SEARCHING = "検索中";

        // -------------------------------------------------------------------------------
        // ini情報
        // -------------------------------------------------------------------------------
        /// <summary>
        /// iniファイルの格納パス
        /// </summary>
        public const string INI_FILEPATH = @".\yardrepro.ini";

        /// <summary>
        /// 後処理(DTC実行)結果のセクション名
        /// </summary>
        public const string INI_SECTION_NAME = "LOG_FILE";

        /// <summary>
        /// 後処理(DTC実行)結果のタイムアウトキー
        /// </summary>
        public const string INI_TIMEOUT_KEY = "TIMEOUT";

        /// <summary>
        /// 後処理(DTC実行)結果のタイムアウト初期値
        /// </summary>
        public const int INI_TIMEOUT_VALUE = 10;

        /// <summary>
        /// DTC logファイルの保存先キー
        /// </summary>
        public const string INI_SAVE_FOLDER_KEY = "SAVE_FOLDER";

        /// <summary>
        /// DTC logファイルの保存先
        /// </summary>
        public const string INI_SAVE_FOLDER_VALUE = @"\YardRepro";

        /// <summary>
        /// DTC logファイルの保存先
        /// </summary>
        public const string DTC_LOG_FILE_NAME = @"\YardRepro_DTC";

        /// <summary>
        /// 認証セクション名
        /// </summary>
        public const string INI_AUTH_SECTION_NAME = "AUTHENTICATION";

        /// <summary>
        /// 認証URLキー
        /// </summary>
        public const string INI_AUTH_URL_KEY = "URL";

        /// <summary>
        /// 認証URL
        /// ・試行機(ktrt00845)：URL（日）
        /// 　https://w2k-t01.kitora.toyota.co.jp/auth/KT01811/ZD/servlet/jp.co.toyota.pzd1008.CCZD1043?L=Ja&DS=DMYZD01&M=DUM&PID=CCZD1043&CID=P5X001S
        /// ・試行機(ktrt00845)：URL（英）
        /// 　https://w2k-t01.kitora.toyota.co.jp/auth/KT01811/ZD/servlet/jp.co.toyota.pzd1008.CCZD1043?L=En&DS=DMYZD01&M=DUM&PID=CCZD1043&CID=P5X001S
        /// ・号口機(ktrg00715)：URL（日）
        /// 　https://w2k-g01.kitora.toyota.co.jp/auth/KG01081/ZD/servlet/jp.co.toyota.pzd1008.CCZD1043?L=Ja&DS=DMYZD01&M=DUM&PID=CCZD1043&CID=P5X001S
        /// ・号口機(ktrg00715)：URL（英）
        /// 　https://w2k-g01.kitora.toyota.co.jp/auth/KG01081/ZD/servlet/jp.co.toyota.pzd1008.CCZD1043?L=En&DS=DMYZD01&M=DUM&PID=CCZD1043&CID=P5X001S
        /// </summary>
        public const string INI_AUTH_URL_VALUE = "https://w2k-g01.kitora.toyota.co.jp/auth/KG01081/ZD/servlet/jp.co.toyota.pzd1008.CCZD1043?L=Ja&DS=DMYZD01&M=DUM&PID=CCZD1043&CID=P5X001S";

        // -------------------------------------------------------------------------------
        // リプロ鍵署名情報
        // -------------------------------------------------------------------------------
        /// <summary>
        /// リプロ鍵署名要求XMLファイルの格納パス
        /// </summary>
        public const string SIGNATURE_REQUEST_FILEPATH = @".\ReprokeySignatureRequest.xml";

        /// <summary>
        /// GTSサーバー - XML格納要素名
        /// </summary>
        public const string XML_ELEMENT_NAME = "ReproKeyRequest";

        /// <summary>
        /// ダウンロードフォルダの格納パス
        /// </summary>
        public const string SIGNATURE_DOWNLOADS_FILEPATH = @"%USERPROFILE%\Downloads";

        /// <summary>
        /// 保存ダイアログのフィルタ
        /// </summary>
        public const string SIGNATURE_XML_FILTER = "XMLファイル(*.xml)|*.xml|すべてのファイル(*.*)|*.*";

        /// <summary>
        /// リプロ鍵署名要求XML[バージョン]
        /// </summary>
        public const string SIGNATURE_X_VERSION = "X-Version";

        /// <summary>
        /// リプロ鍵署名要求XML[ソフトウェアID]
        /// </summary>
        public const string SIGNATURE_SOFTWARE_ID = "SoftwareID";

        /// <summary>
        /// リプロ鍵署名要求XML[ソフトウェアバージョン]
        /// </summary>
        public const string SIGNATURE_SOFTWARE_VERSION = "SoftwareVersion";

        /// <summary>
        /// リプロ鍵署名要求XML[ライセンスキー]
        /// </summary>
        public const string SIGNATURE_LICENSE_KEY = "LicenseKey";

        /// <summary>
        /// リプロ鍵署名要求XML[VIN]
        /// </summary>
        public const string SIGNATURE_VIN = "VehicleIdentificationNumber";

        /// <summary>
        /// リプロ鍵署名要求XML[要求元種別]
        /// </summary>
        public const string SIGNATURE_REQUESTER_KIND = "RequesterKind";

        /// <summary>
        /// リプロ鍵署名要求XML[有線リプロ鍵ID]
        /// </summary>
        public const string SIGNATURE_KEYPAIR_ID = "KeypairID";

        /// <summary>
        /// リプロ鍵署名要求XML[Seed値]
        /// </summary>
        public const string SIGNATURE_SEED_VALUE = "SeedValue";

        /// <summary>
        /// リプロ鍵署名応答XML[署名]
        /// </summary>
        public const string SIGNATURE_SIGNATURE = "Signature";

        // -------------------------------------------------------------------------------
        // CSV出力情報
        // -------------------------------------------------------------------------------
        /// <summary>
        /// 保存ダイアログのデフォルトファイル名
        /// </summary>
        public const string CSV_DEFAULT_FILENAME = "newfile.csv";

        /// <summary>
        /// 保存ダイアログのフィルタ
        /// </summary>
        public const string CSV_FILTER = "CSVファイル(*.csv)|*.csv|すべてのファイル(*.*)|*.*";

        /// <summary>
        /// 保存ダイアログのタイトル
        /// </summary>
        public const string CSV_TITLE = "保存先のファイルを選択してください";

        /// <summary>
        /// CSVファイルのヘッダ 2019.02
        /// </summary>
        public const string CSV_HEADER = "リプロツール情報,Vin,リプロ前ソフト品番,リプロ後ソフト品番,リプロ状況";

        /// <summary>
        /// CSVファイルのフォーマット
        /// </summary>
        public const string CSV_FORMAT = "{0},{1},{2},{3},{4}";

        // -------------------------------------------------------------------------------
        // DST-WiFiとソケット通信する情報
        // -------------------------------------------------------------------------------
        /// <summary>
        /// DST-WiFi接続用のポート番号
        /// </summary>
        //public const int DSTWL_PORT = 60700;

        /// <summary>
        /// DST-WiFiとソケット通信するためのポート番号
        /// </summary>
        //public const int DSTWL_SOCKET_PORT = DSTWL_PORT + 1;

        // -------------------------------------------------------------------------------
        // DST-i4とソケット通信する情報
        // -------------------------------------------------------------------------------
        /// <summary>
        /// DST-i4接続用のポート番号 2019.12 将来的（2020.03月まで？）にnanoからi4へ切り替わる予定
        /// </summary>
        public const int DSTWL_PORT = 60702;

        /// <summary>
        /// DST-i4とソケット通信するためのポート番号 2019.12 将来的（2020.03月まで？）にnanoからi4へ切り替わる予定
        /// </summary>
        public const int DSTWL_SOCKET_PORT = DSTWL_PORT + 1;

        /// <summary>
        /// タイムアウト時間（ミリ秒）
        /// </summary>
        public const int TIMEOUT = 1000;

        // -------------------------------------------------------------------------------
        // DST-WiFiとソケット通信する際のコマンドID
        // -------------------------------------------------------------------------------
        /// <summary>
        /// DST-WiFiとソケット通信する際のコマンドID：WiFi接続モード強制変更
        /// </summary>
        public const byte SOCKET_ID_CHANGE_CONNECT_MODE = 1;
        /// <summary>
        /// DST-WiFiとソケット通信する際のコマンドID：WiFi情報読出し
        /// </summary>
        public const byte SOCKET_ID_GET_WIFI_DATA = 2;
        /// <summary>
        /// DST-WiFiとソケット通信する際のコマンドID：WiFi接続情報読出し
        /// </summary>
        public const byte SOCKET_ID_GET_CONNECTION_DATA = 3;
        /// <summary>
        /// DST-WiFiとソケット通信する際のコマンドID：WiFi接続ホスト情報登録
        /// </summary>
        public const byte SOCKET_ID_UPDATE_HOSTNAME = 4;
        /// <summary>
        /// DST-WiFiとソケット通信する際のコマンドID：ブザー
        /// </summary>
        public const byte SOCKET_ID_BUZZER = 5;
        /// <summary>
        /// DST-WiFiとソケット通信する際のコマンドID：ステータス取得
        /// </summary>
        public const byte SOCKET_ID_STATUS = 0x11;
        /// <summary>
        /// DST-WiFiとソケット通信する際のコマンドID：VIN取得
        /// </summary>
        public const byte SOCKET_ID_VIN = 0x12;
        /// <summary>
        /// DST-WiFiとソケット通信する際のコマンドID：ソフトウェア品番取得
        /// </summary>
        public const byte SOCKET_ID_SOFTNO = 0x13;
        /// <summary>
        /// DST-WiFiとソケット通信する際のコマンドID：リトライ要求
        /// </summary>
        public const byte SOCKET_ID_REPRORETRY = 0x14;
        /// <summary>
        /// DST-WiFiとソケット通信する際のコマンドID：後処理開始要求
        /// </summary>
        public const byte SOCKET_ID_DTC_EXEC = 0x15;
        /// <summary>
        /// DST-WiFiとソケット通信する際のコマンドID：ログファイル取得要求
        /// </summary>
        public const byte SOCKET_ID_DTC_EXEC_LOG = 0x16;
        /// <summary>
        /// DST-WiFiとソケット通信する際のコマンドID：後処理ステータス取得
        /// </summary>
        public const byte SOCKET_ID_DTC_EXEC_STATUS = 0x17;
        /// <summary>
        /// DST-i4とソケット通信する際のコマンドID：Seed取得
        /// </summary>
        public const byte SOCKET_ID_SEED = 0x18;
        /// <summary>
        /// DST-i4とソケット通信する際のコマンドID：Key送信
        /// </summary>
        public const byte SOCKET_ID_KEY_SEND = 0x19;
        // -------------------------------------------------------------------------------

        /// <summary>
        /// 一覧リフレッシュ時間（ミリ秒）
        /// </summary>
        public const int REFRESH_TIME = 5000;

        /// <summary>
        /// ソケットの受信バッファサイズ
        /// </summary>
        // ブロードキャストに対する応答を格納するのに十分なサイズを指定すること
        // 目安はデータサイズ×255
        public const int SOCKET_RECEIVE_BUFFER_SIZE = 65535;

        /// <summary>
        /// ソケットの応答待ち時間（ミリ秒単位）
        /// </summary>
        public const int SOCKET_RECEIVE_WAIT_TIME = 2000;

        /// <summary>
        /// ステータスの更新間隔（ミリ秒単位）
        /// </summary>
        public const int STATUS_REFRESH_TIME = 3000;

        /// <summary>
        /// 応答フレーム最大サイズ 2019.02
        /// </summary>
        public const int RESPONSE_FRAME_MAX_SIZE = 512;

        /// <summary>
        /// 応答フレームヘッダーサイズ（分割有のフレーム） 2019.02
        /// </summary>
        public const int RESPONSE_FRAME_HEADER_SIZE = 7;

        /// <summary>
        /// リプロ実行中 2019.02
        /// </summary>
        public const string REPRO_EXEC = "1";

        /// <summary>
        /// リプロ差替え済み 2019.02
        /// </summary>
        public const string REPRO_REPLACED = "0";

        // ------------------------------------------------------------------------------

        /// <summary>
        /// メッセージ：システムエラー
        /// </summary>
        public const string MESSAGE_ERROR_SYSTEM = "システムエラーが発生しました。\nシステム管理者に問い合わせてください。";

        /// <summary>
        /// メッセージ：無線LANなし
        /// </summary>
        public const string MESSAGE_ERROR_WLAN_NOT = "ワイヤレスＬＡＮが使用できません。\n設定確認して再度実行してください。";

        /// <summary>
        /// メッセージ：無線LANサービスエラー
        /// </summary>
        public const string MESSAGE_ERROR_WLAN_SERVICE = "ＷＬＡＮ ＡｕｔｏＣｏｎｆｉｇが起動されていません。\n設定を確認して再度実行してください。";

        /// <summary>
        /// メッセージ：リトライを行うには、IGスイッチを「OFF」にした後で「ON」にする必要があります。\nIGスイッチの「OFF/ON」を行いましたか？
        /// </summary>
        public const string MESSAGE_IG_OFF_ON = "リトライを行う為にＩＧスイッチを「ＯＦＦ」にした後で「ＯＮ」にする必要があります。\n\nＩＧスイッチの「ＯＦＦ／ＯＮ」を行いましたか？";

        /// <summary>
        /// メッセージ：リトライ要求が失敗したか、既にリトライ実行中です。
        /// </summary>
        public const string MESSAGE_ERROR_RETRY = "リトライ要求が失敗したか、既にリトライ実行中です。";

        /// <summary>
        /// メッセージ：DTC消去要求に失敗
        /// </summary>
        public const string MESSAGE_ERROR_DTC_EXEC = "ＤＴＣ消去要求に失敗しました。\nＤＳＴのＬＥＤが全点灯しているか確認してください。";

        /// <summary>
        /// メッセージ：CSVファイル書込みエラー
        /// </summary>
        public const string MESSAGE_ERROR_CSV = "書込みに失敗しました。\n出力先を確認して再度実行してください。";

        // ------------------------------------------------------------------------------
        /// <summary>
        /// メッセージ：XMLファイル出力エラー
        /// </summary>
        public const string MESSAGE_ERROR_XML_OUTPUT = "署名要求XMLファイルの出力に失敗しました。";

        /// <summary>
        /// メッセージ：XMLファイル読込エラー
        /// </summary>
        public const string MESSAGE_ERROR_XML_INPUT = "署名応答XMLファイルの読み込みに失敗しました。\n取込ファイルが正しいか確認してください。";

        /// <summary>
        /// メッセージ：リトライ回数上限確認
        /// </summary>
        public const string MESSAGE_UPPER_LIMIT_RETRY = "リトライ回数が上限を超えました。リトライを継続しますか？";
    }
}
