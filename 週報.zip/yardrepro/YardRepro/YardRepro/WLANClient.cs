﻿using NLog;
using System.ServiceProcess;

namespace YardRepro
{
    /// <summary>
    /// 無線LANクライアントクラス
    /// </summary>
    class WLANClient : NativeWifi.WlanClient
    {

        /// <summary>
        /// ログ出力クラス
        /// </summary>
        private static readonly Logger log = LogManager.GetCurrentClassLogger();

        /// <summary>
        /// WiFiモジュール有無をチェック
        /// </summary>
        /// <returns>WiFiモジュール有の場合true</returns>
        /// ### 機能説明 #######
        /// -# WiFiモジュール有無をチェック
        /// -# WiFiモジュール数が0の場合
        ///     -# 戻り値Falseで返却
        /// -# 戻り値Trueで返却
        public bool IsWLanInterfaces()
        {
            // WiFiモジュール有無をチェック
            // WiFiモジュール数が0の場合
            if (this.Interfaces.Length == 0)
            {
                log.Debug("Interfaces None");
                return false;
            }
            return true;
        }

        /// <summary>
        /// WLAN AutoConfigサービスが起動しているかチェックする
        /// </summary>
        /// <returns>WLAN AutoConfigサービスが起動している場合true</returns>
        /// ### 機能説明 #######
        /// -# WLAN AutoConfigサービスのインスタンス生成
        /// -# サービス取得失敗した場合
        ///     -# 戻り値Falseで返却
        /// -# サービス起動中の場合
        ///     -# 戻り値Trueで返却
        /// -# 戻り値Falseで返却
        public static bool IsWLanAutoConfigAlive()
        {
            // WLAN AutoConfigサービスチェック
            log.Debug("START");

            ServiceController sc = new ServiceController(Consts.WLAN_AUTOCONFIG_SERVICE, ".");
            // サービス取得失敗
            if (sc == null)
            {
                log.Debug("ServiceController is null");
                return false;
            }

            // サービス起動中
            if (sc.Status == ServiceControllerStatus.Running)
            {
                log.Debug("ServiceController is Running");
                return true;
            }

            log.Debug("ServiceController is not Running");
            return false;
        }
    }
}
