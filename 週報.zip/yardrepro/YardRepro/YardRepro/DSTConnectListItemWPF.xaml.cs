﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using YardRepro.dto;
using NLog;

namespace YardRepro
{
    /// <summary>
    /// DST接続アイテムコントロール
    /// </summary>
    public partial class DSTConnectListItemWPF : UserControl
    {

        /// <summary>
        /// ログ出力クラス
        /// </summary>
        private static readonly Logger log = LogManager.GetCurrentClassLogger();

        /// <summary>
        /// コンストラクタ
        /// </summary>
        /// ### 機能説明 #######
        /// -# 画面コンポーネントの初期処理
        public DSTConnectListItemWPF()
        {
            InitializeComponent();
        }

        /// <summary>
        /// 選択チェンジイベント
        /// </summary>
        public event EventHandler OnSelectedChange;

        /// <summary>
        /// DST接続アイテムデータプロパティ
        /// </summary>
        public DSTDto DSTiDATA
        {
            get { return (DSTDto)GetValue(DstiDtoProperty); }
            set { SetValue(DstiDtoProperty, value); }
        }

        /// <summary>
        /// DST接続アイテムデータのデータバインディング用プロパティ
        /// </summary>
        public static readonly DependencyProperty DstiDtoProperty = DependencyProperty.Register("DSTiDATA", typeof(DSTDto), typeof(DSTConnectListItemWPF), new PropertyMetadata(default(DSTDto)));

        /// <summary>
        /// マウスクリックイベント
        /// </summary>
        /// <param name="sender">発生元オブジェクト</param>
        /// <param name="e">イベント引数</param>
        /// ### 機能説明 #######
        /// -# 選択チェックを逆にする
        /// -# DST接続アイテムの選択チェックを更新
        /// -# 選択チェック更新イベントを発生させる
        private void MouseClick(object sender, MouseButtonEventArgs e)
        {
            // 選択チェックを逆にする
            checkBox1.IsChecked = !checkBox1.IsChecked;
            // DST接続アイテムの選択チェックを更新
            DSTiDATA.isSelected = (bool)checkBox1.IsChecked;
            // 選択チェック更新イベントを発生させる
            if (OnSelectedChange != null) OnSelectedChange(this, EventArgs.Empty);
        }

        /// <summary>
        /// チェックボックスチェックイベント
        /// </summary>
        /// <param name="sender">発生元オブジェクト</param>
        /// <param name="e">イベント引数</param>
        /// ### 機能説明 #######
        /// -# 選択チェック更新イベントを発生させる
        private void checkBox1_Checked(object sender, RoutedEventArgs e)
        {
            // 選択チェック更新イベントを発生させる
            if (OnSelectedChange != null) OnSelectedChange(this, EventArgs.Empty);
        }

        /// <summary>
        /// チェックボックスアンチェックイベント
        /// </summary>
        /// <param name="sender">発生元オブジェクト</param>
        /// <param name="e">イベント引数</param>
        /// ### 機能説明 #######
        /// -# 選択チェック更新イベントを発生させる
        private void checkBox1_Unchecked(object sender, RoutedEventArgs e)
        {
            // 選択チェック更新イベントを発生させる
            if (OnSelectedChange != null) OnSelectedChange(this, EventArgs.Empty);
        }
        
    }
}
