﻿
namespace dstwifiReconect.dto
{
    public class HDSInfoDto
    {
        // 言語情報取得レジストリ
        public string languageregistry { get; set; }
        // 仕向け情報取得レジストリ
        public string marketregistry { get; set; }
        // 仕向け情報取得レジストリ(LAC)
        public string lacmarketregistry { get; set; }
        // 販売店番号取得レジストリ
        public string dealernumberregistry { get; set; }
        // 国コード取得レジストリ
        public string isocoderegistry { get; set; }
        // 言語情報デフォルト
        public string language_default { get; set; }
    }
}
