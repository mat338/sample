﻿using System;
using System.Collections.Generic;
using System.Text;

namespace dstwifiReconect.dto
{
    public class DefinitionDetailDto
    {
        // HDS情報
        public HDSInfoDto hdsinfo { get; set; }
        // ログ出力先
        public string logfilepath { get; set; }
        // ソケット通信のリトライ回数
        public int socketRetryCount { get; set; }
        // アドホック接続用IPアドレス
        public string adhocIPAddress { get; set; }
        // バージョン
        public string version { get; set;}
        // Pingの送信要否
        public bool pingSendFlg { get; set; }
        // Pingのリトライ回数
        public int pingRetryCount { get; set; }
        // Pingのリトライ間隔
        public int pingRetryInterval { get; set; }
        // Pingのタイムアウト時間
        public int pingTimeout { get; set; }
        // 連続でPing送信する際の送信間隔
        // 0ならPing送信自体を行わない
        public int pingInterval { get; set; }
        // 連続でPing送信する際の送信数
        public int pingCountAtOnce { get; set; }
        // 連続未検出回数(表示に至れば検出、UDP限定)
        // この回数を超えると一覧から削除
        public int noDetectLimit { get; set; }
    }
}
