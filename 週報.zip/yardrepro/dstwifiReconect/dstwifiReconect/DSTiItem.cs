﻿using System;
using System.Windows.Forms;
using dstwifiReconect.dto;
using System.Drawing;
using NLog;

namespace dstwifiReconect
{
    /// <summary>
    /// DST-i情報表示アイテム
    /// </summary>
    public partial class DSTiItem : UserControl
    {
        /// <summary>
        /// ログ出力クラス
        /// </summary>
        private static readonly Logger log = LogManager.GetCurrentClassLogger();

        /// <summary>
        /// DST-i情報
        /// </summary>
        public DSTiDto dstiDto { get; set; }

        /// <summary>
        /// 設定ファイル格納クラス
        /// </summary>
        private DefinitionDetailDto defDetailDto;

        /// <summary>
        /// 文言格納クラス
        /// </summary>
        private LanguageDto languageDto;

        /// <summary>
        /// 選択されたDST-iの背景色
        /// </summary>
        private Color selectedColor = Color.FromArgb(185, 209, 234);

        /// <summary>
        /// 未検出回数
        /// </summary>
        private int noDetectCount = 0;

        /// <summary>
        /// コンストラクタ
        /// </summary>
        /// <param name="dstiDto">初期設定するDST-i情報</param>
        public DSTiItem(DSTiDto dstiDto, LanguageDto languageDto, DefinitionDetailDto defDetailDto)
        {
            
            InitializeComponent();

            this.dstiDto = dstiDto;
            this.languageDto = languageDto;
            this.defDetailDto = defDetailDto;
        }

        /// <summary>
        /// 子要素にマウスダウンイベントを付与する
        /// </summary>
        /// <param name="e">追加するイベント</param>
        public void addMouseDownEvent(MouseEventHandler e)
        {
            this.MouseDown += e;
            this.lblSerialNo.MouseDown += e;
            this.lblStatus.MouseDown += e;
            this.pbDefaultConnect.MouseDown += e;
            this.pbConnectMode.MouseDown += e;
            this.lblColor.MouseDown += e;
        }

        /// <summary>
        /// DST-iアイテムにマウスエンターイベントを付与する
        /// </summary>
        /// <param name="e"></param>
        public void AddMouseEnterEvent(EventHandler e)
        {
            this.MouseEnter += e;
        }

        /// <summary>
        /// アイテムが選択された場合の処理
        /// </summary>
        public void selected()
        {
            this.BackColor = selectedColor;
            this.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
        }

        /// <summary>
        /// アイテムが選択されなかった場合の処理
        /// </summary>
        public void notSelected()
        {
            this.BackColor = SystemColors.Control;
            this.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
        }

        /// <summary>
        /// 描画イベントをオーバーライド
        /// </summary>
        /// <param name="pe"></param>
        protected override void OnPaint(PaintEventArgs pe)
        {

            //シリアルNo.
            if (string.IsNullOrEmpty(dstiDto.serialNo))
            {
                this.lblSerialNo.Text = "";
            }
            else
            {
                this.lblSerialNo.Text = languageDto.connectionManager.serialNoPrefix + dstiDto.serialNo;
            }

            //通常使用アイコン
            bool lblDefaultConnectVisible;
            if (dstiDto.defaultConnect)
            {
                lblDefaultConnectVisible = true;
            }
            else
            {
                lblDefaultConnectVisible = false;
            }
            pbDefaultConnect.Visible = lblDefaultConnectVisible;

            //接続モード
            switch (dstiDto.connectMode)
            {
                case Consts.ConnectMode.ADHOC:
                    //pbConnectMode.Image = global::dstwifiReconect.Properties.Resources.adhoc;
                    break;
                case Consts.ConnectMode.INFRA:
                    //pbConnectMode.Image = global::dstwifiReconect.Properties.Resources.infra;
                    break;
                default:
                    pbConnectMode.Visible = false;
                    break;
            }

            //接続状態
            string status = "";
            if (isConnectable())
            {
                //接続可
                status = languageDto.connectionManager.connectStatus.connectable;
            }
            else if (isUnconnectable())
            {
                //接続不可
                status = String.Format(languageDto.connectionManager.connectStatus.unconnectable, dstiDto.hostName);
            }
            else
            {
                log.Debug("invalid status - hostName [" + dstiDto.hostName + "]");
            }
            this.lblStatus.Text = status;

            //仕向け先がカナダの場合
            if(ConnectionManagerUtil.isCanada(ConnectionManagerUtil.getHDSMarket(defDetailDto))) {
                //色情報
                byte[] rgb = dstiDto.color;
                this.lblColor.BackColor = Color.FromArgb(rgb[0], rgb[1], rgb[2]);
            }
            
            base.OnPaint(pe);
        }

        /// <summary>
        /// DST-iが接続可能か否かを返す
        /// </summary>
        /// <returns>接続可能な場合、true</returns>
        public bool isConnectable()
        {
            //接続中でない かつ ホスト名未設定 または 自PC名と一致の場合はの場合は接続可
            return dstiDto.connection == 0 && (String.IsNullOrEmpty(dstiDto.hostName) || Environment.MachineName.Equals(dstiDto.hostName));
        }

        /// <summary>
        /// DST-iに接続不可か否かを返す
        /// </summary>
        /// <returns>接続不可の場合、true</returns>
        public bool isUnconnectable()
        {
            //接続中の場合 または ホスト名設定あり かつ 自PC名と不一致の場合は接続不可
            return dstiDto.connection == 1 || (!String.IsNullOrEmpty(dstiDto.hostName) && !Environment.MachineName.Equals(dstiDto.hostName));
        }

        /// <summary>
        /// 連続未検出回数を加算する
        /// </summary>
        public void countupNoDetect()
        {
            /*
            if(dstiDto.communicationMode.Equals(Consts.CommunicationMode.UDP))
            {
                this.noDetectCount++;
            }
            */
            this.noDetectCount++;
        }

        /// <summary>
        /// 連続未検出回数をクリアする
        /// </summary>
        public void clearNoDetect()
        {
            this.noDetectCount = 0;
        }

        /// <summary>
        /// 連続未検出回数を返す
        /// </summary>
        public int CurrentNoDetect
        {
            get{ return this.noDetectCount; }
        }

        #region トライアルモード関数
        /// <summary>
        /// トライアルモード用に色情報を強制表示する
        /// </summary>
        public void setColorForTrial()
        {
            byte[] rgb = dstiDto.color;
            this.lblColor.BackColor = Color.FromArgb(rgb[0], rgb[1], rgb[2]);
        }
        #endregion
    }
}
