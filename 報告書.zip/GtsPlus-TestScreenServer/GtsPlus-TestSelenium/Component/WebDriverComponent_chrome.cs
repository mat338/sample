﻿using GtsPlus_TestSelenium.Constant;
using OpenQA.Selenium;
using OpenQA.Selenium.Edge;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Remote;
using OpenQA.Selenium.Support.Extensions;
using OpenQA.Selenium.Support.UI;
using System;
using System.IO;
using System.Reflection;
using System.Drawing.Imaging;
using IWshRuntimeLibrary;
using System.Xml.Linq;
using System.Collections.Generic;
using System.Threading;
using System.Collections.ObjectModel;

namespace GtsPlus_TestSelenium.Component
{
    /// <summary>
    /// 共通_WebDriver(Chrome)操作用コンポーネントクラス
    /// </summary>
    public class WebDriverComponent : IDisposable
    {
        /// <summary>
        /// ChromeDriver
        /// </summary>
        //private ChromeDriver chromeDriver;

        /// <summary>
        /// WebDriverWait
        /// </summary>
        private WebDriverWait webDriverWait;

        RemoteWebDriver driver;

        /// <summary>
        /// コンストラクタ
        /// </summary>
        /// <param name="IsHeadlessMode">ヘッドレスモード判定</param>
        /// <param name="timeoutMilliSeconds">タイムアウト時間(ミリ秒)</param>
        public WebDriverComponent(bool IsHeadlessMode, int timeoutMilliSeconds)
        {
            EdgeOptions optionsEdge = new EdgeOptions();
            optionsEdge.SetLoggingPreference(LogType.Browser, LogLevel.All);
            optionsEdge.AddArgument(Constants.WebDriverOption.HEADLESS_MODE);

            string serverPath = Directory.GetCurrentDirectory();
            driver = new EdgeDriver(serverPath, optionsEdge);

            webDriverWait = new WebDriverWait(driver, TimeSpan.FromMilliseconds(timeoutMilliSeconds));

            // 暗黙的待機 (要素を検索するときに、見つけられるまで指定時間分だけ待つ)
            //driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);

            //if (IsHeadlessMode)
            //{
            //    var chromeOptions = new ChromeOptions();
            //    chromeOptions.AddArgument(Constants.WebDriverOption.HEADLESS_MODE);
            //    chromeDriver = new ChromeDriver(Path.GetDirectoryName(Assembly.GetEntryAssembly().Location), chromeOptions);
            //}
            //else
            //{
            //    ChromeOptions options = new ChromeOptions();
            //    options.SetLoggingPreference(LogType.Browser, LogLevel.All);

            //    //chromeDriver = new ChromeDriver(Path.GetDirectoryName(Assembly.GetEntryAssembly().Location), options);
            //    chromeDriver = new ChromeDriver(Path.GetDirectoryName(Assembly.GetEntryAssembly().Location), options);
            //}

        }

        /// <summary>
        /// ページオープン処理(ID指定・待機あり)
        /// </summary>
        /// <param name="url">URL</param>
        /// <param name="waitTargetId">待機対象要素のID</param>
        public void OpenPageAndWaitByID(string url, string waitTargetId)
        {
            chromeDriver.Navigate().GoToUrl(@url);
            webDriverWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.Id(waitTargetId)));
        }

        /// <summary>
        /// ページオープン処理(ID指定・待機あり)
        /// </summary>
        /// <param name="url">URL</param>
        /// <param name="waitTargetId">待機対象要素のID</param>
        public void OpenPage(string url)
        {
            chromeDriver.Navigate().GoToUrl(@url);
        }

        /// <summary>
        /// 入力処理(ID指定)
        /// </summary>
        /// <param name="value">入力値</param>
        /// <param name="targetId">対象要素のID</param>
        public void TypeById(string value, string targetId)
        {
            chromeDriver.FindElementById(targetId).SendKeys(value);
        }

        /// <summary>
        /// 入力値クリア処理(ID指定)
        /// </summary>
        /// <param name="targetId">対象要素のID</param>
        public void ClearById(string targetId)
        {
            chromeDriver.FindElementById(targetId).Clear();
        }

        /// <summary>
        /// 値取得処理(ID指定)
        /// </summary>
        /// <param name="targetId">対象要素のID</param>
        /// <returns>値</returns>
        public string GetValueById(string targetId)
        {
            return chromeDriver.FindElementById(targetId).Text;
        }

        /// <summary>
        /// 値取得処理(ID指定-select)
        /// </summary>
        /// <param name="targetId">対象要素のID</param>
        /// <returns>値</returns>
        public string SelectValueById(string targetId)
        {
            //IWebElement selectElement = chromeDriver.FindElementById(targetId);
            return chromeDriver.FindElementById(targetId).GetAttribute("value");
        }

        /// <summary>
        /// Text取得処理(ID指定-select)
        /// </summary>
        /// <param name="targetId">対象要素のID</param>
        /// <returns>値</returns>
        public string SelectTextById(string targetId)
        {
            //IWebElement selectElement = chromeDriver.FindElementById(targetId);
            return chromeDriver.FindElementById(targetId).GetAttribute("Text");
        }

        /// <summary>
        /// クリック処理(ID指定)
        /// </summary>
        /// <param name="targetId">対象要素のID</param>
        public void ClickById(string targetId)
        {
            chromeDriver.FindElementById(targetId).Click();
        }

        /// <summary>
        /// オプションリスト選択処理
        /// </summary>
        /// <param name="targetId">対象要素のID</param>
        /// <param name="upDown">現在選択インデックスから変更する方向(true:up、false:down)</param>
        /// <param name="idx">変更インデックス数</param>
        public void SelectOptionById(string targetId, bool upDown, int idx)
        {
            IWebElement selectElement = chromeDriver.FindElementById(targetId);
            Thread.Sleep(1000);

            // リスト表示
            selectElement.Click();
            Thread.Sleep(1000);
            // 移動
            for (int i = 1; i <= idx; i++)
            {
                // 矢印キーの方向別
                if (upDown)
                {
                    // 「↑」キー
                    selectElement.SendKeys(Keys.ArrowUp);
                }
                else
                {
                    // 「↓」キー
                    selectElement.SendKeys(Keys.ArrowDown);
                }
                Thread.Sleep(1000);
            }
            // 選択
            selectElement.SendKeys(Keys.Return);
            Thread.Sleep(1000);
        }

        /// <summary>
        /// クリック可能状態になるまでの待機処理(ID指定)
        /// </summary>
        /// <param name="waitTargetId">待機対象要素のID</param>
        public void WaitUntilClickableById(string waitTargetId)
        {
            webDriverWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementToBeClickable(By.Id(waitTargetId)));
        }

        /// <summary>
        /// 要素表示判定
        /// </summary>
        /// <param name="targetId">対象要素のID</param>
        public bool IsDisplayedById(string targetId)
        {
            return chromeDriver.FindElementById(targetId).Displayed;
        }

        /// <summary>
        /// 有効判定
        /// </summary>
        /// <param name="targetId">対象要素のID</param>
        /// <returns>true:有効/false:無効</returns>
        public bool IsEnableById(string targetId)
        {
            return chromeDriver.FindElementById(targetId).Enabled;
        }

        /// <summary>
        /// 画面キャプチャー取得
        /// </summary>
        /// <param name="saveFolder">保存フォルダ</param>
        /// <param name="saveName">保存ファイル名</param>
        public void GetScreenshot(string saveFolder, string saveName)
        {
            chromeDriver.GetScreenshot().SaveAsFile(saveFolder + "/" + saveName + ".png");
        }

        /// <summary>
        /// ブラウザログの取得
        /// </summary>
        public ReadOnlyCollection<LogEntry> GetWebLog()
        {
            return chromeDriver.Manage().Logs.GetLog(LogType.Browser);
            //ReadOnlyCollection<LogEntry> entries = chromeDriver.Manage().Logs.GetLog(LogType.Browser);
            //foreach (var entry in entries)
            //{
            //    Console.WriteLine(entry.ToString());
            //}

            //return entries;
        }

        /// <summary>
        /// 画面更新
        /// </summary>
        public void RefreshScreen()
        {
            chromeDriver.Navigate().Refresh();
        }

        /// <summary>
        /// 破棄処理
        /// </summary>
        public void Dispose()
        {
            if (chromeDriver != null)
            {
                chromeDriver.Dispose();
            }
        }
    }
}
