﻿using System;
using System.Diagnostics;
using GtsPlus_TestSelenium.Constant;

namespace GtsPlus_TestSelenium.Component
{
    /// <summary>
    /// 共通_Http Serverユーティリティクラス
    /// </summary>
    public class HttpServer
    {
        /// <summary>
        /// procHttpSever
        /// </summary>
        Process procHttpSever = null;

        /// <summary>
        /// dir
        /// </summary>
        string dir = null;

        /// <summary>
        /// コンストラクタ
        /// <param name="dir">起動ディレクトリ</param>
        /// </summary>
        public HttpServer(string dir)
        {
            this.dir = dir;
        }

        /// <summary>
        /// HTTP Server起動
        /// </summary>
        public void StartHTTPServer()
        {
            ProcessStartInfo pInfo = new ProcessStartInfo();
            pInfo.FileName = dir + Constants.FilePath.HTTP_SERVER;
            pInfo.UseShellExecute = true;
            pInfo.CreateNoWindow = true;
            procHttpSever = Process.Start(pInfo);
        }

        /// <summary>
        /// HTTP Server停止
        /// </summary>
        /// <param name="procHttpSever">起動プロセス</param>
        /// <returns>値</returns>
        public void StopHTTPServer()
        {
            // httpサーバー終了
            if (procHttpSever != null)
            {
                procHttpSever.CloseMainWindow();
                procHttpSever.Close();
            }
        }
    }
}
