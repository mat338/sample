﻿using GtsPlus_TestSelenium.Constant;
using OpenQA.Selenium;
using OpenQA.Selenium.Edge;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Remote;
using OpenQA.Selenium.Support.Extensions;
using OpenQA.Selenium.Support.UI;
using System;
using System.IO;
using System.Reflection;
using System.Drawing.Imaging;
using IWshRuntimeLibrary;
using System.Xml.Linq;
using System.Collections.Generic;
using System.Threading;
using System.Collections.ObjectModel;

namespace GtsPlus_TestSelenium.Component
{
    /// <summary>
    /// 共通_WebDriver(Chrome)操作用コンポーネントクラス
    /// </summary>
    public class WebDriverComponent : IDisposable
    {
        /// <summary>
        /// ChromeDriver
        /// </summary>
        //private ChromeDriver driver;

        /// <summary>
        /// WebDriverWait
        /// </summary>
        private WebDriverWait webDriverWait;

        RemoteWebDriver driver;

        /// <summary>
        /// コンストラクタ
        /// </summary>
        /// <param name="IsHeadlessMode">ヘッドレスモード判定</param>
        /// <param name="timeoutMilliSeconds">タイムアウト時間(ミリ秒)</param>
        public WebDriverComponent(bool IsHeadlessMode, int timeoutMilliSeconds)
        {
            EdgeOptions options = new EdgeOptions();
            options.SetLoggingPreference(LogType.Browser, LogLevel.All);

            string serverPath = Directory.GetCurrentDirectory();

            if (IsHeadlessMode)
            {
                options.AddArgument(Constants.WebDriverOption.HEADLESS_MODE);
                driver = new EdgeDriver(serverPath, options);
            }
            else
            {
                driver = new EdgeDriver(serverPath, options);
            }

            webDriverWait = new WebDriverWait(driver, TimeSpan.FromMilliseconds(timeoutMilliSeconds));
        }

        /// <summary>
        /// ページオープン処理(ID指定・待機あり)
        /// </summary>
        /// <param name="url">URL</param>
        /// <param name="waitTargetId">待機対象要素のID</param>
        public void OpenPageAndWaitByID(string url, string waitTargetId)
        {
            driver.Navigate().GoToUrl(@url);
            webDriverWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.Id(waitTargetId)));
        }

        /// <summary>
        /// ページオープン処理(ID指定・待機あり)
        /// </summary>
        /// <param name="url">URL</param>
        /// <param name="waitTargetId">待機対象要素のID</param>
        public void OpenPage(string url)
        {
            driver.Navigate().GoToUrl(@url);
        }

        /// <summary>
        /// 入力処理(ID指定)
        /// </summary>
        /// <param name="value">入力値</param>
        /// <param name="targetId">対象要素のID</param>
        public void TypeById(string value, string targetId)
        {
            driver.FindElementById(targetId).SendKeys(value);
        }

        /// <summary>
        /// 入力値クリア処理(ID指定)
        /// </summary>
        /// <param name="targetId">対象要素のID</param>
        public void ClearById(string targetId)
        {
            driver.FindElementById(targetId).Clear();
        }

        /// <summary>
        /// 値取得処理(ID指定)
        /// </summary>
        /// <param name="targetId">対象要素のID</param>
        /// <returns>値</returns>
        public string GetValueById(string targetId)
        {
            try
            {
                return driver.FindElementById(targetId).Text;
            }
            catch
            {
                return null;
            }
        }

        /// <summary>
        /// 値取得処理(ID指定)
        /// </summary>
        /// <param name="targetId">対象要素のID</param>
        /// <returns>値</returns>
        public string GetValueByIdNoneDisplay(string targetId)
        {
            try
            {
                return driver.FindElementById(targetId).GetAttribute("Value");
            }
            catch
            {
                return null;
            }
        }

        /// <summary>
        /// 値取得処理(ID指定-select)
        /// </summary>
        /// <param name="targetId">対象要素のID</param>
        /// <returns>値</returns>
        public string SelectValueById(string targetId)
        {
            //
            try
            {
                return driver.FindElementById(targetId).GetAttribute("value");
            }
            catch
            {
                return null;
            }
        }

        /// <summary>
        /// Text取得処理(ID指定-select)
        /// </summary>
        /// <param name="targetId">対象要素のID</param>
        /// <returns>値</returns>
        public string SelectTextById(string targetId)
        {
            //IWebElement selectElement = driver.FindElementById(targetId);
            return driver.FindElementById(targetId).GetAttribute("Text");
        }

        /// <summary>
        /// クリック処理(ID指定)
        /// </summary>
        /// <param name="targetId">対象要素のID</param>
        public void ClickById(string targetId)
        {
            driver.FindElementById(targetId).Click();
        }

        /// <summary>
        /// クリック処理([ECU名]指定)
        /// </summary>
        /// <param name="targetId">対象要素のECU ID</param>
        public void ClickByEcuName(string targetId)
        {
            driver.FindElementByXPath("//P[@data-name='" + targetId + "']").Click();
        }

        /// <summary>
        /// オプションリスト選択処理
        /// </summary>
        /// <param name="targetId">対象要素のID</param>
        /// <param name="upDown">現在選択インデックスから変更する方向(true:up、false:down)</param>
        /// <param name="idx">変更インデックス数</param>
        public void SelectOptionById(string targetId, bool upDown, int idx)
        {
            IWebElement selectElement = driver.FindElementById(targetId);
            Thread.Sleep(1000);

            // リスト表示
            selectElement.Click();
            Thread.Sleep(1000);
            // 移動
            for (int i = 1; i <= idx; i++)
            {
                // 矢印キーの方向別
                if (upDown)
                {
                    // 「↑」キー
                    selectElement.SendKeys(Keys.ArrowUp);
                }
                else
                {
                    // 「↓」キー
                    selectElement.SendKeys(Keys.ArrowDown);
                }
                Thread.Sleep(1000);
            }
            // 選択
            selectElement.SendKeys(Keys.Return);
            Thread.Sleep(1000);
        }

        /// <summary>
        /// クリック可能状態になるまでの待機処理(ID指定)
        /// </summary>
        /// <param name="waitTargetId">待機対象要素のID</param>
        public void WaitUntilClickableById(string waitTargetId)
        {
            webDriverWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementToBeClickable(By.Id(waitTargetId)));
        }

        /// <summary>
        /// 要素表示判定
        /// </summary>
        /// <param name="targetId">対象要素のID</param>
        public bool IsDisplayedById(string targetId)
        {
            bool ret = false;
            try
            {
                ret = driver.FindElementById(targetId).Displayed;
            }
            catch
            {
                // 項目が画面に無い場合Exception発生。この場合はFalseを返却する
            }

            return ret;
        }

        /// <summary>
        /// 要素表示判定([ECU名]指定)
        /// </summary>
        /// <param name="targetId">対象要素のECU ID</param>
        public bool IsDisplayedByEcuName(string targetId)
        {
            bool ret = false;
            try
            {
                ret = driver.FindElementByXPath("//P[@data-name='" + targetId + "']").Displayed;
            }
            catch
            {
                // 項目が画面に無い場合Exception発生。この場合はFalseを返却する
            }

            return ret;
        }

        /// <summary>
        /// 要素表示判定(Name)
        /// </summary>
        /// <param name="targetId">対象要素のID</param>
        public bool IsDisplayedByName(string targetId)
        {
            bool ret = false;
            try
            {
                ret = driver.FindElementByName(targetId).Displayed;
            }
            catch
            {
                // 項目が画面に無い場合Exception発生。この場合はFalseを返却する
            }

            return ret;
        }

        /// <summary>
        /// 有効判定
        /// </summary>
        /// <param name="targetId">対象要素のID</param>
        /// <returns>true:有効/false:無効</returns>
        public bool IsEnableById(string targetId)
        {
            return driver.FindElementById(targetId).Enabled;
        }

        /// <summary>
        /// 画面キャプチャー取得
        /// </summary>
        /// <param name="saveFolder">保存フォルダ</param>
        /// <param name="saveName">保存ファイル名</param>
        public void GetScreenshot(string saveFolder, string saveName)
        {
            driver.GetScreenshot().SaveAsFile(saveFolder + "/" + saveName + ".png");
        }

        /// <summary>
        /// ブラウザログの取得（Chrome/Chromedriverのみ対応）
        /// </summary>
        public ReadOnlyCollection<LogEntry> GetWebLog()
        {
            return driver.Manage().Logs.GetLog(LogType.Browser);

            //ReadOnlyCollection<LogEntry> entries = driver.Manage().Logs.GetLog(LogType.Browser);
            //foreach (var entry in entries)
            //{
            //    Console.WriteLine(entry.ToString());
            //}

            //return entries;
        }

        /// <summary>
        /// 画面更新
        /// </summary>
        public void RefreshScreen()
        {
            driver.Navigate().Refresh();
        }

        /// <summary>
        /// 破棄処理
        /// </summary>
        public void Dispose()
        {
            if (driver != null)
            {
                driver.Dispose();
            }
        }
    }
}
