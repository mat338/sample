﻿using System;
using System.IO;
using System.Threading;
using System.Diagnostics;
using System.Linq;
using IWshRuntimeLibrary;
using log4net;
using GtsPlus_TestSelenium.Constant;
using System.Collections.ObjectModel;
using OpenQA.Selenium;
using System.Text;

namespace GtsPlus_TestSelenium.Utils
{
    /// <summary>
    /// 共通_ファイル操作関連ユーティリティクラス
    /// </summary>
    public static class FileUtils
    {
        /// <summary>
        /// ディレクトリのコピー処理
        /// </summary>
        /// <param name="sourcePath">コピー元フォルダ</param>
        /// <param name="destinationPath">コピー先フォルダ</param>
        public static void DirectoryCopy(string sourcePath, string destinationPath)
        {
            DirectoryInfo sourceDirectory = new DirectoryInfo(sourcePath);
            DirectoryInfo destinationDirectory = new DirectoryInfo(destinationPath);

            //コピー先のディレクトリがなければ作成する
            if (destinationDirectory.Exists == false)
            {
                destinationDirectory.Create();
                destinationDirectory.Attributes = sourceDirectory.Attributes;
            }

            //ファイルのコピー
            foreach (FileInfo fileInfo in sourceDirectory.GetFiles())
            {
                //同じファイルが存在していたら、常に上書きする
                fileInfo.CopyTo(destinationDirectory.FullName + @"\" + fileInfo.Name, true);
            }

            //ディレクトリのコピー（再帰を使用）
            foreach (DirectoryInfo directoryInfo in sourceDirectory.GetDirectories())
            {
                DirectoryCopy(directoryInfo.FullName, destinationDirectory.FullName + @"\" + directoryInfo.Name);
            }
        }

        /// <summary>
        /// エビデンスディレクトリの作成処理
        /// </summary>
        /// <param name="evidencePath">エビデンスフォルダ</param>
        public static void createEvidenceDirectory(string evidencePath)
        {
            if (Directory.Exists(evidencePath))
            {
                // 古いフォルダを削除
                Directory.Delete(evidencePath, true);
                Thread.Sleep(500);
            }

            // フォルダ作成
            DirectoryInfo evidenceDirectory = new DirectoryInfo(evidencePath);
            evidenceDirectory.Create();
        }

        /// <summary>
        /// PFの再起動処理
        /// </summary>
        /// <param name="currentDir">GTSPlusArbitration.exeのショートカットファイルパス</param>
        public static void rebootPF(string currentDir)
        {
            // PF終了
            stopPF();
            Thread.Sleep(5000);

            // PFの起動
            startPF(currentDir);
            Thread.Sleep(2000);
        }

        /// <summary>
        /// PFの再起動処理（KantanWebServer起動あり）
        /// </summary>
        /// <param name="currentDir">GTSPlusArbitration.exeのショートカットファイルパス</param>
        /// <param name="proc">WebServer用プロセス</param>
        public static void rebootPF_WebServer(string currentDir, Process proc)
        {
            // PF終了
            stopPF();
            Thread.Sleep(2000);

            // KantanWebServer起動
            startWebServer(currentDir, proc);
            Thread.Sleep(10000);

            // PRの起動
            startPF(currentDir);
            Thread.Sleep(2000);
        }

        /// <summary>
        /// PFの終了処理
        /// </summary>
        public static void stopPF()
        {
            //プロセスを強制的に終了させる
            Process.GetProcessesByName(Constants.PF.GTS_PLUS_ARBITRATION).ToList().ForEach(p => p.Kill());
            Process.GetProcessesByName(Constants.PF.GTS_PLUS).ToList().ForEach(p => p.Kill());
        }

        /// <summary>
        /// PFの起動処理
        /// <param name="currentDir">GTSPlusArbitration.exeのショートカットファイルパス</param>
        /// </summary>
        public static void startPF(string currentDir)
        {
            var proc = new Process();
            proc.StartInfo.FileName = currentDir + "/" + Constants.PF.GTS_PLUS_ARBITRATION;
            proc.Start();
        }

        /// <summary>
        /// PF LOGファイルの削除
        /// <param name="currentDir">カレントディレクトリ</param>
        /// </summary>
        public static void deletePfLogFile(string currentDir)
        {
            // ショートカットのリンク先の取得
            string shortcutPath = getShortcutLink(currentDir);

            if (Directory.Exists(shortcutPath + "logs"))
            {
                Directory.Delete(shortcutPath + "logs", true);
                Thread.Sleep(2000);
            }
        }

        /// <summary>
        /// WebServerの起動処理
        /// <param name="currentDir">GTSPlusArbitration.exeのショートカットファイルパス</param>
        /// <param name="proc">WebServer用プロセス</param>
        /// </summary>
        public static void startWebServer(string currentDir, Process proc)
        {
            //var proc = new Process();
            proc.StartInfo.FileName = currentDir + Constants.FilePath.WEB_SERVER;
            proc.Start();
        }

        /// <summary>
        /// ショートカットのリンク先の取得
        /// </summary>
        /// <param name="currentDir">GTSPlusArbitration.exeのショートカットファイルパス</param>
        public static string getShortcutLink(string currentDir)
        {
            string[] files = Directory.GetFiles(currentDir, "*");

            foreach (string file in files)
            {
                //拡張子取得
                string extension = Path.GetExtension(file);

                //ショートカット
                if (extension.Equals(".lnk"))
                {
                    //Windows Script Host Object Model参照
                    WshShell shell = new WshShell();
                    IWshShortcut sc = (IWshShortcut)shell.CreateShortcut(file);

                    // ショートカットのリンク先の取得
                    return string.Format("{0}/{1}", sc.WorkingDirectory, Path.GetFileName(null));
                }
            }

            return "";
        }

        /// <summary>
        /// ファイル内容読み込み処理
        /// </summary>
        /// <param name="filePath">ファイルパス</param>
        /// <returns>ファイル内容</returns>
        public static string ReadFileContent(string filePath)
        {
            string content = "";
            // 読み込みたいテキストを開く
            using (StreamReader st = new StreamReader(filePath, Encoding.GetEncoding("UTF-8")))
            {
                // テキストファイルをString型で読み込む
                content = st.ReadToEnd();
            }

            return content;
        }

        /// <summary>
        /// ファイル出力処理（追記）
        /// </summary>
        /// <param name="evidenceFile">ファイルパス</param>
        /// <param name="content">出力内容</param>
        public static void WriteLog(string evidenceFile, string content)
        {
            FileStream stream = null;
            StreamWriter sW = null;
            TextWriter writerSync = null;

            try
            {
                // ファイルを排他ロックする
                using (stream = new FileStream(evidenceFile, FileMode.Append, FileAccess.Write, FileShare.None))
                using (sW = new StreamWriter(stream))
                using (writerSync = TextWriter.Synchronized(sW))
                {
                    writerSync.WriteLine(content);
                    writerSync.Flush();
                }
            }
            catch (IOException ioe)
            {
                throw(ioe);
            }
       }


        /// <summary>
        /// URI ⇒ ファイルパス変換処理
        /// </summary>
        /// <param name="source">ソース</param>
        /// <returns>変換結果</returns>
        public static string UriToFilePath(string source)
        {
            return source.Replace("/", "\\");
        }

        /// <summary>
        /// Jsonファイル出力処理
        /// </summary>
        /// <param name="fileName">出力ファイル名</param>
        /// <param name="json">出力内容</param>
        public static void WriteJson(string fileName, string json)
        {
            Encoding utf8Enc = Encoding.GetEncoding("utf-8");
            // テキストファイルを開いて（なければ作って）StreamWriterオブジェクトを得る
            using (StreamWriter writer = new StreamWriter(fileName, false, utf8Enc))
            {
                // ファイルにテキストを書き込む
                writer.WriteLine(json);
            }
        }
    }
}
