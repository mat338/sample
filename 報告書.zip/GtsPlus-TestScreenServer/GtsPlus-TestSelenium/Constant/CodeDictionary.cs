﻿using System;
using System.Collections.Generic;

namespace GtsPlus_TestSelenium.Constant
{
    /// <summary>
    /// 共通_コード定義クラス
    /// </summary>
    public class CodeDictionary
    {

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public CodeDictionary()
        {
        }

        /// <summary>
        /// 仕向一覧
        /// </summary>
        /// <returns>regionDic</returns>
        public Dictionary<string, string> RegionDictionary()
        {
            Dictionary<string, string>  regionDic = new Dictionary<string, string>();

            regionDic.Add("1", "NA");
            regionDic.Add("2", "EU");
            regionDic.Add("3", "JP");
            regionDic.Add("4", "OT");

            return regionDic;
        }

        /// <summary>
        /// 言語一覧
        /// </summary>
        /// <returns>KeyCodesDic</returns>
        public Dictionary<string, string> LanguageDictionary()
        {
            Dictionary<string, string> languageDic = new Dictionary<string, string>();

            languageDic.Add("1", "EN");
            languageDic.Add("2", "DE");
            languageDic.Add("3", "FR");
            languageDic.Add("4", "ES");
            languageDic.Add("5", "IT");
            languageDic.Add("6", "ZH");
            languageDic.Add("7", "JA");
            languageDic.Add("8", "SV");
            languageDic.Add("10", "PT");
            languageDic.Add("11", "PL");
            languageDic.Add("12", "NO");
            languageDic.Add("13", "HU");
            languageDic.Add("14", "EL");
            languageDic.Add("16", "RU");
            languageDic.Add("17", "TR");
            languageDic.Add("18", "CS");
            languageDic.Add("19", "NL");
            languageDic.Add("20", "FI");
            languageDic.Add("21", "DA");

            return languageDic;
        }

        /// <summary>
        /// ダイアグ種別（PHASE5）
        /// </summary>
        /// <returns>regionDic</returns>
        public Dictionary<string, string> Kind5Dictionary()
        {
            Dictionary<string, string> kindDic = new Dictionary<string, string>();

            kindDic.Add("0", "ダイアグなし");   // ダイアグなし
            kindDic.Add("1", "Test Failed");    // 現在ダイアグ、TestFail(最新)
            kindDic.Add("2", "Curr Conf");      // 過去ダイアグ、Confirmed(確定)
            kindDic.Add("3", "対象外");         // レディネスダイアグ
            kindDic.Add("4", "Pend");           // ペンディング
            kindDic.Add("5", "Perm");           // パーマネント
            kindDic.Add("6", "対象外");         // 予兆

            return kindDic;
        }

        /// <summary>
        /// ダイアグ種別（PHASE4）
        /// </summary>
        /// <returns>regionDic</returns>
        public Dictionary<string, string> Kind4Dictionary()
        {
            Dictionary<string, string> kindDic = new Dictionary<string, string>();

            kindDic.Add("0", "ダイアグなし");   // ダイアグなし
            kindDic.Add("1", "Curr Conf");      // 現在ダイアグ、TestFail(最新)
            kindDic.Add("2", "Hist");           // 過去ダイアグ、Confirmed(確定)
            kindDic.Add("3", "対象外");         // レディネスダイアグ
            kindDic.Add("4", "Pend");           // ペンディング
            kindDic.Add("5", "Perm");           // パーマネント
            kindDic.Add("6", "対象外");         // 予兆

            return kindDic;
        }
    }
}