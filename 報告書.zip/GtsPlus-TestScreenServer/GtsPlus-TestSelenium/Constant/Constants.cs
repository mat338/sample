﻿namespace GtsPlus_TestSelenium.Constant
{
    /// <summary>
    /// 共通_定数クラス
    /// </summary>
    public static class Constants
    {
        /// <summary>
        /// ファイルパス
        /// </summary>
        public static class FilePath
        {
            /// <summary>
            /// コピー元httpディレクトリ
            /// </summary>
            public const string FROM_HTTP_DIRECTRY = "/../../../GtsPlus-TestScreenServer/bin/Release/Presentation";

            /// <summary>
            /// コピー先httpディレクトリ
            /// </summary>
            public const string TO_HTTP_DIRECTRY = "/Presentation";

            /// <summary>
            /// httpサーバー起動
            /// </summary>
            public const string HTTP_SERVER = "/../../../GtsPlus-TestScreenServer/bin/Release/GtsPlus-TestScreenServer.exe";

            /// <summary>
            /// WebServer
            /// </summary>
            public const string WEB_SERVER = "/KantanWebServer/KantanWEBServer.exe";

            /// <summary>
            /// アプリログフォルダ
            /// </summary>
            public const string LOG_FOLDER = "/Log";
        }

        /// <summary>
        /// PFファイル
        /// </summary>
        public static class PF
        {
            /// <summary>
            /// GTSPlusArbitration
            /// </summary>
            public const string GTS_PLUS_ARBITRATION = "GTSPlusArbitration";

            /// <summary>
            /// GTSPlus
            /// </summary>
            public const string GTS_PLUS = "GTSPlus";
        }

        /// <summary>
        /// 定数インナークラス_WebDriverオプション
        /// </summary>
        public static class WebDriverOption
        {
            /// <summary>
            /// ヘッドレスモード
            /// </summary>
            public const string HEADLESS_MODE = "--headless";

            /// <summary>
            /// タイムアウト
            /// </summary>
            public const int WAIT_TIMEOUT_MILLI_SECONDS = 60000;
        }

        /// <summary>
        /// テストURLファイル
        /// </summary>
        public static class URL
        {
            /// <summary>
            /// QR code
            /// </summary>
            public const string GTS_PLUS_QR_CODE = "http://localhost:38080/Presentation/Html/";

            /// <summary>
            /// Vehicle confirmed
            /// </summary>
            public const string GTS_PLUS_VHCN = "http://localhost:38080/Presentation/Html/vhcn_001.html";
        }

        /// <summary>
        /// 表示完了判定対象ID
        /// </summary>
        public static class WAIT_ID
        {
            /// <summary>
            /// QR code item
            /// </summary>
            public const string GTS_PLUS_QR_CODE = "image_qr";

            /// <summary>
            /// QR code confirm item
            /// </summary>
            public const string GTS_PLUS_QR_CODE_CONFIRM = "button_forced_continuation";

            /// <summary>
            /// Vehicle confirmed item
            /// </summary>
            public const string GTS_PLUS_VHCN = "table_confirm";

            /// <summary>
            /// Vehicle confirmed Confirmation item
            /// </summary>
            public const string GTS_PLUS_VHCN_CONFIRM = "button_yes";
        }

        /// <summary>
        /// APID
        /// </summary>
        public static class APID
        {
            // APID桁数
            public const int APID_LENGTH = 8;

            // GUI-PF間接続初期化
            public const string SET_CONNECTION_CONDTION = "CN000001";

            // チャレンジコード生成
            public const string CREATE_CHALLENGE_CODE = "CN000002";

            // API認証用ハッシュコードチェック
            public const string CHECK_API_AUTHENTICATION = "CN000003";

            // 車両選択
            public const string SELECT_VEHICLE = "DV000001";

            // 車両カテゴリ情報取得
            public const string SELECT_VEHICLE_CATEGORY = "DV000002";

            // 車両ID確定
            public const string SET_VEHICLE_ID = "DV000003";

            // 車両カテゴリ情報取得
            public const string GET_MOUNT_ECU_LIST = "DV000004";

            // ECU接続確認
            public const string CHECK_ECU_CONNECT = "DV000005";

            // ECU機能リスト取得
            public const string GET_ECU_FUNC_LIST = "DV000006";

            // DTC取得
            public const string GET_DTC = "DV000008";

            // 車両例外対応
            public const string REPLACE_VEHICLE_EXCEPTION = "DV000066";

            // システム例外対応
            public const string REPLACE_SYSTEM_EXCEPTION = "DV000067";

            // DK-ISO9141通信初期化
            //public const string INITIALIZE_DK_ISO9141 = "DV000077";

            // リモートダイアグDTC送信マスク設定
            public const string SET_REMOTE_DIAG_SEND_MASK = "DV000078";

            // 車両キャッシュ取得
            public const string GET_VEHICLE_CACHE = "DV000089";

            // 車両確定情報取得 
            public const string GET_VEHICLE_CONFIRMATION = "IF000004";

            // 接続情報取得
            public const string GET_CONNECTION_INFO_HL = "IF100001";

            // 診断開始
            public const string START_DIAGNOSIS = "SC000001";

            // 診断終了
            public const string END_DIAGNOSIS = "SC000002";

            // 車両確定通知
            public const string NOTIFY_VEHICLE_CONFIRMATION = "SC000003";

            // 診断情報取得
            public const string GET_DIAGNOSTIC_INFORMATION = "SC000006";

            // 強制診断終了
            public const string FORCED_END_DIAGNOSISON= "SC000007";
        }

        /// <summary>
        /// APIレスポンス-抽出
        /// </summary>
        public static class Sample_Word
        {
            /// <summary>
            /// WebSocketServer start
            /// </summary>
            public const string WEB_SOCKET_SERVER_START = "Successful connection to GTS+.";

            /// <summary>
            /// Port番号：50010
            /// </summary>
            public const string PORT_NUMBER_50010 = "50010";

            /// <summary>
            /// Port番号：50011
            /// </summary>
            public const string PORT_NUMBER_50011 = "50011";

            /// <summary>
            /// Port番号：50012
            /// </summary>
            public const string PORT_NUMBER_50012 = "50012";

            /// <summary>
            /// common-apid
            /// </summary>
            public const string COMMON_APID = "\"apiId\":\"";

            /// <summary>
            /// resultInfo-result
            /// </summary>
            public const string RESULTINFO_RESULT = "\"result\":";

            /// <summary>
            /// result結果成功
            /// </summary>
            public const string RESULT_SUCCESS = "0";

            /// <summary>
            /// result結果失敗
            /// </summary>
            public const string RESULT_FAILED = "-1";

            /// <summary>
            /// DIAGNOSIS_START_STATUS
            /// </summary>
            public const string DIAGNOSIS_START_STATUS = "\"diagnosisStartStatus\":";

            /// <summary>
            /// regionId
            /// </summary>
            public const string REGION_ID = "\"regionId\":";

            /// <summary>
            /// languageId
            /// </summary>
            public const string LANGUAGE_ID = "\"languageId\":";

            /// <summary>
            /// vehicleId
            /// </summary>
            public const string VEHICLE_ID = "\"vehicleId\":";

            /// <summary>
            /// vinCode
            /// </summary>
            public const string VIN = "\"vin\":";

            /// <summary>
            /// index
            /// </summary>
            public const string INDEX = "\"index\":";

            /// <summary>
            /// categoryItemList3（車型）
            /// </summary>
            public const string CATEGORY_ITEM_LIST3 = "{\"id\":3";

            /// <summary>
            /// categoryItemList4（エンジン形式）
            /// </summary>
            public const string CATEGORY_ITEM_LIST4 = "\"id\":4";

            /// <summary>
            /// selectItemList
            /// </summary>
            public const string SELECT_ITEM_LIST_START = "\"selectItemList\":[";

            /// <summary>
            /// selectItemList終了
            /// </summary>
            public const string SELECT_ITEM_LIST_END = "]";


            /// <summary>
            /// ECU ID
            /// </summary>
            public const string ECU_ID = "\"ecuId\":";

            /// <summary>
            /// phaseType
            /// </summary>
            public const string PHASE_TYPE = "\"phaseType\":";

            /// <summary>
            /// 接続状態
            /// </summary>
            public const string CONNECT = "\"connect\":";

            /// <summary>
            /// ECU ID レスポンス[DV000005]
            /// </summary>
            public const string RESPONCE_ECU_ID_CHECK_ECU_CONNECT = "CHECK_ECU_CONNECT:";

            /// <summary>
            /// ECU ID レスポンス[DV000067]
            /// </summary>
            public const string RESPONCE_ECU_ID_REPLACE_SYSTEM_EXCEPTION = "REPLACE_SYSTEM_EXCEPTION:";

            /// <summary>
            /// ECU ID レスポンス[DV000006]
            /// </summary>
            public const string RESPONCE_ECU_ID_GET_ECU_FUNC_LIST = "GET_ECU_FUNC_LIST:";

            /// <summary>
            /// ECU ID レスポンス[DV000008]
            /// </summary>
            public const string RESPONCE_ECU_ID_GET_DTC = "GET_DTC:";


            /// <summary>
            /// DTC取得結果[codeDisp]
            /// </summary>
            public const string CODE_DISP = "\"codeDisp\":\"";

            /// <summary>
            /// DTC取得結果[name]
            /// </summary>
            public const string NAME = "\"name\":\"";

            /// <summary>
            /// DTC取得結果[kind]
            /// </summary>
            public const string KIND = "\"kind\":[";

            /// <summary>
            /// DTC取得結果[kindFlag]
            /// </summary>
            public const string KIND_FLAG = "\"kindFlag\":";

            /// <summary>
            /// DTC取得結果[ffd]
            /// </summary>
            public const string FFD = "\"ffdType\":";
        }

        /// <summary>
        /// 画面項目ID-QRコード
        /// </summary>
        public static class ITEM_ID_QR
        {
            /// <summary>
            /// API結果
            /// </summary>
            public const string QR_CODE_RESULT_API = "retAPI";

            /// <summary>
            /// タイトル
            /// </summary>
            public const string QR_CODE_CONFIRM_TITLE = "title";

            /// <summary>
            /// 言語と仕向け
            /// </summary>
            public const string QR_CODE_CONFIRM_TABLE = "table_info";

            /// <summary>
            /// 継続ボタン
            /// </summary>
            public const string QR_CODE_CONFIRM_CONTINUE = "button_continue";

            /// <summary>
            /// 強制継続ボタン
            /// </summary>
            public const string QR_CODE_CONFIRM_FORCED_CONTINUE = "button_forced_continuation";

            /// <summary>
            /// エラー
            /// </summary>
            public const string QR_CODE_CONFIRM_ERROR = "error_message";
        }

        /// <summary>
        /// 画面項目ID-車両確定
        /// </summary>
        public static class ITEM_ID_VEHICLE_CONFIRMED
        {
            /// <summary>
            /// API結果
            /// </summary>
            public const string VEHICLE_CONFIRMED_RESULT_API = "retAPI";

            /// <summary>
            /// カテゴリーテーブル
            /// </summary>
            public const string VEHICLE_CONFIRMED_TABLE_CATEGORY = "table_category";

            /// <summary>
            /// 選択項目１
            /// </summary>
            public const string VEHICLE_CONFIRMED_SELECT1 = "selectCategory1";

            /// <summary>
            /// 選択項目２
            /// </summary>
            public const string VEHICLE_CONFIRMED_SELECT2 = "selectCategory2";

            /// <summary>
            /// 選択項目３
            /// </summary>
            public const string VEHICLE_CONFIRMED_SELECT3 = "selectCategory3";

            /// <summary>
            /// 選択項目４
            /// </summary>
            public const string VEHICLE_CONFIRMED_SELECT4 = "selectCategory4";

            /// <summary>
            /// オプションテーブル
            /// </summary>
            public const string VEHICLE_CONFIRMED_TABLE_OPTION = "table_option";

            /// <summary>
            /// オプション１
            /// </summary>
            public const string VEHICLE_CONFIRMED_OPTION1 = "selectOption1";

            /// <summary>
            /// オプション２
            /// </summary>
            public const string VEHICLE_CONFIRMED_OPTION2 = "selectOption2";

            /// <summary>
            /// オプション３
            /// </summary>
            public const string VEHICLE_CONFIRMED_OPTION3 = "selectOption3";

            /// <summary>
            /// 確定ボタン
            /// </summary>
            public const string VEHICLE_CONFIRMED_IMAGE_CONFIRM = "image_confirm";

            /// <summary>
            /// エラー
            /// </summary>
            public const string VEHICLE_CONFIRMED_ERROR = "error_message";
        }

        /// <summary>
        /// 画面項目ID-確認画面
        /// </summary>
        public static class ITEM_ID_VEHICLE_CONFIRMATION
        {
            /// <summary>
            /// API結果
            /// </summary>
            public const string VEHICLE_CONFIRMATION_RESULT_API = "retAPI";

            /// <summary>
            /// メッセージタイトル
            /// </summary>
            public const string VEHICLE_CONFIRMATION_TITLE = "title";

            /// <summary>
            /// 仕向/言語
            /// </summary>
            public const string VEHICLE_CONFIRMATION_TITLE_MESSAGE = "車両と通信した結果が残っています。接続している車両はこの車両ですか？";

            /// <summary>
            /// 仕向/言語
            /// </summary>
            public const string VEHICLE_CONFIRMATION_TABLE_INFO = "table_info";

            /// <summary>
            /// [yes]ボタン
            /// </summary>
            public const string VEHICLE_CONFIRMATION_YES = "button_yes";

            /// <summary>
            /// [no]ボタン
            /// </summary>
            public const string VEHICLE_CONFIRMATION_NO = "button_no";

            /// <summary>
            /// 画面タイプ
            /// </summary>
            public const string VEHICLE_CONFIRMATION_TYPE = "confirmType";

            /// <summary>
            /// エラー
            /// </summary>
            public const string VEHICLE_CONFIRMATION_ERROR = "error_message";
        }

        /// <summary>
        /// 画面項目ID-機能メニュー
        /// </summary>
        public static class ITEM_ID_FUNCTION_MENU
        {
            /// <summary>
            /// Function menu item
            /// </summary>
            public const string FUNCTION_MENU_ALL_DTC = "button_all_dtc";
        }

        /// <summary>
        /// 画面項目ID-Allダイアグ（ECU select）画面
        /// </summary>
        public static class ITEM_ID_ALL_DTC_SELECT
        {
            /// <summary>
            /// API結果
            /// </summary>
            public const string ALL_DTC_SELECT_RESULT_API = "retAPI";

            /// <summary>
            /// Ecu list item
            /// </summary>
            public const string ALL_DTC_SLIDER = "slider";

            /// <summary>
            /// 白枠ぐるぐる
            /// </summary>
            public const string ALL_DTC_IMAGE_PROCESSING = "image_processing";

            /// <summary>
            /// 白枠ノットサポート item
            /// </summary>
            public const string ALL_DTC_IMAGE_ABSENCE = "image_absence";

            /// <summary>
            /// 赤枠DTCあり
            /// </summary>
            public const string ALL_DTC_IMAGE_DTC = "image_dtc";

            /// <summary>
            /// 青枠DTCなし
            /// </summary>
            public const string ALL_DTC_IMAGE_NOT_DTC = "image_not_dtc";

            /// <summary>
            /// Powerボタン
            /// </summary>
            public const string ALL_DTC_IMAGE_POWER = "image_power_train";

            /// <summary>
            /// Power Trail項目 Name
            /// </summary>
            public const string ALL_DTC_POWER_TRAIN = "1";

            /// <summary>
            /// Chassisボタン
            /// </summary>
            public const string ALL_DTC_IMAGE_CHASSIS = "image_chassis";

            /// <summary>
            /// CHASSIS項目 Name
            /// </summary>
            public const string ALL_DTC_CHASSIS = "2";

            /// <summary>
            /// Bodyボタン
            /// </summary>
            public const string ALL_DTC_IMAGE_BODY = "image_body";

            /// <summary>
            /// Body項目 Name
            /// </summary>
            public const string ALL_DTC_BODY = "0";
        }

        /// <summary>
        /// 画面項目ID-Allダイアグ（DTC）画面
        /// </summary>
        public static class ITEM_ID_ALL_DTC
        {
            /// <summary>
            /// API結果
            /// </summary>
            public const string ALL_DTC_RESULT_API = "retAPI";

            /// <summary>
            /// ECU一覧
            /// </summary>
            public const string ALL_DTC_ECU_LIST = "ecuList";

            /// <summary>
            /// 戻るボタン
            /// </summary>
            public const string ALL_DTC_BACK = "button_back";
        }

        /// <summary>
        /// 仕向定数
        /// </summary>
        public static class RegionId
        {
            /// <summary>
            /// 北米
            /// </summary>
            public const string REGION_CODE_NORTH_AMERICA = "1";

            /// <summary>
            /// 欧州
            /// </summary>
            public const string REGION_CODE_EUROPE = "2";

            /// <summary>
            /// 日本
            /// </summary>
            public const string REGION_CODE_JAPAN = "3";

            /// <summary>
            /// 一般地
            /// </summary>
            public const string REGION_CODE_OTHER = "4";
        }

        /// <summary>
        /// 言語定数
        /// </summary>
        public static class LanguageId
        {
            /// <summary>
            /// 英語 English
            /// </summary>
            public const string LANGUAGE_ENGLISH = "1";

            /// <summary>
            /// ドイツ語 German
            /// </summary>
            public const string LANGUAGE_GERMAN = "2";

            /// <summary>
            /// フランス語 French
            /// </summary>
            public const string LANGUAGE_FRENCH = "3";

            /// <summary>
            /// スペイン語 Spanish
            /// </summary>
            public const string LANGUAGE_SPANISH = "4";

            /// <summary>
            /// イタリア語 Italian
            /// </summary>
            public const string LANGUAGE_ITALIAN = "5";

            /// <summary>
            /// 中国語 Chinese
            /// </summary>
            public const string LANGUAGE_CHINESE = "6";

            /// <summary>
            /// 日本語 Japanese
            /// </summary>
            public const string LANGUAGE_JAPANESE = "7";

            /// <summary>
            /// スウェーデン語 Swedish
            /// </summary>
            public const string LANGUAGE_SWEDISH = "8";

            /// <summary>
            /// ポルトガル語 Portuguese
            /// </summary>
            public const string LANGUAGE_PORTUGUESE = "10";

            /// <summary>
            /// ポーランド語 Polish
            /// </summary>
            public const string LANGUAGE_POLISH = "11";

            /// <summary>
            /// ノルウェー語 Norwegian
            /// </summary>
            public const string LANGUAGE_NORWEGIAN = "102";

            /// <summary>
            /// ハンガリー語 Hungarian
            /// </summary>
            public const string LANGUAGE_HUNGARIAN = "13";

            /// <summary>
            /// ギリシャ語 Greek
            /// </summary>
            public const string LANGUAGE_GREEK = "14";

            /// <summary>
            /// ロシア語 Russian
            /// </summary>
            public const string LANGUAGE_RUSSIAN = "16";

            /// <summary>
            /// トルコ語 Turkish
            /// </summary>
            public const string LANGUAGE_TURKISH = "17";

            /// <summary>
            /// チェコ語 Czech
            /// </summary>
            public const string LANGUAGE_CZECH = "18";

            /// <summary>
            /// オランダ語 Dutch
            /// </summary>
            public const string LANGUAGE_DUTCH = "19";

            /// <summary>
            /// フィンランド語 Finnish
            /// </summary>
            public const string LANGUAGE_FINNISH = "20";

            /// <summary>
            /// デンマーク語 Danish
            /// </summary>
            public const string LANGUAGE_DANISH = "21";
        }

    }
}
