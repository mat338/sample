﻿namespace GtsPlus_TestSelenium.Constant.Lang
{
    /// <summary>
    /// 共通_定数クラス
    /// </summary>
    public static class Constants_EN
    {
        /// <summary>
        /// QRコード表示項目
        /// </summary>
        public static class QrCodeItem
        {
            /// <summary>
            /// TITLE
            /// </summary>
            public const string TITLE = "Under diagnosis";

            /// <summary>
            /// LANGUAGE_ID
            /// </summary>
            public const string LANGUAGE_ID = "LANGUAGE ID";

            /// <summary>
            /// REGION_ID
            /// </summary>
            public const string REGION_ID = "REGION ID";

            /// <summary>
            /// 継続ボタン
            /// </summary>
            public const string CONTINUE = "Continue";

            /// <summary>
            /// 強制継続ボタン
            /// </summary>
            public const string FORCED_CONTINUATION = "Forced continuation";
        }

        /// <summary>
        /// 車両確定表示項目
        /// </summary>
        public static class VehicleConfirmedItem
        {
            /// <summary>
            /// カテゴリー１
            /// </summary>
            public const string CATEGORY1 = "Division : ";

            /// <summary>
            /// カテゴリー２
            /// </summary>
            public const string CATEGORY2 = "Model :";

            /// <summary>
            /// カテゴリー３
            /// </summary>
            public const string CATEGORY3 = "ModelYear :";

            /// <summary>
            /// カテゴリー４
            /// </summary>
            public const string CATEGORY4 = "Engine :";

            /// <summary>
            /// オプション
            /// </summary>
            public const string OPTION = "Option :";
        }

        /// <summary>
        /// 確認画面表示項目
        /// </summary>
        public static class ConfirmationItem
        {
            /// <summary>
            /// 確認ダイアログ
            /// </summary>
            public const string CONFIRMATION_MSG = "The result of communicating with the vehicle remains. Is the connected vehicle this vehicle?";

            /// <summary>
            /// 車両ID
            /// </summary>
            public const string VEHICLE_ID = "Vehicle ID";

            /// <summary>
            /// VIN
            /// </summary>
            public const string VIN = "VIN";
        }
    }
}