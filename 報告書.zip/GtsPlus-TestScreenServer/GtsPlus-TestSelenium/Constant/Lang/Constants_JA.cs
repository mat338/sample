﻿namespace GtsPlus_TestSelenium.Constant.Lang
{
    /// <summary>
    /// 共通_定数クラス
    /// </summary>
    public static class Constants_JA
    {
        /// <summary>
        /// QRコード表示項目
        /// </summary>
        public static class QrCodeItem
        {
            /// <summary>
            /// TITLE
            /// </summary>
            public const string TITLE = "診断開始中";

            /// <summary>
            /// LANGUAGE_ID
            /// </summary>
            public const string LANGUAGE_ID = "言語ID";

            /// <summary>
            /// REGION_ID
            /// </summary>
            public const string REGION_ID = "仕向ID";

            /// <summary>
            /// 継続ボタン
            /// </summary>
            public const string CONTINUE = "継続";

            /// <summary>
            /// 強制継続ボタン
            /// </summary>
            public const string FORCED_CONTINUATION = "強制継続";
        }

        /// <summary>
        /// 車両確定表示項目
        /// </summary>
        public static class VehicleConfirmedItem
        {
            /// <summary>
            /// カテゴリー１
            /// </summary>
            public const string CATEGORY1 = "ブランド :";

            /// <summary>
            /// カテゴリー２
            /// </summary>
            public const string CATEGORY2 = "車両 :";

            /// <summary>
            /// カテゴリー３
            /// </summary>
            public const string CATEGORY3 = "車型 :";

            /// <summary>
            /// カテゴリー４
            /// </summary>
            public const string CATEGORY4 = "エンジン形式 :";

            /// <summary>
            /// オプション
            /// </summary>
            public const string OPTION = "オプション :";
        }

        /// <summary>
        /// 確認画面表示項目
        /// </summary>
        public static class ConfirmationItem
        {
            /// <summary>
            /// 確認ダイアログ
            /// </summary>
            public const string CONFIRMATION_MSG = "車両と通信した結果が残っています。接続している車両はこの車両ですか？";

            /// <summary>
            /// 車両ID
            /// </summary>
            public const string VEHICLE_ID = "車両ID";

            /// <summary>
            /// VIN
            /// </summary>
            public const string VIN = "VIN";
        }
    }
}
