﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using System.Diagnostics;
using System.Threading;
using IWshRuntimeLibrary;
using log4net;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using SeleniumExtras.WaitHelpers;
using GtsPlus_TestSelenium.Constant;
using GtsPlus_TestSelenium.Component;
using GtsPlus_TestSelenium.Utils;
using GtsPlus_TestSelenium.Constant.Lang;
using System.Collections;

namespace GtsPlus_TestSelenium.Business
{
    /// <summary>
    /// テストシナリオ-Allダイアグ（ECU select）画面
    /// </summary>
    public class P4: IDisposable
    {
        /// <summary>
        /// log4net
        /// </summary>
        private static readonly ILog logger = LogManager.GetLogger(typeof(Program));

        /// <summary>
        /// 大分類名
        /// </summary>
        private const string LOG_OUT_NAME = "P4対応";
        /// <summary>
        /// エビデンスフォルダ-正常系
        /// </summary>
        private const string EVIDENCE_DIR = "/" + LOG_OUT_NAME;
        /// <summary>
        /// JQueryで付与されるオプションリストのID追加文字列
        /// </summary>
        private const string ID_ADD_STRING = "-button";
        /// <summary>
        /// Ecu ID 桁数
        /// </summary>
        private const int ECU_ID_LENGTH = 3;
        /// <summary>
        /// ECU ID（エンジン）
        /// </summary>
        private const string ECU_ID_ENGINE = "234";
        /// <summary>
        /// phaseType 5
        /// </summary>
        private const string PHASE_TYPE_5 = "20";
        /// <summary>
        /// ECU名（エンジン）
        /// </summary>
        private const string ECU_NAME_ENGINE = "エンジン";
        /// <summary>
        /// DTCリスト チェックイメージID
        /// </summary>
        private const string IMAGE_CHECK_ID = "img_check";


        /// <summary>
        /// 実行ディレクトリ
        /// </summary>
        private string currentDir;
        /// <summary>
        /// エビデンス出力ディレクトリ
        /// </summary>
        private string evidenceDirectory;
        /// <summary>
        /// ログ出力先ディレクトリ
        /// </summary>
        private string logOutDir;

        /// <summary>
        /// OK件数
        /// </summary>
        private int chkAllDtcOK = 0;
        /// <summary>
        /// NG件数
        /// </summary>
        private int chkAllDtcNG = 0;

        /// <summary>
        /// Phase type
        /// </summary>
        private string phaseType = "";

        /// <summary>
        /// 接続確認ECU IDリスト
        /// </summary>
        private List<string> listConnectEcuId = new List<string>();
        /// <summary>
        /// DTC取得結果表示用DTCリスト
        /// </summary>
        private List<string> listCodeDisp = new List<string>();
        /// <summary>
        /// DTC取得結果ダイアグコード種別リスト
        /// </summary>
        private Dictionary<string, string> listDtcType = new Dictionary<string, string>();


        /// <summary>
        /// コンストラクタ
        /// </summary>
        public P4(string currentDir, string evidenceDir)
        {
            this.currentDir = currentDir;
            this.logOutDir = currentDir + evidenceDir;

            this.evidenceDirectory = logOutDir + EVIDENCE_DIR;
            // エビデンスフォルダ作成
            FileUtils.createEvidenceDirectory(evidenceDirectory);
        }

        /// <summary>
        /// シナリオNo.1～5
        /// </summary>
        public void testScenario_1()
        {
            logger.Info(" ################### GTS+ P4 [START] ################### ");

            try
            {
                // PF再起動
                FileUtils.rebootPF(currentDir);

                // Allダイアグ（ECU select）画面の表示
                using (var webDriverComponent = new WebDriverComponent(false, Constants.WebDriverOption.WAIT_TIMEOUT_MILLI_SECONDS))
                {
                    /*
                     * 機能メニューを表示するまで進める
                     * */
                    // 車両確定画面を開く
                    logger.Debug("【車両確定画面を開く】");
                    webDriverComponent.OpenPageAndWaitByID(Constants.URL.GTS_PLUS_VHCN, Constants.WAIT_ID.GTS_PLUS_VHCN);
                    Thread.Sleep(5000);

                    // オプション１選択（「<SELECT>」の下の項目を選択）
                    logger.Debug("【オプション項目選択変更】: オプション１");
                    webDriverComponent.SelectOptionById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_OPTION1 + ID_ADD_STRING, false, 1);
                    // オプション２選択（「<SELECT>」の下の項目を選択）
                    logger.Debug("【オプション項目選択変更】: オプション２");
                    webDriverComponent.SelectOptionById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_OPTION2 + ID_ADD_STRING, false, 1);

                    // Confirmボタン押下 
                    logger.Debug("【確定ボタン押下】");
                    webDriverComponent.ClickById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_IMAGE_CONFIRM);
                    Thread.Sleep(30000);

                    //webDriverComponent.OpenPageAndWaitByID(Constants.URL.GTS_PLUS_VHCN, Constants.ITEM_ID_VEHICLE_CONFIRMATION.VEHICLE_CONFIRMATION_YES);
                    //Thread.Sleep(1000);
                    //webDriverComponent.ClickById(Constants.ITEM_ID_VEHICLE_CONFIRMATION.VEHICLE_CONFIRMATION_YES);
                    //Thread.Sleep(1000);

                    // 機能メニュー画面のキャプチャ取得
                    logger.Debug("【機能メニュー画面】");
                    Thread.Sleep(2000);

                    /*
                     * Allダイアグ（ECU select）画面
                     * */
                    // All DTCボタン押下 
                    logger.Debug("【All DTCボタン押下 】");
                    webDriverComponent.ClickById(Constants.ITEM_ID_FUNCTION_MENU.FUNCTION_MENU_ALL_DTC);
                    Thread.Sleep(3000);

                    // Power Trailのみ表示させる（スクロール不要にする為）
                    webDriverComponent.ClickById(Constants.ITEM_ID_ALL_DTC_SELECT.ALL_DTC_IMAGE_BODY);
                    webDriverComponent.ClickById(Constants.ITEM_ID_ALL_DTC_SELECT.ALL_DTC_IMAGE_CHASSIS);

                    // DTC取得
                    DateTime startTime = DateTime.Now;
                    logger.Debug(startTime + " - DTC取得APIを全件取得するまで待機開始");
                    while (true)
                    {
                        // DTC取得APIが全て返却されるまで（赤枠が表示されるまで）
                        if (webDriverComponent.IsDisplayedById(Constants.ITEM_ID_ALL_DTC_SELECT.ALL_DTC_IMAGE_DTC))
                        {
                            logger.Debug(DateTime.Now.Subtract(startTime).TotalMilliseconds + "msec - DTC取得API 全件取得経過時間");
                            // APIのレスポンスチェック
                            CheckApi(webDriverComponent.GetValueByIdNoneDisplay(Constants.ITEM_ID_ALL_DTC_SELECT.ALL_DTC_SELECT_RESULT_API),
                                Constants.APID.GET_DTC);
                            break;
                        }
                        else
                        {
                            // タイムアウト
                            if (DateTime.Now.Subtract(startTime).TotalMilliseconds > 3000000)
                            {
                                logger.Error("タイムアウト：" + DateTime.Now);
                                break;
                            }
                        }

                        // 間隔
                        Thread.Sleep(1000);
                    }

                    webDriverComponent.ClickByEcuName(ECU_NAME_ENGINE);
                    Thread.Sleep(1000);

                    // Allダイアグ（DTC）画面のキャプチャ取得
                    logger.Info("**************** Allダイアグ（DTC）画面 *****************");
                    webDriverComponent.GetScreenshot(evidenceDirectory, "No.1-5_AllDtc");

                    /*
                     * Allダイアグ（DTC）画面
                     * */
                    string list = webDriverComponent.GetValueById(Constants.ITEM_ID_ALL_DTC.ALL_DTC_ECU_LIST);
                    // ダイアグコード種別チェック No.1～5
                    CheckDtcImageList(webDriverComponent);
                    Thread.Sleep(1000);


                    logger.Info("*********************************");
                    logger.Info("結果 check OK : " + chkAllDtcOK + " / check NG : " + chkAllDtcNG);
                    logger.Info("*********************************");

                }
            }
            catch (Exception exception)
            {
                logger.Debug("*********************************");
                logger.Debug("途中結果 check OK : " + chkAllDtcOK + " / check NG : " + chkAllDtcNG);
                logger.Debug("*********************************");
                logger.Debug("Unexpected exception occurred during asynchronous processing.", exception);
            }

            logger.Info(" ################### GTS+ P4 [END] ################### \r\n\r\n");

            // LOGのlogファイルコピー
            FileUtils.DirectoryCopy(currentDir + Constants.FilePath.LOG_FOLDER, logOutDir);
        }

        /// <summary>
        /// APIレスポンスチェック
        /// </summary>
        /// <param name="retApi">API戻り値</param>
        /// <param name="checkApid">チェック対象APID（指定がない場合は空文字）</param>
        private void CheckApi(string retApi, string checkApid)
        {
            string apid = "";
            string[] api = retApi.Replace("\r\n", "\n").Split(new[] { '\n', '\r' });

            foreach (string retValue in api)
            {
                // APID応答データ抽出
                apid = "";
                int apidIndex = retValue.IndexOf(Constants.Sample_Word.COMMON_APID);
                if (apidIndex > -1)
                {
                    apid = retValue.Substring(apidIndex + Constants.Sample_Word.COMMON_APID.Length, Constants.APID.APID_LENGTH);
                }

                // 応答結果：result
                string result = "";
                int resultIdx = retValue.IndexOf(Constants.Sample_Word.RESULTINFO_RESULT);
                if (resultIdx > -1)
                {
                    result = retValue.Substring(resultIdx + Constants.Sample_Word.RESULTINFO_RESULT.Length, 2).Trim().Replace(",", "").Replace("}", "");
                }

                // APID別チェック
                if (string.IsNullOrEmpty(checkApid))
                {
                    // チェック対象のAPID指定が無い場合
                    logger.Debug(retValue);
                    if (resultIdx > -1) CheckApid(apid, result, retValue);
                }
                else
                {
                    // チェック対象のAPID指定が有る場合
                    if (checkApid.Equals(apid))
                    {
                        logger.Debug(retValue);
                        CheckApid(apid, result, retValue);
                    }
                }
            }
        }

        /// <summary>
        /// APID別チェック
        /// </summary>
        /// <param name="apid">APID</param>
        /// <param name="result">応答結果</param>
        /// <param name="json">APIレスポンス</param>
        private void CheckApid(string apid, string result, string json)
        {
            switch (apid)
            {
                // DV000008
                case Constants.APID.GET_DTC:
                    if (result == "0")
                    {
                        int idx = 0;

                        // [ECU ID]抽出
                        string ecuId = "";
                        idx = json.IndexOf(Constants.Sample_Word.RESPONCE_ECU_ID_GET_DTC);
                        if (idx > -1)
                        {
                            ecuId = json.Substring(idx + Constants.Sample_Word.RESPONCE_ECU_ID_GET_DTC.Length, ECU_ID_LENGTH);

                            logger.Debug("【ECU ID】" + ecuId);

                            // エンジンの場合のみ抽出
                            if (ECU_ID_ENGINE.Equals(ecuId))
                            {
                                int startIdx = 0;
                                int endIdx = 0;
                                string codeDisp = "";
                                string kind = "";

                                // phaseTypeを取得
                                idx = json.IndexOf(Constants.Sample_Word.PHASE_TYPE, startIdx);
                                if (idx > -1)
                                {
                                    startIdx = idx + Constants.Sample_Word.PHASE_TYPE.Length;
                                    endIdx = json.IndexOf("}", startIdx);
                                    // phaseType
                                    phaseType = json.Substring(startIdx, endIdx - startIdx);
                                }

                                // [codeDisp]抽出
                                while (true)
                                {
                                    idx = json.IndexOf(Constants.Sample_Word.CODE_DISP, startIdx);
                                    if (idx > -1)
                                    {
                                        startIdx = idx + Constants.Sample_Word.CODE_DISP.Length;
                                        endIdx = json.IndexOf("\"", startIdx);
                                        // codeDispをリストに追加
                                        codeDisp = json.Substring(startIdx, endIdx - startIdx);
                                        logger.Debug("【codeDisp】" + codeDisp);
                                        if (listDtcType.ContainsKey(codeDisp))
                                        {
                                            codeDisp += DateTime.Now.ToString();
                                        }
                                        listCodeDisp.Add(codeDisp);

                                        // [kind]抽出
                                        idx = json.IndexOf(Constants.Sample_Word.KIND, startIdx);
                                        if (idx > -1)
                                        {
                                            startIdx = idx + Constants.Sample_Word.KIND.Length;
                                            endIdx = json.IndexOf("]", startIdx);
                                            // kind
                                            kind = json.Substring(startIdx, endIdx - startIdx);
                                            logger.Debug("【kind】" + kind);
                                            listDtcType.Add(codeDisp, kind);
                                        }
                                        else
                                        {
                                            break;
                                        }
                                    }
                                    else
                                    {
                                        break;
                                    }
                                }
                            }

                        }
                    }
                    else
                    {
                        chkAllDtcNG++;
                        logger.Info("【" + LOG_OUT_NAME + " NG No." + chkAllDtcNG + "】: " + apid + " GET_DTC");
                    }

                    //FileUtils.WriteJson(evidenceDirectory + "\\No." + (chkAllDtcOK + chkAllDtcNG) + "_" + apid + ".json", json);
                    break;
                default:
                    break;
            }
        }

        /// <summary>
        /// DTC一覧画像チェック
        /// </summary>
        /// <param name="webDriverComponent">WebDriverComponent</param>
        private void CheckDtcImageList(WebDriverComponent webDriverComponent)
        {
            string kindList = "";
            int kindIdx = 0;
            bool checkKind = true;
            // 行単位
            for (int i = 0; i < listCodeDisp.Count; i++)
            {
                logger.Info("**************** [" + i + "行目] *****************");

                // 各行の[kind]を取得
                kindList = listDtcType[listCodeDisp[i]];
                logger.Debug("kindList:" + kindList);
                // 0:ダイアグなし、1:現在ダイアグ/TestFail(最新)、2:過去ダイアグ、Confirmed(確定)、
                // 3:レディネスダイアグ、4:ペンディング、5:パーマネント、6:予兆
                for (int j = 0; j <= 6; j++)
                {
                    int ret = kindList.IndexOf(j.ToString(), 0);
                    string kindName = GetKindName(j.ToString());

                    // データ取得有の場合はチェックイメージを表示（kind=0はダイアグなし）
                    if (ret > -1 && !kindList.Equals("0"))
                    {
                        // チェックイメージ画像の有無をチェック
                        if (webDriverComponent.IsDisplayedById(IMAGE_CHECK_ID + i + j))
                        {
                            logger.Debug("kind:" + j + " チェック " + kindName);
                            kindIdx++;
                        }
                        else
                        {
                            chkAllDtcNG++;
                            checkKind = false;
                            logger.Info("【" + LOG_OUT_NAME + " NG No." + chkAllDtcNG +  "】: kind:" + j + " チェック無 " + kindName);
                        }
                    }
                    // データ取得無の場合はチェックイメージを非表示
                    else
                    {
                        // チェックイメージ画像の有無をチェック
                        if (!webDriverComponent.IsDisplayedById(IMAGE_CHECK_ID + i + j))
                        {
                            logger.Debug("kind:" + j + " チェック無 " + kindName);
                        }
                        else
                        {
                            chkAllDtcNG++;
                            checkKind = false;
                            logger.Info("【" + LOG_OUT_NAME + " NG No." + chkAllDtcNG +  "】: kind:" + j + " チェック " + kindName);
                            kindIdx++;
                        }
                    }

                }
            }

            // 判定
            if (checkKind)
            {
                chkAllDtcOK += 5;
                logger.Info("【" + LOG_OUT_NAME + " OK No.1】: ダイアグコードチェック");
                logger.Info("【" + LOG_OUT_NAME + " OK No.2】: 現在ダイアグ、TestFail(最新)");
                logger.Info("【" + LOG_OUT_NAME + " OK No.3】: 過去ダイアグ、Confirmed(確定)");
                logger.Info("【" + LOG_OUT_NAME + " OK No.4】: ペンディング");
                logger.Info("【" + LOG_OUT_NAME + " OK No.5】: パーマネント");
            }
        }

        /// <summary>
        /// ダイアグコード種別名の取得
        /// </summary>
        /// <param name="kind">ダイアグコード種別</param>
        private string GetKindName(string kind)
        {
            CodeDictionary dic = new CodeDictionary();
            Dictionary<string, string> kindDic = null;

            if (PHASE_TYPE_5.Equals(phaseType))
            {
                // Phase5の場合
                kindDic = dic.Kind5Dictionary();
            }
            else
            {
                // Phase5以外の場合
                kindDic = dic.Kind4Dictionary();
            }

            return kindDic[kind];
        }

        /// <summary>
        /// 破棄処理
        /// </summary>
        public void Dispose()
        {
        }
    }
}
