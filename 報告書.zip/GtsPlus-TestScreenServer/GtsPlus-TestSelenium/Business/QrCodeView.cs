﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using System.Diagnostics;
using System.Threading;
using IWshRuntimeLibrary;
using log4net;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using SeleniumExtras.WaitHelpers;
using GtsPlus_TestSelenium.Constant;
using GtsPlus_TestSelenium.Component;
using GtsPlus_TestSelenium.Utils;
using GtsPlus_TestSelenium.Constant.Lang;

namespace GtsPlus_TestSelenium.Business
{
    /// <summary>
    /// テストシナリオ-QRコード表示
    /// </summary>
    public class QrCodeView : IDisposable
    {
        /// <summary>
        /// log4net
        /// </summary>
        private static readonly ILog logger = LogManager.GetLogger(typeof(Program));

        /// <summary>
        /// 大分類名
        /// </summary>
        private const string LOG_OUT_NAME = "QRコード";
        /// <summary>
        /// エビデンスフォルダ-正常系
        /// </summary>
        private const string EVIDENCE_DIR = "/" + LOG_OUT_NAME;
        /// <summary>
        /// Port番号：50011 - No.34
        /// </summary>
        private const string PORT_50011 = "50011";
        /// <summary>
        /// 診断開始未実施
        /// </summary>
        private const string DIAGNOSIS_START_STATUS_STOP = "0";
        /// <summary>
        /// 診断開始中
        /// </summary>
        private const string DIAGNOSIS_START_STATUS_START = "1";
        /// <summary>
        /// 画面ID-確定画面
        /// </summary>
        private const int VIEW_ID_1 = 1;
        /// <summary>
        /// 画面ID-確認画面
        /// </summary>
        private const int VIEW_ID_2 = 2;

        /// <summary>
        /// 実行ディレクトリ
        /// </summary>
        private string currentDir;
        /// <summary>
        /// エビデンス出力ディレクトリ
        /// </summary>
        private string evidenceDirectory;
        /// <summary>
        /// ログ出力先ディレクトリ
        /// </summary>
        private string logOutDir;

        /// <summary>
        /// 画面ID[1：QR画面、2：確認画面]
        /// </summary>
        private int viewID = 0;

        /// <summary>
        /// OK件数
        /// </summary>
        private int chkQrCodeOK = 0;
        /// <summary>
        /// NG件数
        /// </summary>
        private int chkQrCodeNG = 0;

        /// <summary>
        /// OK件数(No.34)
        /// </summary>
        private int chkQrCodeWebOK = 0;
        /// <summary>
        /// NG件数(No.34)
        /// </summary>
        private int chkQrCodeWebNG = 0;

        /// <summary>
        /// 仕向ID
        /// </summary>
        private string regionId = "";

        /// <summary>
        /// 言語ID
        /// </summary>
        private string languageId = "";

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public QrCodeView(string currentDir, string evidenceDir)
        {
            this.currentDir = currentDir;
            this.logOutDir = currentDir + evidenceDir;

            this.evidenceDirectory = logOutDir + EVIDENCE_DIR;
            // エビデンスフォルダ作成
            FileUtils.createEvidenceDirectory(evidenceDirectory);
        }

        /// <summary>
        /// シナリオNo.1～33
        /// </summary>
        public void testScenario_1()
        {
            logger.Info(" ################### GTS+ QRコード表示正常系 [START] ################### ");

            viewID = VIEW_ID_1;

            try
            {
                // PF再起動
                FileUtils.rebootPF(currentDir);

                // QRコードの表示
                using (var webDriverComponent = new WebDriverComponent(false, Constants.WebDriverOption.WAIT_TIMEOUT_MILLI_SECONDS))
                {
                    // QRコード画面を開く
                    webDriverComponent.OpenPageAndWaitByID(Constants.URL.GTS_PLUS_QR_CODE, Constants.WAIT_ID.GTS_PLUS_QR_CODE);
                    Thread.Sleep(1000);

                    // APIのレスポンスチェック No.1～9
                    CheckApi(webDriverComponent.GetValueByIdNoneDisplay(Constants.ITEM_ID_QR.QR_CODE_RESULT_API));

                    // QRコード表示のキャプチャ取得 No.10
                    webDriverComponent.GetScreenshot(evidenceDirectory, "No.10_QR_VIEW");
                    chkQrCodeOK++;
                    logger.Info("【" + LOG_OUT_NAME + " OK No." + (chkQrCodeOK + chkQrCodeNG) + "】: QRコードの表示");

                    viewID = VIEW_ID_2;

                    // QRコード確認画面を開く
                    webDriverComponent.OpenPageAndWaitByID(Constants.URL.GTS_PLUS_QR_CODE, Constants.WAIT_ID.GTS_PLUS_QR_CODE_CONFIRM);
                    Thread.Sleep(1000);

                    // APIのレスポンスチェック No.11～17
                    CheckApi(webDriverComponent.GetValueByIdNoneDisplay(Constants.ITEM_ID_QR.QR_CODE_RESULT_API));

                    // 確認画面表示のキャプチャ取得 No.18
                    webDriverComponent.GetScreenshot(evidenceDirectory, "No.18_QR_Confirm");

                    // 画面項目確認（言語と仕向け） No.18
                    string title = webDriverComponent.GetValueById(Constants.ITEM_ID_QR.QR_CODE_CONFIRM_TITLE);
                    string tableItem = webDriverComponent.GetValueById(Constants.ITEM_ID_QR.QR_CODE_CONFIRM_TABLE);
                    string continueButton = webDriverComponent.GetValueById(Constants.ITEM_ID_QR.QR_CODE_CONFIRM_CONTINUE);
                    string forcedButton = webDriverComponent.GetValueById(Constants.ITEM_ID_QR.QR_CODE_CONFIRM_FORCED_CONTINUE);
                    // 画面項目のチェック
                    if (CheckRegionLanguage(title, tableItem, continueButton, forcedButton))
                    {
                        chkQrCodeOK++;
                        logger.Info("【" + LOG_OUT_NAME + " OK No." + (chkQrCodeOK + chkQrCodeNG) + "】: 画面項目仕向");
                    }
                    else
                    {
                        chkQrCodeNG++;
                        logger.Info("【" + LOG_OUT_NAME + " NG No." + (chkQrCodeOK + chkQrCodeNG) + "】: 画面項目仕向");
                    }

                    viewID = VIEW_ID_1;

                    logger.Info("**************** QRコード確認画面（継続ボタン） *****************");

                    // 継続ボタン押下
                    webDriverComponent.ClickById(Constants.ITEM_ID_QR.QR_CODE_CONFIRM_CONTINUE);
                    Thread.Sleep(1000);

                    // APIのレスポンスチェック No.19～20
                    CheckApi(webDriverComponent.GetValueByIdNoneDisplay(Constants.ITEM_ID_QR.QR_CODE_RESULT_API));

                    // QRコード表示のキャプチャ取得 No.21
                    webDriverComponent.GetScreenshot(evidenceDirectory, "No.21_QR_Continue");
                    chkQrCodeOK++;
                    logger.Info("【" + LOG_OUT_NAME + " OK No." + (chkQrCodeOK + chkQrCodeNG) + "】: QRコードの表示");

                    viewID = VIEW_ID_2;

                    // QRコード確認画面を開く
                    webDriverComponent.OpenPageAndWaitByID(Constants.URL.GTS_PLUS_QR_CODE, Constants.WAIT_ID.GTS_PLUS_QR_CODE_CONFIRM);
                    Thread.Sleep(1000);

                    // APIのレスポンスチェック No.22～28
                    CheckApi(webDriverComponent.GetValueByIdNoneDisplay(Constants.ITEM_ID_QR.QR_CODE_RESULT_API));

                    // 確認画面表示のキャプチャ取得 No29
                    webDriverComponent.GetScreenshot(evidenceDirectory, "No.29_QR_Confirm");

                    // 画面項目確認（言語と仕向け） No.29
                    title = webDriverComponent.GetValueById(Constants.ITEM_ID_QR.QR_CODE_CONFIRM_TITLE);
                    tableItem = webDriverComponent.GetValueById(Constants.ITEM_ID_QR.QR_CODE_CONFIRM_TABLE);
                    continueButton = webDriverComponent.GetValueById(Constants.ITEM_ID_QR.QR_CODE_CONFIRM_CONTINUE);
                    forcedButton = webDriverComponent.GetValueById(Constants.ITEM_ID_QR.QR_CODE_CONFIRM_FORCED_CONTINUE);
                    // 画面項目のチェック
                    if (CheckRegionLanguage(title, tableItem, continueButton, forcedButton))
                    {
                        chkQrCodeOK++;
                        logger.Info("【" + LOG_OUT_NAME + " OK No." + (chkQrCodeOK + chkQrCodeNG) + "】: 画面項目仕向");
                    }
                    else
                    {
                        chkQrCodeNG++;
                        logger.Info("【" + LOG_OUT_NAME + " NG No." + (chkQrCodeOK + chkQrCodeNG) + "】: 画面項目仕向");
                    }

                    viewID = VIEW_ID_1;

                    logger.Info("**************** QRコード確認画面（強制継続ボタン） *****************");

                    // 強制継続ボタン押下
                    webDriverComponent.ClickById(Constants.ITEM_ID_QR.QR_CODE_CONFIRM_FORCED_CONTINUE);
                    Thread.Sleep(1000);

                    // APIのレスポンスチェック No.30～32
                    CheckApi(webDriverComponent.GetValueByIdNoneDisplay(Constants.ITEM_ID_QR.QR_CODE_RESULT_API));

                    // QRコード表示のキャプチャ取得 No.33
                    webDriverComponent.GetScreenshot(evidenceDirectory, "No.33_QR_Forced_Continue");
                    chkQrCodeOK++;
                    logger.Info("【" + LOG_OUT_NAME + " OK No." + (chkQrCodeOK + chkQrCodeNG) + "】: QRコードの表示");

                    logger.Info("*********************************");
                    logger.Info("結果 check OK : " + (chkQrCodeOK + chkQrCodeNG) + " / check NG : " + chkQrCodeNG);
                    logger.Info("*********************************");

                }
            }
            catch (Exception exception)
            {
                logger.Debug("*********************************");
                logger.Debug("途中結果 check OK : " + (chkQrCodeOK + chkQrCodeNG) + " / check NG : " + chkQrCodeNG);
                logger.Debug("*********************************");
                logger.Error("Unexpected exception occurred during asynchronous processing.", exception);
            }

            logger.Info(" ################### GTS+ QRコード表示正常系 [END] ################### \r\n\r\n");

            // LOGのlogファイルコピー
            FileUtils.DirectoryCopy(currentDir + Constants.FilePath.LOG_FOLDER, logOutDir);
        }

        /// <summary>
        /// シナリオNo.34
        /// </summary>
        public void testScenario_2()
        {
            logger.Info(" ################### GTS+ QRコード表示異常系 - Port:50011接続 [START] ################### ");

            HttpServer procHttpSever = null;
            var procWebSever = new Process();

            try
            {
                // PF再起動
                FileUtils.rebootPF_WebServer(currentDir, procWebSever);

                // httpサーバー起動
                procHttpSever = new HttpServer(currentDir);
                procHttpSever.StartHTTPServer();

                // QRコードの表示
                using (var webDriverComponent = new WebDriverComponent(false, Constants.WebDriverOption.WAIT_TIMEOUT_MILLI_SECONDS))
                {
                    // QRコード画面を開く
                    webDriverComponent.OpenPageAndWaitByID(Constants.URL.GTS_PLUS_QR_CODE, Constants.WAIT_ID.GTS_PLUS_QR_CODE);
                    Thread.Sleep(1000);
                    // QRコード表示のキャプチャ取得
                    webDriverComponent.GetScreenshot(evidenceDirectory, "No.34_QR_VIEW_50011");

                    // PFログ出力内容のチェック
                    CheckWebServer(webDriverComponent.GetValueByIdNoneDisplay(Constants.ITEM_ID_QR.QR_CODE_RESULT_API));

                    logger.Info("*********************************");
                    logger.Info("結果 check OK : " + chkQrCodeWebOK + " / check NG : " + chkQrCodeWebNG);
                    logger.Info("*********************************");

                }
            }
            catch (Exception exception)
            {
                logger.Debug("*********************************");
                logger.Debug("途中結果 check OK : " + chkQrCodeWebOK + " / check NG : " + chkQrCodeWebNG);
                logger.Debug("*********************************");
                logger.Error("Unexpected exception occurred during asynchronous processing.", exception);
            }

            logger.Info(" ################### GTS+ QRコード表示異常系 - Port:50011接続 [END] ################### \r\n\r\n");

            // WebSever終了
            procWebSever.Kill();
            Thread.Sleep(3000);

            // httpサーバー終了
            procHttpSever.StopHTTPServer();

            // LOGのlogファイルコピー
            FileUtils.DirectoryCopy(currentDir + Constants.FilePath.LOG_FOLDER, logOutDir);
        }

        /// <summary>
        /// シナリオNo.35～37
        /// </summary>
        public void testScenario_3()
        {
            logger.Info(" ################### GTS+ QRコード表示通信エラー系 - [START] ################### ");

            chkQrCodeOK += chkQrCodeWebOK;
            chkQrCodeNG += chkQrCodeWebNG;

            try
            {
                for (int i = 1; i <= 3; i++)
                {
                    switch (i)
                    {
                        case 1:
                            logger.Info(" ### GTS+ 通信エラー  -  PF起動停止（GUI-PF間接続初期化APIでエラー）###");
                            CommunicationError1();
                            break;
                        case 2:
                            logger.Info(" ### GTS+ 通信エラー - PF起動停止（診断開始APIでエラー）###");
                            CommunicationError2();
                            break;
                        case 3:
                            logger.Info(" ### GTS+ 通信エラー - PF起動停止（強制診断終了APIでエラー）###");
                            CommunicationError3();
                            break;
                        default:
                            break;
                    }
                }

                logger.Info("*********************************");
                logger.Info("結果 check OK : " + (chkQrCodeOK + chkQrCodeNG) + " / check NG : " + chkQrCodeNG);
                logger.Info("*********************************");

            }
            catch (Exception exception)
            {
                logger.Debug("*********************************");
                logger.Debug("途中結果 check OK : " + (chkQrCodeOK + chkQrCodeNG) + " / check NG : " + chkQrCodeNG);
                logger.Debug("*********************************");
                logger.Error("Unexpected exception occurred during asynchronous processing.", exception);
            }

            logger.Info(" ################### GTS+ QRコード表示通信エラー系 - [END] ################### \r\n\r\n");

            // LOGのlogファイルコピー
            FileUtils.DirectoryCopy(currentDir + Constants.FilePath.LOG_FOLDER, logOutDir);
        }


        /// <summary>
        /// APIレスポンスチェック
        /// </summary>
        /// <param name="retApi">API戻り値</param>
        private void CheckApi(string retApi)
        {
            int start = 0;

            string[] api = retApi.Replace("\r\n", "\n").Split(new[] { '\n', '\r' });

            foreach (string retValue in api)
            {
                logger.Info(retValue);

                // Successful connection to GTS+.
                start = retValue.IndexOf(Constants.Sample_Word.WEB_SOCKET_SERVER_START);
                if (start != -1)
                {
                    // No.31
                    chkQrCodeOK++;
                    logger.Info("【" + LOG_OUT_NAME + " OK No." + (chkQrCodeOK + chkQrCodeNG) +  "】: サーバーへの接続（" + retValue + "）");

                    // Port番号：50010で接続した場合
                    if (retValue.IndexOf(Constants.Sample_Word.PORT_NUMBER_50010) != -1)
                    {
                        // No.32
                        chkQrCodeOK++;
                        logger.Info("【" + LOG_OUT_NAME + " OK No." + (chkQrCodeOK + chkQrCodeNG) + "】: Port番号：50010で接続（" + retValue + "）");
                    }
                    // Port番号：50011で接続した場合
                    if (retValue.IndexOf(Constants.Sample_Word.PORT_NUMBER_50011) != -1)
                    {
                        // No.32
                        chkQrCodeOK++;
                        logger.Info("【" + LOG_OUT_NAME + " OK No." + (chkQrCodeOK + chkQrCodeNG) + "】: Port番号：50011で接続（" + retValue + "）");
                    }
                    // Port番号：50012で接続した場合
                    if (retValue.IndexOf(Constants.Sample_Word.PORT_NUMBER_50012) != -1)
                    {
                        // No.32
                        chkQrCodeOK++;
                        logger.Info("【" + LOG_OUT_NAME + " OK No." + (chkQrCodeOK + chkQrCodeNG) + "】: Port番号：50012で接続（" + retValue + "）");
                    }
                }

                // APID応答データ抽出
                string apid = "";
                int apidIndex = retValue.IndexOf(Constants.Sample_Word.COMMON_APID);
                if (apidIndex > 0)
                {
                    apid = retValue.Substring(apidIndex + Constants.Sample_Word.COMMON_APID.Length, Constants.APID.APID_LENGTH);
                }

                // 応答結果：result
                string result = "";
                int resultIdx = retValue.IndexOf(Constants.Sample_Word.RESULTINFO_RESULT);
                if (resultIdx > 0)
                {
                    result = retValue.Substring(resultIdx + Constants.Sample_Word.RESULTINFO_RESULT.Length, 2).Trim().Replace(",", "").Replace("}", "");
                }

                // APID別チェック
                if (resultIdx > 0) CheckApid(apid, result, retValue);
            }

        }

        /// <summary>
        /// 接続先チェック - No.34
        /// </summary>
        /// <param name="evidenceLog">PFログファイル</param>
        private void CheckWebServer(string retApi)
        {
            int start = 0;

            string[] api = retApi.Replace("\r\n", "\n").Split(new[] { '\n', '\r' });

            foreach (string retValue in api)
            {
                // Successful connection to GTS+.
                start = retValue.IndexOf(Constants.Sample_Word.WEB_SOCKET_SERVER_START);
                if (start != -1)
                {
                    logger.Info(retValue);

                    // Port番号：50010で接続した場合
                    if (retValue.IndexOf(Constants.Sample_Word.PORT_NUMBER_50010) != -1)
                    {
                        chkQrCodeWebNG++;
                        logger.Info("【" + LOG_OUT_NAME + " NG No.34】: Port番号：50010で接続");
                    }
                    // Port番号：50011で接続した場合
                    if (retValue.IndexOf(Constants.Sample_Word.PORT_NUMBER_50011) != -1)
                    {
                        chkQrCodeWebOK++;
                        logger.Info("【" + LOG_OUT_NAME + " OK No.34】: Port番号：50011で接続");
                    }
                    // Port番号：50012で接続した場合
                    if (retValue.IndexOf(Constants.Sample_Word.PORT_NUMBER_50012) != -1)
                    {
                        chkQrCodeWebNG++;
                        logger.Info("【" + LOG_OUT_NAME + " NG No.34】: Port番号：50012で接続");
                    }
                }
            }
        }

        /// <summary>
        /// APID別チェック
        /// </summary>
        /// <param name="apid">APID</param>
        /// <param name="result">応答結果</param>
        /// <param name="json">APIレスポンス</param>
        private void CheckApid(string apid, string result, string json)
        {
            switch (apid)
            {
                // CN000001
                case Constants.APID.SET_CONNECTION_CONDTION:
                    Checkresult(apid, result, apid + " SET_CONNECTION_CONDTION", json);
                    break;
                // CN000002
                case Constants.APID.CREATE_CHALLENGE_CODE:
                    Checkresult(apid, result, apid + " CREATE_CHALLENGE_CODE", json);
                    break;
                // CN000003
                case Constants.APID.CHECK_API_AUTHENTICATION:
                    Checkresult(apid, result, apid + " CHECK_API_AUTHENTICATION", json);
                    break;
                // SC000006
                case Constants.APID.GET_DIAGNOSTIC_INFORMATION:
                    if (result == "0")
                    {
                        chkQrCodeOK++;
                        logger.Info("【" + LOG_OUT_NAME + " OK No." + (chkQrCodeOK + chkQrCodeNG) +  "】: " + apid + " GET_DIAGNOSTIC_INFORMATION");
                        FileUtils.WriteJson(evidenceDirectory + "\\No." + (chkQrCodeOK + chkQrCodeNG) + "_" + apid + ".json", json);

                        string diagnosisStartStatus = json.Substring(
                        json.IndexOf(Constants.Sample_Word.DIAGNOSIS_START_STATUS) + Constants.Sample_Word.DIAGNOSIS_START_STATUS.Length,
                                1
                            ).Trim().Replace(",", "");

                        // QRコード表示時
                        if(viewID == VIEW_ID_1)
                        {
                            if (DIAGNOSIS_START_STATUS_STOP.Equals(diagnosisStartStatus))
                            {
                                chkQrCodeOK++;
                                logger.Info("【" + LOG_OUT_NAME + " OK No." + (chkQrCodeOK + chkQrCodeNG) +  "】: 診断開始状態 - 0:診断開始未実施");
                            }
                            else
                            {
                                chkQrCodeNG++;
                                logger.Info("【" + LOG_OUT_NAME + " NG No." + (chkQrCodeOK + chkQrCodeNG) +  "】: 診断開始状態 - 1:診断開始中");
                            }
                        }
                        // 確認画面表示時
                        else
                        {
                            if (DIAGNOSIS_START_STATUS_STOP.Equals(diagnosisStartStatus))
                            {
                                chkQrCodeNG++;
                                logger.Info("【" + LOG_OUT_NAME + " NG No." + (chkQrCodeOK + chkQrCodeNG) +  "】: 診断開始状態 - 0:診断開始未実施");
                            }
                            else
                            {
                                chkQrCodeOK++;
                                logger.Info("【" + LOG_OUT_NAME + " OK No." + (chkQrCodeOK + chkQrCodeNG) +  "】: 診断開始状態 - 1:診断開始中");

                                // 仕向IDと言語IDの取得
                                regionId = json.Substring(
                                        json.IndexOf(Constants.Sample_Word.REGION_ID) + Constants.Sample_Word.REGION_ID.Length,
                                        2
                                    ).Trim().Replace(",", "");
                                languageId = json.Substring(
                                        json.IndexOf(Constants.Sample_Word.LANGUAGE_ID) + Constants.Sample_Word.LANGUAGE_ID.Length,
                                        2
                                    ).Trim().Replace(",", "");
                                logger.Info("regionId : " + regionId + " / languageId : " + languageId);
                            }
                        }

                    }
                    else
                    {
                        chkQrCodeNG ++;
                        logger.Info("【" + LOG_OUT_NAME + " NG No." + (chkQrCodeOK + chkQrCodeNG) +  "】: " + apid + " GET_DIAGNOSTIC_INFORMATION");
                        FileUtils.WriteJson(evidenceDirectory + "\\No." + (chkQrCodeOK + chkQrCodeNG) + "_" + apid + ".json", json);
                    }
                    break;
                // SC000001
                case Constants.APID.START_DIAGNOSIS:
                    Checkresult(apid, result, apid + " START_DIAGNOSIS", json);
                    break;
                // IF100001
                case Constants.APID.GET_CONNECTION_INFO_HL:
                    Checkresult(apid, result, apid + " GET_CONNECTION_INFO_HL", json);
                    break;
                // SC000007
                case Constants.APID.FORCED_END_DIAGNOSISON:
                    Checkresult(apid, result, apid + " FORCED_END_DIAGNOSISON", json);
                    break;
                default:
                    chkQrCodeNG ++;
                    logger.Info("【" + LOG_OUT_NAME + " NG No." + (chkQrCodeOK + chkQrCodeNG) +  "】: " + apid + " API未定義");
                    break;
            }
        }

        /// <summary>
        /// 応答結果チェック
        /// </summary>
        /// <param name="apid">apid</param>
        /// <param name="result">応答結果</param>
        /// <param name="msg">NG時メッセージ</param>
        /// <param name="json">応答Json</param>
        private void Checkresult(string apid, string result, string msg, string json)
        {
            if (result == "0")
            {
                chkQrCodeOK++;
                logger.Info("【" + LOG_OUT_NAME + " OK No." + (chkQrCodeOK + chkQrCodeNG) +  "】: " + msg);
            }
            else
            {
                chkQrCodeNG++;
                logger.Info("【" + LOG_OUT_NAME + " NG No." + (chkQrCodeOK + chkQrCodeNG) +  "】: " + msg);
            }

            FileUtils.WriteJson(evidenceDirectory + "\\No." + (chkQrCodeOK + chkQrCodeNG) + "_" + apid + ".json", json);
        }

        /// <summary>
        /// 仕向/言語チェック
        /// </summary>
        /// <param name="title">タイトル</param>
        /// <param name="table">仕向言語表</param>
        /// <param name="continueBtn">継続ボタン</param>
        /// <param name="forcedBtn">強制継続ボタン</param>
        private bool CheckRegionLanguage(string title, string table, string continueBtn, string forcedBtn)
        {
            // コードテーブルを取得
            CodeDictionary codeDic = new CodeDictionary();
            // 言語
            Dictionary<string, string> languageDic = codeDic.LanguageDictionary();
            string language = languageDic[languageId];
            // 仕向
            Dictionary<string, string> regionDic = codeDic.RegionDictionary();
            string region = regionDic[regionId];

            // 改行コードから仕向と言語を分ける
            string[] del = { "\r\n" };
            string[] arr = table.Split(del, StringSplitOptions.None);
            string[] viewLanguage = arr[0].Split(' ');
            string languageTitle = viewLanguage[0];
            string languageValue = viewLanguage[1];
            string[] viewRegion = arr[1].Split(' ');
            string regionTitle = viewRegion[0];
            string regionValue = viewRegion[1];

            // タイトル
            string region_title = "";
            // 言語
            string region_LanguageTitle = "";
            // 仕向
            string region_RegionTitle = "";
            // 継続
            string region_ContinueBtn = "";
            // 強制継続
            string region_ForcedBtn = "";

            switch (regionId)
            {
                // 日本向けの場合
                case Constants.RegionId.REGION_CODE_JAPAN:
                    region_title = Constants_JA.QrCodeItem.TITLE;
                    region_LanguageTitle = Constants_JA.QrCodeItem.LANGUAGE_ID;
                    region_RegionTitle = Constants_JA.QrCodeItem.REGION_ID;
                    region_ContinueBtn = Constants_JA.QrCodeItem.CONTINUE;
                    region_ForcedBtn = Constants_JA.QrCodeItem.FORCED_CONTINUATION;
                    break;
                // 北米向けの場合
                case Constants.RegionId.REGION_CODE_NORTH_AMERICA:
                    region_title = Constants_EN.QrCodeItem.TITLE;
                    region_LanguageTitle = Constants_EN.QrCodeItem.LANGUAGE_ID;
                    region_RegionTitle = Constants_EN.QrCodeItem.REGION_ID;
                    region_ContinueBtn = Constants_EN.QrCodeItem.CONTINUE;
                    region_ForcedBtn = Constants_EN.QrCodeItem.FORCED_CONTINUATION;
                    break;
                case Constants.RegionId.REGION_CODE_EUROPE:
                    break;
                case Constants.RegionId.REGION_CODE_OTHER:
                    break;
                default:
                    break;
            }


            // タイトル
            if (region_title != title)
            {
                logger.Info("【" + LOG_OUT_NAME + " NG No." + (chkQrCodeOK + chkQrCodeNG) +  "】タイトル : " + title);
                return false;
            }
            // 言語
            if (region_LanguageTitle != languageTitle)
            {
                logger.Info("【" + LOG_OUT_NAME + " NG No." + (chkQrCodeOK + chkQrCodeNG) +  "】言語ID : " + languageTitle);
                return false;
            }
            if (language != languageValue)
            {
                logger.Info("【" + LOG_OUT_NAME + " NG No." + (chkQrCodeOK + chkQrCodeNG) +  "】言語 : " + languageValue);
                return false;
            }
            // 仕向
            if (region_RegionTitle != regionTitle)
            {
                logger.Info("【" + LOG_OUT_NAME + " NG No." + (chkQrCodeOK + chkQrCodeNG) +  "】仕向ID : " + regionTitle);
                return false;
            }
            if (region != regionValue)
            {
                logger.Info("【" + LOG_OUT_NAME + " NG No." + (chkQrCodeOK + chkQrCodeNG) +  "】仕向 : " + regionValue);
                return false;
            }
            // 継続
            if (region_ContinueBtn != continueBtn)
            {
                logger.Info("【" + LOG_OUT_NAME + " NG No." + (chkQrCodeOK + chkQrCodeNG) +  "】継続ボタン : " + continueBtn);
                return false;
            }
            // 強制継続
            if (region_ForcedBtn != forcedBtn)
            {
                logger.Info("【" + LOG_OUT_NAME + " NG No." + (chkQrCodeOK + chkQrCodeNG) +  "】 強制継続ボタン: " + forcedBtn);
                return false;
            }

            return true;
        }

        /// <summary>
        /// 通信エラーチェック１ 
        /// </summary>
        private void CommunicationError1()
        {
            // 確定画面コードの表示
            using (var webDriverComponent = new WebDriverComponent(false, Constants.WebDriverOption.WAIT_TIMEOUT_MILLI_SECONDS))
            {
                // PF停止
                FileUtils.stopPF();
                logger.Info("PF停止");

                // QRコード画面を開く
                webDriverComponent.OpenPage(Constants.URL.GTS_PLUS_QR_CODE);
                Thread.Sleep(10000);
                // Error画面のキャプチャ取得
                webDriverComponent.GetScreenshot(evidenceDirectory, "No.35_QR_ERROR");
                bool ret = webDriverComponent.IsDisplayedById(Constants.ITEM_ID_QR.QR_CODE_CONFIRM_ERROR);
                CheckError(ret);
            }
        }

        /// <summary>
        /// 通信エラーチェック２
        /// </summary>
        private void CommunicationError2()
        {
            // 確定画面コードの表示
            using (var webDriverComponent = new WebDriverComponent(false, Constants.WebDriverOption.WAIT_TIMEOUT_MILLI_SECONDS))
            {
                // PF再起動
                FileUtils.rebootPF(currentDir);

                // QRコード画面を開く
                webDriverComponent.OpenPageAndWaitByID(Constants.URL.GTS_PLUS_QR_CODE, Constants.WAIT_ID.GTS_PLUS_QR_CODE);
                Thread.Sleep(1000);
                // 確認画面を開く
                webDriverComponent.OpenPageAndWaitByID(Constants.URL.GTS_PLUS_QR_CODE, Constants.WAIT_ID.GTS_PLUS_QR_CODE_CONFIRM);
                Thread.Sleep(1000);
                // 確認画面のキャプチャ取得
                webDriverComponent.GetScreenshot(evidenceDirectory, "No.36_1_QR_Confirm");

                // PF停止
                FileUtils.stopPF();
                logger.Info("PF停止");

                // 継続ボタン押下
                webDriverComponent.ClickById(Constants.ITEM_ID_QR.QR_CODE_CONFIRM_CONTINUE);

                Thread.Sleep(33000);
                // Error画面のキャプチャ取得
                webDriverComponent.GetScreenshot(evidenceDirectory, "No.36_2_QR_ERROR");
                bool ret = webDriverComponent.IsDisplayedById(Constants.ITEM_ID_QR.QR_CODE_CONFIRM_ERROR);
                CheckError(ret);
            }
        }

        /// <summary>
        /// 通信エラーチェック３
        /// </summary>
        private void CommunicationError3()
        {
            // 確定画面コードの表示
            using (var webDriverComponent = new WebDriverComponent(false, Constants.WebDriverOption.WAIT_TIMEOUT_MILLI_SECONDS))
            {
                // PF再起動
                FileUtils.rebootPF(currentDir);

                // QRコード画面を開く
                webDriverComponent.OpenPageAndWaitByID(Constants.URL.GTS_PLUS_QR_CODE, Constants.WAIT_ID.GTS_PLUS_QR_CODE);
                Thread.Sleep(1000);
                // 確認画面を開く
                webDriverComponent.OpenPageAndWaitByID(Constants.URL.GTS_PLUS_QR_CODE, Constants.WAIT_ID.GTS_PLUS_QR_CODE_CONFIRM);
                Thread.Sleep(1000);
                // 確認画面のキャプチャ取得
                webDriverComponent.GetScreenshot(evidenceDirectory, "No.37_1_QR_Confirm");

                // PF停止
                FileUtils.stopPF();
                Thread.Sleep(2000);
                logger.Info("PF停止");

                // 強制継続ボタン押下
                webDriverComponent.ClickById(Constants.ITEM_ID_QR.QR_CODE_CONFIRM_FORCED_CONTINUE);

                Thread.Sleep(33000);
                // Error画面のキャプチャ取得
                webDriverComponent.GetScreenshot(evidenceDirectory, "No.37_2_QR_ERROR");
                bool ret = webDriverComponent.IsDisplayedById(Constants.ITEM_ID_QR.QR_CODE_CONFIRM_ERROR);
                CheckError(ret);
            }
        }

        /// <summary>
        /// 通信エラーログ出力
        /// </summary>
        /// <param name="ret">成否</param>
        private void CheckError(bool ret)
        {
            if (ret)
            {
                chkQrCodeOK++;
                logger.Info("【" + LOG_OUT_NAME + " OK No." + (chkQrCodeOK + chkQrCodeNG) + "】: Error画面表示 --- OK.");
            }
            else
            {
                chkQrCodeNG++;
                logger.Info("【" + LOG_OUT_NAME + " NG No." + (chkQrCodeOK + chkQrCodeNG) + "】: Error画面表示 --- NG.");
            }
        }

        /// <summary>
        /// 破棄処理
        /// </summary>
        public void Dispose()
        {
        }
    }
}
