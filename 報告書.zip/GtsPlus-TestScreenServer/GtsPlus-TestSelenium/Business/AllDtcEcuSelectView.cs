﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using System.Diagnostics;
using System.Threading;
using IWshRuntimeLibrary;
using log4net;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using SeleniumExtras.WaitHelpers;
using GtsPlus_TestSelenium.Constant;
using GtsPlus_TestSelenium.Component;
using GtsPlus_TestSelenium.Utils;
using GtsPlus_TestSelenium.Constant.Lang;
using System.Collections;

namespace GtsPlus_TestSelenium.Business
{
    /// <summary>
    /// テストシナリオ-Allダイアグ（ECU select）画面
    /// </summary>
    public class AllDtcEcuSelectView:IDisposable
    {
        /// <summary>
        /// log4net
        /// </summary>
        private static readonly ILog logger = LogManager.GetLogger(typeof(Program));

        /// <summary>
        /// 大分類名
        /// </summary>
        private const string LOG_OUT_NAME = "Allダイアグ";
        /// <summary>
        /// エビデンスフォルダ-正常系
        /// </summary>
        private const string EVIDENCE_DIR = "/" + LOG_OUT_NAME;
        /// <summary>
        /// JQueryで付与されるオプションリストのID追加文字列
        /// </summary>
        private const string ID_ADD_STRING = "-button";
        /// <summary>
        /// Ecu ID 桁数
        /// </summary>
        private const int ECU_ID_LENGTH = 3;
        /// <summary>
        /// ECU ID
        /// </summary>
        private const string ECU_ID = "ecuId";
        /// <summary>
        /// ECU ID[ENGINE]
        /// </summary>
        private const string ECU_ID_ENGINE = "372";
        /// <summary>
        /// phaseType 5
        /// </summary>
        private const string PHASE_TYPE_5 = "20";
        /// <summary>
        /// 接続状態：接続
        /// </summary>
        private const string CONNECT_ARI = "1";
        /// <summary>
        /// 接続状態桁数
        /// </summary>
        private const int CONNECT_LENGTH = 1;
        /// <summary>
        /// ECU名（エンジン）
        /// </summary>
        private const string ECU_NAME_ENGINE = "エンジン";
        /// <summary>
        /// ECU名（ABS- VSC- TRC）
        /// </summary>
        private const string ECU_NAME_ABS_VSC_TRC = "ABS- VSC- TRC";
        /// <summary>
        /// ECU名（A/C）
        /// </summary>
        private const string ECU_NAME_A_C = "A/C";
        /// <summary>
        /// ECU名（メインボデー）
        /// </summary>
        private const string ECU_NAME_MAIN_BODY = "メインボデー";
        /// <summary>
        /// FFD対象外
        /// </summary>
        private const string FFD_NASI = "0";
        /// <summary>
        /// DTCリスト フラグチェックイメージID
        /// </summary>
        private const string IMAGE_CHECK_ENHANCED_ID = "enhanced";
        /// <summary>
        /// DTCリスト フラグチェックイメージID
        /// </summary>
        private const string IMAGE_CHECK_GENERIC_ID = "generic";
        /// <summary>
        /// DTCリスト チェックイメージID
        /// </summary>
        private const string IMAGE_CHECK_ID = "img_check";
        /// <summary>
        /// DTCリスト FFDチェックイメージID
        /// </summary>
        private const string IMAGE_CHECK_FFD_ID = "img_ffd";


        /// <summary>
        /// 実行ディレクトリ
        /// </summary>
        private string currentDir;
        /// <summary>
        /// エビデンス出力ディレクトリ
        /// </summary>
        private string evidenceDirectory;
        /// <summary>
        /// ログ出力先ディレクトリ
        /// </summary>
        private string logOutDir;

        /// <summary>
        /// OK件数
        /// </summary>
        private int chkAllDtcOK = 0;
        /// <summary>
        /// NG件数
        /// </summary>
        private int chkAllDtcNG = 0;
        /// <summary>
        /// 先行チェック（No.17、18、19）件数
        /// </summary>
        private int chkAllDtc = 0;

        /// <summary>
        /// ECU IDリスト
        /// </summary>
        private List<string> listEcuId = new List<string>();

        /// <summary>
        /// Phase type
        /// </summary>
        private string phaseType = "";

        /// <summary>
        /// 接続状態：接続件数
        /// </summary>
        private int connect = 0;

        /// <summary>
        /// 接続確認ECU IDリスト
        /// </summary>
        private List<string> listConnectEcuId = new List<string>();

        /// <summary>
        /// DTC取得結果表示用DTCリスト
        /// </summary>
        private List<string> listCodeDisp = new List<string>();
        /// <summary>
        /// DTC取得結果表示用名称リスト
        /// </summary>
        private List<string> listName = new List<string>();
        /// <summary>
        /// DTC取得結果ダイアグコード種別フラグリスト
        /// </summary>
        private Dictionary<string, string> listKindFlag = new Dictionary<string, string>();
        /// <summary>
        /// DTC取得結果ダイアグコード種別リスト
        /// </summary>
        private Dictionary<string, string> listDtcType = new Dictionary<string, string>();
        /// <summary>
        /// DTC取得結果FFDリスト
        /// </summary>
        private Dictionary<string, string> listFfd = new Dictionary<string, string>();


        /// <summary>
        /// コンストラクタ
        /// </summary>
        public AllDtcEcuSelectView(string currentDir, string evidenceDir)
        {
            this.currentDir = currentDir;
            this.logOutDir = currentDir + evidenceDir;

            this.evidenceDirectory = logOutDir + EVIDENCE_DIR;
            // エビデンスフォルダ作成
            FileUtils.createEvidenceDirectory(evidenceDirectory);
        }

        /// <summary>
        /// シナリオNo.177～218
        /// </summary>
        public void testScenario_1()
        {
            logger.Info(" ################### GTS+ Allダイアグ（ECU select）画面 [START] ################### ");

            try
            {
                // PF再起動
                FileUtils.rebootPF(currentDir);

                // Allダイアグ（ECU select）画面の表示
                using (var webDriverComponent = new WebDriverComponent(false, Constants.WebDriverOption.WAIT_TIMEOUT_MILLI_SECONDS))
                {
                    #region "function menu"
                    /*
                     * 機能メニューを表示するまで進める
                     * */
                    // 車両確定画面を開く
                    logger.Debug("【車両確定画面を開く】");
                    webDriverComponent.OpenPageAndWaitByID(Constants.URL.GTS_PLUS_VHCN, Constants.WAIT_ID.GTS_PLUS_VHCN);
                    Thread.Sleep(5000);

                    // オプション選択（「<SELECT>」の下の項目を選択）
                    logger.Debug("【オプション項目選択変更】: オプション１");
                    webDriverComponent.SelectOptionById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_OPTION1 + ID_ADD_STRING, false, 1);

                    // Confirmボタン押下 
                    logger.Debug("【確定ボタン押下】");
                    webDriverComponent.ClickById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_IMAGE_CONFIRM);
                    Thread.Sleep(30000);

                    //webDriverComponent.OpenPageAndWaitByID(Constants.URL.GTS_PLUS_VHCN, Constants.ITEM_ID_VEHICLE_CONFIRMATION.VEHICLE_CONFIRMATION_YES);
                    //Thread.Sleep(1000);
                    //webDriverComponent.ClickById(Constants.ITEM_ID_VEHICLE_CONFIRMATION.VEHICLE_CONFIRMATION_YES);
                    //Thread.Sleep(1000);


                    // 機能メニュー画面のキャプチャ取得
                    logger.Debug("【機能メニュー画面】");
                    webDriverComponent.GetScreenshot(evidenceDirectory, "No.0_FunctionMenu");

                    #endregion "function menu"

                    /*
                     * Allダイアグ（ECU select）画面
                     * */
                    #region "all diag select"

                    // All DTCボタン押下 
                    logger.Debug("【All DTCボタン押下 】");
                    webDriverComponent.ClickById(Constants.ITEM_ID_FUNCTION_MENU.FUNCTION_MENU_ALL_DTC);
                    Thread.Sleep(2000);

                    // APIのレスポンスチェック No.1
                    DateTime startTime = DateTime.Now;
                    string responce = "";
                    while(true)
                    {
                        responce = webDriverComponent.GetValueByIdNoneDisplay(Constants.ITEM_ID_ALL_DTC_SELECT.ALL_DTC_SELECT_RESULT_API);
                        if (!string.IsNullOrEmpty(responce))
                        {
                            break;
                        }
                        else
                        {
                            // タイムアウト
                            if (DateTime.Now.Subtract(startTime).TotalMilliseconds > 1200000)
                            {
                                logger.Error("タイムアウト：" + DateTime.Now);
                                break;
                            }
                        }

                        // 間隔
                        Thread.Sleep(1000);
                    }
                    // No.1
                    CheckApi(responce, Constants.APID.GET_MOUNT_ECU_LIST);

                    // Allダイアグ（ECU select）画面のキャプチャ取得
                    webDriverComponent.GetScreenshot(evidenceDirectory, "No.2-3_AllDtcSelectInit");
                    // No.2
                    if (webDriverComponent.IsDisplayedById(Constants.ITEM_ID_ALL_DTC_SELECT.ALL_DTC_SLIDER))
                    {
                        chkAllDtcOK++;
                        logger.Info("【" + LOG_OUT_NAME + " OK No.2】: Slider表示");
                    }
                    else
                    {
                        chkAllDtcNG++;
                        logger.Info("【" + LOG_OUT_NAME + " NG No.2】: Slider表示");
                    }
                    // No.3
                    if (webDriverComponent.IsDisplayedById(Constants.ITEM_ID_ALL_DTC_SELECT.ALL_DTC_IMAGE_PROCESSING))
                    {
                        chkAllDtcOK++;
                        logger.Info("【" + LOG_OUT_NAME + " OK No.3】: 処理中アイコン表示");
                    }
                    else
                    {
                        chkAllDtcNG++;
                        logger.Info("【" + LOG_OUT_NAME + " NG No.3】: 処理中アイコン表示");
                    }
                    // ECU一覧項目押下 No.17
                    webDriverComponent.WaitUntilClickableById(Constants.ITEM_ID_ALL_DTC_SELECT.ALL_DTC_IMAGE_PROCESSING);
                    webDriverComponent.GetScreenshot(evidenceDirectory, "No.17_AllDtcProcessingClick");
                    if (webDriverComponent.IsDisplayedById(Constants.ITEM_ID_ALL_DTC_SELECT.ALL_DTC_SLIDER))
                    {
                        chkAllDtcOK++;
                        logger.Info("【" + LOG_OUT_NAME + " OK No.17】: 白枠（処理中）押下");
                    }
                    else
                    {
                        chkAllDtcNG++;
                        logger.Info("【" + LOG_OUT_NAME + " NG No.17】: 白枠（処理中）押下");
                    }
                    chkAllDtc++;


                    // ECU接続確認
                    startTime = DateTime.Now;
                    logger.Debug(startTime + " - ECU接続確認APIを全件取得するまで待機開始");
                    while (true)
                    {
                        // ECU接続確認APIが全て返却されるまで（白枠ノットサポートが表示されるまで）
                        if (webDriverComponent.IsDisplayedById(Constants.ITEM_ID_ALL_DTC_SELECT.ALL_DTC_IMAGE_ABSENCE))
                        {
                            logger.Debug(DateTime.Now.Subtract(startTime).TotalMilliseconds + "msec - ECU接続確認API 全件取得経過時間");

                            // APIのレスポンスチェック No.4
                            CheckApi(webDriverComponent.GetValueByIdNoneDisplay(Constants.ITEM_ID_ALL_DTC_SELECT.ALL_DTC_SELECT_RESULT_API),
                                Constants.APID.CHECK_ECU_CONNECT);
                            logger.Debug("【接続状態】接続あり：" + connect + "件");

                            // 白枠ノットサポートのキャプチャ取得 No.5
                            webDriverComponent.GetScreenshot(evidenceDirectory, "No.5_AllDtcSelectAbsence");
                            if (webDriverComponent.IsDisplayedById(Constants.ITEM_ID_ALL_DTC_SELECT.ALL_DTC_IMAGE_ABSENCE))
                            {
                                chkAllDtcOK++;
                                logger.Info("【" + LOG_OUT_NAME + " OK No.5】: ノットサポート表示");
                            }
                            else
                            {
                                chkAllDtcNG++;
                                logger.Info("【" + LOG_OUT_NAME + " NG No.5】: ノットサポート表示");
                            }

                            break;
                        }
                        else
                        {
                            // タイムアウト
                            if(DateTime.Now.Subtract(startTime).TotalMilliseconds > 1200000)
                            {
                                logger.Error("タイムアウト：" + DateTime.Now);
                                break;
                            }
                        }

                        // 間隔
                        Thread.Sleep(1000);
                    }
                    // ECU一覧項目押下 No.18
                    webDriverComponent.WaitUntilClickableById(Constants.ITEM_ID_ALL_DTC_SELECT.ALL_DTC_IMAGE_ABSENCE);
                    webDriverComponent.GetScreenshot(evidenceDirectory, "No.18_AllDtcAbsenceClick");
                    if (webDriverComponent.IsDisplayedById(Constants.ITEM_ID_ALL_DTC_SELECT.ALL_DTC_SLIDER))
                    {
                        chkAllDtcOK++;
                        logger.Info("【" + LOG_OUT_NAME + " OK No.18】: 白枠（ECU not supported）押下");
                    }
                    else
                    {
                        chkAllDtcNG++;
                        logger.Info("【" + LOG_OUT_NAME + " NG No.18】: 白枠（ECU not supported）押下");
                    }
                    chkAllDtc++;
                    Thread.Sleep(3000);


                    // システム例外対応 No.6
                    CheckApi(webDriverComponent.GetValueByIdNoneDisplay(Constants.ITEM_ID_ALL_DTC_SELECT.ALL_DTC_SELECT_RESULT_API),
                        Constants.APID.REPLACE_SYSTEM_EXCEPTION);
                    Thread.Sleep(5000);


                    // ECU機能リスト取得 No.7
                    CheckApi(webDriverComponent.GetValueByIdNoneDisplay(Constants.ITEM_ID_ALL_DTC_SELECT.ALL_DTC_SELECT_RESULT_API),
                        Constants.APID.GET_ECU_FUNC_LIST);

                    // DTC取得
                    startTime = DateTime.Now;
                    logger.Debug(startTime + " - DTC取得APIを全件取得するまで待機開始");
                    while (true)
                    {
                        // DTC取得APIが全て返却されるまで（赤枠が表示されるまで）
                        if (webDriverComponent.IsDisplayedById(Constants.ITEM_ID_ALL_DTC_SELECT.ALL_DTC_IMAGE_DTC))
                        {
                            logger.Debug(DateTime.Now.Subtract(startTime).TotalMilliseconds + "msec - DTC取得API 全件取得経過時間");

                            // APIのレスポンスチェック No.8
                            CheckApi(webDriverComponent.GetValueByIdNoneDisplay(Constants.ITEM_ID_ALL_DTC_SELECT.ALL_DTC_SELECT_RESULT_API),
                                Constants.APID.GET_DTC);

                            // 赤枠DTCありのキャプチャ取得
                            webDriverComponent.GetScreenshot(evidenceDirectory, "No.9_AllDtcSelectDtc");
                            // No.9
                            if (webDriverComponent.IsDisplayedById(Constants.ITEM_ID_ALL_DTC_SELECT.ALL_DTC_IMAGE_DTC))
                            {
                                chkAllDtcOK++;
                                logger.Info("【" + LOG_OUT_NAME + " OK No.9】: DTC表示");
                            }
                            else
                            {
                                chkAllDtcNG++;
                                logger.Info("【" + LOG_OUT_NAME + " NG No.9】: DTC表示");
                            }

                            // No.10、19
                            webDriverComponent.WaitUntilClickableById(Constants.ITEM_ID_ALL_DTC_SELECT.ALL_DTC_IMAGE_NOT_DTC);
                            // 青枠DTCなしのキャプチャ取得
                            webDriverComponent.GetScreenshot(evidenceDirectory, "No.10_AllDtcSelectNotDtc");
                            webDriverComponent.GetScreenshot(evidenceDirectory, "No.19_AllDtcSelectNotDtcClick");
                            if (webDriverComponent.IsDisplayedById(Constants.ITEM_ID_ALL_DTC_SELECT.ALL_DTC_IMAGE_NOT_DTC))
                            {
                                chkAllDtcOK++;
                                logger.Info("【" + LOG_OUT_NAME + " OK No.10】: 青枠表示");
                                chkAllDtcOK++;
                                logger.Info("【" + LOG_OUT_NAME + " OK No.19】: 青枠押下");
                            }
                            else
                            {
                                chkAllDtcNG++;
                                logger.Info("【" + LOG_OUT_NAME + " NG No.10】: 青枠表示");
                                chkAllDtcNG++;
                                logger.Info("【" + LOG_OUT_NAME + " NG No.19】: 青枠押下");
                            }
                            chkAllDtc++;

                            break;
                        }
                        else
                        {
                            // タイムアウト
                            if (DateTime.Now.Subtract(startTime).TotalMilliseconds > 1200000)
                            {
                                logger.Error("タイムアウト：" + DateTime.Now);
                                break;
                            }
                        }

                        // 間隔
                        Thread.Sleep(1000);
                    }

                    #region "button click"

                    // Power trainボタン押下
                    logger.Debug("【CHASSISとBODY項目を非表示にする】");
                    webDriverComponent.ClickById(Constants.ITEM_ID_ALL_DTC_SELECT.ALL_DTC_IMAGE_CHASSIS);
                    webDriverComponent.ClickById(Constants.ITEM_ID_ALL_DTC_SELECT.ALL_DTC_IMAGE_BODY);
                    Thread.Sleep(1000);
                    logger.Debug("【Power trainボタン押下（表示→非表示）】");
                    webDriverComponent.ClickById(Constants.ITEM_ID_ALL_DTC_SELECT.ALL_DTC_IMAGE_POWER);
                    Thread.Sleep(1000);
                    // Power trainのキャプチャ取得
                    webDriverComponent.GetScreenshot(evidenceDirectory, "No.11_AllDtcSelectPower_OFF");
                    // Power train表示チェック No.11
                    if(!webDriverComponent.IsDisplayedByEcuName(ECU_NAME_ENGINE))
                    {
                        chkAllDtcOK++;
                        logger.Info("【" + LOG_OUT_NAME + " OK No.11】: Power train非表示");
                    }
                    else
                    {
                        chkAllDtcNG++;
                        logger.Info("【" + LOG_OUT_NAME + " NG No.11】: Power train表示");
                    }
                    logger.Debug("【Power trainボタン押下（非表示→表示）】");
                    webDriverComponent.ClickById(Constants.ITEM_ID_ALL_DTC_SELECT.ALL_DTC_IMAGE_POWER);
                    Thread.Sleep(1000);
                    // Power trainのキャプチャ取得
                    webDriverComponent.GetScreenshot(evidenceDirectory, "No.12_AllDtcSelectPower_ON");
                    // Power train表示チェック No.12
                    if (webDriverComponent.IsDisplayedByEcuName(ECU_NAME_ENGINE))
                    {
                        chkAllDtcOK++;
                        logger.Info("【" + LOG_OUT_NAME + " OK No.12】: Power train表示");
                    }
                    else
                    {
                        chkAllDtcNG++;
                        logger.Info("【" + LOG_OUT_NAME + " NG No.12】: Power train非表示");
                    }
                    Thread.Sleep(1000);

                    // CHASSISボタン押下
                    logger.Debug("【POWER TRAILとBODY項目を非表示にする】");
                    webDriverComponent.ClickById(Constants.ITEM_ID_ALL_DTC_SELECT.ALL_DTC_IMAGE_POWER);
                    webDriverComponent.ClickById(Constants.ITEM_ID_ALL_DTC_SELECT.ALL_DTC_IMAGE_CHASSIS);
                    Thread.Sleep(1000);
                    logger.Debug("【CHASSISボタン押下（表示→非表示）】");
                    webDriverComponent.ClickById(Constants.ITEM_ID_ALL_DTC_SELECT.ALL_DTC_IMAGE_CHASSIS);
                    Thread.Sleep(1000);
                    // CHASSISのキャプチャ取得
                    webDriverComponent.GetScreenshot(evidenceDirectory, "No.13_AllDtcSelectChassis_OFF");
                    // CHASSIS表示チェック No.13
                    if (!webDriverComponent.IsDisplayedByEcuName(ECU_NAME_ABS_VSC_TRC))
                    {
                        chkAllDtcOK++;
                        logger.Info("【" + LOG_OUT_NAME + " OK No.13】: CHASSIS非表示");
                    }
                    else
                    {
                        chkAllDtcNG++;
                        logger.Info("【" + LOG_OUT_NAME + " NG No.13】: CHASSIS表示");
                    }
                    logger.Debug("【CHASSISボタン押下（非表示→表示）】");
                    webDriverComponent.ClickById(Constants.ITEM_ID_ALL_DTC_SELECT.ALL_DTC_IMAGE_CHASSIS);
                    Thread.Sleep(1000);
                    // CHASSISのキャプチャ取得
                    webDriverComponent.GetScreenshot(evidenceDirectory, "No.14_AllDtcSelectChassis_ON");
                    // CHASSIS表示チェック No.14
                    if (webDriverComponent.IsDisplayedByEcuName(ECU_NAME_ABS_VSC_TRC))
                    {
                        chkAllDtcOK++;
                        logger.Info("【" + LOG_OUT_NAME + " OK No.14】: CHASSIS表示");
                    }
                    else
                    {
                        chkAllDtcNG++;
                        logger.Info("【" + LOG_OUT_NAME + " NG No.14】: CHASSIS非表示");
                    }
                    Thread.Sleep(1000);

                    // BODYボタン押下
                    logger.Debug("【POWER TRAILとCHASSIS項目を非表示にする】");
                    webDriverComponent.ClickById(Constants.ITEM_ID_ALL_DTC_SELECT.ALL_DTC_IMAGE_CHASSIS);
                    webDriverComponent.ClickById(Constants.ITEM_ID_ALL_DTC_SELECT.ALL_DTC_IMAGE_BODY);
                    Thread.Sleep(1000);
                    logger.Debug("【BODYボタン押下（表示→非表示）】");
                    webDriverComponent.ClickById(Constants.ITEM_ID_ALL_DTC_SELECT.ALL_DTC_IMAGE_BODY);
                    Thread.Sleep(1000);
                    // BODYのキャプチャ取得
                    webDriverComponent.GetScreenshot(evidenceDirectory, "No.15_AllDtcSelectBodt_OFF");
                    // BODY表示チェック No.15
                    if (!webDriverComponent.IsDisplayedByEcuName(ECU_NAME_A_C))
                    {
                        chkAllDtcOK++;
                        logger.Info("【" + LOG_OUT_NAME + " OK No.15】: BODY非表示");
                    }
                    else
                    {
                        chkAllDtcNG++;
                        logger.Info("【" + LOG_OUT_NAME + " NG No.15】: BODY表示");
                    }
                    logger.Debug("【BODYボタン押下（非表示→表示）】");
                    webDriverComponent.ClickById(Constants.ITEM_ID_ALL_DTC_SELECT.ALL_DTC_IMAGE_BODY);
                    Thread.Sleep(1000);
                    // BODYのキャプチャ取得
                    webDriverComponent.GetScreenshot(evidenceDirectory, "No.16_AllDtcSelectBody_ON");
                    // BODY表示チェック No.16
                    if (webDriverComponent.IsDisplayedByEcuName(ECU_NAME_A_C))
                    {
                        chkAllDtcOK++;
                        logger.Info("【" + LOG_OUT_NAME + " OK No.16】: BODY表示");
                    }
                    else
                    {
                        chkAllDtcNG++;
                        logger.Info("【" + LOG_OUT_NAME + " NG No.16】: BODY非表示");
                    }

                    #endregion "button click"

                    // ECU一覧項目押下
                    webDriverComponent.ClickById(Constants.ITEM_ID_ALL_DTC_SELECT.ALL_DTC_IMAGE_POWER);
                    webDriverComponent.ClickById(Constants.ITEM_ID_ALL_DTC_SELECT.ALL_DTC_IMAGE_CHASSIS);
                    Thread.Sleep(1000);
                    logger.Debug("【エンジンボタン押下（ALLダイアグ（DTC）画面表示）】");
                    webDriverComponent.ClickByEcuName(ECU_NAME_ENGINE);
                    Thread.Sleep(1000);
                    // Allダイアグ（DTC）画面のキャプチャ取得
                    webDriverComponent.GetScreenshot(evidenceDirectory, "No.20-29_AllDtc");
                    // No.20
                    if (webDriverComponent.IsDisplayedById(Constants.ITEM_ID_ALL_DTC.ALL_DTC_ECU_LIST))
                    {
                        chkAllDtcOK++;
                        logger.Info("【" + LOG_OUT_NAME + " OK No.20】: 赤枠押下");
                    }
                    else
                    {
                        chkAllDtcNG++;
                        logger.Info("【" + LOG_OUT_NAME + " NG No.20】: 赤枠押下");
                    }

                    logger.Info("**************** Allダイアグ（DTC）画面 *****************");

                    #endregion "all diag select"

                    /*
                     * Allダイアグ（DTC）画面
                     * */
                    #region "all diag dtc"

                    string list = webDriverComponent.GetValueById(Constants.ITEM_ID_ALL_DTC.ALL_DTC_ECU_LIST);
                    // 画面表示コード/名称/件数
                    CheckDtcList(list);
                    // ダイアグコード種別チェック
                    CheckDtcImageList(webDriverComponent);

                    logger.Info("**************** Allダイアグ（ECU select）画面へ戻る *****************");
                    // 戻るボタン押下
                    logger.Debug("【戻るボタン押下（ALLダイアグ（ECU select）画面表示）】");
                    webDriverComponent.ClickById(Constants.ITEM_ID_ALL_DTC.ALL_DTC_BACK);
                    Thread.Sleep(1000);
                    // Allダイアグ（ECU select）画面のキャプチャ取得 No.30
                    webDriverComponent.GetScreenshot(evidenceDirectory, "No.30_AllDtc1");
                    bool check1 = CheckView(webDriverComponent,true, true, true);
                    if (check1)
                    {
                        chkAllDtcOK++;
                        logger.Info("【" + LOG_OUT_NAME + " OK No.30】: 戻るボタン押下 表示維持");
                    }
                    else
                    {
                        chkAllDtcNG++;
                        logger.Info("【" + LOG_OUT_NAME + " NG No.30】: 戻るボタン押下 表示維持");
                    }


                    //Power Trailのみ
                    webDriverComponent.ClickById(Constants.ITEM_ID_ALL_DTC_SELECT.ALL_DTC_IMAGE_CHASSIS);
                    webDriverComponent.ClickById(Constants.ITEM_ID_ALL_DTC_SELECT.ALL_DTC_IMAGE_BODY);
                    // Allダイアグ（ECU select）画面のキャプチャ取得 No.31
                    webDriverComponent.GetScreenshot(evidenceDirectory, "No.31_AllDtc1");
                    logger.Debug("【エンジンボタン押下（ALLダイアグ（DTC）画面表示）】");
                    webDriverComponent.ClickByEcuName(ECU_NAME_ENGINE);
                    Thread.Sleep(1000);
                    // 戻るボタン押下
                    logger.Debug("【戻るボタン押下（ALLダイアグ（ECU select）画面表示）】");
                    webDriverComponent.ClickById(Constants.ITEM_ID_ALL_DTC.ALL_DTC_BACK);
                    Thread.Sleep(1000);
                    // Allダイアグ（ECU select）画面のキャプチャ取得 No.31
                    webDriverComponent.GetScreenshot(evidenceDirectory, "No.31_AllDtc2");
                    bool check2 = CheckView(webDriverComponent, true, false, false);
                    if (check2)
                    {
                        chkAllDtcOK++;
                        logger.Info("【" + LOG_OUT_NAME + " OK No.31】: 戻るボタン押下(Power trainボタンのみ表示) 表示維持");
                    }
                    else
                    {
                        chkAllDtcNG++;
                        logger.Info("【" + LOG_OUT_NAME + " NG No.31】: 戻るボタン押下(Power trainボタンのみ表示) 表示維持");
                    }


                    //Bodyのみ
                    webDriverComponent.ClickById(Constants.ITEM_ID_ALL_DTC_SELECT.ALL_DTC_IMAGE_POWER);
                    webDriverComponent.ClickById(Constants.ITEM_ID_ALL_DTC_SELECT.ALL_DTC_IMAGE_BODY);
                    Thread.Sleep(1000);
                    // Allダイアグ（ECU select）画面のキャプチャ取得 No.32
                    webDriverComponent.GetScreenshot(evidenceDirectory, "No.32_AllDtc1");
                    logger.Debug("【メインボデーボタン押下（ALLダイアグ（DTC）画面表示）】");
                    webDriverComponent.ClickByEcuName(ECU_NAME_MAIN_BODY);
                    Thread.Sleep(1000);
                    // 戻るボタン押下
                    logger.Debug("【戻るボタン押下（ALLダイアグ（ECU select）画面表示）】");
                    webDriverComponent.ClickById(Constants.ITEM_ID_ALL_DTC.ALL_DTC_BACK);
                    Thread.Sleep(1000);
                    // Allダイアグ（ECU select）画面のキャプチャ取得 No.32
                    webDriverComponent.GetScreenshot(evidenceDirectory, "No.32_AllDtc2");
                    bool check3 = CheckView(webDriverComponent, false, false, true);
                    if (check3)
                    {
                        chkAllDtcOK++;
                        logger.Info("【" + LOG_OUT_NAME + " OK No.32】: 戻るボタン押下(Bodyボタンのみ表示) 表示維持");
                    }
                    else
                    {
                        chkAllDtcNG++;
                        logger.Info("【" + LOG_OUT_NAME + " NG No.32】: 戻るボタン押下(Bodyボタンのみ表示) 表示維持");
                    }

                    #endregion "all diag dtc"


                    logger.Info("*********************************");
                    logger.Info("結果 check OK：" + chkAllDtcOK + " / check NG：" + chkAllDtcNG);
                    logger.Info("*********************************");

                }
            }
            catch (Exception exception)
            {
                logger.Error("*********************************");
                logger.Error("途中結果 check OK：" + chkAllDtcOK + " / check NG：" + chkAllDtcNG);
                logger.Error("*********************************");
                logger.Error("Unexpected exception occurred during asynchronous processing.", exception);
            }

            logger.Info(" ################### GTS+ Allダイアグ（ECU select）画面 [END] ################### \r\n\r\n");

            // LOGのlogファイルコピー
            FileUtils.DirectoryCopy(currentDir + Constants.FilePath.LOG_FOLDER, logOutDir);
        }

        /// <summary>
        /// シナリオNo.195
        /// </summary>
        public void testScenario_2()
        {
            logger.Info(" ################### GTS+ Allダイアグ通信エラー系 - [START] ################### ");

            try
            {
                // PF再起動
                FileUtils.rebootPF(currentDir);

                // Allダイアグ（ECU select）画面の表示
                using (var webDriverComponent = new WebDriverComponent(false, Constants.WebDriverOption.WAIT_TIMEOUT_MILLI_SECONDS))
                {
                    /*
                     * 機能メニューを表示するまで進める
                     * */
                    // 車両確定画面を開く
                    logger.Debug("【車両確定画面を開く】");
                    webDriverComponent.OpenPageAndWaitByID(Constants.URL.GTS_PLUS_VHCN, Constants.WAIT_ID.GTS_PLUS_VHCN);
                    Thread.Sleep(5000);

                    // オプション選択（「<SELECT>」の下の項目を選択）
                    logger.Debug("【オプション項目選択変更】: オプション１");
                    webDriverComponent.SelectOptionById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_OPTION1 + ID_ADD_STRING, false, 1);

                    // Confirmボタン押下 
                    logger.Debug("【確定ボタン押下】");
                    webDriverComponent.ClickById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_IMAGE_CONFIRM);
                    Thread.Sleep(30000);

                    //webDriverComponent.OpenPageAndWaitByID(Constants.URL.GTS_PLUS_VHCN, Constants.ITEM_ID_VEHICLE_CONFIRMATION.VEHICLE_CONFIRMATION_YES);
                    //Thread.Sleep(1000);
                    //webDriverComponent.ClickById(Constants.ITEM_ID_VEHICLE_CONFIRMATION.VEHICLE_CONFIRMATION_YES);
                    //Thread.Sleep(1000);

                    // 機能メニュー画面のキャプチャ取得
                    logger.Debug("【機能メニュー画面】");

                    // PF停止
                    FileUtils.stopPF();
                    logger.Debug("PF停止");


                    /*
                     * Allダイアグ（ECU select）画面
                     * */
                    // All DTCボタン押下 
                    logger.Debug("【All DTCボタン押下 】");
                    webDriverComponent.ClickById(Constants.ITEM_ID_FUNCTION_MENU.FUNCTION_MENU_ALL_DTC);
                    Thread.Sleep(33000);

                    // Error画面のキャプチャ取得
                    webDriverComponent.GetScreenshot(evidenceDirectory, "No.33_Communication_ERROR");
                    bool ret = webDriverComponent.IsDisplayedById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_ERROR);
                    CheckError(ret);
                    Thread.Sleep(1000);

                }

                logger.Info("*********************************");
                logger.Info("結果 check OK：" + chkAllDtcOK + " / check NG：" + chkAllDtcNG);
                logger.Info("*********************************");

            }
            catch (Exception exception)
            {
                logger.Error("Unexpected exception occurred during asynchronous processing.", exception);
            }

            logger.Info(" ################### GTS+ Allダイアグ通信エラー系 - [END] ################### \r\n\r\n");

            // LOGのlogファイルコピー
            FileUtils.DirectoryCopy(currentDir + Constants.FilePath.LOG_FOLDER, logOutDir);
        }


        /// <summary>
        /// APIレスポンスチェック
        /// </summary>
        /// <param name="retApi">API戻り値</param>
        /// <param name="checkApid">チェック対象APID（指定がない場合は空文字）</param>
        private void CheckApi(string retApi, string checkApid)
        {
            int checkCnt = 0;
            string apid = "";
            string[] api = retApi.Replace("\r\n", "\n").Split(new[] { '\n', '\r' });

            foreach (string retValue in api)
            {
                // APID応答データ抽出
                apid = "";
                int apidIndex = retValue.IndexOf(Constants.Sample_Word.COMMON_APID);
                if (apidIndex > -1)
                {
                    apid = retValue.Substring(apidIndex + Constants.Sample_Word.COMMON_APID.Length, Constants.APID.APID_LENGTH);
                }

                // 応答結果：result
                string result = "";
                int resultIdx = retValue.IndexOf(Constants.Sample_Word.RESULTINFO_RESULT);
                if (resultIdx > -1)
                {
                    result = retValue.Substring(resultIdx + Constants.Sample_Word.RESULTINFO_RESULT.Length, 2).Trim().Replace(",", "").Replace("}", "");
                }

                // APID別チェック
                if (string.IsNullOrEmpty(checkApid))
                {
                    // チェック対象のAPID指定が無い場合
                    logger.Debug(retValue);
                    if (resultIdx > -1) CheckApid(apid, result, retValue, 0);
                }
                else
                {
                    // チェック対象のAPID指定が有る場合
                    if (checkApid.Equals(apid))
                    {
                        logger.Debug(retValue);
                        CheckApid(apid, result, retValue, checkCnt);
                        checkCnt++;
                    }
                }
            }

            // 搭載ECUリストの件数と同件数処理が行われたかのチェック（対象：DV000005）
            if (Constants.APID.CHECK_ECU_CONNECT.Equals(checkApid))
            {
                if (listEcuId.Count == checkCnt)
                {
                    chkAllDtcOK++;
                    logger.Info("【" + LOG_OUT_NAME + " OK No.4】: " + checkApid + " CHECK_ECU_CONNECT --- 確認件数：" + listEcuId.Count + "件、チェック件数：" + checkCnt + "件");
                }
                else
                {
                    chkAllDtcNG++;
                    logger.Info("【" + LOG_OUT_NAME + " NG No.4】: " + checkApid + " CHECK_ECU_CONNECT --- 確認件数：" + listEcuId.Count + "件、チェック件数：" + checkCnt + "件");
                }
            }


            // 接続確認された件数と同件数処理が行われたかのチェック（対象：DV000067、DV000006、DV000008）
            if (Constants.APID.REPLACE_SYSTEM_EXCEPTION.Equals(checkApid) || Constants.APID.GET_ECU_FUNC_LIST.Equals(checkApid) || 
                Constants.APID.GET_DTC.Equals(checkApid))
            {
                string apidString = "";
                string TestNum = "";
                switch (checkApid)
                {
                    // DV000067
                    case Constants.APID.REPLACE_SYSTEM_EXCEPTION:
                        apidString = "REPLACE_SYSTEM_EXCEPTION";
                        TestNum = "6";
                        break;
                    // DV000006
                    case Constants.APID.GET_ECU_FUNC_LIST:
                        apidString = "GET_ECU_FUNC_LIST";
                        TestNum = "7";
                        break;
                    // DV000008
                    case Constants.APID.GET_DTC:
                        apidString = "GET_DTC";
                        TestNum = "8";
                        break;

                }

                if (connect == checkCnt)
                {
                    chkAllDtcOK++;
                    logger.Info("【" + LOG_OUT_NAME + " OK No." + TestNum +  "】: " + checkApid + " "+ apidString + " --- 接続確認件数：" + connect + "件、チェック件数：" + checkCnt + "件");
                }
                else
                {
                    chkAllDtcNG++;
                    logger.Info("【" + LOG_OUT_NAME + " NG No." + TestNum +  "】: " + checkApid + " " + apidString + " --- 接続確認件数：" + connect + "件、チェック件数：" + checkCnt + "件");
                }
            }
        }

        /// <summary>
        /// APID別チェック
        /// </summary>
        /// <param name="apid">APID</param>
        /// <param name="result">応答結果</param>
        /// <param name="json">APIレスポンス</param>
        /// <param name="checkCnt">同一APIレスポンス取得番号</param>
        private void CheckApid(string apid, string result, string json, int checkCnt)
        {
            switch (apid)
            {
                // DV000004
                case Constants.APID.GET_MOUNT_ECU_LIST:
                    if (Constants.Sample_Word.RESULT_SUCCESS.Equals(result))
                    {
                        // ecuId抽出
                        int startIdx = 0;
                        int idx = 0;
                        string ecuId = "";

                        while (true)
                        {
                            idx = json.IndexOf(Constants.Sample_Word.ECU_ID, startIdx);
                            if (idx > -1)
                            {
                                // ECU ID（3桁固定）をリストに追加
                                ecuId = json.Substring(idx + Constants.Sample_Word.ECU_ID.Length, ECU_ID_LENGTH);
                                listEcuId.Add(ecuId);
                                startIdx = idx + Constants.Sample_Word.ECU_ID.Length + ECU_ID_LENGTH;

                                // エンジンの場合 phaseTypeを取得
                                if (ECU_ID_ENGINE.Equals(ecuId))
                                {
                                    idx = json.IndexOf(Constants.Sample_Word.PHASE_TYPE, startIdx);
                                    if (idx > -1)
                                    {
                                        startIdx = idx + Constants.Sample_Word.PHASE_TYPE.Length;
                                        int endIdx = json.IndexOf("}", startIdx);
                                        // phaseType
                                        phaseType = json.Substring(startIdx, endIdx - startIdx);
                                    }
                                }
                            }
                            else
                            {
                                break;
                            }

                        }

                        // Ecu件数の取得
                        string ret = json.Replace(ECU_ID, "");
                        int ecuCnt = (json.Length - ret.Length) / ECU_ID.Length;
                        logger.Debug("【取得ECU件数】: " + ecuCnt + "件");

                        chkAllDtcOK++;
                        logger.Info("【" + LOG_OUT_NAME + " OK No.1】: " + apid + " GET_MOUNT_ECU_LIST");
                    }
                    else
                    {
                        chkAllDtcNG++;
                        logger.Info("【" + LOG_OUT_NAME + " NG No.1】: " + apid + " GET_MOUNT_ECU_LIST");
                    }

                    FileUtils.WriteJson(evidenceDirectory + "\\No.1_" + apid + ".json", json);
                    break;
                // DV000005
                case Constants.APID.CHECK_ECU_CONNECT:
                    if (Constants.Sample_Word.RESULT_SUCCESS.Equals(result))
                    {
                        // [ECU ID]抽出
                        int idx = json.IndexOf(Constants.Sample_Word.RESPONCE_ECU_ID_CHECK_ECU_CONNECT);
                        string ecuId = "";
                        if (idx > -1)
                        {
                            ecuId = json.Substring(idx + Constants.Sample_Word.RESPONCE_ECU_ID_CHECK_ECU_CONNECT.Length, ECU_ID_LENGTH);

                            // リクエストした[ECU ID]の返却チェック
                            int num = listEcuId.IndexOf(ecuId) + 1;
                            if (num > -1)
                            {
                                logger.Debug("【ECU ID】" + ecuId + "："+ num + "番目");
                            }
                            else
                            {
                                chkAllDtcNG++;
                                logger.Info("【" + LOG_OUT_NAME + " NG No.4】: " + apid + " CHECK_ECU_CONNECT " + ecuId);
                            }
                        }

                        // 接続状態抽出
                        idx = json.IndexOf(Constants.Sample_Word.CONNECT);
                        if (idx > -1)
                        {
                            // 接続ありの場合は件数をカウントアップ
                            if (CONNECT_ARI.Equals(json.Substring(idx + Constants.Sample_Word.CONNECT.Length, CONNECT_LENGTH)))
                            {
                                listConnectEcuId.Add(ecuId);
                                connect++;
                            }
                        }
                    }
                    else
                    {
                        chkAllDtcNG++;
                        logger.Info("【" + LOG_OUT_NAME + " NG No.4】: " + apid + " CHECK_ECU_CONNECT");
                    }

                    FileUtils.WriteJson(evidenceDirectory + "\\No.4_" + checkCnt + "_" + apid + ".json", json);
                    break;
                // DV000067
                case Constants.APID.REPLACE_SYSTEM_EXCEPTION:
                    if (Constants.Sample_Word.RESULT_SUCCESS.Equals(result))
                    {
                        // [ECU ID]抽出
                        string ecuId = "";
                        int idx = json.IndexOf(Constants.Sample_Word.RESPONCE_ECU_ID_REPLACE_SYSTEM_EXCEPTION);
                        if (idx > -1)
                        {
                            ecuId = json.Substring(idx + Constants.Sample_Word.RESPONCE_ECU_ID_REPLACE_SYSTEM_EXCEPTION.Length, ECU_ID_LENGTH);

                            // リクエストした[ECU ID]の返却チェック
                            int num = listConnectEcuId.IndexOf(ecuId) + 1;
                            if (num > -1)
                            {
                                logger.Debug("【ECU ID】" + ecuId + "：" + num + "番目");
                            }
                            else
                            {
                                chkAllDtcNG++;
                                logger.Info("【" + LOG_OUT_NAME + " NG No.6】: " + apid + " REPLACE_SYSTEM_EXCEPTION " + ecuId);
                            }
                        }
                    }
                    else
                    {
                        chkAllDtcNG++;
                        logger.Info("【" + LOG_OUT_NAME + " NG No.6】: " + apid + " REPLACE_SYSTEM_EXCEPTION");
                    }

                    FileUtils.WriteJson(evidenceDirectory + "\\No.6_" + checkCnt + "_" + apid + ".json", json);
                    break;
                // DV000006
                case Constants.APID.GET_ECU_FUNC_LIST:
                    if (Constants.Sample_Word.RESULT_SUCCESS.Equals(result))
                    {
                        // [ECU ID]抽出
                        string ecuId = "";
                        int idx = json.IndexOf(Constants.Sample_Word.RESPONCE_ECU_ID_GET_ECU_FUNC_LIST);
                        if (idx > -1)
                        {
                            ecuId = json.Substring(idx + Constants.Sample_Word.RESPONCE_ECU_ID_GET_ECU_FUNC_LIST.Length, ECU_ID_LENGTH);

                            // リクエストした[ECU ID]の返却チェック
                            int num = listConnectEcuId.IndexOf(ecuId) + 1;
                            if (num > -1)
                            {
                                logger.Debug("【ECU ID】" + ecuId + "：" + num + "番目");
                            }
                            else
                            {
                                chkAllDtcNG++;
                                logger.Info("【" + LOG_OUT_NAME + " NG No.7】: " + apid + " GET_ECU_FUNC_LIST " + ecuId);
                            }
                        }
                    }
                    else
                    {
                        chkAllDtcNG++;
                        logger.Info("【" + LOG_OUT_NAME + " NG No.7】: " + apid + " GET_ECU_FUNC_LIST");
                    }

                    FileUtils.WriteJson(evidenceDirectory + "\\No.7_" + checkCnt + "_" + apid + ".json", json);
                    break;
                // DV000008
                case Constants.APID.GET_DTC:
                    if (Constants.Sample_Word.RESULT_SUCCESS.Equals(result))
                    {
                        int idx = 0;

                        // [ECU ID]抽出
                        string ecuId = "";
                        idx = json.IndexOf(Constants.Sample_Word.RESPONCE_ECU_ID_GET_DTC);
                        if (idx > -1)
                        {
                            ecuId = json.Substring(idx + Constants.Sample_Word.RESPONCE_ECU_ID_GET_DTC.Length, ECU_ID_LENGTH);

                            // リクエストした[ECU ID]の返却チェック
                            int num = listConnectEcuId.IndexOf(ecuId) + 1;
                            if (num > -1)
                            {
                                logger.Debug("【ECU ID】" + ecuId + "：" + num + "番目");

                                // エンジンの場合のみ抽出
                                if (num == 1)
                                {
                                    int startIdx = 0;
                                    int endIdx = 0;
                                    string codeDisp = "";
                                    string ffd = "";
                                    string kind = "";
                                    string kindFlag = "";
                                    // [codeDisp]抽出
                                    while (true)
                                    {
                                        idx = json.IndexOf(Constants.Sample_Word.CODE_DISP, startIdx);
                                        if (idx > -1)
                                        {
                                            startIdx = idx + Constants.Sample_Word.CODE_DISP.Length;
                                            endIdx = json.IndexOf("\"", startIdx);
                                            // codeDispをリストに追加
                                            codeDisp = json.Substring(startIdx, endIdx - startIdx);
                                            if (listDtcType.ContainsKey(codeDisp))
                                            {
                                                codeDisp += DateTime.Now.ToString();
                                            }
                                            listCodeDisp.Add(codeDisp);

                                            // [ffd]抽出
                                            idx = json.IndexOf(Constants.Sample_Word.FFD, startIdx);
                                            if (idx > -1)
                                            {
                                                startIdx = idx + Constants.Sample_Word.FFD.Length;
                                                endIdx = json.IndexOf(",", startIdx);
                                                // ffd
                                                ffd = json.Substring(startIdx, endIdx - startIdx);
                                                listFfd.Add(codeDisp, ffd);
                                            }
                                            else
                                            {
                                                startIdx = 0;
                                                break;
                                            }

                                            // [kind]抽出
                                            idx = json.IndexOf(Constants.Sample_Word.KIND, startIdx);
                                            if (idx > -1)
                                            {
                                                startIdx = idx + Constants.Sample_Word.KIND.Length;
                                                endIdx = json.IndexOf("]", startIdx);
                                                // kind
                                                kind = json.Substring(startIdx, endIdx - startIdx);
                                                listDtcType.Add(codeDisp, kind);
                                            }
                                            else
                                            {
                                                startIdx = 0;
                                                break;
                                            }

                                            // [kindFlag]抽出
                                            idx = json.IndexOf(Constants.Sample_Word.KIND_FLAG, startIdx);
                                            if (idx > -1)
                                            {
                                                startIdx = idx + Constants.Sample_Word.KIND_FLAG.Length;
                                                endIdx = json.IndexOf(",", startIdx);
                                                // kind
                                                kindFlag = json.Substring(startIdx, endIdx - startIdx);
                                                listKindFlag.Add(codeDisp, kindFlag);
                                            }
                                            else
                                            {
                                                startIdx = 0;
                                                break;
                                            }
                                        }
                                        else
                                        {
                                            startIdx = 0;
                                            break;
                                        }
                                    }
                                    // [name]抽出
                                    while (true)
                                    {
                                        idx = json.IndexOf(Constants.Sample_Word.NAME, startIdx);
                                        if (idx > -1)
                                        {
                                            startIdx = idx + Constants.Sample_Word.NAME.Length;
                                            endIdx = json.IndexOf("\"", startIdx);
                                            // nameをリストに追加
                                            listName.Add(json.Substring(startIdx, endIdx - startIdx));
                                        }
                                        else
                                        {
                                            startIdx = 0;
                                            break;
                                        }
                                    }
                                }

                            }
                            else
                            {
                                chkAllDtcNG++;
                                logger.Info("【" + LOG_OUT_NAME + " NG No.8】: " + apid + " GET_DTC " + ecuId);
                            }
                        }
                    }
                    else
                    {
                        chkAllDtcNG++;
                        logger.Info("【" + LOG_OUT_NAME + " NG No.8】: " + apid + " GET_DTC");
                    }

                    FileUtils.WriteJson(evidenceDirectory + "\\No.8_" + checkCnt + "_" + apid + ".json", json);
                    break;
                default:
                    chkAllDtcNG ++;
                    logger.Info("【NG】: " + apid + " API未定義");
                    break;
            }
        }

        /// <summary>
        /// DTC一覧件数/コード/名称チェック
        /// </summary>
        /// <param name="tableItem">画面一覧表示内容</param>
        private void CheckDtcList(string tableItem)
        {
            // 取得失敗時はNG
            if (string.IsNullOrEmpty(tableItem))
            {
                chkAllDtcNG++;
                logger.Info("【" + LOG_OUT_NAME + " NG No.21】: DTC一覧 取得失敗");
                return;
            }

            // 改行コードから行を分ける
            string[] del = { "\r\n" };
            string[] dtcList = tableItem.Split(del, StringSplitOptions.None);

            // 一覧件数のチェック（表のタイトル:３行[Curr Conf]、[Test Failed]に改行文字有）
            if (dtcList.Length - 3 == listCodeDisp.Count)
            {
                chkAllDtcOK++;
                logger.Info("【" + LOG_OUT_NAME + " OK No.21】DTC一覧件数:" + listCodeDisp.Count + "件");
            }
            else
            {
                chkAllDtcNG++;
                logger.Info("【" + LOG_OUT_NAME + " NG No.21】: DTC一覧 取得件数不正（表示：" + (dtcList.Length - 3) +
                            "件/API取得：" + listCodeDisp.Count + "件");
                return;
            }

            string[] dtcRow;
            bool checkDisp = true;
            bool checkNmae = true;

            // 取得内容と表示内容のチェック
            for (int i=3; i< dtcList.Length; i++)
            {
                dtcRow = dtcList[i].Split(' ');
                string dtcDisp = dtcRow[0];
                string dtcName = "";
                for (int j = 1; j < dtcRow.Length; j++)
                {
                    dtcName += dtcRow[j] + " ";
                }
                // 最後のスペースを除去
                dtcName = dtcName.Substring(0, dtcName.Length - 1);
                int num = 0;
                // [dtcDisp]の表示チェック
                num = listCodeDisp.IndexOf(dtcDisp) + 1;
                if (num < 0)
                {
                    chkAllDtcNG++;
                    checkDisp = false;
                    logger.Info("【" + LOG_OUT_NAME + " NG No.23】: " + dtcDisp);
                }
                // [name]の表示チェック
                num = listName.IndexOf(dtcName) + 1;
                if (num < 0)
                {
                    chkAllDtcNG++;
                    checkNmae = false;
                    logger.Info("【" + LOG_OUT_NAME + " NG No.24】: " + dtcName);
                }

                logger.Debug("【codeDisp】" + dtcDisp + "/【name】" + dtcName);
            }

            if (checkDisp)
            {
                chkAllDtcOK++;
                logger.Info("【" + LOG_OUT_NAME + " OK No.23】表示用DTC");
            }
            if (checkNmae)
            {
                chkAllDtcOK++;
                logger.Info("【" + LOG_OUT_NAME + " OK No.24】ダイアグコード名称");
            }
        }

        /// <summary>
        /// DTC一覧画像チェック
        /// </summary>
        /// <param name="webDriverComponent">WebDriverComponent</param>
        private void CheckDtcImageList(WebDriverComponent webDriverComponent)
        {
            string kindFlag = "";
            string kindFlagImage = "";
            string kindList = "";
            int kindIdx = 0;
            string ffd = "";
            bool checkKindFlag = true;
            bool checkKind = true;
            bool checkFfd = true;
            // 行単位
            for (int i = 0; i < listCodeDisp.Count; i++)
            {
                logger.Info("**************** [" + i + "行目] *****************");

                // kindFlag
                kindFlag = listKindFlag[listCodeDisp[i]];
                // 0：Enhanced, 1：Generic
                if (kindFlag.Equals("0"))
                {
                    kindFlagImage = IMAGE_CHECK_ENHANCED_ID + i;
                }
                else
                {
                    kindFlagImage = IMAGE_CHECK_GENERIC_ID + i;
                }

                if (webDriverComponent.IsDisplayedById(kindFlagImage))
                {
                    // 取得データと画面イメージが一致した場合
                    logger.Debug("kindFlag:" + kindFlag + "(" + kindFlagImage + ")");
                }
                else
                {
                    // 取得データと画面イメージが一致しなかった場合
                    chkAllDtcNG++;
                    checkKindFlag = false;
                    logger.Info("【" + LOG_OUT_NAME + " OK No.22】: kindFlag:" + kindFlag + "(" + kindFlagImage + ")");
                }

                // 各行の[kind]を取得
                kindList = listDtcType[listCodeDisp[i]];
                logger.Debug("kindList:" + kindList);
                for (int j = 0; j <= 6; j++)
                {
                    int ret = kindList.IndexOf(j.ToString(), 0);
                    string kindName = GetKindName(j.ToString());
                    // データ取得有の場合はチェックイメージを表示（kind=0はダイアグなし）
                    if (ret > -1 && !kindList.Equals("0"))
                    {
                        // チェックイメージ画像の有無をチェック
                        if (webDriverComponent.IsDisplayedById(IMAGE_CHECK_ID + i + j))
                        {
                            logger.Debug("kind:" + j + " チェック " + kindName);
                            kindIdx++;
                        }
                        else
                        {
                            chkAllDtcNG++;
                            checkKind = false;
                            logger.Info("【" + LOG_OUT_NAME + " NG No.25～28】: kind:" + j + " チェック無 " + kindName);
                        }
                    }
                    // データ取得無の場合はチェックイメージを非表示
                    else
                    {
                        // チェックイメージ画像の有無をチェック
                        if (!webDriverComponent.IsDisplayedById(IMAGE_CHECK_ID + i + j))
                        {
                            logger.Debug("kind:" + j + " チェック無 " + kindName);
                        }
                        else
                        {
                            chkAllDtcNG++;
                            checkKind = false;
                            logger.Info("【" + LOG_OUT_NAME + " NG No.25～28】: kind:" + j + " チェック " + kindName);
                            kindIdx++;
                        }
                    }

                }

                // FFD
                ffd = listFfd[listCodeDisp[i]];
                // イメージ表示有の場合
                if (webDriverComponent.IsDisplayedById(IMAGE_CHECK_FFD_ID + i))
                {
                    // FFD対象
                    if (!FFD_NASI.Equals(ffd))
                    {
                        logger.Debug("FFD:" + ffd + " 表示有");
                    }
                    else
                    {
                        chkAllDtcNG++;
                        checkFfd = false;
                        logger.Info("【" + LOG_OUT_NAME + " NG No.29】: FFD:" + ffd + " 表示無");
                    }
                }
                // イメージ表示無の場合
                else
                {
                    // FFD対象
                    if (FFD_NASI.Equals(ffd))
                    {
                        logger.Debug("FFD:" + ffd + " 表示無");
                    }
                    else
                    {
                        chkAllDtcNG++;
                        checkFfd = false;
                        logger.Info("【" + LOG_OUT_NAME + " NG No.29】: FFD:" + ffd + " 表示有");
                    }
                }
            }

            // 判定
            if (checkKindFlag)
            {
                chkAllDtcOK++;
                logger.Info("【" + LOG_OUT_NAME + " OK No.22】: フラグ");
            }
            if (checkKind)
            {
                // 4件分のチェック
                chkAllDtcOK += 4;
                logger.Info("【" + LOG_OUT_NAME + " OK No.25】: ダイアグコードチェック");
                logger.Info("【" + LOG_OUT_NAME + " OK No.26】: 現在ダイアグ、TestFail(最新)");
                logger.Info("【" + LOG_OUT_NAME + " OK No.27】: 過去ダイアグ、Confirmed(確定)");
                logger.Info("【" + LOG_OUT_NAME + " OK No.28】: ペンディング");
            }
            if (checkFfd)
            {
                chkAllDtcOK++;
                logger.Info("【" + LOG_OUT_NAME + " OK No.29】: FFDチェック");
            }
        }

        /// <summary>
        /// 表示/非表示切替チェック
        /// </summary>
        /// <param name="webDriverComponent">WebDriverComponent</param>
        /// <param name="power">Power Trail表示/非表示フラグ</param>
        /// <param name="chassis">chassis表示/非表示フラグ</param>
        /// <param name="body">body表示/非表示フラグ</param>
        private bool CheckView(WebDriverComponent webDriverComponent, bool power, bool chassis, bool body)
        {
            bool check = true;

            // Power train表示チェック
            if (webDriverComponent.IsDisplayedByEcuName(ECU_NAME_ENGINE) != power)
            {
                check = false;
            }

            // CHASSIS表示チェック
            if (webDriverComponent.IsDisplayedByEcuName(ECU_NAME_ABS_VSC_TRC) != chassis)
            {
                check = false;
            }

            // Power Trail表示中の場合は一旦非表示にする（Bodyが表示されないため）
            if (power) webDriverComponent.ClickById(Constants.ITEM_ID_ALL_DTC_SELECT.ALL_DTC_IMAGE_POWER);
            // Chassis表示中の場合は一旦非表示にする（Bodyが表示されないため）
            if (chassis) webDriverComponent.ClickById(Constants.ITEM_ID_ALL_DTC_SELECT.ALL_DTC_IMAGE_CHASSIS);
            Thread.Sleep(1000);
            // BODY表示チェック
            if (webDriverComponent.IsDisplayedByEcuName(ECU_NAME_A_C) != body)
            {
                check = false;
            }
            // 元に戻す
            if (power) webDriverComponent.ClickById(Constants.ITEM_ID_ALL_DTC_SELECT.ALL_DTC_IMAGE_POWER);
            if (chassis) webDriverComponent.ClickById(Constants.ITEM_ID_ALL_DTC_SELECT.ALL_DTC_IMAGE_CHASSIS);
            Thread.Sleep(1000);

            return check;
        }

        /// <summary>
        /// ダイアグコード種別名の取得
        /// </summary>
        /// <param name="kind">ダイアグコード種別</param>
        private string GetKindName(string kind)
        {
            CodeDictionary dic = new CodeDictionary();
            Dictionary<string, string> kindDic = null;

            if (PHASE_TYPE_5.Equals(phaseType))
            {
                // Phase5の場合
                kindDic = dic.Kind5Dictionary();
            }
            else
            {
                // Phase5以外の場合
                kindDic = dic.Kind4Dictionary();
            }

            return kindDic[kind];
        }

        /// <summary>
        /// 通信エラーログ出力
        /// </summary>
        /// <param name="ret">成否</param>
        private void CheckError(bool ret)
        {
            if (ret)
            {
                chkAllDtcOK++;
                logger.Info("【" + LOG_OUT_NAME + " OK No.33】: Error画面表示 --- OK.");
            }
            else
            {
                chkAllDtcNG++;
                logger.Info("【" + LOG_OUT_NAME + " NG No.33】: Error画面表示 --- NG.");
            }
        }

        /// <summary>
        /// 破棄処理
        /// </summary>
        public void Dispose()
        {
        }
    }
}
