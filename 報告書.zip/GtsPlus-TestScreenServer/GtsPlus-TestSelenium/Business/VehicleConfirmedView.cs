﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Threading;
using IWshRuntimeLibrary;
using log4net;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using SeleniumExtras.WaitHelpers;
using GtsPlus_TestSelenium.Constant;
using GtsPlus_TestSelenium.Component;
using GtsPlus_TestSelenium.Utils;
using GtsPlus_TestSelenium.Constant.Lang;
using System.Collections.ObjectModel;

namespace GtsPlus_TestSelenium.Business
{
    /// <summary>
    /// テストシナリオ-QRコード表示
    /// </summary>
    public class VehicleConfirmedView:IDisposable
    {
        /// <summary>
        /// log4net
        /// </summary>
        private static readonly ILog logger = LogManager.GetLogger(typeof(Program));

        /// <summary>
        /// 大分類名
        /// </summary>
        private const string LOG_OUT_NAME = "車種確定";
        /// <summary>
        /// エビデンスフォルダ-正常系
        /// </summary>
        private const string EVIDENCE_DIR = "/" + LOG_OUT_NAME;
        /// <summary>
        /// 画面ID-確定画面
        /// </summary>
        private const int VIEW_ID_1 = 1;
        /// <summary>
        /// 画面ID-確認画面➁
        /// </summary>
        private const int VIEW_ID_2 = 2;
        /// <summary>
        /// 画面ID-確認画面①
        /// </summary>
        private const int VIEW_ID_3 = 3;
        /// <summary>
        /// JQueryで付与されるオプションリストのID追加文字列
        /// </summary>
        private const string ID_ADD_STRING = "-button";
        /// <summary>
        /// 診断開始未実施
        /// </summary>
        private const string DIAGNOSIS_START_STATUS_STOP = "0";
        /// <summary>
        /// 診断開始中
        /// </summary>
        private const string DIAGNOSIS_START_STATUS_START = "1";

        /// <summary>
        /// 実行ディレクトリ
        /// </summary>
        private string currentDir;
        /// <summary>
        /// エビデンス出力ディレクトリ
        /// </summary>
        private string evidenceDirectory;
        /// <summary>
        /// ログ出力先ディレクトリ
        /// </summary>
        private string logOutDir;

        /// <summary>
        /// 画面ID[1：確定画面、2：確認画面➁、3：確認画面①]
        /// </summary>
        private int viewID = 0;

        /// <summary>
        /// OK件数
        /// </summary>
        private int chkVehicleConfirmedOK = 0;
        /// <summary>
        /// NG件数
        /// </summary>
        private int chkVehicleConfirmedNG = 0;

        /// <summary>
        /// 仕向ID
        /// </summary>
        private string regionId = "";
        /// <summary>
        /// 言語ID
        /// </summary>
        private string languageId = "";

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public VehicleConfirmedView(string currentDir, string evidenceDir)
        {
            this.currentDir = currentDir;
            this.logOutDir = currentDir + evidenceDir;

            this.evidenceDirectory = logOutDir + EVIDENCE_DIR;
            // エビデンスフォルダ作成
            FileUtils.createEvidenceDirectory(evidenceDirectory);
        }

        /// <summary>
        /// シナリオNo.1～36
        /// </summary>
        public void testScenario_1()
        {
            logger.Info(" ################### GTS+ 車種確定画面表示 [START] ################### ");

            viewID = VIEW_ID_1;

            try
            {
                // PF再起動
                FileUtils.rebootPF(currentDir);

                // 車両確定画面の表示
                using (var webDriverComponent = new WebDriverComponent(false, Constants.WebDriverOption.WAIT_TIMEOUT_MILLI_SECONDS))
                {
                    // 車両確定画面を開く
                    webDriverComponent.OpenPageAndWaitByID(Constants.URL.GTS_PLUS_VHCN, Constants.WAIT_ID.GTS_PLUS_VHCN);
                    Thread.Sleep(4000);
                    // 車両確定画面のキャプチャ取得
                    webDriverComponent.GetScreenshot(evidenceDirectory, "No.13-18_Vehicle_Confirmed_VIEW");

                    // APIのレスポンスチェック
                    CheckApi(webDriverComponent.GetValueByIdNoneDisplay(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_RESULT_API));


                    // 画面初期表示項目確認
                    string select1 = webDriverComponent.SelectValueById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_SELECT1);
                    string select2 = webDriverComponent.SelectValueById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_SELECT2);
                    string select3_1 = webDriverComponent.SelectValueById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_SELECT3);
                    string select4 = webDriverComponent.SelectValueById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_SELECT4);
                    string option1_1 = webDriverComponent.SelectValueById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_OPTION1);
                    CheckView(select1, "カテゴリー１項目取得失敗");
                    CheckView(select2, "カテゴリー２項目取得失敗");
                    CheckView(select3_1, "カテゴリー３項目取得失敗");
                    CheckView(select4, "カテゴリー４項目取得失敗");
                    CheckView(option1_1, "オプション項目取得失敗");

                    // 画面項目確認（言語と仕向け）
                    string tableItemCat = webDriverComponent.GetValueById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_TABLE_CATEGORY);
                    string tableItemOpt = webDriverComponent.GetValueById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_TABLE_OPTION);
                    // 画面項目のチェック
                    if (CheckRegionLanguageComfirm(VIEW_ID_1, tableItemCat, tableItemOpt))
                    {
                        chkVehicleConfirmedOK++;
                        logger.Info("【" + LOG_OUT_NAME + " OK No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) + "】: 画面項目仕向");
                    }
                    else
                    {
                        chkVehicleConfirmedNG++;
                        logger.Info("【" + LOG_OUT_NAME + " NG No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) + "】: 画面項目仕向");
                    }

                    // 車型オプションクリック
                    logger.Debug("【カテゴリー項目押下】: 車型");
                    webDriverComponent.ClickById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_SELECT3 + ID_ADD_STRING);
                    // APIのレスポンスチェック）No.19～20
                    CheckApi(webDriverComponent.GetValueByIdNoneDisplay(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_RESULT_API));
                    // 車型オプション選択（１つ↑の項目を選択）
                    logger.Debug("【カテゴリー項目選択変更】: 車型");
                    webDriverComponent.SelectOptionById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_SELECT3 + ID_ADD_STRING, true, 1);
                    string select3_2 = webDriverComponent.SelectValueById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_SELECT3);
                    logger.Debug("【カテゴリー項目選択変更値】:" + select3_1 + " → " + select3_2);
                    // APIのレスポンスチェック）No.21～23
                    CheckApi(webDriverComponent.GetValueByIdNoneDisplay(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_RESULT_API));

                    // オプション項目確認（「<SELECT>」項目にリセット）No.24
                    string option1_2 = webDriverComponent.SelectValueById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_OPTION1);
                    logger.Info("【オプション項目リセット】:" + option1_1 + " → " + option1_2);
                    // オプション項目のキャプチャ取得
                    webDriverComponent.GetScreenshot(evidenceDirectory, "No.24_Option_Reset1");
                    if (option1_2 == "0")
                    {
                        chkVehicleConfirmedOK++;
                        logger.Info("【" + LOG_OUT_NAME + " OK No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) + "】: オプション項目リセット 成功");
                    }
                    else
                    {
                        chkVehicleConfirmedNG++;
                        logger.Info("【" + LOG_OUT_NAME + " NG No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) + "】: オプション項目リセット 失敗");
                    }


                    // オプション選択（「<SELECT>」の１つ下の項目を選択） 
                    logger.Debug("【オプション項目選択変更】: オプション１");
                    webDriverComponent.SelectOptionById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_OPTION1 + ID_ADD_STRING, false, 1);
                    string option1_3 = webDriverComponent.SelectValueById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_OPTION1);
                    logger.Debug("【オプション項目選択変更値】: " + option1_2 + " → " + option1_3);
                    // APIのレスポンスチェック）No.25
                    CheckApi(webDriverComponent.GetValueByIdNoneDisplay(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_RESULT_API));
                    Thread.Sleep(1000);

                    // 下位オプション-有効 No.26
                    bool option = webDriverComponent.IsEnableById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_OPTION2);
                    if (option)
                    {
                        chkVehicleConfirmedOK++;
                        logger.Info("【" + LOG_OUT_NAME + " OK No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) +  "】: 下位オプション有効");
                    }
                    else
                    {
                        chkVehicleConfirmedNG++;
                        logger.Info("【" + LOG_OUT_NAME + " NG No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) +  "】: 下位オプション無効");
                    }

                    // 下位オプション項目確認（「<SELECT>」項目にリセット） No.27
                    string option2 = webDriverComponent.SelectValueById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_OPTION2);
                    // 下位オプション項目のキャプチャ取得
                    webDriverComponent.GetScreenshot(evidenceDirectory, "No.26-27_Option_Reset2");
                    if (option2 == "0")
                    {
                        chkVehicleConfirmedOK++;
                        logger.Info("【" + LOG_OUT_NAME + " OK No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) + "】: 下位オプション項目リセット");
                    }
                    else
                    {
                        chkVehicleConfirmedNG++;
                        logger.Info("【" + LOG_OUT_NAME + " NG No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) + "】: 下位オプション項目リセット失敗");
                    }


                    // 車型オプション選択（１つ↓の項目を選択）（元の状態に戻す）
                    logger.Debug("【カテゴリー項目選択変更（元の状態に戻す）】: 車型");
                    webDriverComponent.SelectOptionById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_SELECT3 + ID_ADD_STRING, false, 1);
                    string select3_3 = webDriverComponent.SelectValueById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_SELECT3);
                    logger.Debug("【カテゴリー項目選択変更値】:" + select3_2 + " → " + select3_3);
                    // APIのレスポンスチェック）No.28～30
                    CheckApi(webDriverComponent.GetValueByIdNoneDisplay(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_RESULT_API));

                    // オプション項目確認（「<SELECT>」項目にリセット）No.31
                    string option1_4 = webDriverComponent.SelectValueById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_OPTION1);
                    logger.Debug("【オプション項目リセット】:" + option1_3 + " → " + option1_4);
                    // オプション項目のキャプチャ取得
                    webDriverComponent.GetScreenshot(evidenceDirectory, "No.31_Option_Reset3");
                    if (option1_4 == "0")
                    {
                        chkVehicleConfirmedOK++;
                        logger.Info("【" + LOG_OUT_NAME + " OK No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) + "】: オプション項目リセット");
                    }
                    else
                    {
                        chkVehicleConfirmedNG++;
                        logger.Info("【" + LOG_OUT_NAME + " NG No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) + "】: オプション項目リセット失敗");
                    }

                    // オプション選択（「<SELECT>」の下の項目を選択）No.32
                    logger.Debug("【オプション項目選択変更】: オプション１");
                    webDriverComponent.SelectOptionById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_OPTION1 + ID_ADD_STRING, false, 1);
                    string option1_5 = webDriverComponent.SelectValueById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_OPTION1);
                    logger.Debug("【オプション項目選択変更値】: " + option1_4 + " → " + option1_5);
                    // APIのレスポンスチェック）No.32
                    CheckApi(webDriverComponent.GetValueByIdNoneDisplay(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_RESULT_API));

                    // 確定ボタン-有効 No.33
                    bool confirm2 = webDriverComponent.IsEnableById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_IMAGE_CONFIRM);
                    logger.Debug("【確定ボタン有効/無効】: " + confirm2);
                    // 確定ボタンのキャプチャ取得
                    webDriverComponent.GetScreenshot(evidenceDirectory, "No.33_Confirm_Enable");
                    if (confirm2)
                    {
                        chkVehicleConfirmedOK++;
                        logger.Info("【" + LOG_OUT_NAME + " OK No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) + "】: 確定ボタン有効");
                    }
                    else
                    {
                        chkVehicleConfirmedNG++;
                        logger.Info("【" + LOG_OUT_NAME + " NG No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) + "】: 確定ボタン無効");
                    }

                    // Confirmボタン押下 
                    webDriverComponent.ClickById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_IMAGE_CONFIRM);
                    Thread.Sleep(1000);
                    // 車両確定確認画面のキャプチャ取得
                    webDriverComponent.GetScreenshot(evidenceDirectory, "No.36_1_Confirmed");
                    Thread.Sleep(25000);
                    // APIのレスポンスチェック）No.34～36
                    CheckApi(webDriverComponent.GetValueByIdNoneDisplay(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_RESULT_API));

                    // 機能メニュー画面のキャプチャ取得
                    webDriverComponent.GetScreenshot(evidenceDirectory, "No.36_2_FunctionMenu");

                    logger.Info("*********************************");
                    logger.Info("結果 check OK：" + chkVehicleConfirmedOK + " / check NG：" + chkVehicleConfirmedNG);
                    logger.Info("*********************************");

                }
            }
            catch (Exception exception)
            {
                logger.Debug("*********************************");
                logger.Debug("途中結果 check OK：" + chkVehicleConfirmedOK + " / check NG：" + chkVehicleConfirmedNG);
                logger.Debug("*********************************");
                logger.Error("Unexpected exception occurred during asynchronous processing.", exception);
            }

            logger.Info(" ################### GTS+ 車種確定画面表示 [END] ################### \r\n\r\n");

            // LOGのlogファイルコピー
            FileUtils.DirectoryCopy(currentDir + Constants.FilePath.LOG_FOLDER, logOutDir);
        }

        /// <summary>
        /// シナリオNo.37～69
        /// </summary>
        public void testScenario_2()
        {
            logger.Info(" ################### GTS+ 車種確定画面表示-確認画面２ [START] ################### ");
            // 初期化
            viewID = VIEW_ID_2;

            try
            {
                // 確認画面２の表示
                using (var webDriverComponent = new WebDriverComponent(false, Constants.WebDriverOption.WAIT_TIMEOUT_MILLI_SECONDS))
                {
                    // 確認画面２を開く
                    webDriverComponent.OpenPageAndWaitByID(Constants.URL.GTS_PLUS_VHCN, Constants.WAIT_ID.GTS_PLUS_VHCN_CONFIRM);
                    Thread.Sleep(1000);
                    // APIのレスポンスチェック）No.37～45
                    CheckApi(webDriverComponent.GetValueByIdNoneDisplay(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_RESULT_API));
                    // 確認画面２のキャプチャ取得
                    webDriverComponent.GetScreenshot(evidenceDirectory, "No.46-49_Confirm2_VIEW");


                    // 画面初期表示項目確認 No.46
                    string title = webDriverComponent.GetValueById(Constants.ITEM_ID_VEHICLE_CONFIRMATION.VEHICLE_CONFIRMATION_TITLE);
                    if (Constants.ITEM_ID_VEHICLE_CONFIRMATION.VEHICLE_CONFIRMATION_TITLE_MESSAGE.Equals(title))
                    {
                        chkVehicleConfirmedOK++;
                        logger.Info("【" + LOG_OUT_NAME + " OK No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) +  "】: 画面表示");
                    }
                    else
                    {
                        chkVehicleConfirmedNG++;
                        logger.Info("【" + LOG_OUT_NAME + " NG No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) +  "】: 画面表示");
                    }
                    // 画面初期表示項目確認 No.47～48
                    string table = webDriverComponent.GetValueById(Constants.ITEM_ID_VEHICLE_CONFIRMATION.VEHICLE_CONFIRMATION_TABLE_INFO);
                    CheckVehicleVin(table);

                    // 画面項目確認（言語と仕向け）
                    string tableItemTitle = webDriverComponent.GetValueById(Constants.ITEM_ID_VEHICLE_CONFIRMATION.VEHICLE_CONFIRMATION_TITLE);
                    string tableItemTableInfo = webDriverComponent.GetValueById(Constants.ITEM_ID_VEHICLE_CONFIRMATION.VEHICLE_CONFIRMATION_TABLE_INFO);
                    // 画面項目のチェック
                    if (CheckRegionLanguageComfirm(VIEW_ID_2, tableItemTitle, tableItemTableInfo))
                    {
                        chkVehicleConfirmedOK++;
                        logger.Info("【" + LOG_OUT_NAME + " OK No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) + "】: 画面項目仕向");
                    }
                    else
                    {
                        chkVehicleConfirmedNG++;
                        logger.Info("【" + LOG_OUT_NAME + " NG No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) + "】: 画面項目仕向");
                    }

                    logger.Info("**************** 車種確定画面表示-確認画面２（[yes]ボタン） *****************");

                    // [yes]ボタン押下
                    logger.Debug("【[yes]ボタン押下】");
                    webDriverComponent.ClickById(Constants.ITEM_ID_VEHICLE_CONFIRMATION.VEHICLE_CONFIRMATION_YES);
                    Thread.Sleep(5000);
                    // APIのレスポンスチェック）No.50～51
                    CheckApi(webDriverComponent.GetValueByIdNoneDisplay(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_RESULT_API));
                    // 機能メニューのキャプチャ取得
                    webDriverComponent.GetScreenshot(evidenceDirectory, "No.51_FunctionMenu");


                    // 確認画面２を開く（リロード）
                    logger.Debug("【リロード】");
                    webDriverComponent.OpenPageAndWaitByID(Constants.URL.GTS_PLUS_VHCN, Constants.WAIT_ID.GTS_PLUS_VHCN_CONFIRM);
                    Thread.Sleep(1000);

                    logger.Info("**************** 車種確定画面表示-確認画面２（[no]ボタン） *****************");

                    // [no]ボタン押下
                    logger.Debug("【[no]ボタン押下】");
                    // 確定画面を表示するため画面IDを変更する
                    viewID = VIEW_ID_1;
                    webDriverComponent.ClickById(Constants.ITEM_ID_VEHICLE_CONFIRMATION.VEHICLE_CONFIRMATION_NO);
                    Thread.Sleep(7000);
                    // 強制終了API後、リロードされるためAPI結果の取得不可（リロードで消えてしまう為）
                    // エラー発生時はエラー画面が表示されることから、エラー画面の表示チェックで代替する No.52
                    string error = webDriverComponent.GetValueById(Constants.ITEM_ID_VEHICLE_CONFIRMATION.VEHICLE_CONFIRMATION_ERROR);
                    if(string.IsNullOrEmpty(error))
                    {
                        chkVehicleConfirmedOK++;
                        logger.Info("【" + LOG_OUT_NAME + " OK No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) + "】: SC000007 FORCED_END_DIAGNOSISON");
                    }
                    else
                    {
                        chkVehicleConfirmedOK++;
                        logger.Info("【" + LOG_OUT_NAME + " NG No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) + "】: SC000007 FORCED_END_DIAGNOSISON");
                    }
                    // APIのレスポンスチェック）No.53～64
                    CheckApi(webDriverComponent.GetValueByIdNoneDisplay(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_RESULT_API));
                    // 車両確定画面のキャプチャ取得
                    webDriverComponent.GetScreenshot(evidenceDirectory, "No.65-69_Vehicle_Confirmed_VIEW");


                    // 画面初期表示項目確認 No.65～69
                    string select1 = webDriverComponent.SelectValueById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_SELECT1);
                    string select2 = webDriverComponent.SelectValueById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_SELECT2);
                    string select3_1 = webDriverComponent.SelectValueById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_SELECT3);
                    string select4 = webDriverComponent.SelectValueById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_SELECT4);
                    string option1_1 = webDriverComponent.SelectValueById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_OPTION1);
                    CheckView(select1, "カテゴリー１項目取得失敗");
                    CheckView(select2, "カテゴリー２項目取得失敗");
                    CheckView(select3_1, "カテゴリー３項目取得失敗");
                    CheckView(select4, "カテゴリー４項目取得失敗");
                    CheckView(option1_1, "オプション項目取得失敗");

                    logger.Info("*********************************");
                    logger.Info("結果 check OK：" + chkVehicleConfirmedOK + " / check NG：" + chkVehicleConfirmedNG);
                    logger.Info("*********************************");

                }
            }
            catch (Exception exception)
            {
                logger.Debug("*********************************");
                logger.Debug("途中結果 check OK：" + chkVehicleConfirmedOK + " / check NG：" + chkVehicleConfirmedNG);
                logger.Debug("*********************************");
                logger.Error("Unexpected exception occurred during asynchronous processing.", exception);
            }

            logger.Info(" ################### GTS+ 車種確定画面表示-確認画面２ [END] ################### \r\n\r\n");

            // LOGのlogファイルコピー
            FileUtils.DirectoryCopy(currentDir + Constants.FilePath.LOG_FOLDER, logOutDir);
        }

        /// <summary>
        /// シナリオNo.70～124
        /// </summary>
        public void testScenario_3()
        {
            logger.Info(" ################### GTS+ 車種確定画面表示-確認画面１ [START] ################### ");
            // 初期化
            viewID = VIEW_ID_3;

            try
            {
                // PF再起動
                FileUtils.rebootPF(currentDir);

                // 確認画面１の表示
                using (var webDriverComponent = new WebDriverComponent(false, Constants.WebDriverOption.WAIT_TIMEOUT_MILLI_SECONDS))
                {
                    // 確定画面を開く
                    webDriverComponent.OpenPageAndWaitByID(Constants.URL.GTS_PLUS_VHCN, Constants.WAIT_ID.GTS_PLUS_VHCN);
                    Thread.Sleep(4000);

                    // オプション選択（「<SELECT>」の下の項目を選択）
                    logger.Debug("【オプション項目選択変更】: オプション１");
                    webDriverComponent.SelectOptionById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_OPTION1 + ID_ADD_STRING, false, 1);
                    string option1_1 = webDriverComponent.SelectValueById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_OPTION1);
                    logger.Debug("【オプション項目選択変更値】: 0 → " + option1_1);
                    // APIのレスポンスチェック）No.70
                    CheckApi(webDriverComponent.GetValueByIdNoneDisplay(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_RESULT_API));

                    // 確定ボタン-有効 No.71
                    bool confirm = webDriverComponent.IsEnableById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_IMAGE_CONFIRM);
                    logger.Debug("【確定ボタン有効/無効】: " + confirm);
                    // 確定ボタンのキャプチャ取得
                    webDriverComponent.GetScreenshot(evidenceDirectory, "No.71_Confirm_Enable");
                    if (confirm)
                    {
                        chkVehicleConfirmedOK++;
                        logger.Info("【" + LOG_OUT_NAME + " OK No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) + "】: 確定ボタン有効");
                    }
                    else
                    {
                        chkVehicleConfirmedNG++;
                        logger.Info("【" + LOG_OUT_NAME + " NG No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) + "】: 確定ボタン無効");
                    }


                    // 確認画面１を開く
                    webDriverComponent.OpenPageAndWaitByID(Constants.URL.GTS_PLUS_VHCN, Constants.WAIT_ID.GTS_PLUS_VHCN_CONFIRM);
                    Thread.Sleep(1000);

                    // APIのレスポンスチェック）No.72～82
                    CheckApi(webDriverComponent.GetValueByIdNoneDisplay(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_RESULT_API));
                    // 確認画面１のキャプチャ取得
                    webDriverComponent.GetScreenshot(evidenceDirectory, "No.83-86_Confirm1_VIEW");

                    // 画面初期表示項目確認 No.83
                    string title = webDriverComponent.GetValueById(Constants.ITEM_ID_VEHICLE_CONFIRMATION.VEHICLE_CONFIRMATION_TITLE);
                    if (Constants.ITEM_ID_VEHICLE_CONFIRMATION.VEHICLE_CONFIRMATION_TITLE_MESSAGE.Equals(title))
                    {
                        chkVehicleConfirmedOK++;
                        logger.Info("【" + LOG_OUT_NAME + " OK No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) +  "】: 画面表示");
                    }
                    else
                    {
                        chkVehicleConfirmedNG++;
                        logger.Info("【" + LOG_OUT_NAME + " NG No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) +  "】: 画面表示");
                    }
                    // 画面初期表示項目確認 No.84～85
                    string table = webDriverComponent.GetValueById(Constants.ITEM_ID_VEHICLE_CONFIRMATION.VEHICLE_CONFIRMATION_TABLE_INFO);
                    CheckVehicleVin(table);

                    // 画面項目確認（言語と仕向け）
                    string tableItemTitle = webDriverComponent.GetValueById(Constants.ITEM_ID_VEHICLE_CONFIRMATION.VEHICLE_CONFIRMATION_TITLE);
                    string tableItemTableInfo = webDriverComponent.GetValueById(Constants.ITEM_ID_VEHICLE_CONFIRMATION.VEHICLE_CONFIRMATION_TABLE_INFO);
                    // 画面項目のチェック
                    if (CheckRegionLanguageComfirm(VIEW_ID_3, tableItemTitle, tableItemTableInfo))
                    {
                        chkVehicleConfirmedOK++;
                        logger.Info("【" + LOG_OUT_NAME + " OK No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) + "】: 画面項目仕向");
                    }
                    else
                    {
                        chkVehicleConfirmedNG++;
                        logger.Info("【" + LOG_OUT_NAME + " NG No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) + "】: 画面項目仕向");
                    }


                    // 確定画面を表示するため画面IDを変更する
                    viewID = VIEW_ID_1;

                    logger.Info("**************** 車種確定画面表示-確認画面１（[no]ボタン） *****************");

                    // [no]ボタン押下
                    logger.Debug("【[no]ボタン押下】");
                    webDriverComponent.ClickById(Constants.ITEM_ID_VEHICLE_CONFIRMATION.VEHICLE_CONFIRMATION_NO);
                    Thread.Sleep(4000);
                    // 強制終了API後、リロードされるためAPI結果の取得不可（リロードで消えてしまう為）
                    // エラー発生時はエラー画面が表示されることから、エラー画面の表示チェックで代替する No.87
                    string error = webDriverComponent.GetValueById(Constants.ITEM_ID_VEHICLE_CONFIRMATION.VEHICLE_CONFIRMATION_ERROR);
                    if (string.IsNullOrEmpty(error))
                    {
                        chkVehicleConfirmedOK++;
                        logger.Info("【" + LOG_OUT_NAME + " OK No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) + "】: SC000007 FORCED_END_DIAGNOSISON");
                    }
                    else
                    {
                        chkVehicleConfirmedOK++;
                        logger.Info("【" + LOG_OUT_NAME + " NG No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) + "】: SC000007 FORCED_END_DIAGNOSISON");
                    }
                    // APIのレスポンスチェック）No.88～99
                    CheckApi(webDriverComponent.GetValueByIdNoneDisplay(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_RESULT_API));
                    // 車両確定画面のキャプチャ取得
                    webDriverComponent.GetScreenshot(evidenceDirectory, "No.100-104_Vehicle_Confirmed_VIEW");


                    // 画面初期表示項目確認 No.100～104
                    string select1 = webDriverComponent.SelectValueById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_SELECT1);
                    string select2 = webDriverComponent.SelectValueById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_SELECT2);
                    string select3_1 = webDriverComponent.SelectValueById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_SELECT3);
                    string select4 = webDriverComponent.SelectValueById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_SELECT4);
                    string option1_2 = webDriverComponent.SelectValueById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_OPTION1);
                    CheckView(select1, "カテゴリー１項目取得失敗");
                    CheckView(select2, "カテゴリー２項目取得失敗");
                    CheckView(select3_1, "カテゴリー３項目取得失敗");
                    CheckView(select4, "カテゴリー４項目取得失敗");
                    CheckView(option1_2, "オプション項目取得失敗");


                    // 確認画面①を表示するため画面IDを変更する
                    viewID = VIEW_ID_3;

                    // オプション選択（「<SELECT>」の下の項目を選択）
                    logger.Debug("【オプション項目選択変更】: オプション１");
                    webDriverComponent.SelectOptionById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_OPTION1 + ID_ADD_STRING, false, 1);
                    option1_1 = webDriverComponent.SelectValueById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_OPTION1);
                    logger.Debug("【オプション項目選択変更値】: 0 → " + option1_1);
                    // APIのレスポンスチェック）No.105
                    CheckApi(webDriverComponent.GetValueByIdNoneDisplay(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_RESULT_API));

                    // 確定ボタン-有効 No.106
                    confirm = webDriverComponent.IsEnableById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_IMAGE_CONFIRM);
                    logger.Debug("【確定ボタン有効/無効】: " + confirm);
                    // 確定ボタンのキャプチャ取得
                    webDriverComponent.GetScreenshot(evidenceDirectory, "No.106_Confirm_Enable");
                    if (confirm)
                    {
                        chkVehicleConfirmedOK++;
                        logger.Info("【" + LOG_OUT_NAME + " OK No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) + "】: 確定ボタン有効");
                    }
                    else
                    {
                        chkVehicleConfirmedNG++;
                        logger.Info("【" + LOG_OUT_NAME + " NG No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) + "】: 確定ボタン無効");
                    }


                    // 確認画面１を開く
                    webDriverComponent.OpenPageAndWaitByID(Constants.URL.GTS_PLUS_VHCN, Constants.WAIT_ID.GTS_PLUS_VHCN_CONFIRM);
                    Thread.Sleep(1000);

                    // APIのレスポンスチェック）No.107～117
                    CheckApi(webDriverComponent.GetValueByIdNoneDisplay(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_RESULT_API));
                    // 確認画面１のキャプチャ取得
                    webDriverComponent.GetScreenshot(evidenceDirectory, "No.118-120_Confirm1_VIEW");

                    // 画面初期表示項目確認 No.118
                    title = webDriverComponent.GetValueById(Constants.ITEM_ID_VEHICLE_CONFIRMATION.VEHICLE_CONFIRMATION_TITLE);
                    if (Constants.ITEM_ID_VEHICLE_CONFIRMATION.VEHICLE_CONFIRMATION_TITLE_MESSAGE.Equals(title))
                    {
                        chkVehicleConfirmedOK++;
                        logger.Info("【" + LOG_OUT_NAME + " OK No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) + "】: 画面表示");
                    }
                    else
                    {
                        chkVehicleConfirmedNG++;
                        logger.Info("【" + LOG_OUT_NAME + " NG No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) + "】: 画面表示");
                    }
                    // 画面初期表示項目確認 No.119～120
                    table = webDriverComponent.GetValueById(Constants.ITEM_ID_VEHICLE_CONFIRMATION.VEHICLE_CONFIRMATION_TABLE_INFO);
                    CheckVehicleVin(table);

                    logger.Info("**************** 車種確定画面表示-確認画面１（[yes]ボタン） *****************");

                    // [yes]ボタン押下
                    logger.Debug("【[yes]ボタン押下】");
                    webDriverComponent.ClickById(Constants.ITEM_ID_VEHICLE_CONFIRMATION.VEHICLE_CONFIRMATION_YES);
                    Thread.Sleep(25000);
                    // APIのレスポンスチェック）No.121～124
                    CheckApi(webDriverComponent.GetValueByIdNoneDisplay(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_RESULT_API));
                    // 機能メニューのキャプチャ取得
                    webDriverComponent.GetScreenshot(evidenceDirectory, "No.124__FunctionMenu");


                    logger.Info("*********************************");
                    logger.Info("結果 check OK：" + chkVehicleConfirmedOK + " / check NG：" + chkVehicleConfirmedNG);
                    logger.Info("*********************************");

                }
            }
            catch (Exception exception)
            {
                logger.Debug("*********************************");
                logger.Debug("途中結果 check OK：" + chkVehicleConfirmedOK + " / check NG：" + chkVehicleConfirmedNG);
                logger.Debug("*********************************");
                logger.Error("Unexpected exception occurred during asynchronous processing.", exception);
            }

            logger.Info(" ################### GTS+ 車種確定画面表示-確認画面１ [END] ################### \r\n\r\n");


            // LOGのlogファイルコピー
            FileUtils.DirectoryCopy(currentDir + Constants.FilePath.LOG_FOLDER, logOutDir);
        }

        /// <summary>
        /// シナリオNo.125～133
        /// </summary>
        public void testScenario_4()
        {
            logger.Info(" ################### GTS+ 確定画面通信エラー系 - [START] ################### ");

            // 初期化
            viewID = VIEW_ID_1;

            try
            {
                // PF再起動
                FileUtils.rebootPF(currentDir);

                for (int i = 1; i <= 9; i++)
                {
                    switch (i)
                    {
                        case 1:
                            logger.Info(" ### GTS+ 通信エラー  - PF起動停止（GUI-PF間接続初期化APIでエラー）###");
                            CommunicationError1();
                            break;
                        case 2:
                            FileUtils.rebootPF(currentDir);
                            logger.Info(" ### GTS+ 通信エラー  - PF起動停止（車両カテゴリ押下時情報取得APIでエラー）###");
                            CommunicationError2();
                            break;
                        case 3:
                            FileUtils.rebootPF(currentDir);
                            logger.Info(" ### GTS+ 通信エラー  - PF起動停止（車両カテゴリ変更時情報取得APIでエラー）###");
                            CommunicationError3();
                            break;
                        case 4:
                            FileUtils.rebootPF(currentDir);
                            logger.Info(" ### GTS+ 通信エラー  - PF起動停止（車両選択APIでエラー）###");
                            CommunicationError4();
                            break;
                        case 5:
                            FileUtils.rebootPF(currentDir);
                            logger.Info(" ### GTS+ 通信エラー  - PF起動停止（車両確定通知APIでエラー）###");
                            CommunicationError5();
                            break;
                        case 6:
                            FileUtils.rebootPF(currentDir);
                            viewID = VIEW_ID_3;
                            logger.Info(" ### GTS+ 通信エラー  - PF起動停止（確認画面①強制診断終了APIでエラー）###");
                            CommunicationError6();
                            break;
                        case 7:
                            FileUtils.rebootPF(currentDir);
                            viewID = VIEW_ID_3;
                            logger.Info(" ### GTS+ 通信エラー  - PF起動停止（車両ID確定APIでエラー）###");
                            CommunicationError7();
                            break;
                        case 8:
                            FileUtils.rebootPF(currentDir);
                            viewID = VIEW_ID_2;
                            logger.Info(" ### GTS+ 通信エラー  - PF起動停止（リモートダイアグDTC送信マスク設定APIでエラー）###");
                            CommunicationError8();
                            break;
                        case 9:
                            FileUtils.rebootPF(currentDir);
                            viewID = VIEW_ID_2;
                            logger.Info(" ### GTS+ 通信エラー  - PF起動停止（確認画面➁強制診断終了APIでエラー）###");
                            CommunicationError9();
                            break;
                        default:
                            break;
                    }
                }

                logger.Info("*********************************");
                logger.Info("結果 check OK：" + chkVehicleConfirmedOK + " / check NG：" + chkVehicleConfirmedNG);
                logger.Info("*********************************");
            }
            catch (Exception exception)
            {
                logger.Debug("*********************************");
                logger.Debug("途中結果 check OK：" + chkVehicleConfirmedOK + " / check NG：" + chkVehicleConfirmedNG);
                logger.Debug("*********************************");
                logger.Error("Unexpected exception occurred during asynchronous processing.", exception);
            }

            logger.Info(" ################### GTS+ 確定画面通信エラー系 - [END] ################### \r\n\r\n");

            // LOGのlogファイルコピー
            FileUtils.DirectoryCopy(currentDir + Constants.FilePath.LOG_FOLDER, logOutDir);
        }

        /// <summary>
        /// APIレスポンスチェック
        /// </summary>
        /// <param name="retApi">API戻り値</param>
        private void CheckApi(string retApi)
        {
            int start = 0;

            string[] api = retApi.Replace("\r\n", "\n").Split(new[] { '\n', '\r' });

            foreach (string retValue in api)
            {
                logger.Info(retValue);

                // Successful connection to GTS+.
                start = retValue.IndexOf(Constants.Sample_Word.WEB_SOCKET_SERVER_START);
                if (start != -1)
                {
                    // No.31
                    chkVehicleConfirmedOK++;
                    logger.Info("【" + LOG_OUT_NAME + " OK No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) + "】: サーバーへの接続（" + retValue + "）");

                    // Port番号：50010で接続した場合
                    if (retValue.IndexOf(Constants.Sample_Word.PORT_NUMBER_50010) != -1)
                    {
                        // No.32
                        chkVehicleConfirmedOK++;
                        logger.Info("【" + LOG_OUT_NAME + " OK No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) + "】: Port番号：50010で接続（" + retValue + "）");
                    }
                    // Port番号：50011で接続した場合
                    if (retValue.IndexOf(Constants.Sample_Word.PORT_NUMBER_50011) != -1)
                    {
                        // No.32
                        chkVehicleConfirmedOK++;
                        logger.Info("【" + LOG_OUT_NAME + " OK No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) + "】: Port番号：50011で接続（" + retValue + "）");
                    }
                    // Port番号：50012で接続した場合
                    if (retValue.IndexOf(Constants.Sample_Word.PORT_NUMBER_50012) != -1)
                    {
                        // No.32
                        chkVehicleConfirmedOK++;
                        logger.Info("【" + LOG_OUT_NAME + " OK No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) + "】: Port番号：50012で接続（" + retValue + "）");
                    }
                }

                // APID応答データ抽出
                string apid = "";
                int apidIndex = retValue.IndexOf(Constants.Sample_Word.COMMON_APID);
                if (apidIndex > 0)
                {
                    apid = retValue.Substring(apidIndex + Constants.Sample_Word.COMMON_APID.Length, Constants.APID.APID_LENGTH);
                }

                // 応答結果：result
                string result = "";
                int resultIdx = retValue.IndexOf(Constants.Sample_Word.RESULTINFO_RESULT);
                if (resultIdx > 0)
                {
                    result = retValue.Substring(resultIdx + Constants.Sample_Word.RESULTINFO_RESULT.Length, 2).Trim().Replace(",", "").Replace("}", "");
                }

                // APID別チェック
                if (resultIdx > 0) CheckApid(apid, result, retValue);
            }

        }

        /// <summary>
        /// APID別チェック
        /// </summary>
        /// <param name="apid">APID</param>
        /// <param name="result">応答結果</param>
        /// <param name="json">APIレスポンス</param>
        private void CheckApid(string apid, string result, string json)
        {
            switch (apid)
            {
                // CN000001
                case Constants.APID.SET_CONNECTION_CONDTION:
                    CheckResult(apid, result, apid + " SET_CONNECTION_CONDTION", json);
                    break;
                // CN000002
                case Constants.APID.CREATE_CHALLENGE_CODE:
                    CheckResult(apid, result, apid + " CREATE_CHALLENGE_CODE", json);
                    break;
                // CN000003
                case Constants.APID.CHECK_API_AUTHENTICATION:
                    CheckResult(apid, result, apid + " CHECK_API_AUTHENTICATION", json);
                    break;
                // SC000001
                case Constants.APID.START_DIAGNOSIS:
                    CheckResult(apid, result, apid + " START_DIAGNOSIS", json);
                    break;
                // SC000006
                case Constants.APID.GET_DIAGNOSTIC_INFORMATION:
                    if (Constants.Sample_Word.RESULT_SUCCESS.Equals(result))
                    {
                        chkVehicleConfirmedOK++;
                        logger.Info("【" + LOG_OUT_NAME + " OK No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) +  "】: "+ apid + " GET_DIAGNOSTIC_INFORMATION");

                        string diagnosisStartStatus = json.Substring(
                        json.IndexOf(Constants.Sample_Word.DIAGNOSIS_START_STATUS) + Constants.Sample_Word.DIAGNOSIS_START_STATUS.Length,
                                1
                            ).Trim().Replace(",", "");
                        //logger.Info("【" + LOG_OUT_NAME + " OK No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) +  "】" + apid + " - diagnosisStartStatus：" + diagnosisStartStatus);

                        // 「1:診断開始中」であるはず
                        if (DIAGNOSIS_START_STATUS_START == diagnosisStartStatus)
                        {
                            // 仕向IDと言語IDの取得
                            regionId = json.Substring(
                                    json.IndexOf(Constants.Sample_Word.REGION_ID) + Constants.Sample_Word.REGION_ID.Length,
                                    2
                                ).Trim().Replace(",", "");
                            languageId = json.Substring(
                                    json.IndexOf(Constants.Sample_Word.LANGUAGE_ID) + Constants.Sample_Word.LANGUAGE_ID.Length,
                                    2
                                ).Trim().Replace(",", "");
                            logger.Debug("--- regionId：" + regionId + " / languageId：" + languageId + " ---");
                        }
                        else
                        {
                            chkVehicleConfirmedNG ++;
                            logger.Info("【" + LOG_OUT_NAME + " NG No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) +  "】: " + apid + " GET_DIAGNOSTIC_INFORMATION");
                        }

                    }
                    else
                    {
                        chkVehicleConfirmedNG ++;
                        logger.Info("【" + LOG_OUT_NAME + " NG No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) +  "】: " + apid + " GET_DIAGNOSTIC_INFORMATION");
                    }

                    FileUtils.WriteJson(evidenceDirectory + "\\No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) + "_" + apid + ".json", json);
                    break;
                // IF000004
                case Constants.APID.GET_VEHICLE_CONFIRMATION:
                    if (Constants.Sample_Word.RESULT_SUCCESS.Equals(result))
                    {
                        chkVehicleConfirmedOK++;
                        logger.Info("【" + LOG_OUT_NAME + " OK No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) +  "】: " + apid + " GET_VEHICLE_CONFIRMATION");
                        FileUtils.WriteJson(evidenceDirectory + "\\No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) + "_" + apid + ".json", json);

                        int ret = json.IndexOf(Constants.Sample_Word.VEHICLE_ID);
                        if (ret == -1)
                        {
                            if(viewID != VIEW_ID_2)
                            {
                                chkVehicleConfirmedOK++;
                                logger.Info("【" + LOG_OUT_NAME + " OK No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) +  "】: vehicleId 取得無");
                            }
                            else
                            {
                                chkVehicleConfirmedNG++;
                                logger.Info("【" + LOG_OUT_NAME + " NG No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) +  "】: vehicleId 取得無");
                            }
                        }
                        else
                        { 
                            int idxStart = ret + Constants.Sample_Word.VEHICLE_ID.Length;
                            int idxEnd = json.IndexOf("}", idxStart);
                            string vehicleId = json.Substring(idxStart, idxEnd - idxStart).Trim();

                            if (viewID == VIEW_ID_2)
                            {
                                chkVehicleConfirmedOK++;
                                logger.Info("【" + LOG_OUT_NAME + " OK No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) +  "】: vehicleId = " + vehicleId);
                            }
                            else
                            {
                                chkVehicleConfirmedNG++;
                                logger.Info("【" + LOG_OUT_NAME + " NG No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) +  "】: vehicleId = " + vehicleId);
                            }
                        }
                    }
                    else
                    {
                        chkVehicleConfirmedNG++;
                        logger.Info("【" + LOG_OUT_NAME + " NG No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) +  "】:  " + apid + " GET_VEHICLE_CONFIRMATION");
                        FileUtils.WriteJson(evidenceDirectory + "\\No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) + "_" + apid + ".json", json);
                    }
                    break;
                // DV000089
                case Constants.APID.GET_VEHICLE_CACHE:
                    if (Constants.Sample_Word.RESULT_SUCCESS.Equals(result))
                    {
                        chkVehicleConfirmedOK++;
                        logger.Info("【" + LOG_OUT_NAME + " OK No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) +  "】: " + apid + " GET_VEHICLE_CACHE");
                        FileUtils.WriteJson(evidenceDirectory + "\\No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) + "_" + apid + ".json", json);

                        // vin：「null or 0」または vehicleId：「1～65534」以外     →   確定画面表示
                        // vin：「null or 0ではない」かつ vehicleId：「1～65534」   →   確認画面①表示 
                        bool retVin = false;        // true:「null or 0ではない」、false:「null or 0」
                        bool retVVehicleId = false; // true:「1～65534」、false:「1～65534」以外 
                        int idxStart = 0;
                        int idxEnd = 0;

                        // VIN
                        int idxVin = json.IndexOf(Constants.Sample_Word.VIN);
                        if (idxVin != -1)
                        {
                            // VINがnullではない場合
                            idxStart = idxVin + Constants.Sample_Word.VIN.Length;
                            idxEnd = json.IndexOf(",", idxStart);
                            string vinCode = json.Substring(idxStart, idxEnd - idxStart).Trim().Replace("}", "");
                            logger.Debug("【" + apid + "】" + "vin：" + vinCode);

                            // 数値チェック
                            int intVinCode = 0;
                            bool checkVinCode = int.TryParse(vinCode, out intVinCode);
                            if (checkVinCode)
                            {
                                if (intVinCode != 0)
                                {
                                    // true:「null or 0ではない」
                                    retVin = true;
                                }
                            }
                            else
                            {
                                // true:「null or 0ではない」
                                retVin = true;
                            }
                        }

                        // vehicleId
                        int idxVehicleId = json.IndexOf(Constants.Sample_Word.VEHICLE_ID);
                        if (idxVehicleId != -1)
                        {
                            // vehicleIdがnullではない場合
                            idxStart = idxVehicleId + Constants.Sample_Word.VEHICLE_ID.Length;
                            idxEnd = json.IndexOf(",", idxStart);
                            string vehicleId = json.Substring(idxStart, idxEnd - idxStart).Trim().Replace("}", "");
                            logger.Debug("【" + apid + "】" + "vehicleId：" + vehicleId);

                            // 数値チェック
                            int intVehicleId = 0;
                            bool checkVehicleId = int.TryParse(vehicleId, out intVehicleId);
                            if (checkVehicleId)
                            {
                                // true:「1～65534」、false:「1～65534」以外 
                                // vehicleIdキャッシュ有無チェック
                                if (intVehicleId > 0 && intVehicleId < 65535)
                                {
                                    // true:「1～65534」
                                    retVVehicleId = true;
                                }
                            }
                        }

                        // キャッシュの有無判定
                        bool cache = false;
                        if (retVin && retVVehicleId) cache = true;

                        // 状況別判定
                        if (viewID == VIEW_ID_3)
                        {
                            if(cache)
                            {
                                // キャッシュ有
                                chkVehicleConfirmedOK++;
                                logger.Info("【" + LOG_OUT_NAME + " OK No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) +  "】: キャッシュ有");
                            }
                            else
                            {
                                // キャッシュ無
                                chkVehicleConfirmedNG++;
                                logger.Info("【" + LOG_OUT_NAME + " NG No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) +  "】: キャッシュ無");
                            }
                        }
                        else
                        {
                            if (cache)
                            {
                                // キャッシュ有
                                chkVehicleConfirmedNG++;
                                logger.Info("【" + LOG_OUT_NAME + " NG No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) +  "】: キャッシュ有");
                            }
                            else
                            {
                                // キャッシュ無
                                chkVehicleConfirmedOK++;
                                logger.Info("【" + LOG_OUT_NAME + " OK No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) +  "】: キャッシュ無");
                            }
                        }

                    }
                    else
                    {
                        chkVehicleConfirmedNG++;
                        logger.Info("【" + LOG_OUT_NAME + " NG No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) +  "】: " + apid + " GET_VEHICLE_CACHE");
                        FileUtils.WriteJson(evidenceDirectory + "\\No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) + "_" + apid + ".json", json);
                    }
                    break;
                // DV000001
                case Constants.APID.SELECT_VEHICLE:
                    if (Constants.Sample_Word.RESULT_SUCCESS.Equals(result))
                    {
                        chkVehicleConfirmedOK++;
                        logger.Info("【" + LOG_OUT_NAME + " OK No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) + "】: " + apid + " SELECT_VEHICLE");

                        int idxStart = 0;
                        int idxEnd = 0;

                        string index = "";
                        string vehicleId = "";
                        // index取得
                        int retIndex = json.IndexOf(Constants.Sample_Word.INDEX);
                        if (retIndex != -1)
                        {
                            idxStart = retIndex + Constants.Sample_Word.INDEX.Length;
                            idxEnd = json.IndexOf(",", idxStart);
                            index = json.Substring(idxStart, idxEnd - idxStart).Trim().Replace("}", "");
                        }

                        // vehicleId取得
                        int retVehicleId = json.IndexOf(Constants.Sample_Word.VEHICLE_ID);
                        if (retVehicleId != -1)
                        {
                            idxStart = retVehicleId + Constants.Sample_Word.VEHICLE_ID.Length;
                            idxEnd = json.IndexOf(",", idxStart);
                            vehicleId = json.Substring(idxStart, idxEnd - idxStart).Trim().Replace("}", "");
                        }

                        logger.Debug("index：" + index + " / vehicleId：" + vehicleId);
                    }
                    else
                    {
                        chkVehicleConfirmedNG++;
                        logger.Info("【" + LOG_OUT_NAME + " NG No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) +  "】: " + apid + " SELECT_VEHICLE");
                    }

                    FileUtils.WriteJson(evidenceDirectory + "\\No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) + "_" + apid + ".json", json);
                    break;
                // DV000002
                case Constants.APID.SELECT_VEHICLE_CATEGORY:
                    if (Constants.Sample_Word.RESULT_SUCCESS.Equals(result))
                    {
                        chkVehicleConfirmedOK++;
                        logger.Info("【" + LOG_OUT_NAME + " OK No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) +  "】: " + apid + " SELECT_VEHICLE_CATEGORY");
                        FileUtils.WriteJson(evidenceDirectory + "\\No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) + "_" + apid + ".json", json);

                        int idxStart = 0;
                        int idxEnd = 0;

                        // 車型選択リスト取得
                        int retCategory = json.IndexOf(Constants.Sample_Word.CATEGORY_ITEM_LIST3);
                        if (retCategory > 0)
                        {
                            idxStart = json.IndexOf(Constants.Sample_Word.SELECT_ITEM_LIST_START, retCategory);
                            if (idxStart != -1)
                            {
                                idxEnd = json.IndexOf(Constants.Sample_Word.SELECT_ITEM_LIST_END, idxStart);
                                if (idxEnd > 0)
                                {
                                    string selectItemList = json.Substring(idxStart, (idxEnd+1) - idxStart).Trim();
                                    // 車型項目用の一覧が取得されること
                                    chkVehicleConfirmedOK++;
                                    logger.Info("【" + LOG_OUT_NAME + " OK No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) +  "】: selectItemList[選択項目リスト]：" + selectItemList);
                                }
                                else
                                {
                                    chkVehicleConfirmedNG++;
                                    logger.Info("【" + LOG_OUT_NAME + " NG No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) +  "】: selectItemList[選択項目リスト]：未取得");
                                }
                            }
                        }
                    }
                    else
                    {
                        chkVehicleConfirmedNG++;
                        logger.Info("【" + LOG_OUT_NAME + " NG No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) +  "】: " + apid + " SELECT_VEHICLE_CATEGORY");
                        FileUtils.WriteJson(evidenceDirectory + "\\No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) + "_" + apid + ".json", json);
                    }
                    break;
                // DV000003
                case Constants.APID.SET_VEHICLE_ID:
                    CheckResult(apid, result, apid + " SET_VEHICLE_ID", json);
                    break;
                // SC000003
                case Constants.APID.NOTIFY_VEHICLE_CONFIRMATION:
                    CheckResult(apid, result, apid + " NOTIFY_VEHICLE_CONFIRMATION", json);
                    break;
                // DV000077 // 廃止 2020.06.02
                //case Constants.APID.INITIALIZE_DK_ISO9141:
                //    CheckResult(result, apid + " INITIALIZE_DK_ISO9141");
                //    break;
                // DV000078
                case Constants.APID.SET_REMOTE_DIAG_SEND_MASK:
                    CheckResult(apid, result, apid + " SET_REMOTE_DIAG_SEND_MASK", json);
                    break;
                // DV000066
                case Constants.APID.REPLACE_VEHICLE_EXCEPTION:
                    CheckResult(apid, result, apid + " REPLACE_VEHICLE_EXCEPTION", json);
                    break;
                default:
                    chkVehicleConfirmedNG ++;
                    logger.Info("【" + LOG_OUT_NAME + " NG No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) +  "】: " + apid + " API未定義");
                    break;
            }
        }

        /// <summary>
        /// 画面表示結果チェック
        /// </summary>
        /// <param name="result">画面取得値</param>
        /// <param name="msg">NG時メッセージ</param>
        private void CheckView(string result, string msg)
        {
            if (!string.IsNullOrWhiteSpace(result))
            {
                chkVehicleConfirmedOK++;
                logger.Info("【" + LOG_OUT_NAME + " OK No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) + "】: 画面表示項目");
            }
            else
            {
                chkVehicleConfirmedNG++;
                logger.Info("【" + LOG_OUT_NAME + " NG No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) + "】: 画面表示項目：" + msg);
            }
        }

        /// <summary>
        /// 応答結果チェック
        /// </summary>
        /// <param name="apid">apid</param>
        /// <param name="result">応答結果</param>
        /// <param name="msg">NG時メッセージ</param>
        /// <param name="json">応答Json</param>
        private void CheckResult(string apid, string result, string msg, string json)
        {
            if (Constants.Sample_Word.RESULT_SUCCESS.Equals(result))
            {
                chkVehicleConfirmedOK++;
                logger.Info("【" + LOG_OUT_NAME + " OK No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) +  "】: " + msg);
            }
            else
            {
                chkVehicleConfirmedNG++;
                logger.Info("【" + LOG_OUT_NAME + " NG No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) +  "】: " + msg);
            }

            FileUtils.WriteJson(evidenceDirectory + "\\No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) + "_" + apid + ".json", json);
        }

        /// <summary>
        /// 車両ID/VINチェック
        /// </summary>
        /// <param name="tableItem">車両ID/VIN</param>
        /// <returns>値</returns>
        private void CheckVehicleVin(string tableItem)
        {
            // 取得失敗時はNG
            if(string.IsNullOrWhiteSpace(tableItem))
            {
                chkVehicleConfirmedNG++;
                logger.Info("【" + LOG_OUT_NAME + " NG No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) +  "】: 車両ID/VIN 取得失敗");
                return;
            }

            // 改行コードから車両IDとVINを分ける
            string[] del = { "\r\n" };
            string[] VehicleVin = tableItem.Split(del, StringSplitOptions.None);

            // 車両IDとVINチェック
            if (VehicleVin.Length > 1)
            {
                // 車両ID
                string Vehicle = "";
                int index = VehicleVin[0].IndexOf(" ");
                if(index > 0)
                {
                    Vehicle = VehicleVin[0].Substring(index + 1);
                    chkVehicleConfirmedOK++;
                    logger.Info("【" + LOG_OUT_NAME + " OK No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) +  "】: [車両ID:" + Vehicle + "]");
                }
                else
                {
                    chkVehicleConfirmedNG++;
                    logger.Info("【" + LOG_OUT_NAME + " NG No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) +  "】: 車両ID 取得失敗");
                    return;
                }

                // VIN
                bool retVin = false;
                string Vin = "";
                index = VehicleVin[1].IndexOf(" ");
                if (index > 0)
                {
                    Vin = VehicleVin[1].Substring(index + 1);
                    retVin = true;
                }

                // 状況別判定
                if(viewID == VIEW_ID_2)
                {
                    // 確認画面➁
                    if(retVin)
                    {
                        chkVehicleConfirmedNG++;
                        logger.Info("【" + LOG_OUT_NAME + " NG No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) +  "】: [VIN:" + Vin + "]");
                    }
                    else
                    {
                        chkVehicleConfirmedOK++;
                        logger.Info("【" + LOG_OUT_NAME + " OK No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) +  "】: VIN 未取得");
                    }
                }
                else if (viewID == VIEW_ID_3)
                {
                    // 確認画面①
                    if (retVin)
                    {
                        chkVehicleConfirmedOK++;
                        logger.Info("【" + LOG_OUT_NAME + " OK No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) +  "】: [VIN:" + Vin + "]");
                    }
                    else
                    {
                        chkVehicleConfirmedNG++;
                        logger.Info("【" + LOG_OUT_NAME + " NG No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) +  "】: VIN 未取得");
                    }
                }
                else
                {
                    // 何もしない（通過しないはず）
                }
            }
            else
            {
                chkVehicleConfirmedNG++;
                logger.Info("【" + LOG_OUT_NAME + " NG No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) +  "】: 車両ID/VIN 取得失敗");
                return;
            }
        }

        /// <summary>
        /// 仕向/言語チェック
        /// </summary>
        /// <param name="tableItemCat">カテゴリー</param>
        /// <param name="tableItemOpt">オプション</param>
        /// <returns>値</returns>
        private bool CheckRegionLanguageComfirm(int flg, string item1, string item2)
        {
            // コードテーブルを取得
            CodeDictionary codeDic = new CodeDictionary();
            // 言語
            Dictionary<string, string> languageDic = codeDic.LanguageDictionary();
            string language = languageDic[languageId];
            // 仕向
            Dictionary<string, string> regionDic = codeDic.RegionDictionary();
            string region = regionDic[regionId];
            
            // カテゴリー１
            string region_Category1 = "";
            // カテゴリー２
            string region_Category2 = "";
            // カテゴリー３
            string region_Category3 = "";
            // カテゴリー４
            string region_Category4 = "";
            // オプション
            string region_Option = "";
            // タイトル
            string region_Title = "";
            // 車両ID
            string region_VehicleId = "";
            // VIN
            string region_Vin = "";

            switch (regionId)
            {
                // 日本向けの場合
                case Constants.RegionId.REGION_CODE_JAPAN:
                    region_Category1 = Constants_JA.VehicleConfirmedItem.CATEGORY1;
                    region_Category2 = Constants_JA.VehicleConfirmedItem.CATEGORY2;
                    region_Category3 = Constants_JA.VehicleConfirmedItem.CATEGORY3;
                    region_Category4 = Constants_JA.VehicleConfirmedItem.CATEGORY4;
                    region_Option = Constants_JA.VehicleConfirmedItem.OPTION;
                    region_Title = Constants_JA.ConfirmationItem.CONFIRMATION_MSG;
                    region_VehicleId = Constants_JA.ConfirmationItem.VEHICLE_ID;
                    region_Vin = Constants_JA.ConfirmationItem.VIN;
                    break;
                // 北米向けの場合
                case Constants.RegionId.REGION_CODE_NORTH_AMERICA:
                    region_Category1 = Constants_EN.VehicleConfirmedItem.CATEGORY1;
                    region_Category2 = Constants_EN.VehicleConfirmedItem.CATEGORY2;
                    region_Category3 = Constants_EN.VehicleConfirmedItem.CATEGORY3;
                    region_Category4 = Constants_EN.VehicleConfirmedItem.CATEGORY4;
                    region_Option = Constants_EN.VehicleConfirmedItem.OPTION;
                    region_Title = Constants_EN.ConfirmationItem.CONFIRMATION_MSG;
                    region_VehicleId = Constants_EN.ConfirmationItem.VEHICLE_ID;
                    region_Vin = Constants_EN.ConfirmationItem.VIN;
                    break;
                case Constants.RegionId.REGION_CODE_EUROPE:
                    break;
                case Constants.RegionId.REGION_CODE_OTHER:
                    break;
                default:
                    break;
            }

            // 改行コードから仕向と言語を分ける
            string[] del = { "\r\n" };
            if (flg == VIEW_ID_1)
            {
                string[] category = item1.Split(del, StringSplitOptions.None);
                string[] option = item2.Split(del, StringSplitOptions.None);

                // カテゴリー１
                if (region_Category1.Trim() != category[0])
                {
                    logger.Info("【" + LOG_OUT_NAME + " NG No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) +  "】カテゴリー１：" + category[0]);
                    return false;
                }
                // カテゴリー２
                if (region_Category2.Trim() != category[2])
                {
                    logger.Info("【" + LOG_OUT_NAME + " NG No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) +  "】カテゴリー２：" + category[2]);
                    return false;
                }
                // カテゴリー３
                if (region_Category3.Trim() != category[4])
                {
                    logger.Info("【" + LOG_OUT_NAME + " NG No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) +  "】カテゴリー３：" + category[4]);
                    return false;
                }
                // カテゴリー４
                if (region_Category4.Trim() != category[6])
                {
                    logger.Info("【" + LOG_OUT_NAME + " NG No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) +  "】カテゴリー４：" + category[6]);
                    return false;
                }
                // オプション
                if (region_Option.Trim() != option[0])
                {
                    logger.Info("【" + LOG_OUT_NAME + " NG No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) +  "】オプション：" + option[0]);
                    return false;
                }
            }
            else
            {
                string[] tableInfo = item2.Split(del, StringSplitOptions.None);
                int idx = tableInfo[0].IndexOf(" ");
                string vehicleId = "";
                if (idx > -1)
                {
                    vehicleId = tableInfo[0].Substring(0, region_VehicleId.Length);
                }
                else
                {
                    vehicleId = tableInfo[0];
                }

                idx = tableInfo[1].IndexOf(" ");
                string vin = "";
                if (idx > -1)
                {
                    vin = tableInfo[1].Substring(0, region_Vin.Length);
                }
                else
                {
                    vin = tableInfo[1];
                }


                // タイトル
                if (region_Title != item1)
                {
                    logger.Info("【" + LOG_OUT_NAME + " NG No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) +  "】タイトル：" + item1);
                    return false;
                }
                // 車両ID
                if (region_VehicleId != vehicleId)
                {
                    logger.Info("【" + LOG_OUT_NAME + " NG No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) +  "】車両ID：" + vehicleId);
                    return false;
                }
                // VIN
                if (region_Vin != vin)
                {
                    logger.Info("【" + LOG_OUT_NAME + " NG No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) +  "】VIN：" + vin);
                    return false;
                }
            }

            return true;
        }



        /// <summary>
        /// 通信エラーチェック１ 
        /// </summary>
        private void CommunicationError1()
        {
            // 確定画面コードの表示
            using (var webDriverComponent = new WebDriverComponent(false, Constants.WebDriverOption.WAIT_TIMEOUT_MILLI_SECONDS))
            {
                // PF停止
                FileUtils.stopPF();
                logger.Debug("PF停止");

                // 確定画面を開く
                webDriverComponent.OpenPageAndWaitByID(Constants.URL.GTS_PLUS_VHCN, Constants.WAIT_ID.GTS_PLUS_VHCN);
                Thread.Sleep(10000);
                // Error画面のキャプチャ取得
                webDriverComponent.GetScreenshot(evidenceDirectory, "No.125_Communication_ERROR");
                bool ret = webDriverComponent.IsDisplayedById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_ERROR);
                CheckError(ret);
            }
        }

        /// <summary>
        /// 通信エラーチェック２
        /// </summary>
        private void CommunicationError2()
        {
            // 確定画面コードの表示
            using (var webDriverComponent = new WebDriverComponent(false, Constants.WebDriverOption.WAIT_TIMEOUT_MILLI_SECONDS))
            {
                // 確定画面を開く
                webDriverComponent.OpenPageAndWaitByID(Constants.URL.GTS_PLUS_VHCN, Constants.WAIT_ID.GTS_PLUS_VHCN);
                Thread.Sleep(7000);

                // PF停止
                FileUtils.stopPF();
                logger.Debug("PF停止");

                // 車型オプションクリック
                logger.Debug("【カテゴリー項目押下】: 車型");
                webDriverComponent.ClickById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_SELECT3 + ID_ADD_STRING);
                Thread.Sleep(33000);

                // Error画面のキャプチャ取得
                webDriverComponent.GetScreenshot(evidenceDirectory, "No.126_Communication_ERROR");
                bool ret = webDriverComponent.IsDisplayedById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_ERROR);
                CheckError(ret);
            }
        }

        /// <summary>
        /// 通信エラーチェック３
        /// </summary>
        private void CommunicationError3()
        {
            // 確定画面コードの表示
            using (var webDriverComponent = new WebDriverComponent(false, Constants.WebDriverOption.WAIT_TIMEOUT_MILLI_SECONDS))
            {
                // 確定画面を開く
                webDriverComponent.OpenPageAndWaitByID(Constants.URL.GTS_PLUS_VHCN, Constants.WAIT_ID.GTS_PLUS_VHCN);
                Thread.Sleep(4000);

                // 車型オプションクリック
                logger.Debug("【カテゴリー項目押下】: 車型");
                webDriverComponent.ClickById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_SELECT3 + ID_ADD_STRING);

                // PF停止
                FileUtils.stopPF();
                logger.Debug("PF停止");

                // 車型オプション選択（１つ↑の項目を選択）
                logger.Debug("【カテゴリー項目選択変更】: 車型");
                webDriverComponent.SelectOptionById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_SELECT3 + ID_ADD_STRING, true, 1);
                Thread.Sleep(33000);

                // Error画面のキャプチャ取得
                webDriverComponent.GetScreenshot(evidenceDirectory, "No.127_Communication_ERROR");
                bool ret = webDriverComponent.IsDisplayedById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_ERROR);
                CheckError(ret);
            }
        }

        /// <summary>
        /// 通信エラーチェック４
        /// </summary>
        private void CommunicationError4()
        {
            // 確定画面コードの表示
            using (var webDriverComponent = new WebDriverComponent(false, Constants.WebDriverOption.WAIT_TIMEOUT_MILLI_SECONDS))
            {
                // 確定画面を開く
                webDriverComponent.OpenPageAndWaitByID(Constants.URL.GTS_PLUS_VHCN, Constants.WAIT_ID.GTS_PLUS_VHCN);
                Thread.Sleep(4000);

                // 車型オプションクリック
                logger.Debug("【カテゴリー項目押下】: 車型");
                webDriverComponent.ClickById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_SELECT3 + ID_ADD_STRING);

                // 車型オプション選択（１つ↑の項目を選択）
                logger.Debug("【カテゴリー項目選択変更】: 車型");
                webDriverComponent.SelectOptionById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_SELECT3 + ID_ADD_STRING, true, 1);

                // PF停止
                FileUtils.stopPF();
                logger.Debug("PF停止");

                // オプション選択（「<SELECT>」の１つ下の項目を選択） 
                logger.Debug("【オプション項目選択変更】: オプション１");
                webDriverComponent.SelectOptionById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_OPTION1 + ID_ADD_STRING, false, 1);
                Thread.Sleep(33000);

                // Error画面のキャプチャ取得
                webDriverComponent.GetScreenshot(evidenceDirectory, "No.128_Communication_ERROR");
                bool ret = webDriverComponent.IsDisplayedById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_ERROR);
                CheckError(ret);
            }
        }

        /// <summary>
        /// 通信エラーチェック５
        /// </summary>
        private void CommunicationError5()
        {
            // 確定画面コードの表示
            using (var webDriverComponent = new WebDriverComponent(false, Constants.WebDriverOption.WAIT_TIMEOUT_MILLI_SECONDS))
            {
                // 確定画面を開く
                webDriverComponent.OpenPageAndWaitByID(Constants.URL.GTS_PLUS_VHCN, Constants.WAIT_ID.GTS_PLUS_VHCN);
                Thread.Sleep(4000);

                // オプション選択（「<SELECT>」の１つ下の項目を選択） 
                logger.Debug("【オプション項目選択変更】: オプション１");
                webDriverComponent.SelectOptionById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_OPTION1 + ID_ADD_STRING, false, 1);

                // PF停止
                FileUtils.stopPF();
                logger.Debug("PF停止");

                // Confirmボタン押下 
                logger.Debug("【確定ボタン押下】");
                webDriverComponent.ClickById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_IMAGE_CONFIRM);
                Thread.Sleep(33000);

                // Error画面のキャプチャ取得
                webDriverComponent.GetScreenshot(evidenceDirectory, "No.129_Communication_ERROR");
                bool ret = webDriverComponent.IsDisplayedById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_ERROR);
                CheckError(ret);
            }
        }

        /// <summary>
        /// 通信エラーチェック６
        /// </summary>
        private void CommunicationError6()
        {
            // 確定画面コードの表示
            using (var webDriverComponent = new WebDriverComponent(false, Constants.WebDriverOption.WAIT_TIMEOUT_MILLI_SECONDS))
            {
                // 確定画面を開く
                webDriverComponent.OpenPageAndWaitByID(Constants.URL.GTS_PLUS_VHCN, Constants.WAIT_ID.GTS_PLUS_VHCN);
                Thread.Sleep(4000);

                // オプション選択（「<SELECT>」の１つ下の項目を選択） 
                logger.Debug("【オプション項目選択変更】: オプション１");
                webDriverComponent.SelectOptionById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_OPTION1 + ID_ADD_STRING, false, 1);

                // 確認画面を開く
                logger.Debug("【確認画面①】");
                webDriverComponent.OpenPageAndWaitByID(Constants.URL.GTS_PLUS_VHCN, Constants.WAIT_ID.GTS_PLUS_VHCN_CONFIRM);
                Thread.Sleep(4000);

                // PF停止
                FileUtils.stopPF();
                logger.Debug("PF停止");

                // Yesボタン押下 
                logger.Debug("【Yesボタン押下】");
                webDriverComponent.ClickById(Constants.ITEM_ID_VEHICLE_CONFIRMATION.VEHICLE_CONFIRMATION_YES);
                Thread.Sleep(33000);

                // Error画面のキャプチャ取得
                webDriverComponent.GetScreenshot(evidenceDirectory, "No.130_Communication_ERROR");
                bool ret = webDriverComponent.IsDisplayedById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_ERROR);
                CheckError(ret);
            }
        }

        /// <summary>
        /// 通信エラーチェック７
        /// </summary>
        private void CommunicationError7()
        {
            // 確定画面コードの表示
            using (var webDriverComponent = new WebDriverComponent(false, Constants.WebDriverOption.WAIT_TIMEOUT_MILLI_SECONDS))
            {
                // 確定画面を開く
                webDriverComponent.OpenPageAndWaitByID(Constants.URL.GTS_PLUS_VHCN, Constants.WAIT_ID.GTS_PLUS_VHCN);
                Thread.Sleep(4000);

                // オプション選択（「<SELECT>」の１つ下の項目を選択） 
                logger.Debug("【オプション項目選択変更】: オプション１");
                webDriverComponent.SelectOptionById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_OPTION1 + ID_ADD_STRING, false, 1);

                // 確認画面を開く
                logger.Debug("【確認画面①】");
                webDriverComponent.OpenPageAndWaitByID(Constants.URL.GTS_PLUS_VHCN, Constants.WAIT_ID.GTS_PLUS_VHCN_CONFIRM);
                Thread.Sleep(4000);

                // PF停止
                FileUtils.stopPF();
                logger.Debug("PF停止");

                // Noボタン押下
                logger.Debug("【Noボタン押下】");
                webDriverComponent.ClickById(Constants.ITEM_ID_VEHICLE_CONFIRMATION.VEHICLE_CONFIRMATION_NO);
                Thread.Sleep(33000);

                // Error画面のキャプチャ取得
                webDriverComponent.GetScreenshot(evidenceDirectory, "No.131_Communication_ERROR");
                bool ret = webDriverComponent.IsDisplayedById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_ERROR);
                CheckError(ret);
            }
        }

        /// <summary>
        /// 通信エラーチェック８
        /// </summary>
        private void CommunicationError8()
        {
            // 確定画面コードの表示
            using (var webDriverComponent = new WebDriverComponent(false, Constants.WebDriverOption.WAIT_TIMEOUT_MILLI_SECONDS))
            {
                // 確定画面を開く
                webDriverComponent.OpenPageAndWaitByID(Constants.URL.GTS_PLUS_VHCN, Constants.WAIT_ID.GTS_PLUS_VHCN);
                Thread.Sleep(4000);

                // オプション選択（「<SELECT>」の１つ下の項目を選択） 
                logger.Debug("【オプション項目選択変更】: オプション１");
                webDriverComponent.SelectOptionById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_OPTION1 + ID_ADD_STRING, false, 1);

                // Confirmボタン押下
                logger.Debug("【確定ボタン押下】");
                webDriverComponent.ClickById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_IMAGE_CONFIRM);
                Thread.Sleep(33000);

                // 確認画面を開く
                logger.Debug("【確認画面➁】");
                webDriverComponent.OpenPageAndWaitByID(Constants.URL.GTS_PLUS_VHCN, Constants.WAIT_ID.GTS_PLUS_VHCN_CONFIRM);
                Thread.Sleep(4000);

                // PF停止
                FileUtils.stopPF();
                logger.Debug("PF停止");

                // Yesボタン押下 
                logger.Debug("【Yesボタン押下】");
                webDriverComponent.ClickById(Constants.ITEM_ID_VEHICLE_CONFIRMATION.VEHICLE_CONFIRMATION_YES);
                Thread.Sleep(33000);

                // Error画面のキャプチャ取得
                webDriverComponent.GetScreenshot(evidenceDirectory, "No.132_Communication_ERROR");
                bool ret = webDriverComponent.IsDisplayedById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_ERROR);
                CheckError(ret);
            }
        }

        /// <summary>
        /// 通信エラーチェック９
        /// </summary>
        private void CommunicationError9()
        {
            // 確定画面コードの表示
            using (var webDriverComponent = new WebDriverComponent(false, Constants.WebDriverOption.WAIT_TIMEOUT_MILLI_SECONDS))
            {
                // 確定画面を開く
                webDriverComponent.OpenPageAndWaitByID(Constants.URL.GTS_PLUS_VHCN, Constants.WAIT_ID.GTS_PLUS_VHCN);
                Thread.Sleep(4000);

                // オプション選択（「<SELECT>」の１つ下の項目を選択） 
                logger.Debug("【オプション項目選択変更】: オプション１");
                webDriverComponent.SelectOptionById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_OPTION1 + ID_ADD_STRING, false, 1);

                // Confirmボタン押下
                logger.Debug("【確定ボタン押下】");
                webDriverComponent.ClickById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_IMAGE_CONFIRM);
                Thread.Sleep(33000);

                // 確認画面を開く
                logger.Debug("【確認画面➁】");
                webDriverComponent.OpenPageAndWaitByID(Constants.URL.GTS_PLUS_VHCN, Constants.WAIT_ID.GTS_PLUS_VHCN_CONFIRM);
                Thread.Sleep(4000);

                // PF停止
                FileUtils.stopPF();
                logger.Debug("PF停止");

                // Noボタン押下
                logger.Debug("【Noボタン押下】");
                webDriverComponent.ClickById(Constants.ITEM_ID_VEHICLE_CONFIRMATION.VEHICLE_CONFIRMATION_NO);
                Thread.Sleep(33000);

                // Error画面のキャプチャ取得
                webDriverComponent.GetScreenshot(evidenceDirectory, "No.133_Communication_ERROR");
                bool ret = webDriverComponent.IsDisplayedById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_ERROR);
                CheckError(ret);
            }
        }

        /// <summary>
        /// 通信エラーログ出力
        /// </summary>
        /// <param name="ret">成否</param>
        private void CheckError(bool ret)
        {
            if (ret)
            {
                chkVehicleConfirmedOK++;
                logger.Info("【" + LOG_OUT_NAME + " OK No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) + "】: Error画面表示 --- OK.");
            }
            else
            {
                chkVehicleConfirmedNG++;
                logger.Info("【" + LOG_OUT_NAME + " NG No." + (chkVehicleConfirmedOK + chkVehicleConfirmedNG) + "】: Error画面表示 --- NG.");
            }
        }

        /// <summary>
        /// 破棄処理
        /// </summary>
        public void Dispose()
        {
        }
    }
}
