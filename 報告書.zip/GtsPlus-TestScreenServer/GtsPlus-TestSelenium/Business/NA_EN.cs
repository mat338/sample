﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Threading;
using IWshRuntimeLibrary;
using log4net;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using SeleniumExtras.WaitHelpers;
using GtsPlus_TestSelenium.Constant;
using GtsPlus_TestSelenium.Component;
using GtsPlus_TestSelenium.Utils;
using GtsPlus_TestSelenium.Constant.Lang;
using System.Collections.ObjectModel;

namespace GtsPlus_TestSelenium.Business
{
    /// <summary>
    /// テストシナリオ-QRコード表示
    /// </summary>
    public class NA_EN
    {
        /// <summary>
        /// log4net
        /// </summary>
        private static readonly ILog logger = LogManager.GetLogger(typeof(Program));

        /// <summary>
        /// 大分類名
        /// </summary>
        private const string LOG_OUT_NAME = "NA仕向言語対応";
        /// <summary>
        /// エビデンスフォルダ-正常系
        /// </summary>
        private const string EVIDENCE_DIR = "/" + LOG_OUT_NAME;
        /// <summary>
        /// 画面ID-確定画面
        /// </summary>
        private const int VIEW_ID_1 = 1;
        /// <summary>
        /// 画面ID-確認画面➁
        /// </summary>
        private const int VIEW_ID_2 = 2;
        /// <summary>
        /// 画面ID-確認画面①
        /// </summary>
        private const int VIEW_ID_3 = 3;

        /// <summary>
        /// JQueryで付与されるオプションリストのID追加文字列
        /// </summary>
        private const string ID_ADD_STRING = "-button";

        /// <summary>
        /// 実行ディレクトリ
        /// </summary>
        private string currentDir;
        /// <summary>
        /// エビデンス出力ディレクトリ
        /// </summary>
        private string evidenceDirectory;
        /// <summary>
        /// ログ出力先ディレクトリ
        /// </summary>
        private string logOutDir;

        /// <summary>
        /// OK件数
        /// </summary>
        private int chkVehicleConfirmedOK = 0;
        /// <summary>
        /// NG件数
        /// </summary>
        private int chkVehicleConfirmedNG = 0;

        /// <summary>
        /// 仕向ID
        /// </summary>
        private string regionId = "";
        /// <summary>
        /// 言語ID
        /// </summary>
        private string languageId = "";

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public NA_EN(string currentDir, string evidenceDir)
        {
            this.currentDir = currentDir;
            this.logOutDir = currentDir + evidenceDir;

            this.evidenceDirectory = logOutDir + EVIDENCE_DIR;
            // エビデンスフォルダ作成
            FileUtils.createEvidenceDirectory(evidenceDirectory);
        }

        /// <summary>
        /// シナリオNo.31～68
        /// </summary>
        public void testScenario_1()
        {
            logger.Info(" ################### GTS+ 多言語 [START] ################### ");

            try
            {
                // PF再起動
                FileUtils.rebootPF(currentDir);

                // 車両確定画面の表示
                using (var webDriverComponent = new WebDriverComponent(false, Constants.WebDriverOption.WAIT_TIMEOUT_MILLI_SECONDS))
                {
                    // 車両確定画面を開く
                    webDriverComponent.OpenPageAndWaitByID(Constants.URL.GTS_PLUS_VHCN, Constants.WAIT_ID.GTS_PLUS_VHCN);
                    Thread.Sleep(4000);
                    // 車両確定画面のキャプチャ取得
                    webDriverComponent.GetScreenshot(evidenceDirectory, "No.1_Vehicle_Confirmed_VIEW");

                    string retAPI = webDriverComponent.GetValueByIdNoneDisplay(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_RESULT_API);

                    // 仕向IDと言語IDの取得
                    regionId = retAPI.Substring(
                            retAPI.IndexOf(Constants.Sample_Word.REGION_ID) + Constants.Sample_Word.REGION_ID.Length,
                            2
                        ).Trim().Replace(",", "");
                    languageId = retAPI.Substring(
                            retAPI.IndexOf(Constants.Sample_Word.LANGUAGE_ID) + Constants.Sample_Word.LANGUAGE_ID.Length,
                            2
                        ).Trim().Replace(",", "");
                    logger.Debug("--- regionId：" + regionId + " / languageId：" + languageId + " ---");

                    // 画面項目確認（言語と仕向け）
                    string tableItemCat = webDriverComponent.GetValueById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_TABLE_CATEGORY);
                    string tableItemOpt = webDriverComponent.GetValueById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_TABLE_OPTION);
                    // 画面項目のチェック
                    if (CheckRegionLanguageComfirm(VIEW_ID_1, tableItemCat, tableItemOpt))
                    {
                        chkVehicleConfirmedOK++;
                        logger.Info("【" + LOG_OUT_NAME + " OK No." + chkVehicleConfirmedOK + "】: 車両確定画面項目");
                    }
                    else
                    {
                        chkVehicleConfirmedNG++;
                        logger.Info("【" + LOG_OUT_NAME + " NG No." + chkVehicleConfirmedNG  + "】: 車両確定画面項目");
                    }


                    // オプション選択（「<SELECT>」の下の項目を選択）
                    logger.Debug("【オプション項目選択変更】: オプション１");
                    webDriverComponent.SelectOptionById(Constants.ITEM_ID_VEHICLE_CONFIRMED.VEHICLE_CONFIRMED_OPTION1 + ID_ADD_STRING, false, 1);

                    // 車両確定画面を開く
                    webDriverComponent.OpenPageAndWaitByID(Constants.URL.GTS_PLUS_VHCN, Constants.WAIT_ID.GTS_PLUS_VHCN_CONFIRM);
                    Thread.Sleep(4000);
                    // 車両確認画面①のキャプチャ取得
                    webDriverComponent.GetScreenshot(evidenceDirectory, "No.2_Vehicle_Confirmed_VIEW");

                    // 画面項目確認（言語と仕向け）
                    string tableItemTitle = webDriverComponent.GetValueById(Constants.ITEM_ID_VEHICLE_CONFIRMATION.VEHICLE_CONFIRMATION_TITLE);
                    string tableItemTableInfo = webDriverComponent.GetValueById(Constants.ITEM_ID_VEHICLE_CONFIRMATION.VEHICLE_CONFIRMATION_TABLE_INFO);
                    // 画面項目のチェック
                    if (CheckRegionLanguageComfirm(VIEW_ID_3, tableItemTitle, tableItemTableInfo))
                    {
                        chkVehicleConfirmedOK++;
                        logger.Info("【" + LOG_OUT_NAME + " OK No." + chkVehicleConfirmedOK + "】: 車両確認画面①項目");
                    }
                    else
                    {
                        chkVehicleConfirmedNG++;
                        logger.Info("【" + LOG_OUT_NAME + " NG No." + chkVehicleConfirmedNG  + "】: 車両確認画面①項目");
                    }


                    logger.Debug("【yesボタン押下】");
                    webDriverComponent.ClickById(Constants.ITEM_ID_VEHICLE_CONFIRMATION.VEHICLE_CONFIRMATION_YES);
                    Thread.Sleep(33000);

                    // 車両確定画面を開く
                    webDriverComponent.OpenPageAndWaitByID(Constants.URL.GTS_PLUS_VHCN, Constants.WAIT_ID.GTS_PLUS_VHCN_CONFIRM);
                    Thread.Sleep(4000);
                    // 車両確認画面➁のキャプチャ取得
                    webDriverComponent.GetScreenshot(evidenceDirectory, "No.3_Vehicle_Confirmed_VIEW");

                    // 画面項目確認（言語と仕向け）
                    tableItemTitle = webDriverComponent.GetValueById(Constants.ITEM_ID_VEHICLE_CONFIRMATION.VEHICLE_CONFIRMATION_TITLE);
                    tableItemTableInfo = webDriverComponent.GetValueById(Constants.ITEM_ID_VEHICLE_CONFIRMATION.VEHICLE_CONFIRMATION_TABLE_INFO);
                    // 画面項目のチェック
                    if (CheckRegionLanguageComfirm(VIEW_ID_2, tableItemTitle, tableItemTableInfo))
                    {
                        chkVehicleConfirmedOK++;
                        logger.Info("【" + LOG_OUT_NAME + " OK No." + chkVehicleConfirmedOK + "】: 車両確認画面➁項目");
                    }
                    else
                    {
                        chkVehicleConfirmedNG++;
                        logger.Info("【" + LOG_OUT_NAME + " NG No." + chkVehicleConfirmedNG  + "】: 車両確認画面➁項目");
                    }


                    logger.Info("*********************************");
                    logger.Info("結果 check OK：" + chkVehicleConfirmedOK + " / check NG：" + chkVehicleConfirmedNG);
                    logger.Info("*********************************");

                }
            }
            catch (Exception exception)
            {
                logger.Debug("*********************************");
                logger.Debug("途中結果 check OK：" + chkVehicleConfirmedOK + " / check NG：" + chkVehicleConfirmedNG);
                logger.Debug("*********************************");
                logger.Error("Unexpected exception occurred during asynchronous processing.", exception);
            }

            logger.Info(" ################### GTS+ 車種確定画面表示 [END] ################### \r\n\r\n");

            // LOGのlogファイルコピー
            FileUtils.DirectoryCopy(currentDir + Constants.FilePath.LOG_FOLDER, logOutDir);
        }

        /// <summary>
        /// 仕向/言語チェック
        /// </summary>
        /// <param name="tableItemCat">カテゴリー</param>
        /// <param name="tableItemOpt">オプション</param>
        /// <returns>値</returns>
        private bool CheckRegionLanguageComfirm(int flg, string item1, string item2)
        {
            // コードテーブルを取得
            CodeDictionary codeDic = new CodeDictionary();
            // 言語
            Dictionary<string, string> languageDic = codeDic.LanguageDictionary();
            string language = languageDic[languageId];
            // 仕向
            Dictionary<string, string> regionDic = codeDic.RegionDictionary();
            string region = regionDic[regionId];
            
            // カテゴリー１
            string region_Category1 = "";
            // カテゴリー２
            string region_Category2 = "";
            // カテゴリー３
            string region_Category3 = "";
            // カテゴリー４
            string region_Category4 = "";
            // オプション
            string region_Option = "";
            // タイトル
            string region_Title = "";
            // 車両ID
            string region_VehicleId = "";
            // VIN
            string region_Vin = "";

            switch (regionId)
            {
                // 日本向けの場合
                case Constants.RegionId.REGION_CODE_JAPAN:
                    region_Category1 = Constants_JA.VehicleConfirmedItem.CATEGORY1;
                    region_Category2 = Constants_JA.VehicleConfirmedItem.CATEGORY2;
                    region_Category3 = Constants_JA.VehicleConfirmedItem.CATEGORY3;
                    region_Category4 = Constants_JA.VehicleConfirmedItem.CATEGORY4;
                    region_Option = Constants_JA.VehicleConfirmedItem.OPTION;
                    region_Title = Constants_JA.ConfirmationItem.CONFIRMATION_MSG;
                    region_VehicleId = Constants_JA.ConfirmationItem.VEHICLE_ID;
                    region_Vin = Constants_JA.ConfirmationItem.VIN;
                    break;
                // 北米向けの場合
                case Constants.RegionId.REGION_CODE_NORTH_AMERICA:
                    region_Category1 = Constants_EN.VehicleConfirmedItem.CATEGORY1;
                    region_Category2 = Constants_EN.VehicleConfirmedItem.CATEGORY2;
                    region_Category3 = Constants_EN.VehicleConfirmedItem.CATEGORY3;
                    region_Category4 = Constants_EN.VehicleConfirmedItem.CATEGORY4;
                    region_Option = Constants_EN.VehicleConfirmedItem.OPTION;
                    region_Title = Constants_EN.ConfirmationItem.CONFIRMATION_MSG;
                    region_VehicleId = Constants_EN.ConfirmationItem.VEHICLE_ID;
                    region_Vin = Constants_EN.ConfirmationItem.VIN;
                    break;
                case Constants.RegionId.REGION_CODE_EUROPE:
                    break;
                case Constants.RegionId.REGION_CODE_OTHER:
                    break;
                default:
                    break;
            }

            // 改行コードから仕向と言語を分ける
            string[] del = { "\r\n" };
            if (flg == VIEW_ID_1)
            {
                string[] category = item1.Split(del, StringSplitOptions.None);
                string[] option = item2.Split(del, StringSplitOptions.None);

                // カテゴリー１
                if (region_Category1.Trim() != category[0])
                {
                    logger.Info("【" + LOG_OUT_NAME + " NG No." + chkVehicleConfirmedNG  +  "】カテゴリー１：" + category[0]);
                    return false;
                }
                // カテゴリー２
                if (region_Category2.Trim() != category[2])
                {
                    logger.Info("【" + LOG_OUT_NAME + " NG No." + chkVehicleConfirmedNG  +  "】カテゴリー２：" + category[2]);
                    return false;
                }
                // カテゴリー３
                if (region_Category3.Trim() != category[4])
                {
                    logger.Info("【" + LOG_OUT_NAME + " NG No." + chkVehicleConfirmedNG  +  "】カテゴリー３：" + category[4]);
                    return false;
                }
                // カテゴリー４
                if (region_Category4.Trim() != category[6])
                {
                    logger.Info("【" + LOG_OUT_NAME + " NG No." + chkVehicleConfirmedNG  +  "】カテゴリー４：" + category[6]);
                    return false;
                }
                // オプション
                if (region_Option.Trim() != option[0])
                {
                    logger.Info("【" + LOG_OUT_NAME + " NG No." + chkVehicleConfirmedNG  +  "】オプション：" + option[0]);
                    return false;
                }
            }
            else
            {
                string[] tableInfo = item2.Split(del, StringSplitOptions.None);
                int idx = tableInfo[0].IndexOf(" ");
                string vehicleId = vehicleId = tableInfo[0].Substring(0, region_VehicleId.Length);
                string vin = tableInfo[1].Substring(0, region_Vin.Length);


                // タイトル
                if (region_Title != item1)
                {
                    logger.Info("【" + LOG_OUT_NAME + " NG No." + chkVehicleConfirmedNG +  "】タイトル：" + item1);
                    return false;
                }
                // 車両ID
                if (region_VehicleId != vehicleId)
                {
                    logger.Info("【" + LOG_OUT_NAME + " NG No." + chkVehicleConfirmedNG  +  "】車両ID：" + vehicleId);
                    return false;
                }
                // VIN
                if (region_Vin != vin)
                {
                    logger.Info("【" + LOG_OUT_NAME + " NG No." + chkVehicleConfirmedNG  +  "】VIN：" + vin);
                    return false;
                }
            }

            return true;
        }

    }
}
