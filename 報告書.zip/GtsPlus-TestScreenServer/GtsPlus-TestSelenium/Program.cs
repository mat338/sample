﻿using System;
using System.IO;
using System.Diagnostics;
using log4net;
using GtsPlus_TestSelenium.Utils;
using GtsPlus_TestSelenium.Component;
using GtsPlus_TestSelenium.Constant;
using GtsPlus_TestSelenium.Business;
using System.Threading;

namespace GtsPlus_TestSelenium
{
    class Program
    {
        /// <summary>
        /// エビデンスフォルダ
        /// </summary>
        private const string EVIDENCE_DIR = "/TestResult";

        //// コマンドライン引数
        ///// <summary>
        ///// 正常系設定ファイル指定
        ///// </summary>
        //private const string MAIN = "main"; // No.00_P5_Engine_正常系_22239_22401.ini
        ///// <summary>
        ///// P4系設定ファイル指定
        ///// </summary>
        //private const string P4 = "p4";     // P4Engine確認用.ini
        ///// <summary>
        ///// 北米仕向設定ファイル指定
        ///// </summary>
        //private const string NA_EN = "naen";  // P5Engine正常系11838_11839.ini

        /// <summary>
        /// SeleniumでIEを自動操作するサンプル
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            // カレントディレクトリ
            string currentDir = Directory.GetCurrentDirectory();
            // Httpファイルコピー元（テスト対象）
            string sourcePath = currentDir + Constants.FilePath.FROM_HTTP_DIRECTRY;
            // Httpファイルコピー先
            string destinationPath = currentDir + Constants.FilePath.TO_HTTP_DIRECTRY;

            HttpServer procHttpSever = null;
            try
            {
                // LOGファイルの削除
                if (Directory.Exists(currentDir + Constants.FilePath.LOG_FOLDER))
                {
                    Directory.Delete(currentDir + Constants.FilePath.LOG_FOLDER, true);
                }
                FileUtils.createEvidenceDirectory(currentDir + EVIDENCE_DIR);

                // httpディレクトリのコピー
                FileUtils.DirectoryCopy(sourcePath, destinationPath);
                Thread.Sleep(5000);

                // 正常系＆通信エラー系
                // シナリオ - QRコード表示
                QrCodeView qrCodeTest = new QrCodeView(currentDir, EVIDENCE_DIR);
                qrCodeTest.testScenario_2();    // No.34(ポート番号：50010が使用済みの場合、50011で接続)

                // httpサーバー起動
                procHttpSever = new HttpServer(currentDir);
                procHttpSever.StartHTTPServer();

                qrCodeTest.testScenario_1();    // No.1～33(正常系)
                qrCodeTest.testScenario_3();    // No.35～37（通信エラー系）

                // シナリオ - 車種確定画面
                VehicleConfirmedView vehicleConfirmedTest = new VehicleConfirmedView(currentDir, EVIDENCE_DIR);
                vehicleConfirmedTest.testScenario_1();  // No.1～36(正常系)
                vehicleConfirmedTest.testScenario_2();  // No.37～69(確認画面２系)
                vehicleConfirmedTest.testScenario_3();  // No.70～124(確認画面１系)
                vehicleConfirmedTest.testScenario_4();  // No.125～133(通信エラー系)

                // シナリオ - Allダイアグ画面
                AllDtcEcuSelectView allDtcEcuSelectTest = new AllDtcEcuSelectView(currentDir, EVIDENCE_DIR);
                allDtcEcuSelectTest.testScenario_1();   // No.1～32（Allダイアグ画面）
                allDtcEcuSelectTest.testScenario_2();   // No.33(通信エラー系)


                Console.WriteLine("\r\n疑似ECUを「P4Engine確認用.ini」に切替えてください。");
                Console.WriteLine("\r\n\r\n準備が出来たらキーを押下してください。");
                Console.ReadKey();


                // ダイアグ・フリーズP4
                P4 p4 = new P4(currentDir, EVIDENCE_DIR);
                p4.testScenario_1();


                Console.WriteLine("\r\n疑似ECUを「P5Engine正常系11838_11839.ini」に切替えてください。");
                Console.WriteLine("\r\nGTSアプリケーション「Techstream」の仕向を「北米」に、言語を「English」に切替えてください。");
                Console.WriteLine("\r\n\r\n準備が出来たらキーを押下してください。");
                Console.ReadKey();


                // 北米仕向
                NA_EN naen = new NA_EN(currentDir, EVIDENCE_DIR);
                naen.testScenario_1();

                // httpサーバー終了
                if(procHttpSever != null) procHttpSever.StopHTTPServer();

            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                // httpディレクトリの削除
                if (Directory.Exists(destinationPath))
                {
                    Directory.Delete(destinationPath, true);
                }

                Console.WriteLine("\r\nPress any key to exit.");
                Console.ReadKey();
            }
        }

    }
}
