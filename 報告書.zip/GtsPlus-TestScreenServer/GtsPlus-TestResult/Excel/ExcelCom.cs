﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;
using Microsoft.Office.Interop.Excel;
using System.IO;
using Constants = GtsPlus_TestResult.Constant.Constants;

namespace GtsPlus_TestResult.Excel
{
    class ExcelCom : IDisposable
    {
        /// <summary>
        /// Excel操作用オブジェクト
        /// </summary>
        private Application _application = null;
        private Workbook _workbook = null;
        private Worksheet _worksheet = null;

        // Disposeフラグ
        private bool disposedValue = false;

        /// <summary>
        /// Excelワークブックを開く
        /// </summary>
        /// <param name="openFile">ファイルパス</param>
        public void Open(string openFile)
        {
            try
            {
                // Excelアプリケーション生成
                _application = new Application()
                {
                    // 非表示
                    Visible = true
                    //Visible = false
                };

                // Bookを開く
                _workbook = _application.Workbooks.Open(openFile);
            }
            catch (Exception ex)
            {
                throw (ex);
            }
        }

        /// <summary>
        /// 対象シートを選択
        /// </summary>
        /// <param name="sheetName">設定シート名</param>
        public void SetWorksheet(string sheetName)
        {
            try
            {
                // 対象シートを設定する
                _worksheet = _workbook.Worksheets[sheetName];
            }
            catch (Exception ex)
            {
                throw (ex);
            }
        }

        /// <summary>
        /// Excelワークブックをファイル名を指定して保存する
        /// </summary>
        /// <param name="saveFile">保存ファイルパス</param>
        /// <returns>True:正常終了、False:保存失敗</returns>
        public bool SaveAs(string saveFile)
        {
            try
            {
                // ファイル名を指定して保存する
                _workbook.SaveCopyAs(saveFile);
            }
            catch
            {
                return false;
            }

            return true;
        }

        /// <summary>
        /// セル値読込
        /// </summary>
        /// <param name="rowIndex">row</param>
        /// <param name="columnIndex">col</param>
        public string ReadCell(int rowIndex, int columnIndex)
        {
            // セルを指定
            var cells = _worksheet.Cells;
            var range = cells[rowIndex, columnIndex] as Range;

            string val = Convert.ToString(range.Value);

            // cell解放
            Marshal.ReleaseComObject(range);
            Marshal.ReleaseComObject(cells);

            // 値を取得
            return val;
        }

        /// <summary>
        /// セル書込み
        /// </summary>
        /// <param name="rowIndex">row</param>
        /// <param name="columnIndex">col</param>
        /// <param name="value">value</param>
        public void WriteCell(int rowIndex, int columnIndex, object value)
        {
            // セルを指定
            var cells = _worksheet.Cells;
            var range = cells[rowIndex, columnIndex] as Range;

            // 値を設定
            range.Value = value;

            // cell解放
            Marshal.ReleaseComObject(range);
            Marshal.ReleaseComObject(cells);
        }

        /// <summary>
        /// オブジェクト埋込
        /// </summary>
        /// <param name="rowIndex">row</param>
        /// <param name="columnIndex">col</param>
        /// <param name="fileName">埋込ファイル名</param>
        public void WriteObject(int rowIndex, int columnIndex, string fileName)
        {
            // セルを指定
            var cells = _worksheet.Cells;
            var range = cells[rowIndex, columnIndex] as Range;

            range.Select();

            // ファイルを埋め込み
            _worksheet.Shapes.AddOLEObject(Filename: fileName);

            // cell解放
            Marshal.ReleaseComObject(range);
            Marshal.ReleaseComObject(cells);
        }

        /// <summary>
        /// イメージファイル埋込
        /// </summary>
        /// <param name="rowIndex">row</param>
        /// <param name="columnIndex">col</param>
        /// <param name="fileName">埋込ファイル名</param>
        public void WriteImage(int rowIndex, int columnIndex, string fileName)
        {
            // セルを指定
            var cells = _worksheet.Cells;
            var range = cells[rowIndex, columnIndex] as Range;

            float Left = (float)range.Left;
            float Top = (float)range.Top;
            float Width = 0.0F;//(float)widthCell; // 変更
            float Height = 0.0F; //(float)heightCell; //変更

            // ファイルを埋め込み
            dynamic shape = _worksheet.Shapes.AddPicture(fileName, 
                Microsoft.Office.Core.MsoTriState.msoCTrue,
                Microsoft.Office.Core.MsoTriState.msoCTrue, 
                Left, Top, Width, Height);

            // 倍率を50%にする
            shape.ScaleHeight(0.50F, Microsoft.Office.Core.MsoTriState.msoCTrue);
            shape.ScaleWidth(0.50F, Microsoft.Office.Core.MsoTriState.msoCTrue);

            //きっちり挿入
            shape.Placement = XlPlacement.xlMoveAndSize;

            // cell解放
            Marshal.ReleaseComObject(range);
            Marshal.ReleaseComObject(cells);
        }

        /// <summary>
        /// 「format」シートをコピー
        /// </summary>
        /// <param name="sheetName">コピーシート名</param>
        public void CopyWorksheetFormat(string sheetName)
        {
            // シート数を取得
            int totalSheets = _workbook.Sheets.Count;
            // 「format」シートを選択
            SetWorksheet(Constants.Specification.SHEET_FORMAT);
            // 「format」シートを末尾にコピー
            _worksheet.Copy(Type.Missing, _workbook.Worksheets[totalSheets]);

            //末尾シート名変更
            int aft_totalSheets = _workbook.Sheets.Count;
            string sheetname = _workbook.Worksheets[aft_totalSheets].Name;

            _workbook.Worksheets[sheetname].Name = sheetName;
        }

        /// <summary>
        /// シート名からインデックスを取得
        /// </summary>
        /// <param name="sheetName">コピーシート名</param>
        /// <param name="shs">シート</param>
        public int getSheetIndex(string sheetName, Sheets shs)
        {
            int i = 0;
            foreach (Worksheet sh in shs)
            {
                if (sheetName == sh.Name)
                {
                    return i + 1;
                }
                i += 1;
            }

            return 0;
        }

        #region "Dispose"
        protected virtual void Dispose(bool disposing)
        {
            try
            {
                if (!disposedValue)
                {
                    if (disposing)
                    {
                        // TODO: Managed Objectの破棄
                    }

                    if (_workbook != null)
                    {
                        _workbook.Close(false);
                        System.Runtime.InteropServices.Marshal.ReleaseComObject(_workbook);
                        _workbook = null;
                    }

                    if (_application != null)
                    {
                        _application.Quit();
                        System.Runtime.InteropServices.Marshal.ReleaseComObject(_application);
                        _application = null;
                    }

                    disposedValue = true;
                }
            }
            catch
            {
            }
        }

        ~ExcelCom()
        {
            Dispose(false);
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        #endregion "Dispose"
    }
}
