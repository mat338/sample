﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GtsPlus_TestResult.Constant
{
    /// <summary>
    /// 共通_定数クラス
    /// </summary>
    class Constants
    {
        /// <summary>
        /// フォルダ名
        /// </summary>
        public static class Folder
        {
            /// <summary>
            /// 自動テスト実行プロジェクトフォルダ名
            /// </summary>
            public const string GTS_PLUS_TEST_SELENIUM = "TestSelenium";

            /// <summary>
            /// テスト結果生成プロジェクトフォルダ名
            /// </summary>
            public const string GTS_PLUS_TEST_RESULT = "TestResult";

            /// <summary>
            /// 自動テスト結果フォルダ名
            /// </summary>
            public const string TEST_RESULT = "TestResult";

            /// <summary>
            /// Log拡張子
            /// </summary>
            public const string LOG_EXTENSION = "*.log";
        }

        /// <summary>
        /// 仕様書
        /// </summary>
        public static class Specification
        {
            /// <summary>
            /// 検査仕様書ファイル名
            /// </summary>
            public const string BASE_FILE = "【GTS+】ホロレンズ検証用GUI開発検査仕様書";

            /// <summary>
            /// Excel拡張子
            /// </summary>
            public const string EXCEL_EXTENSION = ".xlsx";

            /// <summary>
            /// ワークシート - 試験項目
            /// </summary>
            public const string SHEET_ITEM_LIST = "試験項目";

            /// <summary>
            /// ワークシート - フォーマット
            /// </summary>
            public const string SHEET_FORMAT = "format";

            /// <summary>
            /// ワークシート - ログ添付
            /// </summary>
            public const string SHEET_LOG = "ログファイル";


            /// <summary>
            /// 読取り開始行番号
            /// </summary>
            public const int ROW_START = 3;

            /// <summary>
            /// 大分類列番号
            /// </summary>
            public const int COL_MAJOR_CLASS = 3;

            /// <summary>
            ///No列番号
            /// </summary>
            public const int COL_NO = 5;

            /// <summary>
            /// Json列番号
            /// </summary>
            public const int COL_JSON = 11;

            /// <summary>
            /// キャプチャー列番号
            /// </summary>
            public const int COL_CAPTURE = 12;

            /// <summary>
            /// Log列番号
            /// </summary>
            public const int COL_LOG = 13;

            /// <summary>
            /// 担当者設定列
            /// </summary>
            public const int COL_TANTO = 14;

            /// <summary>
            /// 担当者名
            /// </summary>
            public const string TANTO_NAME = "FSI";

            /// <summary>
            /// 実施月日設定列
            /// </summary>
            public const int COL_NENGETU = 15;

            /// <summary>
            /// 担当者設定列
            /// </summary>
            public const int COL_JUDGMENT = 16;


            /// <summary>
            /// タイトル設定行
            /// </summary>
            public const int TITLE_ROW = 2;

            /// <summary>
            /// タイトル設定列
            /// </summary>
            public const int TITLE_COL = 1;

            /// <summary>
            /// テストNo設定開始行
            /// </summary>
            public const int TEST_NO_START_ROW = 4;

            /// <summary>
            /// テストNo設定列
            /// </summary>
            public const int TEST_NO_COL = 2;

        }
    }
}
