﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GtsPlus_TestResult.Business;
using GtsPlus_TestResult.Utils;
using GtsPlus_TestResult.Constant;

namespace GtsPlus_TestResult
{
    class Program
    {


        static void Main(string[] args)
        {
            // カレントディレクトリ
            string currentDir = Directory.GetCurrentDirectory();

            // コピー先フォルダ
            string copyToDir = currentDir + "\\" + Constants.Folder.TEST_RESULT;
            // テスト結果コピー元フォルダ
            string originalDir = currentDir.Replace(
                Constants.Folder.GTS_PLUS_TEST_RESULT, 
                Constants.Folder.GTS_PLUS_TEST_SELENIUM
                ) + "\\" + Constants.Folder.TEST_RESULT;

            try
            {
                // コピー先フォルダ存在チェック（存在する場合はコピーしない）
                if (!Directory.Exists(copyToDir))
                {
                    // コピー元フォルダ存在チェック
                    if (!Directory.Exists(originalDir))
                    {
                        // コピー先/コピー元共にフォルダが無い場合は実行不能
                        Console.WriteLine("コピー先/コピー元共にエビデンスフォルダが存在しません");
                        Console.WriteLine("\r\n\r\n\r\nPress any key to exit.");
                        Console.ReadKey();
                        return;
                    }

                    FileUtils.DirectoryCopy(originalDir, copyToDir);
                }

                // 検査仕様書作成
                CreateEvidence evidence = new CreateEvidence();
                evidence.main();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }

            Console.WriteLine("\r\nPress any key to exit.");
            Console.ReadKey();

        }
    }
}
