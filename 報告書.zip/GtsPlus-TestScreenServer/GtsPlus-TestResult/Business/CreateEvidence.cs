﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GtsPlus_TestResult.Excel;
using GtsPlus_TestResult.Constant;
using GtsPlus_TestResult.Utils;

namespace GtsPlus_TestResult.Business
{
    /// <summary>
    /// エビデンス作成ツール
    /// </summary>
    public class CreateEvidence
    {
        // Excel操作クラス
        ExcelCom excel = new ExcelCom();

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public CreateEvidence()
        {

        }

        /// <summary>
        /// エビデンスファイル作成
        /// </summary>
        public void main()
        {
            try
            {
                Console.WriteLine("========== 検査仕様書作成開始 ==========");
                // 「【GTS+】ホロレンズ検証用GUI開発検査仕様書.xlsx」を開く
                excel.Open(Directory.GetCurrentDirectory() + "\\" + Constants.Specification.BASE_FILE + Constants.Specification.EXCEL_EXTENSION);

                // エビデンス生成
                CreateEvidenceFile();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }

            // 保存
            bool save = excel.SaveAs(
                Directory.GetCurrentDirectory() + "\\" + Constants.Specification.BASE_FILE + "_" +
                DateTime.Now.ToString("yyyyMMdd_HHmmss") + Constants.Specification.EXCEL_EXTENSION);
        }

        /// <summary>
        /// エビデンス生成
        /// </summary>
        private void CreateEvidenceFile()
        {
            Console.WriteLine("========== 試験項目一覧読込 ==========");
            // 「試験項目」シートを選択
            excel.SetWorksheet(Constants.Specification.SHEET_ITEM_LIST);
            // 「試験項目」シート読込
            List<TestItems> itemsList = GetTestItem();

            Console.WriteLine("========== ログ出力内容読込 ==========");
            // 「GtsPlus-TestSelenium-yyyymmdd.log」の出力内容読込
            string content = GetLogContent();

            int startIdx = 0;
            int endIdx = 0;
            int idx = 0;
            string searchStr = "";
            string runningMajorClass = "";

            int rowCount = 0;   // 行カウンタ
            int colCount = 0;   // 列カウンタ
            string rowStr = "";

            string filePath = "";

            // 試験項目リスト
            foreach (TestItems Item in itemsList)
            {
                #region "シート作成"
                // 大分類別にシートを分ける
                if (!string.IsNullOrEmpty(Item.MajorClass))
                {
                    // シートを追加
                    excel.CopyWorksheetFormat(Item.MajorClass);

                    // 追加したシートを選択
                    excel.SetWorksheet(Item.MajorClass);
                    // タイトルを設定
                    excel.WriteCell(Constants.Specification.TITLE_ROW, Constants.Specification.TITLE_COL, Item.MajorClass);

                    // 大分類名
                    runningMajorClass = Item.MajorClass;
                    // 開始行リセット
                    rowCount = Constants.Specification.TEST_NO_START_ROW;
                }
                #endregion "シート作成"

                // 「試験項目」シートに担当者と日付を記入する
                excel.SetWorksheet(Constants.Specification.SHEET_ITEM_LIST);
                excel.WriteCell(Item.RowNum, Constants.Specification.COL_TANTO, Constants.Specification.TANTO_NAME);
                excel.WriteCell(Item.RowNum, Constants.Specification.COL_NENGETU, DateTime.Now.ToString("MM/dd"));

                #region "ログ抽出"
                // ログ出力結果から該当行を検索
                searchStr = "【" + runningMajorClass + " OK No." + Item.No;// + "】: ";
                idx = content.IndexOf(searchStr);
                if(idx > -1)
                {
                    // ログにOKの記載があった場合
                    startIdx = idx + searchStr.Length + "】: ".Length;
                    endIdx = content.IndexOf("\r\n", startIdx);

                    rowStr = content.Substring(startIdx, endIdx - startIdx);

                    // 試験結果の入力
                    excel.WriteCell(Item.RowNum, Constants.Specification.COL_JUDGMENT, "OK");
                }
                else
                {
                    Console.WriteLine(searchStr);
                    //Console.ReadKey();
                    // 試験結果の入力
                    excel.WriteCell(Item.RowNum, Constants.Specification.COL_JUDGMENT, "NG");
                }
                #endregion "ログ抽出"

                // 追加したシートを選択
                excel.SetWorksheet(runningMajorClass);

                #region "エビデンス貼付け"
                filePath = Directory.GetCurrentDirectory() + "\\" + Constants.Folder.TEST_RESULT + "\\" + runningMajorClass;
                // エビデンスフォルダが存在しない場合は処理しない
                if(Directory.Exists(filePath))
                {
                    // Json
                    if (!string.IsNullOrEmpty(Item.Json))
                    {
                        // テストNo出力
                        excel.WriteCell(rowCount, Constants.Specification.TEST_NO_COL, "【No." + Item.No + "】");

                        // シートにLog出力文字列を挿入する
                        rowCount++;
                        colCount = Constants.Specification.TEST_NO_COL + 1;
                        excel.WriteCell(rowCount, colCount, rowStr);

                        // シートにJsonファイルを挿入する
                        IEnumerable<string> files = FileUtils.SearchFile(filePath, "No." + Item.No + "_*.json");
                        rowCount += 2;
                        foreach (string fileName in files)
                        {
                            Console.WriteLine(fileName);
                            excel.WriteObject(rowCount, colCount, fileName);

                            // 複数のJsonファイルを横並びで出力する際のJsonファイルの幅を加算
                            colCount += 5;
                        }

                        // Jsonファイルの高さを加算
                        rowCount += 4;
                    }

                    // capture
                    if (!string.IsNullOrEmpty(Item.Capture))
                    {
                        // 出力済みフラグ
                        bool viewFlg = false;
                        // シートにpngファイルを挿入する
                        IEnumerable<string> files = FileUtils.SearchFile(filePath, "No." + Item.No + "*.png");
                        foreach (string fileName in files)
                        {
                            // ファイル検索の結果、処理対象外のファイルもヒットするため（No.1を検索→検索結果：No.1、No.10～、No.101～）
                            // テストNoの桁数を判定することで処理対象のファイルのみ処理を行う
                            startIdx = fileName.IndexOf("No.") + "No.".Length;
                            endIdx = fileName.IndexOf("_", startIdx);
                            idx = fileName.IndexOf("-", startIdx);    // １イメージファイルで複数件のエビデンスになっている場合（例：No.13-18_〇〇.png）
                            int lenNo = 0;
                            string testNo = "";
                            // テストNoの桁数
                            if ((startIdx > -1 || endIdx > -1) && idx == -1)
                            {
                                // [No.A_〇〇.png] Aを抽出
                                testNo = fileName.Substring(startIdx, endIdx - startIdx);
                                // [No.A_〇〇.png] Aの桁数
                                lenNo = testNo.Length;
                            }
                            else if((startIdx > -1 || endIdx > -1) && idx != -1)
                            {
                                // [No.A-B_〇〇.png] A-Bを抽出
                                testNo = fileName.Substring(startIdx, endIdx - startIdx);
                                // [No.A-B_〇〇.png] Aの桁数
                                lenNo = fileName.Substring(startIdx, idx - startIdx).Length;
                            }

                            // 処理対象のファイルのみ出力
                            if (Item.No.Length == lenNo)
                            {
                                // 初回のみ出力
                                if (!viewFlg)
                                {
                                    // テストNo出力
                                    excel.WriteCell(rowCount, Constants.Specification.TEST_NO_COL, "【No." + testNo + "】");

                                    // シートにLog出力文字列を挿入する
                                    rowCount++;
                                    colCount = Constants.Specification.TEST_NO_COL + 1;
                                    excel.WriteCell(rowCount, Constants.Specification.TEST_NO_COL + 1, rowStr);

                                    rowCount += 2;
                                    viewFlg = true;
                                }

                                Console.WriteLine(fileName);
                                excel.WriteImage(rowCount, colCount, fileName);

                                // 複数のイメージファイルを横並びで出力する際のイメージファイルの幅を加算
                                colCount += 34;
                            }
                        }

                        // イメージファイルの高さを加算
                        rowCount += 29;
                    }

                    // log
                    if (!string.IsNullOrEmpty(Item.Log))
                    {
                        // テストNo出力
                        excel.WriteCell(rowCount, Constants.Specification.TEST_NO_COL, "【No." + Item.No + "】");

                        // シートにLog出力文字列を挿入する
                        rowCount++;
                        excel.WriteCell(rowCount, Constants.Specification.TEST_NO_COL + 1, rowStr);

                        rowCount += 2;
                    }
                }
                #endregion "エビデンス貼付け"
            }
        }

        /// <summary>
        /// 「試験項目」シート読込
        /// </summary>
        private List<TestItems> GetTestItem()
        {
            List<TestItems> itemsList = new List<TestItems>();
            int row = Constants.Specification.ROW_START;

            while (true)
            {
                // No列に値が無い場合は処理を抜ける
                if (string.IsNullOrEmpty(excel.ReadCell(row, Constants.Specification.COL_NO)))
                {
                    return itemsList;
                }

                // 読込
                TestItems Items = new TestItems
                {
                    RowNum = row,
                    MajorClass = excel.ReadCell(row, Constants.Specification.COL_MAJOR_CLASS),
                    No = excel.ReadCell(row, Constants.Specification.COL_NO),
                    Json = excel.ReadCell(row, Constants.Specification.COL_JSON),
                    Capture = excel.ReadCell(row, Constants.Specification.COL_CAPTURE),
                    Log = excel.ReadCell(row, Constants.Specification.COL_LOG)
                };

                //Console.WriteLine(row + ":" + Items.No);
                itemsList.Add(Items);

                // 次行へ
                row++;
            }
        }

        /// <summary>
        /// 自動試験ログファイルの読込
        /// </summary>
        private string GetLogContent()
        {
            string logFile = FileUtils.SearchFileLog(Directory.GetCurrentDirectory() + "\\" + Constants.Folder.TEST_RESULT, Constants.Folder.LOG_EXTENSION);
            string content = FileUtils.ReadFileContent(logFile);

            // シートを追加
            excel.CopyWorksheetFormat(Constants.Specification.SHEET_LOG);

            // 追加したシートを選択
            excel.SetWorksheet(Constants.Specification.SHEET_LOG);

            // タイトルを設定
            excel.WriteCell(Constants.Specification.TITLE_ROW, Constants.Specification.TITLE_COL, Constants.Specification.SHEET_LOG);

            // シートにJsonファイルを挿入する
            excel.WriteObject(Constants.Specification.TEST_NO_START_ROW, Constants.Specification.TEST_NO_COL, logFile);

            return content;
        }
    }
}
