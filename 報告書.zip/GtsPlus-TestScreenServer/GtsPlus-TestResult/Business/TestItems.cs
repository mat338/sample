﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GtsPlus_TestResult.Business
{
    /// <summary>
    /// 「試験項目」シートプロパティ
    /// </summary>
    class TestItems
    {
        // 行番号
        private int rowNum = 0;
        // 大分類
        private string majorClass = "";
        // No
        private string no = "";
        // json
        private string json = "";
        // capture
        private string capture = "";
        // log
        private string log = "";

        /// <summary>
        /// 行番号
        /// </summary>
		public int RowNum
        {
            get { return (rowNum); }
            set { rowNum = value; }
        }

        /// <summary>
        /// 大分類
        /// </summary>
		public string MajorClass
        {
            get { return (majorClass); }
            set { majorClass = value; }
        }

        /// <summary>
        /// No
        /// </summary>
		public string No
        {
            get { return (no); }
            set { no = value; }
        }

        /// <summary>
        /// json
        /// </summary>
		public string Json
        {
            get { return (json); }
            set { json = value; }
        }

        /// <summary>
        /// capture
        /// </summary>
		public string Capture
        {
            get { return (capture); }
            set { capture = value; }
        }

        /// <summary>
        /// log
        /// </summary>
		public string Log
        {
            get { return (log); }
            set { log = value; }
        }
    }
}
