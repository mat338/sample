﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Text;
using GtsPlus_TestResult.Constant;

namespace GtsPlus_TestResult.Utils
{
    /// <summary>
    /// 共通_ファイル操作関連ユーティリティクラス
    /// </summary>
    public static class FileUtils
    {
        /// <summary>
        /// ディレクトリのコピー処理
        /// </summary>
        /// <param name="sourcePath">コピー元フォルダ</param>
        /// <param name="destinationPath">コピー先フォルダ</param>
        public static void DirectoryCopy(string originalDir, string copyToDir)
        {
            DirectoryInfo sourceDirectory = new DirectoryInfo(originalDir);
            DirectoryInfo copyToDirectory = new DirectoryInfo(copyToDir);

            //コピー先のディレクトリがなければ作成する
            if (copyToDirectory.Exists == false)
            {
                copyToDirectory.Create();
                copyToDirectory.Attributes = sourceDirectory.Attributes;
            }

            //ファイルのコピー
            foreach (FileInfo fileInfo in sourceDirectory.GetFiles())
            {
                //同じファイルが存在していたら、常に上書きする
                fileInfo.CopyTo(copyToDirectory.FullName + @"\" + fileInfo.Name, true);
            }

            //ディレクトリのコピー（再帰を使用）
            foreach (DirectoryInfo directoryInfo in sourceDirectory.GetDirectories())
            {
                DirectoryCopy(directoryInfo.FullName, copyToDirectory.FullName + @"\" + directoryInfo.Name);
            }
        }

        /// <summary>
        /// ディレクトリの作成処理
        /// </summary>
        /// <param name="dirPath">フォルダ</param>
        public static void createDirectory(string dirPath)
        {
            if (Directory.Exists(dirPath))
            {
                // 古いフォルダを削除
                Directory.Delete(dirPath, true);
                Thread.Sleep(500);
            }

            // フォルダ作成
            DirectoryInfo evidenceDirectory = new DirectoryInfo(dirPath);
            evidenceDirectory.Create();
        }

        /// <summary>
        /// ファイル検索処理
        /// </summary>
        /// <param name="filePath">ファイルパス</param>
        /// <param name="extension">拡張子</param>
        /// <returns>ファイル内容</returns>
        public static string SearchFileLog(string filePath, string extension)
        {
            // 「GtsPlus-TestSelenium-yyyymmdd.log」を検索
            IEnumerable<string> files = Directory.EnumerateFiles(filePath, extension);
            // 1ファイルしかないはずなので先頭ファイルを採用
            return files.First();
        }

        /// <summary>
        /// ファイル検索処理
        /// </summary>
        /// <param name="filePath">ファイルパス</param>
        /// <param name="extension">拡張子</param>
        /// <returns>ファイル内容</returns>
        public static IEnumerable<string> SearchFile(string filePath, string pattern)
        {
            IEnumerable<string> files = Directory.EnumerateFiles(filePath, pattern).OrderBy(name => name);

            return files;
        }

        /// <summary>
        /// ファイル内容読み込み処理
        /// </summary>
        /// <param name="filePath">ファイルパス</param>
        /// <returns>ファイル内容</returns>
        public static string ReadFileContent(string filePath)
        {
            string content = "";
            try
            {
                // 読み込みたいテキストを開く
                using (StreamReader st = new StreamReader(filePath, Encoding.GetEncoding("UTF-8")))
                {
                    // テキストファイルをString型で読み込む
                    content = st.ReadToEnd();
                    Console.WriteLine(content);
                }
            }
            catch (IOException e)
            {
                // ファイルを読み込めない場合エラーメッセージを表示
                Console.WriteLine("ファイルを読み込めませんでした");
                Console.WriteLine(e.Message);
            }

            return content;
        }
        
        /// <summary>
        /// URI ⇒ ファイルパス変換処理
        /// </summary>
        /// <param name="source">ソース</param>
        /// <returns>変換結果</returns>
        public static string UriToFilePath(string source)
        {
            return source.Replace("/", "\\");
        }

        /// <summary>
        /// Jsonファイル出力処理
        /// </summary>
        /// <param name="fileName">出力ファイル名</param>
        /// <param name="json">出力内容</param>
        public static void WriteJson(string fileName, string json)
        {
            Encoding utf8Enc = Encoding.GetEncoding("utf-8");
            // テキストファイルを開いて（なければ作って）StreamWriterオブジェクトを得る
            using (StreamWriter writer = new StreamWriter(fileName, false, utf8Enc))
            {
                // ファイルにテキストを書き込む
                writer.WriteLine(json);
            }
        }
    }
}
