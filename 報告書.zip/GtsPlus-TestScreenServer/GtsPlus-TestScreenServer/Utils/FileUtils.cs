﻿using System;
using System.IO;

namespace GtsPlus_TestScreenServer.Utils
{
    /// <summary>
    /// 共通_ファイル操作関連ユーティリティクラス
    /// </summary>
    public static class FileUtils
    {
        /// <summary>
        /// ファイル内容読み込み処理
        /// </summary>
        /// <param name="filePath">ファイルパス</param>
        /// <returns>ファイル内容</returns>
        public static byte[] ReadFileContent(string filePath)
        {
            using (var fileStream = new FileStream(filePath, FileMode.Open, FileAccess.Read, FileShare.Read))
            {
                var byteArray = new byte[fileStream.Length];
                fileStream.Read(byteArray, 0, Convert.ToInt32(fileStream.Length));
                return byteArray;
            }
        }

        /// <summary>
        /// URI ⇒ ファイルパス変換処理
        /// </summary>
        /// <param name="source">ソース</param>
        /// <returns>変換結果</returns>
        public static string UriToFilePath(string source)
        {
            return source.Replace("/", "\\");
        }
    }
}
