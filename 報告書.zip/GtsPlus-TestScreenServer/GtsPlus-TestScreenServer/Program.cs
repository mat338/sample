﻿using GtsPlus_TestScreenServer.Component;
using log4net;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace GtsPlus_TestScreenServer
{
    /// <summary>
    /// メインクラス
    /// </summary>
    public class Program
    {
        /// <summary>
        /// log4net
        /// </summary>
        private static readonly ILog logger = LogManager.GetLogger(typeof(Program));

        /// <summary>
        /// 終了キー
        /// </summary>
        private static readonly string END_KEY = "E";

        /// <summary>
        /// メイン処理
        /// </summary>
        /// <param name="args">起動引数</param>
        public static void Main(string[] args)
        {
            logger.Info("################################################################# GTS+ TestScreenServer [START] #################################################################");
            DoProcess();
            logger.Info("################################################################# GTS+ TestScreenServer [END  ] #################################################################");
            Console.WriteLine("\r\nPress any key to exit.");
            Console.ReadKey();
        }

        /// <summary>
        /// 実行処理
        /// </summary>
        public static void DoProcess()
        {
            using (var cancellationTokenSource = new CancellationTokenSource())
            {
                Task.Run(async () => await WaitForInterruptionAsync(cancellationTokenSource));

                try
                {
                    logger.Info("Start server processing. Press 'E' to interrupt.");
                    using (var httpServerComponent = new HttpServerComponent(new List<Tuple<string, uint>>() {
                        Tuple.Create(Properties.Settings.Default.HttpServerBaseUri, Properties.Settings.Default.HttpServerPortNo),
                        Tuple.Create(Properties.Settings.Default.HttpServerBaseUriSsl, Properties.Settings.Default.HttpServerPortNoSsl)
                    }))
                    {
                        httpServerComponent.StartListening();
                        cancellationTokenSource.Token.WaitHandle.WaitOne(Properties.Settings.Default.CancelWaitMilliseconds);
                        logger.Info("Interrupt server processing...");
                    }
                }
                catch (Exception e)
                {
                    logger.Error("Unexpected exception occurred.", e);
                }
            }
        }

        /// <summary>
        /// 非同期 - 中断待機処理
        /// </summary>
        /// <param name="cancellationTokenSource">キャンセルトークン</param>
        /// <returns>非同期タスク実行結果</returns>
        public static async Task WaitForInterruptionAsync(CancellationTokenSource cancellationTokenSource)
        {
            while (true)
            {
                if (Console.KeyAvailable)
                {
                    if (END_KEY == Console.ReadKey().Key.ToString())
                    {
                        cancellationTokenSource.Cancel();
                        break;
                    }
                }
                await Task.Delay(Properties.Settings.Default.EndWaitInterval);
            }
        }
    }
}
