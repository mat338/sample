/**
 * トップ画面のscript
 */

/**
 * 画面ロード時イベント処理
 */
window.onload = function () {
    // ローディング画像の表示
    ScreenComponent.displayLoading("loading", "Initializing...");

    // GTS+へWebSocket接続
    WebSocketComponent.connectServerAsync(null, null, null, onError = onError).then(WebSocketComponent.terminateConnectProcessAsync()).then(function () {
        // 接続プロセス成功の場合
        apiConnectingProcess().then(function (data) {
            // チャレンジコード生成API
            apiCreateChallengeCode(data).then(function (data) {
                LogManager.info("[API : " + Constants.PlatformApiId.CREATE_CHALLENGE_CODE + "] -----> OK.");
                ScreenComponent.responseApi(data);

                // API認証用ハッシュコード生成
                var hash = createHash(data);

                // API認証用ハッシュコードチェックAPI
                apiCheckApiAuthentication(hash).then(function (data) {
                    LogManager.info("[API : " + Constants.PlatformApiId.CHECK_API_AUTHENTICATION + "] -----> OK.");
                    ScreenComponent.responseApi(data);

                    // 診断情報取得API
                    apiGetDiagnosticInformation().then(function (data) {
                        // 診断情報の結果による分岐
                        if (Constants.PlatformApiResult.SUCCESS === data.resultInfo.result) {
                            LogManager.info("[API : " + Constants.PlatformApiId.GET_DIAGNOSTIC_INFORMATION + "] -----> OK.");
                            ScreenComponent.responseApi(data);

                            // 診断開始状態の判定
                            if (Constants.GetDiagnosticInformationResult.NOT_EXECUTED === data.apiArgs.diagnosisStartStatus) {
                                // 診断開始状態が未実施の場合
                                startDiagnosis();
                            } else {
                                // 診断開始状態が実施中の場合
                                diagnosisConfirmDisplay(data);
                            }
                        }

                    }).catch(function (e) {
                        // API認証用ハッシュコードチェックAPI失敗の場合
                        displayErrorScreen(e.message);
                    });

                }).catch(function (e) {
                    // 診断情報取得API失敗の場合
                    displayErrorScreen(e.message);
                });

            }).catch(function (e) {
                // API認証用ハッシュコードチェックAPI失敗の場合
                displayErrorScreen(e.message);
            });

        }).catch(function (e) {
            // チャレンジコード生成API失敗の場合
            displayErrorScreen(e.message);
        });

    }).catch(function (e) {
        // 接続プロセス失敗の場合
        displayErrorScreen(e.message);
    });
}

/**
 * 接続プロセス成功時処理
 * 
 * @return {Object}
 */
function apiConnectingProcess() {
    // GUI-PF間接続初期化APIの実行
    return WebSocketComponent.executeApiAsync(webSocket = WebSocketComponent.WebSocket, {
        common: {
            apiId: Constants.PlatformApiId.SET_CONNECTION_CONDTION,
            ack: Constants.PlatformApiAckFlag.FALSE,
        },
        apiArgs: {
            name: Constants.PlatformApiCommonArgs.SCREEN_RELAY_API_ID_GTS,
            maxNum: Constants.PlatformApiCommonArgs.SAME_NAME_MAX_CONNECTIONS,
        },
        free: {
            freeMsg: "HELLO",
        },
    });
}

/**
 * GUI-PF間接続初期化API成功時処理
 * 
 * @param {Object} data レスポンスデータ
 * @return {Object}
 */
function apiCreateChallengeCode(data) {
    // レスポンスの解析
    var appName = data.apiArgs.appName;
    var isFailed = true;

    // 処理成功の場合
    if (Constants.PlatformApiResult.SUCCESS === data.resultInfo.result) {
        // GTS+ or miniGTS+の場合
        if (Constants.ApplicationName.GTS_PLUS === appName || Constants.ApplicationName.MINI_GTS_PLUS === appName) {
            // 接続成功として設定
            LogManager.info("[API : " + Constants.PlatformApiId.SET_CONNECTION_CONDTION + "] -----> OK.");
            ScreenComponent.responseApi(data);
            isFailed = false;

            // システム名・最大接続数の保持
            WebSocketComponent.WebSocket.appName = appName;
            WebSocketComponent.WebSocket.maxNumberConnect = data.apiArgs.maxNumberConnect;

            //  チャレンジコード生成APIの実行
            return WebSocketComponent.executeApiAsync(WebSocketComponent.WebSocket, {
                common: {
                    apiId: Constants.PlatformApiId.CREATE_CHALLENGE_CODE,
                    ack: Constants.PlatformApiAckFlag.FALSE,
                },
                free: {
                    freeMsg: "CREATE_CHALLENGE_CODE",
                },
            });
        }
    }

    // APIの結果が失敗している場合
    if (isFailed) {
        throw new Error("[API : " + Constants.PlatformApiId.SET_CONNECTION_CONDTION + "] -----> NG.");
    }
}

/**
 * API認証用ハッシュコード生成
 * 
 * @param {Object} data レスポンスデータ
 */
function createHash(data) {
    // ハッシュコード生成
    const shaObj = new jsSHA('SHA-256', 'TEXT');
    shaObj.update(data.apiArgs.challengeCode);
    shaObj.update(Constants.SystemConstant.SALT);
    const code = shaObj.getHash('HEX');

    return code;
}

/**
 * API認証用ハッシュコードチェック
 * 
 * @param {Object} data レスポンスデータ
 */
function apiCheckApiAuthentication(hash) {
    // API認証用ハッシュコードチェックAPIの実行
    return WebSocketComponent.executeApiAsync(webSocket = WebSocketComponent.WebSocket, {
        common: {
            apiId: Constants.PlatformApiId.CHECK_API_AUTHENTICATION,
            ack: Constants.PlatformApiAckFlag.FALSE,
        },
        apiArgs: {
            authenticationCode: hash,
        },
        free: {
            freeMsg: "CHECK_API_AUTHENTICATION",
        },
    });
}

/**
 * 診断情報取得API
 * 
 */
function apiGetDiagnosticInformation() {
    // 診断情報取得APIの実行
    return WebSocketComponent.executeApiAsync(webSocket = WebSocketComponent.WebSocket, {
        common: {
            apiId: Constants.PlatformApiId.GET_DIAGNOSTIC_INFORMATION,
            ack: Constants.PlatformApiAckFlag.FALSE,
        },
        free: {
            freeMsg: "GET_DIAGNOSTIC_INFORMATION",
        },
    });
}


/**
 * 診断開始処理
 * 
 */
function startDiagnosis() {
    // 診断開始API
    apiStartDiagnosis().then(function (data) {
        LogManager.info("[API : " + Constants.PlatformApiId.START_DIAGNOSIS + "] -----> OK.");
        ScreenComponent.responseApi(data);
        // 接続情報取得API（ホロレンズ用）
        apiGetConnectionInfoHL().then(function (data) {
            // QR画像データ生成/表示処理
            viewQrCode(data);

        }).catch(function (e) {
            // API認証用ハッシュコードチェックAPI失敗の場合
            displayErrorScreen(e.message);
        });

    }).catch(function (e) {
        // 接続情報取得API（ホロレンズ用）失敗の場合
        displayErrorScreen(e.message);
    });
}

/**
 * 診断開始API
 * 
 */
function apiStartDiagnosis() {
    // 診断開始APIの実行
    return WebSocketComponent.executeApiAsync(webSocket = WebSocketComponent.WebSocket, {
        common: {
            apiId: Constants.PlatformApiId.START_DIAGNOSIS,
            ack: Constants.PlatformApiAckFlag.FALSE,
        },
        free: {
            freeMsg: "START_DIAGNOSIS",
        },
    });
}

/**
 * 接続情報取得API（ホロレンズ用）
 * 
 */
function apiGetConnectionInfoHL() {
    // 接続情報取得API（ホロレンズ用）の実行
    return WebSocketComponent.executeApiAsync(webSocket = WebSocketComponent.WebSocket, {
        common: {
            apiId: Constants.PlatformApiId.GET_CONNECTION_INFO_HL,
            ack: Constants.PlatformApiAckFlag.FALSE,
        },
        free: {
            freeMsg: "GET_CONNECTION_INFORMATION_HL",
        },
    });
}

/**
 * QR画像データ生成/表示処理
 * 
 * @param {Object} data レスポンスデータ
 * @return {Object}
 */
function viewQrCode(data) {
    // 結果の解析
    if (Constants.PlatformApiResult.SUCCESS === data.resultInfo.result) {
        // ローディング画像の非表示
        LogManager.info("[API : " + Constants.PlatformApiId.GET_CONNECTION_INFO_HL + "] -----> OK.");
        ScreenComponent.responseApi(data);
        ScreenComponent.removeLoading("loading");
        // 処理中画像の非表示
        ScreenComponent.removeLoading("processing");

        // QR画面へ遷移
        ScreenComponent.navigateAsync(Constants.ScreenId.QR_001).done(function () {
            // QR画像の生成
            $("#image_qr").qrcode({
                text: location.protocol + "//" + data.apiArgs.privateIPAddress + ":" + location.port + Constants.SystemConstant.SCREEN_HTML_PATH_PREFIX_FOR_QR + data.apiArgs.displayFileName,
                width: Constants.SystemConstant.QR_IMAGE_SIZE_WIDTH,
                height: Constants.SystemConstant.QR_IMAGE_SIZE_HEIGHT
            });
        });

    } else {
        throw new Error("[API : " + Constants.PlatformApiId.GET_CONNECTION_INFO_HL + "] -----> NG.");
    }
}


/**
 *  確認画面遷移処理
 *  
 * @param {Object} data レスポンスデータ
 */
function diagnosisConfirmDisplay(data) {
    // ローディング画像の非表示
    ScreenComponent.removeLoading("loading");

    // 画面表示項目_言語別設定
    var region = Constants.RegionCode.REGION_NAME[data.apiArgs.regionId];
    var language = Constants.LanguageId.LANGUAGE[data.apiArgs.languageId];
    var path = Constants.SystemConstant.DYNAMIC_LOADING_JS_PATH + "Lang/" + language + "/constants_lang.js";

    // 確認画面へ遷移
    ScreenComponent.navigateAsync(Constants.ScreenId.DIAG_CONFIRM_001).done(function () {
        // 言語別ファイルの読込
        $.getScript(path, function () {
            // Title
            $('#title').text(Constants_Launuege.Index.TITLE)
            // 言語IDの設定
            $('#table_info tr').eq(0).children('th').eq(0).text(Constants_Launuege.Index.LANGUAGE_ID);
            $('#table_info tr').eq(0).children('td').eq(0).text(language);
            // 仕向IDの設定
            $('#table_info tr').eq(1).children('th').eq(0).text(Constants_Launuege.Index.REGION_ID);
            $('#table_info tr').eq(1).children('td').eq(0).text(region);
            // 継続ボタン
            $('#button_continue').text(Constants_Launuege.Index.CONTINUE)
            // 強制継続ボタン
            $('#button_forced_continuation').text(Constants_Launuege.Index.FORCED_CONTINUATION)
        });
    });
}


/**
 * エラー発生時処理
 * 
 * @param {Object} event イベント
 */
function onError(event) {
    //displayErrorScreen(event.message);
}

/**
 * エラー画面表示処理
 * 
 * @param {String} message エラーメッセージ
 */
function displayErrorScreen(message) {
    // エラー画面表示
    LogManager.error(message);
    ScreenComponent.navigateAsync(Constants.ScreenId.ERR_001).done(function () {
        $("#error_message").text(message);
        // ローディング画像の非表示
        ScreenComponent.removeLoading("loading");
        // 処理中画像の非表示
        ScreenComponent.removeLoading("processing");
    });
}


/**
 * 継続ボタン押下処理
 * 
 */
$(document).on('click', '#button_continue', function () {
    // 処理中画像の表示
    ScreenComponent.displayLoading("processing", "Processing...");
    ScreenComponent.clearApi();
    // 診断開始処理
    startDiagnosis();
});

/**
 * 強制継続ボタン押下処理
 * 
 */
$(document).on('click', '#button_forced_continuation', function () {
    // 処理中画像の表示
    ScreenComponent.displayLoading("processing", "Processing...");
    ScreenComponent.clearApi();
    // 強制診断終了API
    apiForcedEndDiagnosis().then(function (data) {
        LogManager.info("[API : " + Constants.PlatformApiId.FORCED_END_DIAGNOSISON + "] -----> OK.");
        ScreenComponent.responseApi(data);
        // 診断開始処理
        startDiagnosis();
    }).catch(function (e) {
        // 接続情報取得API（ホロレンズ用）失敗の場合
        displayErrorScreen(e.message);
    });
});

/**
 * 強制診断終了API
 * 
 */
function apiForcedEndDiagnosis() {
    // 診断開始APIの実行
    return WebSocketComponent.executeApiAsync(webSocket = WebSocketComponent.WebSocket, {
        common: {
            apiId: Constants.PlatformApiId.FORCED_END_DIAGNOSISON,
            ack: Constants.PlatformApiAckFlag.FALSE,
        },
        free: {
            freeMsg: "FORCED_END_DIAGNOSISON",
        },
    });
}


/**
 * 終了ボタン押下処理
 * 
 */
$(document).on('click', '#button_page_end', function () {
    // セキュリティの関係でclose出来ないようになっている
    //window.open('about:blank', '_self').close();
    ScreenComponent.clearApi();
    apiEndDiagnosis();
    //location.reload();
});

/**
 * 診断終了API
 * 
 */
function apiEndDiagnosis() {
    // 診断終了APIの実行
    return WebSocketComponent.executeApiAsync(webSocket = WebSocketComponent.WebSocket, {
        common: {
            apiId: Constants.PlatformApiId.END_DIAGNOSIS,
            ack: Constants.PlatformApiAckFlag.FALSE,
        },
        free: {
            freeMsg: "END_DIAGNOSIS",
        },
    });
}
