/**
 * 共通Script - log_manager
 */

/**
 * LogManager
 */
if (LogManager === undefined) {
    var LogManager = function () { };
}

/**
 * LogManager - LogLevel
 */
LogManager.LogLevel = {
    ERROR: 0,
    WARN: 1,
    LOG: 2,
    INFO: 3,
    DEBUG: 4
};

/**
 * LogManager - ルートログレベル
 */
LogManager.RootlLogLevel = LogManager.LogLevel.INFO;

/**
 * LogManager - Debugログ出力処理
 * 
 * @param {String} message
 */
LogManager.debug = function (message) {
    (this.RootlLogLevel >= this.LogLevel.DEBUG) && console.debug(LogManager.createLogMessage(message));
};

/**
 * LogManager - Infoログ出力処理
 * 
 * @param {String} message
 */
LogManager.info = function (message) {
    (this.RootlLogLevel >= this.LogLevel.INFO) && console.info(LogManager.createLogMessage(message));
};

/**
 * LogManager - Logログ出力処理
 * 
 * @param {String} message
 */
LogManager.log = function (message) {
    (this.RootlLogLevel >= this.LogLevel.LOG) && console.log(LogManager.createLogMessage(message));
};

/**
 * LogManager - Warnログ出力処理
 * 
 * @param {String} message
 */
LogManager.warn = function (message) {
    (this.RootlLogLevel >= this.LogLevel.WARN) && console.warn(LogManager.createLogMessage(message));
};

/**
 * LogManager - Errorログ出力処理
 * 
 * @param {String} message
 */
LogManager.error = function (message) {
    (this.RootlLogLevel >= this.LogLevel.ERROR) && console.error(LogManager.createLogMessage(message));
};

/**
 * LogManager - ログメッセージ生成処理
 * 
 * @param {String} message
 * @returns {String}
 */
LogManager.createLogMessage = function (message) {
    var date = new Date();
    var year = date.getFullYear();
    var month = ("0" + (date.getMonth() + 1)).slice(-2);
    var day = ("0" + date.getDate()).slice(-2);
    var hour = ("0" + date.getHours()).slice(-2);
    var minute = ("0" + date.getMinutes()).slice(-2);
    var second = ("0" + date.getSeconds()).slice(-2);
    var milliSecond = NumberComponent.toDoubleDigits(date.getMilliseconds());
    return "[" + year + "/" + month + "/" + day + " " + hour + ":" + minute + ":" + second + "." + milliSecond + "] " + String(message);
}