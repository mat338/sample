/**
 * 共通Script - constants
 */

/**
 * Constants
 */
if (Constants === undefined) {
    var Constants = function () { };
}

/**
 * Constants - Debugモード
 */
Constants.Debug = Object.freeze({
    // Debug Mode（1：デバックモード、１以外：デバックモード無）
    DEBUG_MODE: 1
});

/**
 * Constants - WebSocket設定
 */
Constants.WebSocketSetting = Object.freeze({
    // 接続開始ポートNo.
    PORT_NO_LIST: [50010, 50011, 50012],

    // 接続試行タイムアウト(秒)
    CONNECTION_PROCESS_TIMEOUT_SECONDS: 5,

    // 接続試行インターバル(ミリ秒)
    CONNECTION_PROCESS_INTERVAL_MILLISECONDS: 1000,

    // 接続基本URI
    BASE_URI: "ws://" + location.hostname + ":",

    // 受信試行タイムアウト(秒)
    RECEIVING_PROCESS_TIMEOUT_SECONDS: 30,

    // 受信試行インターバル(ミリ秒)
    RECEIVING_PROCESS_INTERVAL_MILLISECONDS: 100,
});

/**
 * Constants - PF_API_ID
 */
Constants.PlatformApiId = Object.freeze({
    // GUI-PF間接続初期化
    SET_CONNECTION_CONDTION: "CN000001",

    // チャレンジコード生成
    CREATE_CHALLENGE_CODE: "CN000002",

    // API認証用ハッシュコードチェック
    CHECK_API_AUTHENTICATION: "CN000003",

    // 車両選択
    SELECT_VEHICLE: "DV000001",

    // 車両カテゴリ情報取得
    SELECT_VEHICLE_CATEGORY: "DV000002",

    // 車両ID確定
    SET_VEHICLE_ID: "DV000003",

    // 車両カテゴリ情報取得
    GET_MOUNT_ECU_LIST: "DV000004",

    // ECU接続確認
    CHECK_ECU_CONNECT: "DV000005",

    // ECU機能リスト取得
    GET_ECU_FUNC_LIST: "DV000006",

    // DTC取得
    GET_DTC: "DV000008",

    // 車両例外対応
    REPLACE_VEHICLE_EXCEPTION: "DV000066",

    // システム例外対応
    REPLACE_SYSTEM_EXCEPTION: "DV000067",

    // DK-ISO9141通信初期化
    //INITIALIZE_DK_ISO9141: "DV000077",

    // リモートダイアグDTC送信マスク設定
    SET_REMOTE_DIAG_SEND_MASK: "DV000078",

    // 車両キャッシュ取得
    GET_VEHICLE_CACHE: "DV000089",

    // 車両確定情報取得 
    GET_VEHICLE_CONFIRMATION: "IF000004",

    // 接続情報取得
    GET_CONNECTION_INFO_HL: "IF100001",

    // 診断開始
    START_DIAGNOSIS: "SC000001",

    // 診断終了
    END_DIAGNOSIS: "SC000002",

    // 車両確定通知
    NOTIFY_VEHICLE_CONFIRMATION: "SC000003",

    // 診断情報取得
    GET_DIAGNOSTIC_INFORMATION: "SC000006",

    // 強制診断終了
    FORCED_END_DIAGNOSISON: "SC000007"
});


/**
 * Constants - PF_API要求メッセージ受領応答フラグ
 */
Constants.PlatformApiAckFlag = Object.freeze({
    // False
    FALSE: 0
});

/**
 * Constants - アプリケーション名
 */
Constants.ApplicationName = Object.freeze({
    // GTS+
    GTS_PLUS: "GTS+",

    // miniGTS+
    MINI_GTS_PLUS: "miniGTS+"
});

/**
 * Constants - PF_API処理結果
 */
Constants.PlatformApiResult = Object.freeze({
    // 成功
    SUCCESS: 0
});

/**
 * Constants - 診断開始状態結果
 */
Constants.GetDiagnosticInformationResult = Object.freeze({
    // 診断開始未実施
    NOT_EXECUTED: 0,

    // 診断開始中
    EXECUTED: 1
});

/**
 * Constants - PF_API共通引数
 */
Constants.PlatformApiCommonArgs = Object.freeze({
    // スクリーンリレーAPI_ID: GTS
    SCREEN_RELAY_API_ID_GTS: "GTS",

    // 同名の最大接続数
    SAME_NAME_MAX_CONNECTIONS: 3
});

/**
 * Constants - 画面ID
 */
Constants.ScreenId = Object.freeze({
    // err_001
    ERR_001: "err_001",

    // qr_001
    QR_001: "qr_001",

    // diag_confirm_001
    DIAG_CONFIRM_001: "diag_confirm_001",

    // diag_confirm_002
    DIAG_CONFIRM_002: "diag_confirm_002",

    // vhcn_001
    VHCN_001: "vhcn_001",

    // diag_001
    DIAG_001: "diag_001",

    // all_diag_001
    ALL_DIAG_001: "all_diag_001",

    // all_diag_002
    ALL_DIAG_002: "all_diag_002",

    // diag_002
    DIAG_002: "diag_002"
});

/**
 * Constants - 確認画面項目ID(カテゴリーは車種カテゴリ情報取得用カテゴリID)
 */
Constants.VhcnItemId = Object.freeze({
    // IT3_DIVISION
    DIVIDION: 1,
    // IT3_Model
    MODEL: 2,
    // IT3_model code(car type)
    MODEL_CODE: 3,
    // IT3_EngineModel
    ENGINE_MODEL: 4,
    // Option1
    OPTION1: 1,
    // Option2
    OPTION2: 2,
    // Option3
    OPTION3: 3
});

/**
 * Constants - システム定数
 */
Constants.SystemConstant = Object.freeze({
    // QR画像用の画面HTMLのパス(接頭語)
    SCREEN_HTML_PATH_PREFIX_FOR_QR: "/Presentation/Html/",

    // 画面テンプレートのパス(接頭語)
    SCREEN_TEMPLATE_PATH_PREFIX: "../Template/",

    // 画面テンプレートのパス(接尾語)
    SCREEN_TEMPLATE_PATH_SUFFIX: ".template",

    // 画面CSSのパス(接頭語)
    SCREEN_CSS_PATH_PREFIX: "../Css/",

    // 画面CSSのパス(接尾語)
    SCREEN_CSS_PATH_SUFFIX: ".css",

    // 動的読込（多言語/仕向）用ファイルパス
    DYNAMIC_LOADING_JS_PATH: "/Presentation/Js/Common/Constant/",

    // ミリ秒 ⇒ 秒変換用
    TO_SECONDS: 1000,

    // QR画像サイズ(幅)
    QR_IMAGE_SIZE_WIDTH: 500,

    // QR画像サイズ(高さ)
    QR_IMAGE_SIZE_HEIGHT: 500,

    // Salt
    SALT: "r8YDeLcSwtwTRpZLFpJY"
});

/**
 * Constants - 仕向定数
 */
Constants.RegionCode = Object.freeze({
    // 北米
    REGION_CODE_NORTH_AMERICA: 1,
    // 欧州
    REGION_CODE_EUROPE: 2,
    // 日本
    REGION_CODE_JAPAN: 3,
    // 一般地
    REGION_CODE_OTHER: 4,

    // 仕向一覧
    REGION_NAME: {
        1: "NA",
        2: "EU",
        3: "JP",
        4: "OT"
    }
});

/**
 * Constants - 言語定数
 */
Constants.LanguageId = Object.freeze({
    // 英語 English
    ENGLISH: 1,
    // ドイツ語 German
    GERMAN: 2,
    // フランス語 French
    FRENCH: 3,
    // スペイン語 Spanish
    SPANISH: 4,
    // イタリア語 Italian
    ITALIAN: 5,
    // 中国語 Chinese
    CHINESE: 6,
    // 日本語 Japanese
    JAPANESE: 7,
    // スウェーデン語 Swedish
    SWEDISH: 8,
    // ポルトガル語 Portuguese
    PORTUGUESE: 10,
    // ポーランド語 Polish
    POLISH: 11,
    // ノルウェー語 Norwegian
    NORWEGIAN: 12,
    // ハンガリー語 Hungarian
    HUNGARIAN: 13,
    // ギリシャ語 Greek
    GREEK: 14,
    // ロシア語 Russian
    RUSSIAN: 16,
    // トルコ語 Turkish
    TURKISH: 17,
    // チェコ語 Czech
    CZECH: 18,
    // オランダ語 Dutch
    DUTCH: 19,
    // フィンランド語 Finnish
    FINNISH: 20,
    // デンマーク語 Danish
    DANISH: 21,

    // 言語一覧
    LANGUAGE: {
        1: "EN",
        2: "DE",
        3: "FR",
        4: "ES",
        5: "IT",
        6: "ZH",
        7: "JA",
        8: "SV",
        10: "PT",
        11: "PL",
        12: "NO",
        13: "HU",
        14: "EL",
        16: "RU",
        17: "TR",
        18: "CS",
        19: "NL",
        20: "FI",
        21: "DA"
    }
});

/**
 * Constants - 車両IDの範囲
 */
Constants.VehicleIdRangeConstant = Object.freeze({
    // 最小
    VEHICLE_ID_MIN: 1,
    // 最大
    VEHICLE_ID_MAX: 65534,
    // 未確定
    VEHICLE_ID_UNDIAGNOSED: 0,
    // 不具合車両
    VEHICLE_ID_BAT: 65535
});

/**
 * Constants - 車両情報項目ID定数
 */
Constants.VehicleInformationItemID = Object.freeze({
    // 車型
    VEHICLE_INFOMATION_ITEM_ID_VEHICLE_TYPE: 1,
    // エンジン形式
    VEHICLE_INFOMATION_ITEM_ID_ENGINE_TYPE: 2,
    // モデルイヤー
    VEHICLE_INFOMATION_ITEM_ID_MODEL_YEAR: 3,
    // 車両名称
    VEHICLE_INFOMATION_ITEM_ID_VEHICLE_NAME: 4,
    // シリンダ数
    VEHICLE_INFOMATION_ITEM_ID_NUMBER_OF_CYLINDERS: 16,
    // トランスミッション
    VEHICLE_INFOMATION_ITEM_ID_TRANSMISSION: 17,
    // ブランド名称
    VEHICLE_INFOMATION_ITEM_ID_BRAND_NAME: 18
});

/**
 * Constants - カテゴリID定数
 */
Constants.CategoryID = Object.freeze({
    // IT3_DIVISION
    CATEGORY_ID_DIVIDION: 11,
    // IT3_Model
    CATEGORY_ID_MODEL: 12,
    // IT3_ModelYear
    CATEGORY_ID_MODEL_YEAR: 13,
    // IT3_EngineModel
    CATEGORY_ID_ENGINE_MODEL: 14,
    // IT2_USERSELECT1
    CATEGORY_ID_USER_SELECT1: 5,
    // IT2_USERSELECT2
    CATEGORY_ID_USER_SELECT2: 6,
    // IT3_model code(car type)
    CATEGORY_ID_MODEL_CODE: 15
});

/**
 * Constants - 車種カテゴリ情報取得用状態ID定数
 */
Constants.StatusId = Object.freeze({
    // 未確定
    UNCONFIRMED: 0,
    // 確定
    CONFIRMED: 1,
    // 不具合車両
    TROUBLE_VEHICLE: 2
});

/**
 * Constants - オプション情報インデックス定数
 */
Constants.indexId = Object.freeze({
    // 確定
    CONFIRMED: 0
});

/**
 * Constants - ECUグループ定数
 */
Constants.ecuGroup = Object.freeze({
    // Power Train
    POWER_TRAIN: 1,
    // Chassis
    CHASSIS: 2,
    // Body
    BODY: 0
});

/**
 * Constants - ECU機能ID定数
 */
Constants.ecuFunctionId = Object.freeze({
    // ダイアグ・フリーズ
    DTC_FFD: 1,
    // データモニター
    DATA_LIST: 2,
    // アクティブテスト
    ACTIVE_TEST: 3,
    // モード移行（ノーマル/チェック）
    MODE_TRANSITION: 4,
    // 基本点検
    BASIC_CHECK: 5,
    // ダイアグ判定完了確認
    DTC_JUDGMENT_CONFIRMATION: 6,
    // 作動時のフリーズデータ
    FFD_DURING_OPERATION: 7,
    // テストモード点検
    TEST_MODE_CHECK: 8,
    // 特殊操作/制御履歴
    SPECIAL_OPERATION_CONTROL_HISTORY: 9,
    // マルチデータモニター
    MULTI_DATALIST: 10,
    // スリープNG情報
    SLEEP_NG_INFORMATION: 11,
    // 作動要因履歴
    OPERATION_HISTORY: 12,
    // 通信要因履歴
    COMMUNICATION_HISTORY: 13,
    // ワイヤレスダイアグモード
    WIRELESS_DIAGNOSTIC_MODE: 14,
    // 電子キーダイアグモード
    ELECTRONIC_KEY_DIAGNOSTIC_MODE: 15,
    // ダイアグ確認
    CHECK_DTC: 16,
    // Monitor通信
    MONITOR_COMMUNICATION: 17,
    // リプログ機能
    REPROGRAMMING_FUNCTION: 18,
    // MIL確認
    CHECK_MIL: 19,
    // カスタマイズ
    CUSTOMIZE: 20,
    // 作動要因分析
    OPERATION_HISTORY_ANALYSIS: 21,
    // DCM 作動要因分析
    DCM_OPERATION_HISTORY_ANALYSIS: 22,
    // 行動記録
    RECORD_ON_BEHAVIOR: 23,
    // データリスト絞込み
    FILTER_DATALIST_ITEMS: 24,
    // カスタムリストヘルプ
    CUSTOMLIST_HELP: 25,
    // 機能別表示カスタムリスト
    DISPLAY_CUSTOM_LIST_BY_FUNCTION: 26,
    // アクティブテストデフォルトリスト設定
    ACTIVE_TEST_DEFAULT_LIST_SETTING: 27,
    // フリーズフレームデータ絞込み
    FILETER_FFD_ITEMS: 28,
    // CID取得
    GET_CID: 29,
    // ダイアグ・フリーズP5
    DTC_FFD_P5: 30,
    // 例外処理ID適用
    EXCEPTIONAL_HANDLING_ID_APPLIED: 31,
    // 法規確認
    CHECK_REGULATORY_COMMUNICATION: 32,
    // PCS作動時フリーズフレームデータ
    FFD_DURING_PCS_OPERATION: 33,
    // PCS画像フリーズフレームデータ
    IMAGE_FFD_DURING_PCS_OPERATION: 34,
    // PCS DDRデータ
    PCS_DDR_DATA: 35,
    // セントラルゲートウェイ対応CANバス診断
    CAN_BUS_DIAGNOSIS_FOR_CENTRAL_GATEWAY_ECU: 36,
    // 市場モニターRAM
    MARKET_MONITOR_RAM: 37,
    // LCS作動時フリーズフレームデータ
    FFD_DURING_LCS_OPERATION: 38
});

/**
 * Constants - ECU機能詳細ID定数
 */
Constants.ecuFunctionDetailId = Object.freeze({
    // 現在ダイアグ
    CURRENT_DTC: 1,
    // 過去ダイアグ
    PAST_DTC: 2,
    // ペンディング
    PENDING: 3,
    // フリーズ
    FFD: 4,
    // 時系列フリーズ
    TIME_SERIES_FFD: 6,
    // タイムスタンプ
    TIMESTAMP: 42,
    // パーマネント
    PERMANENT: 43,
    // ペンディングフリーズ
    PENDING_FFD: 57,
    // 予兆
    PREDICTIVE: 71,
    
    // ダイアグ・フリーズ/ダイアグ確認 対象機能ID
    TARGET_DTC_FFD_CHECK_DTC: {
        1: true,
        2: true,
        3: true,
        4: true,
        6: true,
        42: true,
        43: true,
        57: true,
        71: false
    },

    // ダイアグ・フリーズP5 対象機能ID
    TARGET_DTC_FFD_P5: {
        1: true,
        2: true,
        3: true,
        4: true,
        6: false,
        42: true,
        43: false,
        57: false,
        71: false
    },

    // 法規確認 対象機能ID
    TARGET_CHECK_REGULATORY_COMMUNICATION: {
        1: true,
        2: false,
        3: true,
        4: true,
        6: false,
        42: false,
        43: true,
        57: false,
        71: false
    }
});

/**
 * Constants - Generic/Enhanced識別用定数
 */
Constants.kindFlag = Object.freeze({
    // Enhanced
    ENHANCED: 0,
    // Generic
    GENERIC: 1
});

/**
 * Constants - ダイアグコード種別定数
 */
Constants.kind = Object.freeze({
    // ダイアグなし
    NO_DTC: 0,
    // 現在ダイアグ、TestFail(最新)
    CURRENT_TEST_FAIL: 1,
    // 過去ダイアグ、Confirmed(確定)
    PAST_CONFIRMED: 2,
    // レディネスダイアグ
    READINESS: 3,
    // ペンディング
    PENDING: 4,
    // パーマネント
    PARMANENT: 5,
    // 予兆
    PREDICTIVE: 6
});

/**
 * Constants - phase5識別用定数
 */
Constants.phaseType = Object.freeze({
    // phase5
    PHASE5: 20
});

/**
 * Constants - FFD対象識別用定数
 */
Constants.ffdType = Object.freeze({
    // FFDなし
    NO_FFD: 0
});
