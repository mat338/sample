/**
 * 共通Script - constants
 */

/**
 * Constants_Launuege
 */
if (Constants_Launuege === undefined) {
    var Constants_Launuege = function () { };
}

/**
 * Constants_Launuege - Index
 */
Constants_Launuege.Index = Object.freeze({
    // Title
    TITLE: 'Under diagnosis',
    // LANGUAGE_ID
    LANGUAGE_ID: 'LANGUAGE ID',
    // REGION_ID
    REGION_ID: 'REGION ID',
    // CONTINUE
    CONTINUE: 'Continue',
    // FORCED_CONTINUATION
    FORCED_CONTINUATION: 'Forced continuation'
});

/**
 * Constants_Launuege - Vhcn001
 */
Constants_Launuege.Vhcn001 = Object.freeze({
    // IT3_DIVISION
    CATEGORY_DIVISION: 'Division : ',
    // IT3_Model
    CATEGORY_MODEL: 'Model : ',
    // IT3_model code(car type)
    CATEGORY_MODEL_CODE: 'ModelYear : ',
    // IT3_EngineModel
    CATEGORY_ENGINE_MODEL: 'Engine : ',
    // OPTION
    OPTION: 'Option : '
});

/**
 * Constants_Launuege - Confirmation
 */
Constants_Launuege.Confirmation = Object.freeze({
    // 確認ダイアログ
    CONFIRMATION_MSG: "The result of communicating with the vehicle remains. Is the connected vehicle this vehicle?",
    // 車両ID
    VEHICLE_ID: "Vehicle ID",
    // VIN
    VIN: "VIN"
});
