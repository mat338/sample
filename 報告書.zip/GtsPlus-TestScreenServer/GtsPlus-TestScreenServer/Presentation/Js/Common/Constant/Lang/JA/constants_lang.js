/**
 * 共通Script - constants
 */

/**
 * Constants_Launuege
 */
if (Constants_Launuege === undefined) {
    var Constants_Launuege = function () { };
}

/**
 * Constants_Launuege - Index
 */
Constants_Launuege.Index = Object.freeze({
    // Title
    TITLE: '診断開始中',
    // LANGUAGE_ID
    LANGUAGE_ID: '言語ID',
    // REGION_ID
    REGION_ID: '仕向ID',
    // CONTINUE
    CONTINUE: '継続',
    // FORCED_CONTINUATION
    FORCED_CONTINUATION: '強制継続'
});

/**
 * Constants_Launuege - Vhcn001
 */
Constants_Launuege.Vhcn001 = Object.freeze({
    // IT3_DIVISION
    CATEGORY_DIVISION: 'ブランド : ',
    // IT3_Model
    CATEGORY_MODEL: '車両 : ',
    // IT3_model code(car type)
    CATEGORY_MODEL_CODE: '車型 : ',
    // IT3_EngineModel
    CATEGORY_ENGINE_MODEL: 'エンジン形式 : ',
    // OPTION
    OPTION: 'オプション : '
});

/**
 * Constants_Launuege - Confirmation
 */
Constants_Launuege.Confirmation = Object.freeze({
    // 確認ダイアログ
    CONFIRMATION_MSG: "車両と通信した結果が残っています。接続している車両はこの車両ですか？",
    // 車両ID
    VEHICLE_ID: "車両ID",
    // VIN
    VIN: "VIN"
});
