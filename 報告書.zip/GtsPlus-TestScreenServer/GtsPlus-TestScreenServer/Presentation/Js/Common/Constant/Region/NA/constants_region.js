/**
 * 共通Script - constants
 */

/**
 * Constants_Region
 */
if (Constants_Region === undefined) {
    var Constants_Region = function () { };
}

/**
 * Constants_Region - カテゴリID/車両情報項目IDのリスト定数
 */
Constants_Region.IdList = Object.freeze({
    // 北米-車両選択
    ID_LIST: [11, 12, 13, 14, 1, 2, 16, 17],
    // 北米-車両選択-再
    ID_LIST_RE_SELECT: [11, 12, 13, 14],
    // 北米-車両ID確定
    ID_LIST_ID_CONFIRM: [1, 2, 16, 17],
});
