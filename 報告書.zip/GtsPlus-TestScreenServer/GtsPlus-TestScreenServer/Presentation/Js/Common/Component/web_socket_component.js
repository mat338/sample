/**
 * 共通Script - web_socket_component
 */

/**
 * Component - WebSocketComponent
 */
if (WebSocketComponent === undefined) {
    var WebSocketComponent = function () { };
}

/**
 * WebSocketComponent - WebSocket接続
 */
WebSocketComponent.WebSocket = null;

/**
 * WebSocketComponent - 接続情報リスト
 */
WebSocketComponent.ConnectionInfoList = [];

/**
 * WebSocketComponent - APIレスポンス
 */
WebSocketComponent.Response = null;

/**
 * WebSocketComponent - 接続開始時処理
 * 
 * @param {Object} event イベント
 */
WebSocketComponent.onOpen = function (event) {
    LogManager.info("Connection opened. : " + event.currentTarget.url);
    var webSocket = WebSocketComponent.ConnectionInfoList.filter(function (connectionInfo) {
        return connectionInfo.webSocket === event.currentTarget;
    })[0];
    webSocket.checkResult = true;
}

/**
 * WebSocketComponent - メッセージ受信時処理
 * 
 * @param {Object} event イベント
 */
WebSocketComponent.onMessage = function (event) {
    LogManager.info("Message arrived. Details : " + event.data);
    WebSocketComponent.Response = event.data;
}

/**
 * WebSocketComponent - 接続終了時処理
 */
WebSocketComponent.onClose = function () {
    LogManager.info("Connection closed.");
}

/**
 * WebSocketComponent - エラー発生時処理
 * 
 * @param {Object} event イベント
 */
WebSocketComponent.onError = function (event) {
    LogManager.error(event.message);
    ScreenComponent.responseApi(event.message);
}

/**
 * WebSocketComponent - [非同期]サーバ接続処理
 * 
 * @param {Function} onOpen 接続開始時処理
 * @param {Function} onMessage メッセージ受信時処理
 * @param {Function} onClose 接続終了時処理
 * @param {Function} onError エラー発生時処理
 * @return {Object}
 */
WebSocketComponent.connectServerAsync = function (onOpen, onMessage, onClose, onError) {
    // 接続情報リストのリセット
    this.ConnectionInfoList = []

    // 非同期接続試行
    LogManager.info("Start the connection process.");
    Constants.WebSocketSetting.PORT_NO_LIST.forEach(function (portNo) {
        setTimeout(WebSocketComponent.connectServerCore(portNo, onOpen, onMessage), 0);
    });

    // 接続試行完了待ち
    return new Promise(function (resolve, reject) {
        // 開始日時の取得
        var startTime = new Date().getTime();

        // 非同期処理
        var id = setInterval(function () {
            // 接続を確立したコネクションの存在確認
            var resultList = WebSocketComponent.ConnectionInfoList.filter(function (connection) {
                return connection.webSocket.readyState === WebSocket.OPEN && connection.checkResult;
            });
            if (resultList.length > 0) {
                // 接続成功のコネクションが存在する場合
                LogManager.info("Successful connection to GTS+. : " + resultList[0].webSocket.url);
                ScreenComponent.responseApi("Successful connection to GTS+. : " + resultList[0].webSocket.url);
                WebSocketComponent.WebSocket = resultList[0].webSocket;

                // コールバックの設定
                WebSocketComponent.WebSocket.onclose = WebSocketComponent.onClose;
                WebSocketComponent.WebSocket.onerror = WebSocketComponent.onError;
                if (onClose !== null) {
                    WebSocketComponent.WebSocket.onclose = onClose;
                }
                if (onError !== null) {
                    WebSocketComponent.WebSocket.onerror = onError;
                }

                // 終了
                clearInterval(id);
                resolve();

            } else {
                // 接続成功のコネクションが存在しない場合
                var endTime = new Date().getTime();

                // 終了判定
                if ((endTime - startTime) / Constants.SystemConstant.TO_SECONDS >= Constants.WebSocketSetting.CONNECTION_PROCESS_TIMEOUT_SECONDS) {
                    // 終了
                    clearInterval(id);
                    reject(new Error("Connection to GTS+ failed."));
                }
            }
        }, Constants.WebSocketSetting.CONNECTION_PROCESS_INTERVAL_MILLISECONDS);
    });
}

/**
 * WebSocketComponent - サーバ接続コア処理
 *
 * @param {Number} portNo ポートNo.
 * @param {Function} onOpen 接続開始時処理
 * @param {Function} onMessage メッセージ受信時処理
 */
WebSocketComponent.connectServerCore = function (portNo, onOpen, onMessage) {
    try {
        // 接続
        var uri = Constants.WebSocketSetting.BASE_URI + String(portNo);
        LogManager.info("Trying connect... : " + uri);
        var webSocket = new WebSocket(uri);

        // コールバックの設定
        webSocket.onopen = WebSocketComponent.onOpen;
        webSocket.onmessage = WebSocketComponent.onMessage;
        if (onOpen !== null) {
            webSocket.onopen = onOpen;
        }
        if (onMessage !== null) {
            webSocket.onmessage = onMessage;
        }

        // 接続情報リストに追加
        this.ConnectionInfoList.push(WebSocketComponent.createConnectionInfo(webSocket));

    } catch (e) {
        LogManager.error(e.message);
    }
}

/**
 * WebSocketComponent - 接続情報生成処理
 * 
 * @param {Object} webSocket WebSocket接続
 * @returns {Object}
 */
WebSocketComponent.createConnectionInfo = function (webSocket) {
    var connectionInfo = new Object();
    connectionInfo.webSocket = webSocket;
    connectionInfo.checkResult = false;
    return connectionInfo;
}

/**
 * WebSocketComponent - [非同期]接続プロセス終了処理
 * 
 * @return {Object}
 */
WebSocketComponent.terminateConnectProcessAsync = function () {
    return new Promise(function (resolve) {
        // 接続に失敗したコネクションのクローズ
        WebSocketComponent.ConnectionInfoList.filter(function (connection) {
            return connection.webSocket.readyState === WebSocket.OPEN && !connection.checkResult;
        }).map(function (target) {
            LogManager.info("Close invalid connection. : " + target.webSocket.url);
            target.webSocket.close();
        });

        // 終了
        resolve();
    });
}

/**
 * WebSocketComponent - [非同期]API実行処理
 * 
 * @param {Object} webSocket WebSocket接続
 * @param {Object} data APIリクエストデータ
 * @return {Object}
 */
WebSocketComponent.executeApiAsync = function (webSocket, data) {
    // レスポンスの初期化
    this.Response = null;

    // APIの実行
    var jData = JSON.stringify(data);
    webSocket.send(JSON.stringify(data));
    LogManager.info("executeApiAsync JSON:" + jData);

    // API実行結果の取得
    return new Promise(function (resolve, reject) {
        // 開始日時の取得
        var startTime = new Date().getTime();

        // 非同期処理
        var id = setInterval(function () {
            if (WebSocketComponent.Response !== null) {

                // 終了
                clearInterval(id);
                resolve(JSON.parse(WebSocketComponent.Response));

            } else {
                // 終了判定
                var endTime = new Date().getTime();
                if ((endTime - startTime) / Constants.SystemConstant.TO_SECONDS >= Constants.WebSocketSetting.RECEIVING_PROCESS_TIMEOUT_SECONDS) {
                    // 終了
                    clearInterval(id);
                    reject(new Error("No response from server."));
                }
            }
        }, Constants.WebSocketSetting.RECEIVING_PROCESS_INTERVAL_MILLISECONDS);
    });
}

/**
 * WebSocketComponent - メッセージ受信時処理-書き換え
 * 
 * @param {Function} onMessage メッセージ受信時処理
 * @param {Function} onError エラー発生時処理
 */
WebSocketComponent.recMessage = function (onMessage, onError) {
    // コールバックの設定
    WebSocketComponent.WebSocket.onmessage = WebSocketComponent.onMessage;
    WebSocketComponent.WebSocket.onerror = WebSocketComponent.onError;
    if (onMessage !== null) {
        WebSocketComponent.WebSocket.onmessage = onMessage;
    }
    if (onError !== null) {
        WebSocketComponent.WebSocket.onerror = onError;
    }
}

/**
 * WebSocketComponent - メッセージ受信時処理-リストア
 */
WebSocketComponent.restoreMessage = function () {
    // コールバックの設定
    WebSocketComponent.WebSocket.onmessage = WebSocketComponent.onMessage;
    WebSocketComponent.WebSocket.onerror = WebSocketComponent.onError;
}
