/**
 * 共通Script - screen_component
 */

/**
 * Component - ScreenComponent
 */
if (ScreenComponent === undefined) {
    var ScreenComponent = function () { };
}

/**
 * ScreenComponent - 処理中画像表示処理
 * 
 * @param {String} kind 表示種類名
 * @param {String} message メッセージ
 */
ScreenComponent.displayLoading = function (kind, message) {
    if (message == undefined) {
        message = "";
    }
    var displayMessage = "<div class='" + kind +  "Message'>" + message + "</div>";
    if ($("#" + kind).length == 0) {
        $("body").append("<div id='" + kind +  "'>" + displayMessage + "</div>");
    }
}

/**
 * ScreenComponent - 処理中画像非表示処理
 *
 * @param {String} kind 表示種類名
 * @param {String} message メッセージ
 */
ScreenComponent.removeLoading = function (kind) {
    $("#" + kind).remove();
}

/**
 * ScreenComponent - Debug時APIレスポンス結果格納処理
 *
 * @param {String} data API戻り値（Json）
 */
ScreenComponent.responseApi = function (data) {
    if (Constants.Debug.DEBUG_MODE === 1) {
        var jData = JSON.stringify(data);
        var getData = String($("#retAPI").val());

        $("#retAPI").val(getData + "\n" + jData);
    }
}

/**
 * ScreenComponent - Debug時APIレスポンス結果クリア処理
 *
 */
ScreenComponent.clearApi = function () {
    if (Constants.Debug.DEBUG_MODE === 1) {
        $("#retAPI").val("");
    }
}

/**
 * ScreenComponent - [非同期]画面遷移処理
 * 
 * @param {String} screenId 画面ID
 * @return {Object}
 */
ScreenComponent.navigateAsync = function (screenId) {
    // 完了通知用オブジェクトの生成
    var deferred = new $.Deferred();

    // 表示領域を一時的に隠す
    $("#main").hide();

    // CSSの読み込み
    var css = $("<link rel=\"stylesheet\" type=\"text/css\">").attr("href",
        Constants.SystemConstant.SCREEN_CSS_PATH_PREFIX + screenId + Constants.SystemConstant.SCREEN_CSS_PATH_SUFFIX);
    $("head link:last").after(css);

    // 画面テンプレートの取得
    LogManager.info("Start ajax.");
    $.ajax({
        url: Constants.SystemConstant.SCREEN_TEMPLATE_PATH_PREFIX + screenId + Constants.SystemConstant.SCREEN_TEMPLATE_PATH_SUFFIX,
        type: "GET",
        cache: false

    }).done(function (data) {
        $("#main").html(data).fadeIn();

    }).fail(function (e) {
        LogManager.error(e.message);

    }).always(function () {
        LogManager.info("Complete ajax.");
        deferred.resolve();

    });

    return deferred;
}