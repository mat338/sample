/**
 * 共通Script - number_component
 */

/**
 * Component - NumberComponent
 */
if (NumberComponent === undefined) {
    var NumberComponent = function () { };
}

/**
 * NumberComponent - 1桁数値 ⇒ 2桁数値変換処理
 * 
 * @param {Number} number 変換対象の数値
 * @returns {Number}
 */
NumberComponent.toDoubleDigits = function (number) {
    number += "";
    if (number.length === 1) {
        number = "00" + number;
    } else if (number.length === 2) {
        number = "0" + number;
    }
    return number;
}