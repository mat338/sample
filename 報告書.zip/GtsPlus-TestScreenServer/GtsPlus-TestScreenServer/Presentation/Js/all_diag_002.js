/**
 * all_diag_002画面のscript
 */

/**
 * 初期化処理
 */
function initialize_all_diag_002(ecuId, name) {
    // ローディング画像の表示
    switchConnectionStartMode("loading", "Connecting...");

    var dtcList = ecuListData.get(ecuId).dtcList;
    var phaseType = ecuListData.get(ecuId).phaseType;
    LogManager.info("phaseType : " + phaseType);
    for (i = 0; i < dtcList.length; i++) {
        // 行追加 9列
        $('#ecuList').append('<tr><td class="td_center"></td><td class="td_center"></td><td class="td_left"></td><td class="td_center"></td><td class="td_center"></td><td class="td_center"></td><td class="td_center"></td><td class="td_center"></td><td class="td_center"></td></tr>');

        // フラグ(0：Enhanced, 1：Generic)
        if (Constants.kindFlag.ENHANCED === dtcList[i].kindFlag) {
            $('#ecuList tr').eq(i + 1).children('td').eq(0).html('<img id="enhanced' + i + '" src="../Image/enhanced.png" alt="enhanced"></img>');
        } else {
            $('#ecuList tr').eq(i + 1).children('td').eq(0).html('<img id="generic' + i + '" src="../Image/generic.png" alt="generic"></img>');
        }

        // 表示用DTC
        $('#ecuList tr').eq(i + 1).children('td').eq(1).text(dtcList[i].codeDisp);

        // ダイアグコード名称
        $('#ecuList tr').eq(i + 1).children('td').eq(2).text(dtcList[i].name);

        // ダイアグコード種別
        for (j = 0; j < dtcList.length; j++) {
            var col_num;
            if (Constants.phaseType.PHASE5 === phaseType) {
                // Phase5の場合
                switch (dtcList[i].kind[j]) {
                    // 0:ダイアグなし(No DTC)
                    case Constants.kind.NO_DTC:
                        col_num = -1;
                        break;

                    // 1:現在ダイアグ、TestFail(最新) (Current, TestFail (latest))
                    case Constants.kind.CURRENT_TEST_FAIL:
                        col_num = 6;    // Test Failed
                        break;

                    // 2:過去ダイアグ、Confirmed(確定) (Past, Confirmed)
                    case Constants.kind.PAST_CONFIRMED:
                        col_num = 3;    // Curr Conf
                        break;

                    // 4:ペンディング(Pending)
                    case Constants.kind.PENDING:
                        col_num = 4;    // Pend
                        break;

                    // 5:パーマネント(Parmanent)
                    case Constants.kind.PARMANENT:
                        col_num = 7;    // Perm
                        break;

                    // 上記以外は無効
                    default:
                        col_num = -1;
                        break;
                }
            } else {
                // Phase5以外の場合
                switch (dtcList[i].kind[j]) {
                    // 0:ダイアグなし(No DTC)
                    case Constants.kind.NO_DTC:
                        col_num = -1;
                        break;

                    // 1:現在ダイアグ、TestFail(最新) (Current, TestFail (latest))
                    case Constants.kind.CURRENT_TEST_FAIL:
                        col_num = 3;    // Curr Conf
                        break;

                    // 2:過去ダイアグ、Confirmed(確定) (Past, Confirmed)
                    case Constants.kind.PAST_CONFIRMED:
                        col_num = 5;    // Hist
                        break;

                    // 4:ペンディング(Pending)
                    case Constants.kind.PENDING:
                        col_num = 4;    // Pend
                        break;

                    // 5:パーマネント(Parmanent)
                    case Constants.kind.PARMANENT:
                        col_num = 7;    // Perm
                        break;

                    // 上記以外は無効
                    default:
                        col_num = -1;
                        break;
                }
            }

            if (col_num >= 3) {
                $('#ecuList tr').eq(i + 1).children('td').eq(col_num).html('<img id="img_check' + i + dtcList[i].kind[j] + '" src="../Image/check.png" alt="check"></img>');
            }            
        }

        // FFDタイプ
        if (Constants.ffdType.NO_FFD !== dtcList[i].ffdType) {
            $('#ecuList tr').eq(i + 1).children('td').eq(8).html('<img id="img_ffd' + i + '" src="../Image/FFD.png" alt="FFD"></img>');
        }
    }

    // 画面表示
    ScreenComponent.removeLoading("loading");
}

/*
 * 戻る押下処理
 */
$(document).on("click", "#button_back", function () {
    ScreenComponent.navigateAsync(Constants.ScreenId.ALL_DIAG_001).done(function () {
        show_again_all_diag_001();
    });
});
