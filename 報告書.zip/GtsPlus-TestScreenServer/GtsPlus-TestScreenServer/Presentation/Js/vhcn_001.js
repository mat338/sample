/**
 * vhcn_001画面のscript
 */
// 確認メッセージ
var CONFIRMATION_MSG;
// 仕向/言語
var regionId;
var languageId;
var idList;
var idListReSelect;
var idListIdConfirm;
// 車両確定通知用変数
var confirmData = new Object();

/**
 * 画面ロード時イベント処理
 */
window.onload = function () {
    // 車両接続画面へ遷移
    ScreenComponent.navigateAsync(Constants.ScreenId.VHCN_001).done(function () {
        // 選択項目リスト初期化
        initSelect();

        // 初期化
        initialize();
    });
}

/*
 * 選択項目リスト初期化
 */
function initSelect() {
    // Selectmenu初期化
    $('.category').selectmenu();

    // SelectmenuのオブジェクトにOnClickイベントを設定
    $('.ui-selectmenu-button').click(function () {
        ScreenComponent.clearApi();
        // selectタグのjQueryオブジェクト
        var item = this.id.substr(0, this.id.length - '-button'.length);
        var itemKind = item.substr(0, item.length - 1);
        var itemNum = Number(item.slice(-1));

        // カテゴリーの場合
        if (itemKind === "selectCategory") {
            LogManager.info("click-" + item);
            // カテゴリー選択リスト押下処理
            clickSelectCategory(item, itemNum);
        }
    });

    // SelectmenuのオブジェクトにonChangeイベントを設定
    $('#selectCategory1').selectmenu({
        change: function () {
            LogManager.info("change1");
            ScreenComponent.clearApi();

            // jQueryオブジェクトの生成
            var $select = $('select#selectCategory' + Constants.VhcnItemId.DIVIDION);

            // 車両確定状態を解除
            confirmDisabled(true);

            category1_val = Number($("#selectCategory" + Constants.VhcnItemId.DIVIDION).val());

            // 車両カテゴリ情報取得API → 車両選択API
            changeCategory();

            // 選択項目を削除しているため、再選択する
            $("#selectCategory" + Constants.VhcnItemId.DIVIDION).val(category1_val);

            // Selectmenuを更新
            $select.selectmenu('refresh');
        }
    });
    $('#selectCategory2').selectmenu({
        change: function () {
            LogManager.info("change2");
            ScreenComponent.clearApi();
            // jQueryオブジェクトの生成
            var $select = $('select#selectCategory' + Constants.VhcnItemId.MODEL);

            // 車両確定状態を解除
            confirmDisabled(true);

            category2_val = Number($("#selectCategory" + Constants.VhcnItemId.MODEL).val());

            // 車両カテゴリ情報取得API → 車両選択API
            changeCategory();

            // 選択項目を削除しているため、再選択する
            $("#selectCategory" + Constants.VhcnItemId.MODEL).val(category2_val);

            // Selectmenuを更新
            $select.selectmenu('refresh');
        }
    });
    $('#selectCategory3').selectmenu({
        change: function () {
            LogManager.info("change3");
            ScreenComponent.clearApi();
            // jQueryオブジェクトの生成
            var $select = $('select#selectCategory' + Constants.VhcnItemId.MODEL_CODE);

            // 車両確定状態を解除
            confirmDisabled(true);

            category3_val = Number($("#selectCategory" + Constants.VhcnItemId.MODEL_CODE).val());

            // 車両カテゴリ情報取得API → 車両選択API
            changeCategory();

            // 選択項目を削除しているため、再選択する
            $("#selectCategory" + Constants.VhcnItemId.MODEL_CODE).val(category3_val);

            // Selectmenuを更新
            $select.selectmenu('refresh');
        }
    });
    $('#selectCategory4').selectmenu({
        change: function () {
            LogManager.info("change4");
            ScreenComponent.clearApi();
            // jQueryオブジェクトの生成
            var $select = $('select#selectCategory' + Constants.VhcnItemId.ENGINE_MODEL);

            // 車両確定状態を解除
            confirmDisabled(true);

            category4_val = Number($("#selectCategory" + Constants.VhcnItemId.ENGINE_MODEL).val());

            // 車両カテゴリ情報取得API → 車両選択API
            changeCategory();

            // 選択項目を削除しているため、再選択する
            $("#selectCategory" + Constants.VhcnItemId.ENGINE_MODEL).val(category4_val);

            // Selectmenuを更新
            $select.selectmenu('refresh');
        }
    });
    $('#selectOption1').selectmenu({
        change: function () {
            LogManager.info("change-op1");
            ScreenComponent.clearApi();
            changeOption1();
        }
    });
    $('#selectOption2').selectmenu({
        change: function () {
            LogManager.info("change-op2");
            ScreenComponent.clearApi();
            changeOption2();
        }
    });
    $('#selectOption3').selectmenu({
        change: function () {
            LogManager.info("change-op3");
            ScreenComponent.clearApi();
            changeOption3();
        }
    });
}

/**
 * カテゴリー選択リスト押下処理
 */
function clickSelectCategory(item, itemNum) {
    var selectItem = Number($("#" + item).val());

    switch (itemNum) {
        case Constants.VhcnItemId.DIVIDION:
            category1_val = selectItem;
            break;
        case Constants.VhcnItemId.MODEL:
            category2_val = selectItem;
            break;
        case Constants.VhcnItemId.MODEL_CODE:
            category3_val = selectItem;
            break;
        case Constants.VhcnItemId.ENGINE_MODEL:
            category4_val = selectItem;
            break;
    }

    // 選択項目取得処理
    clickCategory(itemNum, selectItem);
}

/**
 * 初期化処理
 */
function initialize() {
    // ローディング画像の表示
    switchConnectionStartMode("loading", "Connecting...");

    // GTS+へWebSocket接続
    WebSocketComponent.connectServerAsync(null, null, null, onError = onError).then(WebSocketComponent.terminateConnectProcessAsync()).then(function () {
        // GUI-PF間接続初期化API
        apiConnectingProcess().then(function (data) {
            // チャレンジコード生成API
            apiCreateChallengeCode(data).then(function (data) {
                if (Constants.PlatformApiResult.SUCCESS !== data.resultInfo.result) {
                    LogManager.info("[API : " + Constants.PlatformApiId.CREATE_CHALLENGE_CODE + "] -----> NG.");
                    displayErrorScreen("[API : " + Constants.PlatformApiId.CREATE_CHALLENGE_CODE + "] is failed.");
                    return;
                }
                LogManager.info("[API : " + Constants.PlatformApiId.CREATE_CHALLENGE_CODE + "] -----> OK.");
                ScreenComponent.responseApi(data);

                // API認証用ハッシュコード生成
                var hash = createHash(data);

                // API認証用ハッシュコードチェックAPI
                apiCheckApiAuthentication(hash).then(function (data) {
                    if (Constants.PlatformApiResult.SUCCESS !== data.resultInfo.result) {
                        LogManager.info("[API : " + Constants.PlatformApiId.CHECK_API_AUTHENTICATION + "] -----> NG.");
                        displayErrorScreen("[API : " + Constants.PlatformApiId.CHECK_API_AUTHENTICATION + "] is failed.");
                        return;
                    }
                    LogManager.info("[API : " + Constants.PlatformApiId.CHECK_API_AUTHENTICATION + "] -----> OK.");
                    ScreenComponent.responseApi(data);

                    // 診断開始API
                    apiStartDiagnosis().then(function (data) {
                        if (Constants.PlatformApiResult.SUCCESS !== data.resultInfo.result) {
                            LogManager.info("[API : " + Constants.PlatformApiId.START_DIAGNOSIS + "] -----> NG.");
                            displayErrorScreen("[API : " + Constants.PlatformApiId.START_DIAGNOSIS + "] is failed.");
                            return;
                        }
                        LogManager.info("[API : " + Constants.PlatformApiId.START_DIAGNOSIS + "] -----> OK.");
                        ScreenComponent.responseApi(data);

                        // 診断情報取得API
                        apiGetDiagnosticInformation().then(function (data) {
                            if (Constants.PlatformApiResult.SUCCESS !== data.resultInfo.result) {
                                LogManager.info("[API : " + Constants.PlatformApiId.GET_DIAGNOSTIC_INFORMATION + "] -----> NG.");
                                displayErrorScreen("[API : " + Constants.PlatformApiId.GET_DIAGNOSTIC_INFORMATION + "] is failed.");
                                return;
                            }
                            LogManager.info("[API : " + Constants.PlatformApiId.GET_DIAGNOSTIC_INFORMATION + "] -----> OK.");
                            ScreenComponent.responseApi(data);

                            // 画面表示項目_仕向/言語別設定
                            setViewLanguage(data);

                            // 車両確定情報取得API
                            apiGetVehicleConfirmation().then(function (data) {
                                if (Constants.PlatformApiResult.SUCCESS !== data.resultInfo.result) {
                                    LogManager.info("[API : " + Constants.PlatformApiId.GET_VEHICLE_CONFIRMATION + "] -----> NG.");
                                    displayErrorScreen("[API : " + Constants.PlatformApiId.GET_VEHICLE_CONFIRMATION + "] is failed.");
                                    return;
                                }
                                LogManager.info("[API : " + Constants.PlatformApiId.GET_VEHICLE_CONFIRMATION + "] -----> OK.");
                                ScreenComponent.responseApi(data);

                                // 車両確定状態判定
                                judgVehicleConfirmation(data);

                            }).catch(function (e) {
                                // 車両確定状態判定失敗の場合
                                displayErrorScreen(e.message);

                            }).finally(function () {
                                // 接続終了モードへ切替
                                switchConnectionEndMode("loading");
                            });

                        }).catch(function (e) {
                            // 車両確定情報取得API失敗の場合
                            displayErrorScreen(e.message);
                        });

                    }).catch(function (e) {
                        // 診断情報取得API失敗の場合
                        displayErrorScreen(e.message);
                    });

                }).catch(function (e) {
                    // 診断開始API失敗の場合
                    displayErrorScreen(e.message);
                });

            }).catch(function (e) {
                // API認証用ハッシュコードチェックAPI失敗の場合
                displayErrorScreen(e.message);
            });

        }).catch(function (e) {
            // チャレンジコード生成API失敗の場合
            displayErrorScreen(e.message);
        });

    }).catch(function (e) {
        // 接続プロセス失敗の場合
        displayErrorScreen(e.message);
    });
}

/**
 * 接続開始モードへの切替処理
 * 
 * @param {String} kind 表示種類名
 * @param {String} message メッセージ
 */
function switchConnectionStartMode(kind, message) {
    // 車両接続ボタンの非活性・非表示
    $("#button_connect_to_vehicle").prop("disabled", true);
    $("#button_connect_to_vehicle").fadeOut();
    $("#table_category").fadeOut();
    $("#table_option").fadeOut();
    $('#image_confirm').prop('disabled', true);
    $("#image_confirm").fadeOut();

    // ローディング画像の表示
    ScreenComponent.displayLoading(kind, message);
}

/**
 * 接続終了モードへの切替処理
 *
 * @param {String} kind 表示種類名
 */
function switchConnectionEndMode(kind) {
    ScreenComponent.removeLoading(kind);

    // Diag Endボタンの表示
    $("#button_connect_to_vehicle").fadeIn();
    $("#button_connect_to_vehicle").prop("disabled", false);

    $("#table_category").fadeIn();
    $("#table_option").fadeIn();
    $("#image_confirm").fadeIn();
}

/**
 * 接続プロセス成功時処理
 * 
 * @return {Object}
 */
function apiConnectingProcess() {
    // GUI-PF間接続初期化APIの実行
    return WebSocketComponent.executeApiAsync(webSocket = WebSocketComponent.WebSocket, {
        common: {
            apiId: Constants.PlatformApiId.SET_CONNECTION_CONDTION,
            ack: Constants.PlatformApiAckFlag.FALSE,
        },
        apiArgs: {
            name: Constants.PlatformApiCommonArgs.SCREEN_RELAY_API_ID_GTS,
            maxNum: Constants.PlatformApiCommonArgs.SAME_NAME_MAX_CONNECTIONS,
        },
        free: {
            freeMsg: "HELLO",
        },
    });
}

/**
 * チャレンジコード生成API処理
 * 
 * @param {Object} data レスポンスデータ
 * @return {Object}
 */
function apiCreateChallengeCode(data) {
    // レスポンスの解析
    var appName = data.apiArgs.appName;
    var isFailed = true;

    // 処理成功の場合
    if (Constants.PlatformApiResult.SUCCESS === data.resultInfo.result) {
        // GTS+ or miniGTS+の場合
        if (Constants.ApplicationName.GTS_PLUS === appName || Constants.ApplicationName.MINI_GTS_PLUS === appName) {
            // 接続成功として設定
            LogManager.info("[API : " + Constants.PlatformApiId.SET_CONNECTION_CONDTION + "] -----> OK.");
            ScreenComponent.responseApi(data);
            isFailed = false;

            // システム名・最大接続数の保持
            WebSocketComponent.WebSocket.appName = appName;
            WebSocketComponent.WebSocket.maxNumberConnect = data.apiArgs.maxNumberConnect;

            //  チャレンジコード生成APIの実行
            return WebSocketComponent.executeApiAsync(WebSocketComponent.WebSocket, {
                common: {
                    apiId: Constants.PlatformApiId.CREATE_CHALLENGE_CODE,
                    ack: Constants.PlatformApiAckFlag.FALSE,
                },
                free: {
                    freeMsg: "CREATE_CHALLENGE_CODE",
                },
            });
        }
    }

    // APIの結果が失敗している場合
    if (isFailed) {
        throw new Error("[API : " + Constants.PlatformApiId.SET_CONNECTION_CONDTION + "] -----> NG.");
    }
}

/**
 * API認証用ハッシュコード生成
 * 
 * @param {Object} data レスポンスデータ
 */
function createHash(data) {
    // ハッシュコード生成
    const shaObj = new jsSHA('SHA-256', 'TEXT');
    shaObj.update(data.apiArgs.challengeCode);
    shaObj.update(Constants.SystemConstant.SALT);
    const code = shaObj.getHash('HEX');

    return code;
}

/**
 * API認証用ハッシュコードチェック
 * 
 * @param {Object} data レスポンスデータ
 */
function apiCheckApiAuthentication(hash) {
    // API認証用ハッシュコードチェックAPIの実行
    return WebSocketComponent.executeApiAsync(webSocket = WebSocketComponent.WebSocket, {
        common: {
            apiId: Constants.PlatformApiId.CHECK_API_AUTHENTICATION,
            ack: Constants.PlatformApiAckFlag.FALSE,
        },
        apiArgs: {
            authenticationCode: hash,
        },
        free: {
            freeMsg: "CHECK_API_AUTHENTICATION",
        },
    });
}

/**
 * 診断情報取得API
 * 
 * @param {Object} data レスポンスデータ
 */
function apiGetDiagnosticInformation() {
    // 診断情報取得APIの実行
    return WebSocketComponent.executeApiAsync(webSocket = WebSocketComponent.WebSocket, {
        common: {
            apiId: Constants.PlatformApiId.GET_DIAGNOSTIC_INFORMATION,
            ack: Constants.PlatformApiAckFlag.FALSE,
        },
        free: {
            freeMsg: "GET_DIAGNOSTIC_INFORMATION",
        },
    });
}

/**
 * 診断開始API
 * 
 * @param {Object} data レスポンスデータ
 */
function apiStartDiagnosis() {
    // 診断開始APIの実行
    return WebSocketComponent.executeApiAsync(webSocket = WebSocketComponent.WebSocket, {
        common: {
            apiId: Constants.PlatformApiId.START_DIAGNOSIS,
            ack: Constants.PlatformApiAckFlag.FALSE,
        },
        free: {
            freeMsg: "START_DIAGNOSIS",
        },
    });
}

/**
 * 車両確定情報取得API処理
 * 
 * @param {Object} data レスポンスデータ
 */
function apiGetVehicleConfirmation() {
    // 車両確定情報取得APIの実行
    return WebSocketComponent.executeApiAsync(webSocket = WebSocketComponent.WebSocket, {
        common: {
            apiId: Constants.PlatformApiId.GET_VEHICLE_CONFIRMATION,
            ack: Constants.PlatformApiAckFlag.FALSE,
        },
        free: {
            freeMsg: "GET_VEHICLE_CONFIRMATION",
        },
    });
}

/**
 * 画面表示項目_仕向/言語別設定
 * 
 * @param {Object} data レスポンスデータ
 */
function setViewLanguage(data) {
    // デフォルトを日本語に設定
    if (typeof data.apiArgs.regionId === 'undefined' || typeof data.apiArgs.languageId === 'undefined') {
        regionId = Constants.RegionCode.REGION_CODE_JAPAN;
        languageId = Constants.LanguageId.JAPANESE;
    } else {
        regionId = data.apiArgs.regionId;
        languageId = data.apiArgs.languageId;
    }
    var region = Constants.RegionCode.REGION_NAME[regionId];
    var language = Constants.LanguageId.LANGUAGE[languageId];

    var path = Constants.SystemConstant.DYNAMIC_LOADING_JS_PATH + "Lang/" + language + "/constants_lang.js";
    // 言語別ファイルの読込
    $.getScript(path, function () {
        $('#table_category tr').eq(0).children('th').eq(0).text(Constants_Launuege.Vhcn001.CATEGORY_DIVISION);
        $('#table_category tr').eq(1).children('th').eq(0).text(Constants_Launuege.Vhcn001.CATEGORY_MODEL);
        $('#table_category tr').eq(2).children('th').eq(0).text(Constants_Launuege.Vhcn001.CATEGORY_MODEL_CODE);
        $('#table_category tr').eq(3).children('th').eq(0).text(Constants_Launuege.Vhcn001.CATEGORY_ENGINE_MODEL);
        $('#table_option tr').eq(0).children('th').eq(0).text(Constants_Launuege.Vhcn001.OPTION);
    });

    path = Constants.SystemConstant.DYNAMIC_LOADING_JS_PATH + "Region/" + region + "/constants_region.js";
    // 仕向別ファイルの読込
    $.getScript(path, function () {
        // idList
        idList = Constants_Region.IdList.ID_LIST;
        idListReSelect = Constants_Region.IdList.ID_LIST_RE_SELECT;
        idListIdConfirm = Constants_Region.IdList.ID_LIST_ID_CONFIRM;
    });
}


/**
 * 車両確定状態判定処理
 *
 * @param {Object} data レスポンスデータ
 */
function judgVehicleConfirmation(data) {
    // 車両確定情報取得APIが成功の場合
    if (Constants.PlatformApiResult.SUCCESS === data.resultInfo.result) {
        var isConfirm = true;

        // [車両確定情報取得]の応答から車両IDを取得した場合
        if (typeof data.apiArgs !== 'undefined' && typeof data.apiArgs.vehicleId !== 'undefined') {

            // 車両IDが有効範囲（1～65534）の場合
            if (Constants.VehicleIdRangeConstant.VEHICLE_ID_MIN <= data.apiArgs.vehicleId &&
                Constants.VehicleIdRangeConstant.VEHICLE_ID_MAX >= data.apiArgs.vehicleId) {
                // 確認画面➁を表示
                LogManager.info("[confirmation screen 2]");

                // 車両確定情報取得結果を格納
                confirmData.vehicleId = data.apiArgs.vehicleId;

                viewConfirm1(data, 2);

            } else {
                // 車両が未確定の場合
                isConfirm = false;
            }

        } else {
            // 車両が未確定の場合
            isConfirm = false;
        }

        // [車両が未確定]の場合
        if (!isConfirm) {
            // 車両キャッシュ取得API
            apiGetVehicleCache().then(function (data) {
                if (Constants.PlatformApiResult.SUCCESS !== data.resultInfo.result) {
                    LogManager.info("[API : " + Constants.PlatformApiId.GET_VEHICLE_CACHE + "] -----> NG.");
                    displayErrorScreen("[API : " + Constants.PlatformApiId.GET_VEHICLE_CACHE + "] is failed.");
                    return;
                }
                LogManager.info("[API : " + Constants.PlatformApiId.GET_VEHICLE_CACHE + "] -----> OK.");
                ScreenComponent.responseApi(data);

                // 車両情報有無チェック(VIN：有効 かつ 車両ID：有効)
                if ((typeof data.apiArgs.vin !== 'undefined' && (data.apiArgs.vin !== "null" || data.apiArgs.vin !== "0")) &&
                    (typeof data.apiArgs.vehicleId !== 'undefined' &&
                           (Constants.VehicleIdRangeConstant.VEHICLE_ID_MIN <= data.apiArgs.vehicleId &&
                            Constants.VehicleIdRangeConstant.VEHICLE_ID_MAX >= data.apiArgs.vehicleId)
                    )) {
                    // 車両情報有りの場合、確認画面①を表示
                    LogManager.info("[confirmation screen 1]");

                    // 車両キャッシュ取得結果を格納
                    confirmData.vehicleId = data.apiArgs.vehicleId;
                    confirmData.vinCode = data.apiArgs.vinCode;

                    viewConfirm1(data, 1);

                } else {
                    // 車両情報無しの場合、車両選択API
                    apiSelectVehicle(idList, 0, 0).then(function (data) {
                        // 車両選択APIの実行結果が失敗の場合
                        if (Constants.PlatformApiResult.SUCCESS !== data.resultInfo.result) {
                            LogManager.info("[API : " + Constants.PlatformApiId.SELECT_VEHICLE + "] -----> NG.");
                            displayErrorScreen("[API : " + Constants.PlatformApiId.SELECT_VEHICLE + "] is failed.");
                            return;
                        }
                        LogManager.info("[API : " + Constants.PlatformApiId.SELECT_VEHICLE + "] -----> OK.");
                        ScreenComponent.responseApi(data);

                        // 返却値を車両確定通知用変数に保持
                        confirmData.vehicleId = data.apiArgs.vehicleId;
                        confirmData.vinCode = data.apiArgs.vinCode;
                        confirmData.categoryNameList = data.apiArgs.categoryNameList;
                        confirmData.carInfoList = data.apiArgs.carInfoList;
                        confirmData.index = data.apiArgs.index;
                        confirmData.decisionVin = data.apiArgs.decisionVin;
                        confirmData.parentPhaseType = data.apiArgs.parentPhaseType;
                        //LogManager.info("[confirmData.vehicleId : " + confirmData.vehicleId + "]")
                        //LogManager.info("[confirmData.vinCode : " + confirmData.vinCode + "]")
                        //LogManager.info("[confirmData.categoryNameList : " + confirmData.categoryNameList + "]")
                        //LogManager.info("[confirmData.carInfoList : " + confirmData.carInfoList + "]")
                        //LogManager.info("[confirmData.index : " + confirmData.index + "]")
                        //LogManager.info("[confirmData.decisionVin : " + confirmData.decisionVin + "]")
                        //LogManager.info("[confirmData.parentPhaseType : " + confirmData.parentPhaseType + "]")

                        if (Constants.VehicleIdRangeConstant.VEHICLE_ID_UNDIAGNOSED === confirmData.vehicleId) {
                            // 車両未確定のため車両確定画面を表示
                            screenVehicleConfirmation(data);

                        } else if (Constants.VehicleIdRangeConstant.VEHICLE_ID_BAT === confirmData.vehicleId) {
                            // 不具合車両の場合
                            displayErrorScreen("[65535：Defective vehicle]");

                        } else {
                            //// 車両IDが[0]又は[65535]以外であれば、確定したとみなし車両確定通知APIを実行
                            LogManager.info("[" + confirmData.vehicleId + "：Vehicle confirmation]");
                            confirmationProcessing();

                        }
                    }).catch(function (e) {
                        // 車両選択API失敗の場合
                        displayErrorScreen(e.message);
                    });
                }

            }).catch(function (e) {
                // 車両キャッシュ取得API失敗の場合
                displayErrorScreen(e.message);
            });
        }
    }
}

/**
 * 車両キャッシュ取得API処理
 * 
 */
function apiGetVehicleCache() {
    // 車両キャッシュ取得APIの実行
    return WebSocketComponent.executeApiAsync(webSocket = WebSocketComponent.WebSocket, {
        common: {
            apiId: Constants.PlatformApiId.GET_VEHICLE_CACHE,
            ack: Constants.PlatformApiAckFlag.FALSE,
        },
        free: {
            freeMsg: "GET_VEHICLE_CACHE",
        },
    });
}

/**
 * 車両選択 API処理
 * 
 * @param {int[]} idLst カテゴリIDのリスト
 * @param {int} idx カテゴリID
 * @param {int} sltId 選択リストID
 */
function apiSelectVehicle(idLst, idx, sltId) {
    // 車両選択 APIの実行
    return WebSocketComponent.executeApiAsync(webSocket = WebSocketComponent.WebSocket, {
        common: {
            apiId: Constants.PlatformApiId.SELECT_VEHICLE,
            ack: Constants.PlatformApiAckFlag.FALSE,
        },
        apiArgs: {
            divisionId: 0,
            idList: idLst,
            index: idx,
            selectId: sltId,
            nonDispInfoList: "",
        },
        free: {
            freeMsg: "SELECT_VEHICLE",
        },
    });
}


/**
 * 車両確定画面表示処理
 *
 * @param {Object} data レスポンスデータ
 */
function screenVehicleConfirmation(data) {
    // [categoryNameList]取得有無判定
    if (typeof data.apiArgs !== 'undefined' && typeof data.apiArgs.categoryNameList !== 'undefined') {
        // [categoryNameList]内の要素数判定
        if (Object.keys(data.apiArgs.categoryNameList).length > 0) {
            // [IT3_DIVISION(11)]で抽出し、[ブランド(1)]リストに追加
            addCategorySelect(data.apiArgs.categoryNameList, Constants.CategoryID.CATEGORY_ID_DIVIDION, "selectCategory" + Constants.VhcnItemId.DIVIDION);

            // [IT3_Model(12)]で抽出、[車両]リスト(2)]に追加
            addCategorySelect(data.apiArgs.categoryNameList, Constants.CategoryID.CATEGORY_ID_MODEL, "selectCategory" + Constants.VhcnItemId.MODEL);

            // [CATEGORY_ID_MODEL_CODE(15)]で抽出、[車型(3)]リストに追加
            addCategorySelect(data.apiArgs.categoryNameList, Constants.CategoryID.CATEGORY_ID_MODEL_CODE, "selectCategory" + Constants.VhcnItemId.MODEL_CODE);

            // [CATEGORY_ID_MODEL_CODE(13)]で抽出、[Model Year(3)]リストに追加
            addCategorySelect(data.apiArgs.categoryNameList, Constants.CategoryID.CATEGORY_ID_MODEL_YEAR, "selectCategory" + Constants.VhcnItemId.MODEL_CODE);

            // [CATEGORY_ID_ENGINE_MODEL(14)]で抽出、[エンジン形式(4)]リストに追加
            addCategorySelect(data.apiArgs.categoryNameList, Constants.CategoryID.CATEGORY_ID_ENGINE_MODEL, "selectCategory" + Constants.VhcnItemId.ENGINE_MODEL);
        }

        // [オプション情報インデックス]がオプションあり(0以外)、且つ[optionInfoList]内の要素有りの場合
        if (data.apiArgs.index !== 0 && Object.keys(data.apiArgs.optionInfoList).length > 0) {
            // [オプション１]項目に[<SELECT>]選択項目を追加する
            addOptionSelect(Constants.VhcnItemId.OPTION1);
            // Id順に抽出し、[オプション(1)]リストに追加
            for (i = 1; i <= Object.keys(data.apiArgs.optionInfoList).length; i++) {
                addSelect(data.apiArgs.optionInfoList, i, "selectOption" + Constants.VhcnItemId.OPTION1);
            }
        } else if (data.apiArgs.index === 0) {
            // [index]が[0]の場合はオプションなしのため車両確定状態であるが、[vehicleId]が[0]であるため矛盾が発生
            LogManager.info("[車両確定可能]");
            confirmDisabled(false);
        }

    } else {
        LogManager.info("[チェック] NG.")
    }
}

/**
 * カテゴリ選択リスト項目追加処理
 * 
 * @param {Object} data レスポンスデータ（categoryNameList）
 * @param {int} id 抽出条件
 * @param {int} listId 追加対象の選択リストID
 */
function addCategorySelect(data, id, listId) {
    var filterData = data.filter(function (item) {
        if (item.categoryId === id) return true;
    });

    // Selectmenu初期化
    var $select = $('#' + listId);
    
    // 取得データをカテゴリー選択リストに追加
    filterData.forEach(function (value) {
        $select.append($('<option>').html(value.contentsName).val(value.contentsId));
    });

    // Selectmenuを更新
    $select.selectmenu('refresh');
}

/**
 * オプション選択リスト追加処理
 *
 * @param {Object} data レスポンスデータ（optionInfoList）
 * @param {int} id 抽出条件
 * @param {int} listId 追加対象の選択リストID
 */
function addSelect(data, id, listId) {
    var filterData = data.filter(function (item) {
        if (item.id === id) return true;
    });

    // Selectmenu初期化
    var $select = $('#' + listId);

    // 取得データをカテゴリー選択リストに追加
    filterData.forEach(function (value) {
        $select.append($('<option>').html(value.name).val(value.id));
    });

    // Selectmenuを更新
    $select.selectmenu('refresh');
}

/**
 * 選択項目押下イベント用変数
 */
var category1_val = 0;
var category2_val = 0;
var category3_val = 0;
var category4_val = 0;
var opt1_val = 0;
var opt2_val = 0;
var opt3_val = 0;

/**
 * オプション１選択項目変更イベント処理
 */
function changeOption1() {
    // jQueryオブジェクトの生成
    var $select_op1 = $('select#selectOption' + Constants.VhcnItemId.OPTION1);
    var $select_op2 = $('select#selectOption' + Constants.VhcnItemId.OPTION2);

    // 車両確定状態の取得
    var disableFlg = $('#image_confirm').prop('disabled');

    var selectItem = Number($("#selectOption" + Constants.VhcnItemId.OPTION1).val());
    LogManager.info("selectItem:" + selectItem);

    // [オプション１]未選択時は処理を行わない
    if (opt1_val === 0 && selectItem === 0) return;

    // 選択項目に変更がない場合
    if (opt1_val === selectItem) return;


    opt1_val = selectItem;
    // オプション１の[<SELECT>]選択項目を削除
    $('select#selectOption' + Constants.VhcnItemId.OPTION1 + ' option[value=0]').remove();

    // オプション２の[<SELECT>]選択項目を初期選択状態に変更する
    if (opt2_val !== 0) {
        // オプション２が選択済みの場合は「<SELECT>」項目が削除されているため追加する
        $('#selectOption' + Constants.VhcnItemId.OPTION2).prepend($('<option>').html("&lt;SELECT&gt;").val(0));
    }
    opt2_val = 0;
    $('#selectOption' + Constants.VhcnItemId.OPTION2).val(opt2_val);
    confirmDisabled(true);

    // 車両確定済の状態で再選択した場合
    if (!disableFlg) {
        // オプション１の選択を未選択状態からやり直す
        // 車両選択APIの実行（初期化）
        apiSelectVehicle(idListReSelect, 0, 0).then(function (data) {
            // 実行結果NGの場合
            if (Constants.PlatformApiResult.SUCCESS !== data.resultInfo.result) {
                LogManager.info("[API : " + Constants.PlatformApiId.SELECT_VEHICLE + "] -----> NG.");
                displayErrorScreen("[API : " + Constants.PlatformApiId.SELECT_VEHICLE + "] is failed.");
                return;
            }
            LogManager.info("[API : " + Constants.PlatformApiId.SELECT_VEHICLE + "] -----> OK.");
            ScreenComponent.responseApi(data);

            // カテゴリーリストの取得
            confirmData.categoryNameList = data.apiArgs.categoryNameList;
            //LogManager.info("[カテゴリー再選択 confirmData.categoryNameList : " + confirmData.categoryNameList + "]")

            // 車両選択APIの再実行（オプション１-確定）
            optionSelectVehicle(Constants.VhcnItemId.OPTION1, Constants.VhcnItemId.OPTION2, selectItem);

        }).catch(function (e) {
            // 選択項目変更失敗の場合
            displayErrorScreen(e.message);
        });
    } else {
        // 車両選択APIの実行（未確定）
        optionSelectVehicle(Constants.VhcnItemId.OPTION1, Constants.VhcnItemId.OPTION2, selectItem);
    }

    // Selectmenuを更新
    $select_op1.selectmenu('refresh');
    $select_op2.selectmenu('refresh');
}

/**
 * オプション２選択項目変更イベント処理
 */
function changeOption2() {
    // jQueryオブジェクトの生成
    var $select = $('select#selectOption' + Constants.VhcnItemId.OPTION2);

   // 車両確定状態の取得
    var disableFlg = $('#image_confirm').prop('disabled');
    var selectItem1 = Number($("#selectOption" + Constants.VhcnItemId.OPTION1).val());
    var selectItem2 = Number($("#selectOption" + Constants.VhcnItemId.OPTION2).val());

    // [オプション２]未選択時は処理を行わない
    if (opt2_val === 0 && selectItem2 === 0) return;

    // 選択項目に変更がない場合
    if (opt2_val === selectItem2) return;

    opt2_val = selectItem2;
    // オプション２の[<SELECT>]選択項目を削除
    $('select#selectOption' + Constants.VhcnItemId.OPTION2 + ' option[value=0]').remove();

    // オプション３の[<SELECT>]選択項目を初期選択状態に変更する
    if (opt3_val !== 0) {
        // オプション３が選択済みの場合は「<SELECT>」項目が削除されているため追加する
        $('#selectOption' + Constants.VhcnItemId.OPTION3).prepend($('<option>').html("&lt;SELECT&gt;").val(0));
    }
    opt3_val = 0;
    $('#selectOption' + Constants.VhcnItemId.OPTION3).val(0);
    confirmDisabled(true);

    // 車両確定済の状態で再選択した場合
    if (!disableFlg) {
        // オプション２の選択を未選択状態からやり直す
        // 車両選択APIの実行（初期化）
        apiSelectVehicle(idListReSelect, 0, 0).then(function (data) {
            // 実行結果NGの場合
            if (Constants.PlatformApiResult.SUCCESS !== data.resultInfo.result) {
                LogManager.info("[API : " + Constants.PlatformApiId.SELECT_VEHICLE + "] -----> NG.");
                displayErrorScreen("[API : " + Constants.PlatformApiId.SELECT_VEHICLE + "] is failed.");
                return;
            }
            LogManager.info("[API : " + Constants.PlatformApiId.SELECT_VEHICLE + "] -----> OK.");
            ScreenComponent.responseApi(data);

            // カテゴリーリストの取得
            confirmData.categoryNameList = data.apiArgs.categoryNameList;
            //LogManager.info("[カテゴリー再選択 confirmData.categoryNameList : " + confirmData.categoryNameList + "]")

            // 車両選択APIの実行（オプション１）
            apiSelectVehicle(idListReSelect, Constants.VhcnItemId.OPTION1, selectItem1).then(function (data) {
                // 実行結果NGの場合
                if (Constants.PlatformApiResult.SUCCESS !== data.resultInfo.result) {
                    LogManager.info("[API : " + Constants.PlatformApiId.SELECT_VEHICLE + "] -----> NG.");
                    displayErrorScreen("[API : " + Constants.PlatformApiId.SELECT_VEHICLE + "] is failed.");
                    return;
                }
                LogManager.info("[API : " + Constants.PlatformApiId.SELECT_VEHICLE + "] -----> OK.");
                ScreenComponent.responseApi(data);

                // 車両選択APIの再実行（オプション２-確定）
                optionSelectVehicle(Constants.VhcnItemId.OPTION2, Constants.VhcnItemId.OPTION3, selectItem2);
            }).catch(function (e) {
                // 選択項目変更失敗の場合
                displayErrorScreen(e.message);
            });

        }).catch(function (e) {
            // 選択項目変更失敗の場合
            displayErrorScreen(e.message);
        });
    } else {
        // 車両選択APIの実行（未確定）
        optionSelectVehicle(Constants.VhcnItemId.OPTION2, Constants.VhcnItemId.OPTION3, selectItem2);
    }

    // Selectmenuを更新
    $select.selectmenu('refresh');
}

/**
 * オプション３選択項目変更イベント処理
 */
function changeOption3() {
    // jQueryオブジェクトの生成
    var $select = $('select#selectOption' + Constants.VhcnItemId.OPTION3);

    // 車両確定状態の取得
    var disableFlg = $('#image_confirm').prop('disabled');
    var selectItem1 = Number($("#selectOption" + Constants.VhcnItemId.OPTION1).val());
    var selectItem2 = Number($("#selectOption" + Constants.VhcnItemId.OPTION2).val());
    var selectItem3 = Number($("#selectOption" + Constants.VhcnItemId.OPTION3).val());

    // [オプション３]未選択時は処理を行わない
    if (opt3_val === 0 && selectItem3 === 0) return;

    // 選択項目に変更がない場合
    if (opt3_val === selectItem3) return;

    opt3_val = selectItem3;
   // オプション３の[<SELECT>]選択項目を削除
    $('select#selectOption' + Constants.VhcnItemId.OPTION3 + ' option[value=0]').remove();

    confirmDisabled(true);
    
    // 車両確定済の状態で再選択した場合
    if (!disableFlg) {
        // オプション３の選択を未選択状態からやり直す
        // 車両選択APIの実行（初期化）
        apiSelectVehicle(idListReSelect, 0, 0).then(function (data) {
            // 実行結果NGの場合
            if (Constants.PlatformApiResult.SUCCESS !== data.resultInfo.result) {
                LogManager.info("[API : " + Constants.PlatformApiId.SELECT_VEHICLE + "] -----> NG.");
                displayErrorScreen("[API : " + Constants.PlatformApiId.SELECT_VEHICLE + "] is failed.");
                return;
            }
            LogManager.info("[API : " + Constants.PlatformApiId.SELECT_VEHICLE + "] -----> OK.");
            ScreenComponent.responseApi(data);

            // カテゴリーリストの取得
            confirmData.categoryNameList = data.apiArgs.categoryNameList;

            // 車両選択APIの実行（オプション１）
            apiSelectVehicle(idListReSelect, Constants.VhcnItemId.OPTION1, selectItem1).then(function (data) {
                // 実行結果NGの場合
                if (Constants.PlatformApiResult.SUCCESS !== data.resultInfo.result) {
                    LogManager.info("[API : " + Constants.PlatformApiId.SELECT_VEHICLE + "] -----> NG.");
                    displayErrorScreen("[API : " + Constants.PlatformApiId.SELECT_VEHICLE + "] is failed.");
                    return;
                }
                LogManager.info("[API : " + Constants.PlatformApiId.SELECT_VEHICLE + "] -----> OK.");
                ScreenComponent.responseApi(data);

                // 車両選択APIの実行（オプション２）
                apiSelectVehicle(idListReSelect, Constants.VhcnItemId.OPTION2, selectItem2).then(function (data) {
                    // 実行結果NGの場合
                    if (Constants.PlatformApiResult.SUCCESS !== data.resultInfo.result) {
                        LogManager.info("[API : " + Constants.PlatformApiId.SELECT_VEHICLE + "] -----> NG.");
                        displayErrorScreen("[API : " + Constants.PlatformApiId.SELECT_VEHICLE + "] is failed.");
                        return;
                    }
                    LogManager.info("[API : " + Constants.PlatformApiId.SELECT_VEHICLE + "] -----> OK.");
                    ScreenComponent.responseApi(data);

                    // 車両選択APIの再実行（オプション３-確定）
                    optionSelectVehicle(Constants.VhcnItemId.OPTION3, 0, selectItem3);
                }).catch(function (e) {
                    // 選択項目変更失敗の場合
                    displayErrorScreen(e.message);
                });
            }).catch(function (e) {
                // 選択項目変更失敗の場合
                displayErrorScreen(e.message);
            });

        }).catch(function (e) {
            // 選択項目変更失敗の場合
            displayErrorScreen(e.message);
        });
    } else {
        // 車両選択APIの実行（未確定）
        optionSelectVehicle(Constants.VhcnItemId.OPTION3, 0, selectItem3);
    }

    // Selectmenuを更新
    $select.selectmenu('refresh');
}

/**
 * カテゴリー選択リスト押下イベント処理
 */
function clickCategory(idx, select) {
    // jQueryオブジェクトの生成
    var $select = $('select#selectCategory' + idx);

    // 選択リストをクリア
    $('select#selectCategory' + idx + ' option').remove();

    // 車両カテゴリ情報取得API用条件JSONの生成(他カテゴリーの選択項目)
    var json = getClickCategoryId(idx);
    // 車両カテゴリ情報取得APIを実行して、対象カテゴリの一覧を取得する。
    apiSelectVehicleCategory(json).then(function (data) {
        if (Constants.PlatformApiResult.SUCCESS !== data.resultInfo.result) {
            LogManager.info("[API : " + Constants.PlatformApiId.SELECT_VEHICLE_CATEGORY + "] -----> NG.");
            displayErrorScreen("[API : " + Constants.PlatformApiId.SELECT_VEHICLE_CATEGORY + "] is failed.");
            return;
        }
        LogManager.info("[API : " + Constants.PlatformApiId.SELECT_VEHICLE_CATEGORY + "] -----> OK.");
        ScreenComponent.responseApi(data);

        // [categoryItemList]取得有無判定
        if (typeof data.apiArgs !== 'undefined' && typeof data.apiArgs.categoryItemList !== 'undefined') {
            // [categoryItemList.id = 選択リスト]で抽出
            var filterData = data.apiArgs.categoryItemList.filter(function (item) {
                if (item.id === idx) return true;
            });

            if (Object.keys(filterData).length > 0) {
                for (i = 0; i < Object.keys(filterData).length; i++) {
                    if (typeof filterData[i].selectItemList !== 'undefined') {
                        // [selectItemList]からId順に抽出し、選択リストに追加
                        for (j = 0; j < Object.keys(filterData[i].selectItemList).length; j++) {
                            addSelect(filterData[i].selectItemList, filterData[i].selectItemList[j].id, "selectCategory" + idx);
                        }
                    }
                }

                // 選択項目を削除しているため、再選択する
                $("#selectCategory" + idx).val(select);

                // Selectmenuを更新
                $select.selectmenu('refresh');
            }
        }

    }).catch(function (e) {
        // 選択項目変更イベント失敗の場合
        displayErrorScreen(e.message);
    });
}

/**
 * カテゴリー選択項目変更処理
 */
function changeCategory() {
    // [オプション]リストを全クリア
    clearAllOption();

    // 車両カテゴリ情報取得API用条件JSONの生成(他カテゴリーの選択項目)
    var json = getSelectCategoryId();
    // 車両カテゴリ情報取得APIを実行して、カテゴリの絞り込みを設定する。
    apiSelectVehicleCategory(json).then(function (data) {
        if (Constants.PlatformApiResult.SUCCESS === data.resultInfo.result) {
            // 実行結果NGの場合
            if (Constants.PlatformApiResult.SUCCESS !== data.resultInfo.result) {
                LogManager.info("[API : " + Constants.PlatformApiId.SELECT_VEHICLE_CATEGORY + "] -----> NG.");
                displayErrorScreen("[API : " + Constants.PlatformApiId.SELECT_VEHICLE_CATEGORY + "] is failed.");
                return;
            }
            LogManager.info("[API : " + Constants.PlatformApiId.SELECT_VEHICLE_CATEGORY + "] -----> OK.");
            ScreenComponent.responseApi(data);

            // [status]取得有無判定
            if (typeof data.apiArgs !== 'undefined' && typeof data.apiArgs.status !== 'undefined') {
                // 状態IDが「1：確定」の場合、車両選択APIを実行し、オプションを取得
                if (data.apiArgs.status === Constants.StatusId.CONFIRMED) {
                    // 車両選択API
                    apiSelectVehicle(idListReSelect, 0, 0).then(function (data) {
                        // 実行結果NGの場合
                        if (Constants.PlatformApiResult.SUCCESS !== data.resultInfo.result) {
                            LogManager.info("[API : " + Constants.PlatformApiId.SELECT_VEHICLE + "] -----> NG.");
                            displayErrorScreen("[API : " + Constants.PlatformApiId.SELECT_VEHICLE + "] is failed.");
                            return;
                        }
                        LogManager.info("[API : " + Constants.PlatformApiId.SELECT_VEHICLE + "] -----> OK.");
                        ScreenComponent.responseApi(data);

                        // カテゴリーリストの取得
                        confirmData.categoryNameList = data.apiArgs.categoryNameList;
                        //LogManager.info("[カテゴリー再選択 confirmData.categoryNameList : " + confirmData.categoryNameList + "]")

                        // [オプション情報インデックス]がオプションあり(0以外)、且つ[optionInfoList]内の要素有りの場合
                        if (data.apiArgs.index !== Constants.indexId.CONFIRMED && Object.keys(data.apiArgs.optionInfoList).length > 0) {
                            // [オプション１]項目に[<SELECT>]選択項目を追加する
                            addOptionSelect(Constants.VhcnItemId.OPTION1);
                            // Id順に抽出し、[オプション(1)]リストに追加
                            for (i = 1; i <= Object.keys(data.apiArgs.optionInfoList).length; i++) {
                                addSelect(data.apiArgs.optionInfoList, i, "selectOption" + Constants.VhcnItemId.OPTION1);
                            }

                            // 選択項目を削除しているため、再選択する
                            $("#selectOption" + Constants.VhcnItemId.OPTION1).val(opt1_val);

                        } else if (data.apiArgs.index === Constants.indexId.CONFIRMED) {
                            // カテゴリー再選択の時点で確定できる場合
                            confirmData.vehicleId = data.apiArgs.vehicleId;
                            confirmData.index = data.apiArgs.index;
                            confirmData.decisionVin = data.apiArgs.decisionVin;
                            confirmData.parentPhaseType = data.apiArgs.parentPhaseType;
                            //LogManager.info("[カテゴリー再選択-確定 confirmData.vehicleId : " + confirmData.vehicleId + "]")
                            //LogManager.info("[カテゴリー再選択-確定 confirmData.vinCode : " + confirmData.vinCode + "]")
                            //LogManager.info("[カテゴリー再選択-確定 confirmData.categoryNameList : " + confirmData.categoryNameList + "]")
                            //LogManager.info("[カテゴリー再選択-確定 confirmData.carInfoList : " + confirmData.carInfoList + "]")
                            //LogManager.info("[カテゴリー再選択-確定 confirmData.index : " + confirmData.index + "]")
                            //LogManager.info("[カテゴリー再選択-確定 confirmData.decisionVin : " + confirmData.decisionVin + "]")
                            //LogManager.info("[カテゴリー再選択-確定 confirmData.parentPhaseType : " + confirmData.parentPhaseType + "]")
                        }

                    }).catch(function (e) {
                        // 接続情報取得API（ホロレンズ用）失敗の場合
                        displayErrorScreen(e.message);
                    });
                }
            } else {
                LogManager.info("NG.")
            }
        }

    }).catch(function (e) {
        // 接続情報取得API（ホロレンズ用）失敗の場合
        displayErrorScreen(e.message);
    });
}

/**
 * オプション車両確定処理
 *
 * @param {int} target1 選択リストID
 * @param {int} target2 選択リストID + 1
 * @param {int} idx 選択ID
 */
function optionSelectVehicle(target1, target2, idx) {
    // jQueryオブジェクトの生成
    var $select_op1 = $('select#selectOption1');
    var $select_op2 = $('select#selectOption2');
    var $select_op3 = $('select#selectOption3');

    // 車両選択APIの実行
    apiSelectVehicle(idListReSelect, target1, idx).then(function (data) {
        // 車両選択APIの実行結果が失敗の場合
        if (Constants.PlatformApiResult.SUCCESS !== data.resultInfo.result) {
            LogManager.info("[API : " + Constants.PlatformApiId.SELECT_VEHICLE + "] -----> NG.");
            displayErrorScreen("[API : " + Constants.PlatformApiId.SELECT_VEHICLE + "] is failed.");
            return;
        }
        LogManager.info("[API : " + Constants.PlatformApiId.SELECT_VEHICLE + "] -----> OK.");
        ScreenComponent.responseApi(data);

        // 項目取得チェック
        if (typeof data.apiArgs.index !== 'undefined') {
            // [index]が[0]以外の場合は車両未確定状態
            if (Constants.indexId.CONFIRMED !== data.apiArgs.index && typeof data.apiArgs.optionInfoList !== 'undefined') {
                // オプション３以外
                if (target2 !== 0) {
                    $('select#selectOption' + target2 + ' option').remove();
                    // [オプション]項目に[<SELECT>]選択項目を追加する
                    addOptionSelect(target2);
                    // Id順に抽出し、[オプション]リストに追加
                    for (i = 1; i <= Object.keys(data.apiArgs.optionInfoList).length; i++) {
                        addSelect(data.apiArgs.optionInfoList, i, "selectOption" + target2);
                    }

                    // 選択項目を削除しているため、再選択する
                    $("#selectOption" + target2).val(0);
                }

            } else if (Constants.indexId.CONFIRMED !== data.apiArgs.index && typeof data.apiArgs.optionInfoList === 'undefined') {
                // [option]がないにもかかわらず[index]が[0]以外の場合はエラー
                displayErrorScreen("Select vehicle failed.");

            } else {
                // [index]が[0]の場合は車両確定状態
                confirmDisabled(false);

                // 車両確定時の値を保持
                confirmData.vehicleId = data.apiArgs.vehicleId;
                //confirmData.categoryNameList = data.apiArgs.categoryNameList;
                confirmData.index = data.apiArgs.index;
                confirmData.decisionVin = data.apiArgs.decisionVin;
                confirmData.parentPhaseType = data.apiArgs.parentPhaseType;
                //LogManager.info("[車両確定時 confirmData.vehicleId : " + confirmData.vehicleId + "]")
                //LogManager.info("[車両確定時 confirmData.vinCode : " + confirmData.vinCode + "]")
                //LogManager.info("[車両確定時 confirmData.categoryNameList : " + confirmData.categoryNameList + "]")
                //LogManager.info("[車両確定時 confirmData.carInfoList : " + confirmData.carInfoList + "]")
                //LogManager.info("[車両確定時 confirmData.index : " + confirmData.index + "]")
                //LogManager.info("[車両確定時 confirmData.decisionVin : " + confirmData.decisionVin + "]")
                //LogManager.info("[車両確定時 confirmData.parentPhaseType : " + confirmData.parentPhaseType + "]")
            }

        }

    }).catch(function (e) {
        // 選択項目変更失敗の場合
        displayErrorScreen(e.message);
    });

    // Selectmenuを更新
    $select_op1.selectmenu('refresh');
    $select_op2.selectmenu('refresh');
    $select_op3.selectmenu('refresh');
}

/**
 * 確定ボタン押下可否
 *
 * @param {bool} flg 使用可能フラグ
 */
function confirmDisabled(flg) {
    $('#image_confirm').prop('disabled', flg);
    if (flg) {
        $('#image_confirm').attr('src', '../Image/confirm_disable.png');
    } else {
        $('#image_confirm').attr('src', '../Image/confirm_enable.png');
    }
}

/**
 * オプション選択リストの先頭に「<SELECT>」項目の追加
 *
 * @param {int} idx 追加対象の選択リストID
 */
function addOptionSelect(idx) {
    // jQueryオブジェクトの生成
    var $select_op = $('select#selectOption' + idx);
    $('#selectOption' + idx).prop('disabled', false);
    $select_op.selectmenu('refresh');
    $('#selectOption' + idx).append($('<option>').html("&lt;SELECT&gt;").val(0));
    $('#selectOption' + idx).val(0);
    $select_op.selectmenu('refresh');
}

/**
 * [オプション]リスト全クリア処理
 */
function clearAllOption() {
    // jQueryオブジェクトの生成
    var $select_op1 = $('select#selectOption' + Constants.VhcnItemId.OPTION1);
    var $select_op2 = $('select#selectOption' + Constants.VhcnItemId.OPTION2);
    var $select_op3 = $('select#selectOption' + Constants.VhcnItemId.OPTION3);

    $('#selectOption' + Constants.VhcnItemId.OPTION1).prop('disabled', true);
    $select_op1.selectmenu('refresh');
    $('select#selectOption' + Constants.VhcnItemId.OPTION1 + ' option').remove();
    $select_op1.selectmenu('refresh');

    $('#selectOption' + Constants.VhcnItemId.OPTION2).prop('disabled', true);
    $select_op2.selectmenu('refresh');
    $('select#selectOption' + Constants.VhcnItemId.OPTION2 + ' option').remove();
    $select_op2.selectmenu('refresh');

    $('#selectOption' + Constants.VhcnItemId.OPTION3).prop('disabled', true);
    $select_op3.selectmenu('refresh');
    $('select#selectOption' + Constants.VhcnItemId.OPTION3 + ' option').remove();
    $select_op3.selectmenu('refresh');

    opt1_val = 0;
    opt2_val = 0;
    opt3_val = 0;
}

/**
 * 再選択時の車両カテゴリ情報取得API用条件JSON生成処理
 *
 * @param {int} listNum 追加対象の選択リストID
 */
function getSelectCategoryId() {
    return [
        getCategory(Constants.VhcnItemId.DIVIDION),
        getCategory(Constants.VhcnItemId.MODEL),
        getCategory(Constants.VhcnItemId.MODEL_CODE),
        getCategory(Constants.VhcnItemId.ENGINE_MODEL),
    ]
}

/**
 * 選択リスト押下時の車両カテゴリ情報取得API用条件JSON生成処理
 *
 * @param {int} listNum 追加対象の選択リストID
 */
function getClickCategoryId(listNum) {
    var json;
    switch (listNum) {
        case Constants.VhcnItemId.DIVIDION:
            json = [
            ]
            break;
        case Constants.VhcnItemId.MODEL:
            json = [
                getCategory(Constants.VhcnItemId.DIVIDION),
                getCategory(Constants.VhcnItemId.MODEL_CODE),
                getCategory(Constants.VhcnItemId.ENGINE_MODEL),
            ]
            break;
        case Constants.VhcnItemId.MODEL_CODE:
            json = [
                getCategory(Constants.VhcnItemId.DIVIDION),
                getCategory(Constants.VhcnItemId.MODEL),
                getCategory(Constants.VhcnItemId.ENGINE_MODEL),
            ]
            break;
        case Constants.VhcnItemId.ENGINE_MODEL:
            json = [
                getCategory(Constants.VhcnItemId.DIVIDION),
                getCategory(Constants.VhcnItemId.MODEL),
                getCategory(Constants.VhcnItemId.MODEL_CODE),
            ]
            break;
    }

    return json;
}

/**
 * 車両カテゴリ情報取得API用カテゴリー別条件JSON生成処理
 *
 * @param {int} idx 対象のカテゴリーID
 */
function getCategory(idx) {
    var val = Number($("#selectCategory" + idx).val());
    var json = {
        categoryId: idx,
        selectId: val
    }

    return json;
}

/**
 * 車両カテゴリ情報取得API
 * 
 * @param {string} json 選択カテゴリーリスト
 */
function apiSelectVehicleCategory(json) {
    // 診断開始APIの実行
    return WebSocketComponent.executeApiAsync(webSocket = WebSocketComponent.WebSocket, {
        common: {
            apiId: Constants.PlatformApiId.SELECT_VEHICLE_CATEGORY,
            ack: Constants.PlatformApiAckFlag.FALSE,
        },
        apiArgs: {
            selectCategoryList: json,
            busJudge: 0,
            nonDispInfo: "",
        },
        free: {
            freeMsg: "SELECT_VEHICLE_CATEGORY",
        },
    });
}


/**
 * 確定ボタン押下イベント処理
 */
$(document).on("click", "#image_confirm", function () {
    // ローディング画像の表示
    ScreenComponent.displayLoading("processing", "Processing...");
    ScreenComponent.clearApi();

    confirmationProcessing();
});

/**
 * 車両確定処理
 */
function confirmationProcessing() {
    // 車両確定通知API
    apiNotifyVehicleConfirmation().then(function (data) {
        if (Constants.PlatformApiResult.SUCCESS !== data.resultInfo.result) {
            LogManager.info("[API : " + Constants.PlatformApiId.NOTIFY_VEHICLE_CONFIRMATION + "] -----> NG.")
            displayErrorScreen("[API : " + Constants.PlatformApiId.NOTIFY_VEHICLE_CONFIRMATION + "] is failed.");
            return;
        }
        LogManager.info("[API : " + Constants.PlatformApiId.NOTIFY_VEHICLE_CONFIRMATION + "] -----> OK.");
        ScreenComponent.responseApi(data);

        // 機能メニュー表示処理
        viewFuncMenu();

    }).catch(function (e) {
        // 車両確定通知API失敗の場合
        displayErrorScreen(e.message);
        // ローディング画像の非表示
        ScreenComponent.removeLoading("processing");
    });
}

/**
 * 機能メニュー表示処理
 */
function viewFuncMenu() {
    // DK-ISO9141通信初期化API
    //apiInitializeDKISO9141().then(function (data) {
    //    if (Constants.PlatformApiResult.SUCCESS !== data.resultInfo.result) {
    //        LogManager.info("[API : " + Constants.PlatformApiId.INITIALIZE_DK_ISO9141 + "] -----> NG.")
    //        displayErrorScreen("[API : " + Constants.PlatformApiId.INITIALIZE_DK_ISO9141 + "] is failed.");
    //        return;
    //    }
    //    LogManager.info("[API : " + Constants.PlatformApiId.INITIALIZE_DK_ISO9141 + "] -----> OK.");
    //    ScreenComponent.responseApi(data);

        // リモートダイアグDTC送信マスク設定API
        apiSetRemoteDiagSendMask().then(function (data) {
            if (Constants.PlatformApiResult.SUCCESS !== data.resultInfo.result) {
                LogManager.info("[API : " + Constants.PlatformApiId.SET_REMOTE_DIAG_SEND_MASK + "] -----> NG.")
                displayErrorScreen("[API : " + Constants.PlatformApiId.SET_REMOTE_DIAG_SEND_MASK + "] is failed.");
                return;
            }
            LogManager.info("[API : " + Constants.PlatformApiId.SET_REMOTE_DIAG_SEND_MASK + "] -----> OK.");
            ScreenComponent.responseApi(data);

            // 車両例外対応API
            apiReplaceVehicleException().then(function (data) {
                if (Constants.PlatformApiResult.SUCCESS !== data.resultInfo.result) {
                    LogManager.info("[API : " + Constants.PlatformApiId.REPLACE_VEHICLE_EXCEPTION + "] -----> NG.")
                    displayErrorScreen("[API : " + Constants.PlatformApiId.REPLACE_VEHICLE_EXCEPTION + "] is failed.");
                    return;
                }
                LogManager.info("[API : " + Constants.PlatformApiId.REPLACE_VEHICLE_EXCEPTION + "] -----> OK.");
                ScreenComponent.responseApi(data);

                // 機能メニュー画面へ遷移
                ScreenComponent.navigateAsync(Constants.ScreenId.DIAG_001);

            }).catch(function (e) {
                // 車両例外対応API失敗の場合
                displayErrorScreen(e.message);
            }).finally(function () {
                // ローディング画像の非表示
                ScreenComponent.removeLoading("processing");
            });

        }).catch(function (e) {
            // ローディング画像の非表示
            ScreenComponent.removeLoading("processing");
            // リモートダイアグDTC送信マスク設定API失敗の場合
            displayErrorScreen(e.message);
        });
    //}).catch(function (e) {
    //    // ローディング画像の非表示
    //    ScreenComponent.removeLoading("processing");
    //    // DK-ISO9141通信初期化API失敗の場合
    //    displayErrorScreen(e.message);
    //});
}

/**
 * 車両確定通知API処理
 */
function apiNotifyVehicleConfirmation() {
    // 車両確定通知APIの実行
    return WebSocketComponent.executeApiAsync(webSocket = WebSocketComponent.WebSocket, {
        common: {
            apiId: Constants.PlatformApiId.NOTIFY_VEHICLE_CONFIRMATION,
            ack: Constants.PlatformApiAckFlag.FALSE,
        },
        apiArgs: {
            vehicleId: confirmData.vehicleId,
        },
        free: {
            freeMsg: "NOTIFY_VEHICLE_CONFIRMATION",
        },
    });
}

/**
 * DK-ISO9141通信初期化API処理
 */
//function apiInitializeDKISO9141() {
//    // DK-ISO9141通信初期化APIの実行
//    return WebSocketComponent.executeApiAsync(webSocket = WebSocketComponent.WebSocket, {
//        common: {
//            apiId: Constants.PlatformApiId.INITIALIZE_DK_ISO9141,
//            ack: Constants.PlatformApiAckFlag.FALSE,
//        },
//        free: {
//            freeMsg: "INITIALIZE_DK_ISO9141",
//        },
//    });
//}

/**
 * リモートダイアグDTC送信マスク設定API処理
 */
function apiSetRemoteDiagSendMask() {
    // リモートダイアグDTC送信マスク設定APIの実行
    return WebSocketComponent.executeApiAsync(webSocket = WebSocketComponent.WebSocket, {
        common: {
            apiId: Constants.PlatformApiId.SET_REMOTE_DIAG_SEND_MASK,
            ack: Constants.PlatformApiAckFlag.FALSE,
        },
        free: {
            freeMsg: "SET_REMOTE_DIAG_SEND_MASK",
        },
    });
}

/**
 * 車両例外対応API処理
 */
function apiReplaceVehicleException() {
    // 車両例外対応APIの実行
    return WebSocketComponent.executeApiAsync(webSocket = WebSocketComponent.WebSocket, {
        common: {
            apiId: Constants.PlatformApiId.REPLACE_VEHICLE_EXCEPTION,
            ack: Constants.PlatformApiAckFlag.FALSE,
        },
        free: {
            freeMsg: "REPLACE_VEHICLE_EXCEPTION",
        },
    });
}


/**
 * All DTCボタン押下時イベント処理
 */
$(document).on("click", "#button_all_dtc", function () {
    ScreenComponent.clearApi();
    ScreenComponent.navigateAsync(Constants.ScreenId.ALL_DIAG_001).done(function () {
        $.getScript("../Js/all_diag_001.js", function () {
            initialize_all_diag_001();
        });
    });
});

/**
 * 画面項目表示処理
 * 
 * @param {Object} data レスポンスデータ（categoryNameList）
 * @param {int} type 確認画面識別（1：確認画面①、2：確認画面➁）
 */
function viewConfirm1(data, type) {
    // ローディング画像の非表示
    ScreenComponent.removeLoading("loading");

    // 画面表示項目_言語別設定
    var language = Constants.LanguageId.LANGUAGE[languageId];
    var path = Constants.SystemConstant.DYNAMIC_LOADING_JS_PATH + "Lang/" + language + "/constants_lang.js";

    // 確認画面へ遷移
    ScreenComponent.navigateAsync(Constants.ScreenId.DIAG_CONFIRM_002).done(function () {
        // 言語別ファイルの読込
        $.getScript(path, function () {
            // Title
            $('#title').text(Constants_Launuege.Confirmation.CONFIRMATION_MSG);
            // 車両IDの設定
            $('#table_info tr').eq(0).children('th').eq(0).text(Constants_Launuege.Confirmation.VEHICLE_ID);
            $('#table_info tr').eq(0).children('td').eq(0).text(data.apiArgs.vehicleId);
            // VINの設定
            $('#table_info tr').eq(1).children('th').eq(0).text(Constants_Launuege.Confirmation.VIN);
            $('#table_info tr').eq(1).children('td').eq(0).text(data.apiArgs.vin);
            // 確認画面①or➁
            $('#confirmType').val(type);
        });
    });
}

/**
 * Yesボタン押下時イベント処理
 */
$(document).on("click", "#button_yes", function () {
    ScreenComponent.clearApi();
    var val = $('#confirmType').val();
    // 処理中画像の表示
    ScreenComponent.displayLoading("processing", "Processing...");

    // 確認画面①
    if (val === "1") {
        // 車両ID確定API
        apiSetVehicleId().then(function (data) {
            // 車両ID確定APIの実行結果が失敗の場合
            if (Constants.PlatformApiResult.SUCCESS !== data.resultInfo.result) {
                LogManager.info("[API : " + Constants.PlatformApiId.SET_VEHICLE_ID + "] -----> NG.");
                displayErrorScreen("[API : " + Constants.PlatformApiId.SET_VEHICLE_ID + "] is failed.");
                return;
            }
            LogManager.info("[API : " + Constants.PlatformApiId.SET_VEHICLE_ID + "] -----> OK.");
            ScreenComponent.responseApi(data);

            confirmationProcessing();
        }).catch(function (e) {
            // 車両ID確定API失敗の場合
            displayErrorScreen(e.message);
        });

    // 確認画面➁
    } else if (val === "2") {
        // 機能メニュー表示処理
        viewFuncMenu();

    } else {
        // 存在しない
    }
});

/**
 * 車両ID確定API
 */
function apiSetVehicleId() {
    // 確定時の選択項目からタイトルに選択車両の情報を出力
    var val = Number($('#table_info tr').eq(0).children('td').eq(0).text());

    // 車両ID確定APIの実行
    return WebSocketComponent.executeApiAsync(webSocket = WebSocketComponent.WebSocket, {
        common: {
            apiId: Constants.PlatformApiId.SET_VEHICLE_ID,
            ack: Constants.PlatformApiAckFlag.FALSE,
        },
        apiArgs: {
            idList: idListIdConfirm,
            vehicleId: val,
        },
        free: {
            freeMsg: "SET_VEHICLE_ID",
        },
    });
}

/**
 * Noボタン押下時イベント処理
 */
$(document).on("click", "#button_no", function () {
    // 処理中画像の表示
    ScreenComponent.displayLoading("processing", "Processing...");
    ScreenComponent.clearApi();

    // 強制診断終了API
    apiForcedEndDiagnosis().then(function (data) {
        // 強制診断終了APIの実行結果が失敗の場合
        if (Constants.PlatformApiResult.SUCCESS !== data.resultInfo.result) {
            LogManager.info("[API : " + Constants.PlatformApiId.FORCED_END_DIAGNOSISON + "] -----> NG.");
            displayErrorScreen("[API : " + Constants.PlatformApiId.FORCED_END_DIAGNOSISON + "] is failed.");
            return;
        }
        LogManager.info("[API : " + Constants.PlatformApiId.FORCED_END_DIAGNOSISON + "] -----> OK.");
        ScreenComponent.responseApi(data);

        location.reload(true);
    }).catch(function (e) {
        // 強制診断終了API失敗の場合
        displayErrorScreen(e.message);
    });
});


/**
 * 強制診断終了API
 * 
 */
function apiForcedEndDiagnosis() {
    ScreenComponent.clearApi();
    // 診断開始APIの実行
    return WebSocketComponent.executeApiAsync(webSocket = WebSocketComponent.WebSocket, {
        common: {
            apiId: Constants.PlatformApiId.FORCED_END_DIAGNOSISON,
            ack: Constants.PlatformApiAckFlag.FALSE,
        },
        free: {
            freeMsg: "FORCED_END_DIAGNOSISON",
        },
    });
}


/**
 * エラー発生時処理
 * 
 * @param {Object} event イベント
 */
function onError(event) {
    //displayErrorScreen(event.message);
}

/**
 * エラー画面表示処理
 * 
 * @param {String} message エラーメッセージ
 */
function displayErrorScreen(message) {
    // エラー画面表示
    LogManager.error("MSG" + message);
    //$("#label_modal_confirmation").text("Failed to connect to the server.");
    ScreenComponent.navigateAsync(Constants.ScreenId.ERR_001).done(function () {
        $("#error_message").text(message);
        // ローディング画像の非表示
        ScreenComponent.removeLoading("loading");
        ScreenComponent.removeLoading("processing");
    });

    apiEndDiagnosis().then(function (data) {
        ScreenComponent.responseApi(data);
    }).catch(function (e) {
        // 診断終了API失敗の場合
        displayErrorScreen(e.message);
    });
}




/**
 * 車両接続ボタン押下時イベント処理
 */
$(document).on("click", "#button_connect_to_vehicle", function () {
    ScreenComponent.clearApi();
    //apiEndDiagnosis();
});

/**
 * 診断終了API
 * 
 */
function apiEndDiagnosis() {
    // 診断終了APIの実行
    return WebSocketComponent.executeApiAsync(webSocket = WebSocketComponent.WebSocket, {
        common: {
            apiId: Constants.PlatformApiId.END_DIAGNOSIS,
            ack: Constants.PlatformApiAckFlag.FALSE,
        },
        free: {
            freeMsg: "END_DIAGNOSIS",
        },
    });
}
