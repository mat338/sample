/**
 * all_diag_001画面のscript
 */
// ECUグループ表示/非表示フラグ
viewFlgPowertrain = true;
viewFlgChassis = true;
viewFlgBody = true;

// ECU一覧
var ecuListData = new Map();
var resultListData;

// Free Message
const FREE_MSG_CHECK_ECU_CONNECT = "CHECK_ECU_CONNECT:";
const FREE_MSG_REPLACE_SYSTEM_EXCEPTION = "REPLACE_SYSTEM_EXCEPTION:";
const FREE_MSG_GET_ECU_FUNC_LIST = "GET_ECU_FUNC_LIST:";
const FREE_MSG_GET_DTC = "GET_DTC:";

// ステータス
const DTC_EXIST = "DTC_EXIST";          // 赤枠DTCあり
const DTC_NOT_EXIST = "DTC_NOT_EXIST";  // 青枠DTCなし
const ABSENCE = "ABSENCE";              // 白枠ノットサポート
const PROCESSING = "PROCESSING";        // 白枠ぐるぐる


/**
 * 初期化処理
 */
function initialize_all_diag_001() {
    // ローディング画像の表示
    switchConnectionStartMode("loading", "Connecting...");

    // ①:ECU機能リスト取得API
    apiGetMountEcuList().then(function (data) {
        if (Constants.PlatformApiResult.SUCCESS !== data.resultInfo.result) {
            LogManager.info("[API : " + Constants.PlatformApiId.GET_MOUNT_ECU_LIST + "] -----> NG.")
            displayErrorScreen("[API : " + Constants.PlatformApiId.GET_MOUNT_ECU_LIST + "] is failed.");
        }
        LogManager.info("[API : " + Constants.PlatformApiId.GET_MOUNT_ECU_LIST + "] -----> OK.");
        ScreenComponent.responseApi(data);

        // ECU接続確認の返却値から取得したECUの数だけ処理を行う
        var ecuGroupNum = Object.keys(data.apiArgs.ecuGroupList).length;
        for (i = 0; i < ecuGroupNum; i++) {
            for (j = 0; j < Object.keys(data.apiArgs.ecuGroupList[i].ecuInfoList).length; j++) {

                if (typeof data.apiArgs !== 'undefined' && typeof data.apiArgs.ecuGroupList !== 'undefined') {
                    var resData = new Object();
                    resData.groupId = data.apiArgs.ecuGroupList[i].id;  // グループID

                    // グループIDからグループを判別
                    var result = "";
                    var remainder = resData.groupId % 3;
                    switch (remainder) {
                        case 1:
                            result = "POWERTRAIN";
                            break;

                        case 2:
                            result = "CHASSIS";
                            break;

                        case 0:
                            if (resData.groupId !== 0) {
                                result = "BODY";
                            }
                            break;
                    }
                    resData.group = remainder;
                    resData.groupName = result;

                    resData.ecuId = data.apiArgs.ecuGroupList[i].ecuInfoList[j].ecuId;          // ECU ID
                    resData.ecuName = data.apiArgs.ecuGroupList[i].ecuInfoList[j].ecuName;      // ECU Name
                    resData.busId = data.apiArgs.ecuGroupList[i].ecuInfoList[j].busId;          // バス種別
                    resData.phaseType = data.apiArgs.ecuGroupList[i].ecuInfoList[j].phaseType;  // フェーズ種別

                    resData.view = PROCESSING;
                    ecuListData.set(resData.ecuId, resData);
                }
            }
        }

        // ECU一覧表示
        createSlickEcuGroup(ecuListData);

        // 画面表示
        ScreenComponent.removeLoading("loading");

        // 受信処理を[ECU接続確認]用に変更する
        WebSocketComponent.recMessage(onMessage = onMessage, onError = onError);

        resultListData = new Map();
        // ➁:ECU接続確認APIをすべて送信
        for (var value of ecuListData.values()) {
            // ECU接続確認API
            apiCheckECUConnect(value.groupId, value.ecuId, value.busId);
        }

        // レスポンス結果を全て取得
        executeApiResult(ecuListData.size, 90).then(function (data) {
            LogManager.info("CheckECUConnect End... : " + resultListData.size);
            // ECU接続確認APIの結果を取得
            for (var value of ecuListData.values()) {
                var ecuId = value.ecuId;
                value.connect = resultListData.get(ecuId);
                // 画面表示ステータスの設定[‐1 未確認、0 未接続、1 接続]
                if (value.connect !== 1) {
                    // [1:ECU接続]以外は対象外にする
                    value.view = ABSENCE;
                }
                ecuListData.set(ecuId, value);
            }

            // 画面再表示
            viewShow();

            resultListData = new Map();
            var cnt = 0;
            // ➂:システム例外対応APIをすべて送信
            for (var value of ecuListData.values()) {
                    // 処理中場合のみAPIを送信する
                if (value.view === PROCESSING) {
                    // システム例外対応API
                    apiReplaceSystemException(value.ecuId);
                    cnt++;
                }
            }

            // レスポンス結果を全て取得
            executeApiResult(cnt, 30).then(function (data) {
                LogManager.info("ReplaceSystemException End... : " + resultListData.size);
                // システム例外対応APIの結果を取得
                for (var value of ecuListData.values()) {
                    // 処理中の場合のみ結果の判定を行う
                    if (value.view === PROCESSING) {
                        var ecuId = value.ecuId;
                        // API結果が失敗の場合
                        if (Constants.PlatformApiResult.SUCCESS !== resultListData.get(ecuId)) {
                            // API失敗時は対象外にする
                            value.view = ABSENCE;
                            ecuListData.set(ecuId, value);
                        }
                    }
                }

                // 画面再表示
                viewShow();

                resultListData = new Map();
                cnt = 0;
                // ④:ECU機能リスト取得APIをすべて送信
                for (var value of ecuListData.values()) {
                    // 処理中場合のみAPIを送信する
                    if (value.view === PROCESSING) {
                        // ECU機能リスト取得API
                        apiGetECUFuncList(value.ecuId);
                        cnt++;
                    }
                }

                // レスポンス結果を全て取得
                executeApiResult(cnt, 30).then(function (result) {
                    LogManager.info("GetECUFuncList End... : " + resultListData.size);
                    // ECU機能リスト取得APIの結果を取得
                    for (var value of ecuListData.values()) {
                        // 処理中の場合のみ結果の判定を行う
                        if (value.view === PROCESSING) {
                            var ecuId = value.ecuId;
                            var data = resultListData.get(ecuId);
                            // API結果が失敗の場合
                            if (Constants.PlatformApiResult.SUCCESS !== data.resultInfo.result) {
                                // API失敗時は対象外にする
                                value.view = ABSENCE;
                                ecuListData.set(ecuId, value);
                            }

                            // 有効な機能ID(大分類)が一つも存在しない場合
                            if (typeof data.apiArgs === 'undefined' || typeof data.apiArgs.ecuFuncList === 'undefined') {
                                // 取得失敗時は対象外にする
                                value.view = ABSENCE;
                                ecuListData.set(ecuId, value);
                            }

                            // ECU機能リスト取得
                            value.ecuFunctionList = data.apiArgs.ecuFuncList;
                            ecuListData.set(ecuId, value);

                            // DTC機能対象判定
                            judgDtcTarget(ecuId);
                        }
                    }

                    // 画面再表示
                    viewShow();

                    resultListData = new Map();
                    cnt = 0;
                    var getDtcData;
                    // ⑤:DTC取得APIをすべて送信
                    for (var value of ecuListData.values()) {
                        // 処理中場合のみAPIを送信する
                        if (value.view === PROCESSING) {
                            // Request引数オブジェクト生成
                            getDtcData = new Object();
                            getDtcData.ecuId = value.ecuId;
                            getDtcData.busId = value.busId;
                            getDtcData.phaseType = value.phaseType;
                            getDtcData.getDtcId = value.getDtcId;
                            getDtcData.getDtcDetailId = value.getDtcDetailId;
                            getDtcData.legalCommunication = value.legalCommunication;
                            getDtcData.legalCommunicationList = value.legalCommunicationList;

                            // DTC取得API
                            apiGetDtc(getDtcData);
                            cnt++;
                        }
                    }

                    // レスポンス結果を全て取得
                    executeApiResult(cnt, 30).then(function (result) {
                        LogManager.info("GetDtc End... : " + resultListData.size);

                        // DTC取得APIの結果を取得
                        for (var value of ecuListData.values()) {
                            // 処理中の場合のみ結果の判定を行う
                            if (value.view === PROCESSING) {
                                var ecuId = value.ecuId;
                                var data = resultListData.get(ecuId);
                                // API結果が失敗の場合
                                if (Constants.PlatformApiResult.SUCCESS !== data.resultInfo.result) {
                                    // API失敗時は対象外にする
                                    value.view = ABSENCE;
                                    ecuListData.set(ecuId, value);
                                }

                                // レスポンスにダイアグコードリストが含まれていない場合
                                if (typeof data.apiArgs === 'undefined' || typeof data.apiArgs.dtcList === 'undefined') {
                                    // 取得失敗時はDTC対象外にする
                                    value.view = DTC_NOT_EXIST;
                                } else {
                                    // 取得成功時はDTC対象にする
                                    value.view = DTC_EXIST;
                                    value.dtcList = data.apiArgs.dtcList;
                                }
                                ecuListData.set(ecuId, value);
                            }
                        }

                        // 画面再表示
                        viewShow();

                    });

                });
            });
        });

        // 受信処理を[WebSocketComponent]のonMessageに戻す
        //WebSocketComponent.restoreMessage();

    }).catch(function (e) {
        // ECU機能リスト取得API失敗の場合
        displayErrorScreen(e.message);
    });

}

/**
 * 再表示処理
 */
function show_again_all_diag_001() {
    // ローディング画像の表示
    switchConnectionStartMode("loading", "Connecting...");

    // 画面再表示
    createSlickEcuGroup();

    // ECUグループ非表示処理
    if (!viewFlgPowertrain) {
        $('#image_power_train').prop('src', '../Image/power_train_inactive.png');
        viewHide(Constants.ecuGroup.POWER_TRAIN);
    }
    if (!viewFlgChassis) {
        $('#image_chassis').prop('src', '../Image/chassis_inactive.png');
        viewHide(Constants.ecuGroup.CHASSIS);
    }
    if (!viewFlgBody) {
        $('#image_body').prop('src', '../Image/body_inactive.png');
        viewHide(Constants.ecuGroup.BODY);
    }

    // 画面表示
    ScreenComponent.removeLoading("loading");
}

/*
 * ECU一覧表示
 */
function createSlickEcuGroup() {
    // ECU一覧の展開
    for (var value of ecuListData.values()) {
        // 赤枠DTCあり
        p_tag_dtc_exist = "<div name=" + value.group + " class='relativeBoxDtc'>";
        p_tag_dtc_exist += "<P name=" + value.group + " class='box_dtc_exist' data-id=" + value.ecuId + " data-name='" + value.ecuName + "'>" + value.ecuName + "</P>";
        p_tag_dtc_exist += "<div class='status'><img id='image_dtc' src='../Image/dtc.png' alt='There is a DTC.'></img></div></div>";
        // 青枠DTCなし
        p_tag_dtc_not_exist = "<P name=" + value.group + " id='image_not_dtc' class='box_dtc_not_exist' data-name='" + value.ecuName + "'>" + value.ecuName + "</P>";
        // 白枠ノットサポート
        p_tag_absence = "<div name=" + value.group + " class='relativeBoxAbsence'>";
        p_tag_absence += "<P name=" + value.group + " class='box_absence' data-name='" + value.ecuName + "'>" + value.ecuName + "</P>";
        p_tag_absence += "<div class='status'><img id='image_absence' src='../Image/ecu_not_supported.png' alt='ECU not supported or not responding.'></img></div></div>";
        // 白枠ぐるぐる
        p_tag_processing = "<div name=" + value.group + " class='relativeBoxProcessing'>";
        p_tag_processing += "<P name=" + value.group + " class='box_absence' data-name='" + value.ecuName + "'>" + value.ecuName + "</P>";
        p_tag_processing += "<div class='status'><img id='image_processing' src='../Image/processing_all_diag.gif'></img></div></div>";

        // 画面表示設定
        p_tag = "";
        switch (value.view) {
            case DTC_EXIST: // 赤枠DTCあり
                p_tag = p_tag_dtc_exist;
                break;
            case DTC_NOT_EXIST: // 青枠DTCなし
                p_tag = p_tag_dtc_not_exist;
                break;
            case ABSENCE:   // 白枠ノットサポート
                p_tag = p_tag_absence;
                break;
            default:        // 白枠ぐるぐる
                p_tag = p_tag_processing;
                break;
        }

        // 表示項目として追加
        if (value.group === Constants.ecuGroup.POWER_TRAIN && viewFlgPowertrain) {
            $('div[id=slider]').append(p_tag);
        } else if (value.group === Constants.ecuGroup.CHASSIS && viewFlgChassis) {
            $('div[id=slider]').append(p_tag);
        } else if (value.group === Constants.ecuGroup.BODY && viewFlgBody) {
            $('div[id=slider]').append(p_tag);
        } else {
            // 追加しない
        }
    }

    // Slick表示
    setSlick();
}

/*
 * Slick表示設定
 */
function setSlick() {
    $('.slider').slick({
        autoplay: true,         // 自動スクロール
        autoplaySpeed: 10000,   // スクロール間隔（秒）
        dots: true,
        slidesToShow: 8,        // ８項目（ECU）表示
        slidesToScroll: 8       // スライド項目数
    });
}

/*
 * ダイアグ取得対象判定
 * 
 * @param {int} ecuId ECU ID
 */
function judgDtcTarget(ecuId) {
    var value = ecuListData.get(ecuId);

    var dtcTarget = true;
    // 機能ID
    var dtcTarget_1 = false;    // 1:ダイアグ・フリーズ
    var dtcTarget_16 = false;   // 16:ダイアグ確認
    var dtcTarget_30 = false;   // 30:ダイアグ・フリーズP5
    var dtcTarget_32 = false;   // 32:法規確認
    // 機能詳細ID
    var dtcTargetDetail_1_16 = false;
    var dtcTargetDetail_30 = false;
    // 対象機能詳細IDリスト
    var arrDetailList = [];
    var arrRegalDetailList = [];

    for (i = 0; i < value.ecuFunctionList.length; i++) {
        id = value.ecuFunctionList[i].id;

        // ①:DTC取得対象判定(id = 1 or 16)
        // 機能IDが1もしくは16を含む場合はDTC取得に対応
        if (id === Constants.ecuFunctionId.DTC_FFD || id === Constants.ecuFunctionId.CHECK_DTC) {
            // 機能詳細ID確認
            if (typeof value.ecuFunctionList[i].ecuFuncDetailIdList !== 'undefined') {
                for (j = 0; j < value.ecuFunctionList[i].ecuFuncDetailIdList.length; j++) {
                    // 機能詳細ID
                    detailId = value.ecuFunctionList[i].ecuFuncDetailIdList[j].id;
                    if (Constants.ecuFunctionDetailId.TARGET_DTC_FFD_CHECK_DTC[detailId]) {
                        // 含まれていた場合はOK
                        dtcTargetDetail_1_16 = true;
                        arrDetailList.push(retFuncDetail(detailId));
                    }
                }
            }
        }

        if (id === Constants.ecuFunctionId.DTC_FFD) {
            // 機能詳細ID確認チェックOKの場合
            if (dtcTargetDetail_1_16) {
                dtcTarget_1 = true;
            }
        }
        if (id === Constants.ecuFunctionId.CHECK_DTC) {
            // 機能詳細ID確認チェックOKの場合
            if (dtcTargetDetail_1_16) {
                dtcTarget_16 = true;
            }
        }

        // ➁:P5DTC取得対象判定(id = 30)
        // 機能IDが30を含む場合は、P5DTC取得に対応
        if (id === Constants.ecuFunctionId.DTC_FFD_P5) {
            // 機能詳細ID確認
            if (typeof value.ecuFunctionList[i].ecuFuncDetailIdList !== 'undefined') {
                for (j = 0; j < value.ecuFunctionList[i].ecuFuncDetailIdList.length; j++) {
                    // 機能詳細ID
                    detailId = value.ecuFunctionList[i].ecuFuncDetailIdList[j].id;
                    if (Constants.ecuFunctionDetailId.TARGET_DTC_FFD_P5[detailId]) {
                        // 含まれていた場合はOK
                        dtcTargetDetail_30 = true;
                        arrDetailList.push(retFuncDetail(detailId));
                    }
                }
            }

            // 機能詳細ID確認チェックOKの場合
            if (dtcTargetDetail_30) {
                dtcTarget_30 = true;
            }
        }

        // ➂:法規通信対象判定(id = 32)
        if (id === Constants.ecuFunctionId.CHECK_REGULATORY_COMMUNICATION) {
            dtcTargetDetail_32 = false;
            if (typeof value.ecuFunctionList[i].ecuFuncDetailIdList !== 'undefined') {
                for (j = 0; j < value.ecuFunctionList[i].ecuFuncDetailIdList.length; j++) {
                    // 機能詳細ID
                    detailId = value.ecuFunctionList[i].ecuFuncDetailIdList[j].id;
                    if (Constants.ecuFunctionDetailId.TARGET_CHECK_REGULATORY_COMMUNICATION[detailId]) {
                        // 含まれていた場合はOK
                        dtcTargetDetail_32 = true;
                        arrRegalDetailList.push(retFuncDetail(detailId));
                    }
                }
            }

            // 機能詳細ID確認チェックOKの場合
            if (dtcTargetDetail_32) {
                // 法規通信対象
                dtcTarget_32 = true;
            }
        }
    }

    // DTC機能非対称判定
    // 以下の条件を満たしていた場合、対象のECUはDTC取得非対象
    // ①、②のケースが含まれない
    if (!dtcTarget_1 && !dtcTarget_16 && !dtcTarget_30) {
        dtcTarget = false;
    }
    // 1 and 16（両方含まれる）
    if (dtcTarget_1 && dtcTarget_16) {
        dtcTarget = false;
    }
    // 1 and 30（両方含まれる）又は16 and 30（両方含まれる）
    if ((dtcTarget_1 || dtcTarget_16) && dtcTarget_30) {
        dtcTarget = false;
    }

    // DTC対象結果処理
    if (dtcTarget) {
        // DTC対象
        if (dtcTarget_1) {
            value.getDtcId = Constants.ecuFunctionId.DTC_FFD;
        } else if (dtcTarget_16) {
            value.getDtcId = Constants.ecuFunctionId.CHECK_DTC;
        } else if (dtcTarget_30) {
            value.getDtcId = Constants.ecuFunctionId.DTC_FFD_P5;
        }
        value.getDtcDetailId = arrDetailList;
        // 法規通信
        value.legalCommunication = dtcTarget_32;
        value.legalCommunicationList = arrRegalDetailList;

    } else if (!dtcTargetDetail_1_16 && !dtcTargetDetail_30) {
        // 機能詳細不正
        value.view = ABSENCE;

    } else {
        // DTC対象外
        value.view = ABSENCE;
    }
    ecuListData.set(ecuId, value);
}

/**
 * ECU機能リスト取得API処理
 * 
 * @param {Object} data レスポンスデータ
 */
function apiGetMountEcuList() {
    // ECU機能リスト取得APIの実行
    return WebSocketComponent.executeApiAsync(webSocket = WebSocketComponent.WebSocket, {
        common: {
            apiId: Constants.PlatformApiId.GET_MOUNT_ECU_LIST,
            ack: Constants.PlatformApiAckFlag.FALSE,
        },
        free: {
            freeMsg: "GET_MOUNT_ECU_LIST",
        },
    });
}

/**
 * ECU接続確認API処理
 * 
 * @param {int} groupId ECUグループID
 * @param {int} ecuId ECU ID
 * @param {int} busId 種別ID
 * 
 * @param {Object} data レスポンスデータ
 */
function apiCheckECUConnect(groupId, ecuId, busId) {
    // ECU接続確認APIの実行
    return executeApiAsync(webSocket = WebSocketComponent.WebSocket, {
        common: {
            apiId: Constants.PlatformApiId.CHECK_ECU_CONNECT,
            ack: Constants.PlatformApiAckFlag.FALSE,
        },
        apiArgs: {
            groupId: groupId,
            ecuId: ecuId,
            busId: busId,
        },
        free: {
            freeMsg: FREE_MSG_CHECK_ECU_CONNECT + ecuId,
        },
    });
}

/**
 * システム例外対応API処理
 * 
 * @param {int} ecuId ECU ID
 * 
 * @param {Object} data レスポンスデータ
 */
function apiReplaceSystemException(ecuId) {
    // ECU接続確認APIの実行
    return executeApiAsync(webSocket = WebSocketComponent.WebSocket, {
        common: {
            apiId: Constants.PlatformApiId.REPLACE_SYSTEM_EXCEPTION,
            ack: Constants.PlatformApiAckFlag.FALSE,
        },
        apiArgs: {
            ecuId: ecuId,
        },
        free: {
            freeMsg: FREE_MSG_REPLACE_SYSTEM_EXCEPTION + ecuId,
        },
    });
}

/**
 * ECU機能リスト取得API処理
 * 
 * @param {int} ecuId ECU ID
 */
function apiGetECUFuncList(ecuId) {
    // ECU機能リスト取得APIの実行
    return executeApiAsync(webSocket = WebSocketComponent.WebSocket, {
        common: {
            apiId: Constants.PlatformApiId.GET_ECU_FUNC_LIST,
            ack: Constants.PlatformApiAckFlag.FALSE,
        },
        apiArgs: {
            ecuId: ecuId,
        },
        free: {
            freeMsg: FREE_MSG_GET_ECU_FUNC_LIST + ecuId,
        },
    });
}

/**
 * ECU機能リスト取得API処理
 * 
 * @param {int} id 機能詳細ID
 */
function retFuncDetail(id) {
    return {
        getDtcDetailId: id,
    }
    //option: 0,
}

/**
 * DTC取得API処理
 * 
 * @param {Object} data オブジェクトデータ
 * 
 * @return {Object} data レスポンスデータ
 */
function apiGetDtc(data) {
    if (data.legalCommunication && data.getDtcId !== Constants.ecuFunctionId.DTC_FFD_P5) {
        // DTC取得APIの実行
        return executeApiAsync(webSocket = WebSocketComponent.WebSocket, {
            common: {
                apiId: Constants.PlatformApiId.GET_DTC,
                ack: Constants.PlatformApiAckFlag.FALSE,
            },
            apiArgs: {
                ecuId: data.ecuId,
                busId: data.busId,
                phaseType: data.phaseType,
                getDtcList: [
                    getDtcList(data),
                    getRegalList(data),
                ],
            },
            free: {
                freeMsg: FREE_MSG_GET_DTC + data.ecuId,
            },
        });
    } else {
        // DTC取得APIの実行
        return executeApiAsync(webSocket = WebSocketComponent.WebSocket, {
            common: {
                apiId: Constants.PlatformApiId.GET_DTC,
                ack: Constants.PlatformApiAckFlag.FALSE,
            },
            apiArgs: {
                ecuId: data.ecuId,
                busId: data.busId,
                phaseType: data.phaseType,
                getDtcList: [
                    getDtcList(data),
                ],
            },
            free: {
                freeMsg: FREE_MSG_GET_DTC + data.ecuId,
            },
        });
    }
}

/*
 * DTC取得用getDtcList-JSON取得
 * 
 * @param {Object} data オブジェクトデータ
 * 
 * @return {String} JSON
 */
function getDtcList(data) {
    var json = {
        getDtcId: data.getDtcId,
        getDtcDetailList: data.getDtcDetailId,
    }
    return json;
}

/*
 * DTC取得用getRegalList-JSON取得
 * 
 * @param {Object} data オブジェクトデータ
 * 
 * @return {String} JSON
 */
function getRegalList(data) {
    var json = {
        getDtcId: Constants.ecuFunctionId.CHECK_REGULATORY_COMMUNICATION,
        getDtcDetailList: data.legalCommunicationList,
    }
    return json;
}

/*
 * Power Train押下処理
 */
$(document).on("click", "#image_power_train", function () {
    if (viewFlgPowertrain) {
        $('#image_power_train').prop('src', '../Image/power_train_inactive.png');
        viewFlgPowertrain = false;
        viewHide(Constants.ecuGroup.POWER_TRAIN);

    } else {
        $('#image_power_train').prop('src', '../Image/power_train_active.png');
        viewFlgPowertrain = true;
        viewShow();
    }
});

/*
 * Chassis押下処理
 */
$(document).on("click", "#image_chassis", function () {
    if (viewFlgChassis) {
        $('#image_chassis').prop('src', '../Image/chassis_inactive.png');
        //$("p").filter('.box_dtc_yes').hide();//.css('border', 'solid 1px Red');
        //$("p").filter('p[name=1]').hide();
        viewFlgChassis = false;
        viewHide(Constants.ecuGroup.CHASSIS);

    } else {
        $('#image_chassis').prop('src', '../Image/chassis_active.png');
        //$("p").show();
        //$('.slider').slick('slickFilter', '.filter');
        viewFlgChassis = true;
        viewShow();
    }
});

/*
 * Body押下処理
 */
$(document).on("click", "#image_body", function () {
    if (viewFlgBody) {
        $('#image_body').prop('src', '../Image/body_inactive.png');
        viewFlgBody = false;
        viewHide(Constants.ecuGroup.BODY);

    } else {
        $('#image_body').prop('src', '../Image/body_active.png');
        viewFlgBody = true;
        viewShow();
    }
});

/*
 * 非表示処理
 */
function viewHide(idx) {
    $('.slider').slick('unslick');
    $("p[name=" + idx + "]").remove();
    $("div[name=" + idx + "]").remove();
    setSlick();
}

/*
 * 再表示処理
 */
function viewShow() {
    $('.slider').slick('unslick');
    // slider構成要素をすべてクリア
    $(".relativeBoxDtc").remove();
    $(".relativeBoxAbsence").remove();
    $(".relativeBoxProcessing").remove();
    $("p[name=" + Constants.ecuGroup.POWER_TRAIN + "]").remove();
    $("p[name=" + Constants.ecuGroup.CHASSIS + "]").remove();
    $("p[name=" + Constants.ecuGroup.BODY + "]").remove();
    // sliderの再構成
    createSlickEcuGroup();
}

/*
 * ECU枠押下処理
 */
$(document).on("click", "p", function () {
    var clickId = $(this).data('id');
    var clickName = $(this).data('name');
    if (typeof clickId === "undefined") {
        // 空の<P>タグは空振りさせる
        //LogManager.info("undefined return");
        return;

    } else {
        //LogManager.info(clickId + ":" + clickName);
        ScreenComponent.navigateAsync(Constants.ScreenId.ALL_DIAG_002).done(function () {
            $.getScript("../Js/all_diag_002.js", function () {
                initialize_all_diag_002(clickId, clickName);
            });
        });
    }
});

/**
 * WebSocketComponent - メッセージ受信時処理
 * 
 * @param {Object} event イベント
 */
function onMessage(event) {
    LogManager.info("All Diag Message arrived. Details : " + event.data + " : " + resultListData.size);
    var responce = JSON.parse(event.data)

    // レスポンス結果格納
    if (typeof responce.common.apiId !== 'undefined') {
        ScreenComponent.responseApi(responce);
        // APID別に格納
        switch (responce.common.apiId) {
            case Constants.PlatformApiId.CHECK_ECU_CONNECT:
                // ECU IDの抽出
                if (responce.free.freeMsg) {
                    var ecuId = Number(responce.free.freeMsg.replace(FREE_MSG_CHECK_ECU_CONNECT, ""));
                }

                // ECU接続確認[DV000005]
                resultListData.set(ecuId, responce.apiArgs.connect);
                break;
            case Constants.PlatformApiId.REPLACE_SYSTEM_EXCEPTION:
                // ECU IDの抽出
                if (responce.free.freeMsg) {
                    var ecuId = Number(responce.free.freeMsg.replace(FREE_MSG_REPLACE_SYSTEM_EXCEPTION, ""));
                }

                // システム例外対応[DV000067]
                //LogManager.info("All Diag Message arrived. Details : " + event.data);
                resultListData.set(ecuId, responce.resultInfo.result);
                break;
            case Constants.PlatformApiId.GET_ECU_FUNC_LIST:
                // ECU IDの抽出
                if (responce.free.freeMsg) {
                    var ecuId = Number(responce.free.freeMsg.replace(FREE_MSG_GET_ECU_FUNC_LIST, ""));
                }

                // ECU機能リスト取得[DV000006]
                //LogManager.info("All Diag Message arrived. Details : " + event.data);
                resultListData.set(ecuId, responce);
                break;
            case Constants.PlatformApiId.GET_DTC:
                // ECU IDの抽出
                if (responce.free.freeMsg) {
                    var ecuId = Number(responce.free.freeMsg.replace(FREE_MSG_GET_DTC, ""));
                }

                // ECU機能リスト取得[DV000008]
                //LogManager.info("All Diag Message arrived. Details : " + event.data);
                resultListData.set(ecuId, responce);
                break;
        }
    }
}

/**
 * WebSocketComponent - API送信処理
 * 
 * @param {Object} webSocket WebSocket接続
 * @param {Object} data APIリクエストデータ
 */
function executeApiAsync(webSocket, data) {
    // APIの実行
    var jData = JSON.stringify(data);
    webSocket.send(JSON.stringify(data));
    LogManager.info("execute send only JSON:" + jData);
}

/**
 * WebSocketComponent - [非同期]API実行処理
 * 
 * @param {Object} webSocket WebSocket接続
 * @param {Object} data APIリクエストデータ
 * @return {Object}
 */
function executeApiResult(size, timeout) {
    // API実行結果の取得
    return new Promise(function (resolve, reject) {
        // 開始日時の取得
        var startTime = new Date().getTime();

        // 非同期処理
        var id = setInterval(function () {
            //LogManager.info("resultListData.size : " + resultListData.size);
            if (resultListData.size >= size) {
                // 終了
                clearInterval(id);
                resolve(true);

            } else {
                // 終了判定
                var endTime = new Date().getTime();
                if ((endTime - startTime) / Constants.SystemConstant.TO_SECONDS >= timeout) {
                    // 終了
                    clearInterval(id);
                    reject(new Error("Timeout : " + resultListData.size));
                }
            }
        }, Constants.WebSocketSetting.RECEIVING_PROCESS_INTERVAL_MILLISECONDS);
    });
}


$(document).on("click", "#button_Diag_end", function () {
    apiEndDiagnosis();
});
