﻿using GtsPlus_TestScreenServer.Constant;
using GtsPlus_TestScreenServer.Utils;
using log4net;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Web;

namespace GtsPlus_TestScreenServer.Component
{
    /// <summary>
    /// HTTPサーバ用コンポーネントクラス
    /// </summary>
    public class HttpServerComponent : IDisposable
    {
        /// <summary>
        /// log4net
        /// </summary>
        private readonly ILog logger = LogManager.GetLogger(typeof(HttpServerComponent));

        /// <summary>
        /// バイナリの拡張子
        /// </summary>
        private static readonly string[] BINARY_EXTENSIONS = { Constants.EXTENSION.JPG, Constants.EXTENSION.PNG, Constants.EXTENSION.GIF, Constants.EXTENSION.ICO, Constants.EXTENSION.EOT, Constants.EXTENSION.TTF, Constants.EXTENSION.WOFF, Constants.EXTENSION.SVG };

        /// <summary>
        /// バッファサイズ
        /// </summary>
        private static readonly int BUFFER_SIZE = 64 * 1024;

        /// <summary>
        /// HttpListener
        /// </summary>
        private HttpListener httpListener;

        /// <summary>
        /// コンストラクタ
        /// </summary>
        /// <param name="listenConfigList">受信設定リスト</param>
        public HttpServerComponent(List<Tuple<string, uint>> listenConfigList)
        {
            httpListener = new HttpListener();
            listenConfigList.ForEach(listenConfig => httpListener.Prefixes.Add(string.Format(@listenConfig.Item1, listenConfig.Item2)));
        }

        /// <summary>
        /// 通信開始処理
        /// </summary>
        public void StartListening()
        {
            httpListener.Start();
            httpListener.BeginGetContext(OnReceive, null);
            logger.InfoFormat("HTTP Server has started listening at the following port. \r\n-----> {0}", string.Join(string.Concat(Environment.NewLine, "-----> "), httpListener.Prefixes));
        }

        /// <summary>
        /// 受信時処理
        /// </summary>
        /// <param name="asyncResult">非同期処理結果</param>
        public void OnReceive(IAsyncResult asyncResult)
        {
            if (!httpListener.IsListening)
            {
                return;
            }

            HttpListenerContext httpListenerContext = httpListener.EndGetContext(asyncResult);
            httpListener.BeginGetContext(OnReceive, httpListener);

            try
            {
                string httpMethod = httpListenerContext.Request.HttpMethod;
                if (string.Equals(HttpMethod.Get.Method, httpMethod, StringComparison.CurrentCultureIgnoreCase))
                {
                    string requestedUrl = httpListenerContext.Request.RawUrl;
                    if (requestedUrl.Contains("?"))
                    {
                        requestedUrl = requestedUrl.Substring(0, requestedUrl.IndexOf("?"));
                    }

                    logger.InfoFormat("GET request accepted. --- {0}", requestedUrl);
                    if ("/" == requestedUrl.Substring(requestedUrl.Length - 1))
                    {
                        DoRedirect(httpListenerContext, Properties.Settings.Default.HtmlTopPageUriSuffix);
                    }
                    else
                    {
                        string filePath = string.Concat(".", FileUtils.UriToFilePath(requestedUrl));
                        var fileInfo = new FileInfo(filePath);
                        if (!fileInfo.Exists || !fileInfo.FullName.StartsWith(new FileInfo(string.Concat(".", Properties.Settings.Default.HtmlRootUri)).FullName))
                        {
                            throw new FileNotFoundException();
                        }

                        string contentType = MimeMapping.GetMimeMapping(fileInfo.Name);
                        if (IsBinary(fileInfo))
                        {
                            DoResponseForBinary(httpListenerContext.Response, HttpStatusCode.OK, fileInfo.FullName, contentType);
                        }
                        else
                        {
                            if (Constants.EXTENSION.TEMPLATE == fileInfo.Extension)
                            {
                                contentType = Constants.ContentType.TEXT;
                            }

                            DoResponseForString(httpListenerContext.Response, HttpStatusCode.OK, Encoding.UTF8.GetString(FileUtils.ReadFileContent(filePath)), contentType);
                        }
                    }
                }
                else
                {
                    logger.Info("Unsupported request accepted.");
                    DoResponseForString(httpListenerContext.Response, HttpStatusCode.MethodNotAllowed, "This server only supports GET method.", Constants.ContentType.TEXT);
                }
            }
            catch (FileNotFoundException)
            {
                logger.Error("Non-existent resource accessed.");
                DoResponseForString(httpListenerContext.Response, HttpStatusCode.NotFound, null, null);
            }
            catch (Exception e)
            {
                logger.Error("Exception occurred while parsing request.", e);
                string filePath = string.Concat(".", FileUtils.UriToFilePath(Properties.Settings.Default.HtmlErrorPageUriSuffix));
                DoResponseForString(httpListenerContext.Response, HttpStatusCode.InternalServerError, Encoding.UTF8.GetString(FileUtils.ReadFileContent(filePath)),
                                MimeMapping.GetMimeMapping(new FileInfo(filePath).Name));
            }
        }

        /// <summary>
        /// バイナリ判定処理
        /// </summary>
        /// <param name="fileInfo">ファイル情報</param>
        /// <returns>判定結果(true : バイナリ / false : 非バイナリ)</returns>
        private bool IsBinary(FileInfo fileInfo)
        {
            return BINARY_EXTENSIONS.Contains(fileInfo.Extension);
        }

        /// <summary>
        /// リダイレクト処理
        /// </summary>
        /// <param name="httpListenerContext">HttpListenerContext</param>
        /// <param name="destinationSuffix">リダイレクト先の接尾語</param>
        private void DoRedirect(HttpListenerContext httpListenerContext, string destinationSuffix)
        {
            string destinationBase = "http://{0}:{1}{2}";
            if (httpListenerContext.Request.IsSecureConnection)
            {
                destinationBase = "https://{0}:{1}{2}";
            }

            string destination = string.Format(destinationBase, httpListenerContext.Request.Url.DnsSafeHost, httpListenerContext.Request.LocalEndPoint.Port, destinationSuffix);
            httpListenerContext.Response.Redirect(@destination);
            httpListenerContext.Response.Close();
            return;
        }

        /// <summary>
        /// レスポンス実行処理(バイナリコンテンツ用)
        /// </summary>
        /// <param name="httpListenerResponse"></param>
        /// <param name="httpStatusCode"></param>
        /// <param name="filePath"></param>
        /// <param name="contentType"></param>
        private void DoResponseForBinary(HttpListenerResponse httpListenerResponse, HttpStatusCode httpStatusCode, string filePath, string contentType)
        {
            try
            {
                using (FileStream fileStream = File.OpenRead(filePath))
                {
                    httpListenerResponse.ContentLength64 = fileStream.Length;
                    httpListenerResponse.SendChunked = false;
                    httpListenerResponse.ContentType = contentType;
                    httpListenerResponse.AddHeader("Content-disposition", "attachment; filename=" + Path.GetFileName(filePath));

                    byte[] buffer = new byte[BUFFER_SIZE];
                    int read;
                    using (var binaryWriter = new BinaryWriter(httpListenerResponse.OutputStream))
                    {
                        while ((read = fileStream.Read(buffer, 0, buffer.Length)) > 0)
                        {
                            binaryWriter.Write(buffer, 0, read);
                            binaryWriter.Flush();
                        }
                    }

                    httpListenerResponse.StatusCode = (int)httpStatusCode;
                    httpListenerResponse.OutputStream.Close();
                }
            }
            catch (Exception e)
            {
                logger.Error("Exception occurred during response processing.", e);
                httpListenerResponse.Abort();
            }
        }

        /// <summary>
        /// レスポンス実行処理(文字列コンテンツ用)
        /// </summary>
        /// <param name="httpListenerResponse">レスポンス</param>
        /// <param name="httpStatusCode">HttpStatusCode</param>
        /// <param name="content">内容</param>
        /// <param name="contentType">ContentType</param>
        private void DoResponseForString(HttpListenerResponse httpListenerResponse, HttpStatusCode httpStatusCode, string content, string contentType)
        {
            try
            {
                httpListenerResponse.StatusCode = (int)httpStatusCode;
                if (!string.IsNullOrWhiteSpace(contentType))
                {
                    httpListenerResponse.ContentType = contentType;
                }

                if (!string.IsNullOrWhiteSpace(content))
                {
                    using (var streamWriter = new StreamWriter(httpListenerResponse.OutputStream, new UTF8Encoding(false)))
                    {
                        streamWriter.Write(content);
                    }
                }

                httpListenerResponse.Close();
            }
            catch (Exception e)
            {
                logger.Error("Exception occurred during response processing.", e);
                httpListenerResponse.Abort();
            }
        }

        /// <summary>
        /// 破棄処理
        /// </summary>
        public void Dispose()
        {
            if (httpListener != null)
            {
                logger.Info("Shut down the HTTP server.");
                if (httpListener.IsListening)
                {
                    httpListener.Stop();
                }

                httpListener.Prefixes.Clear();
                httpListener.Abort();
            }
        }
    }
}
