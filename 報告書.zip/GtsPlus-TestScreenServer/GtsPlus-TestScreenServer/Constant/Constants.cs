﻿namespace GtsPlus_TestScreenServer.Constant
{
    /// <summary>
    /// 共通_定数クラス
    /// </summary>
    public static class Constants
    {
        /// <summary>
        /// 定数インナークラス_コンテントタイプ
        /// </summary>
        public static class ContentType
        {
            /// <summary>
            /// テキスト
            /// </summary>
            public const string TEXT = "text/plain";
        }

        /// <summary>
        /// 定数インナークラス_拡張子
        /// </summary>
        public static class EXTENSION
        {
            /// <summary>
            /// *.jpg
            /// </summary>
            public const string JPG = ".jpg";

            /// <summary>
            /// *.png
            /// </summary>
            public const string PNG = ".png";

            /// <summary>
            /// *.gif
            /// </summary>
            public const string GIF = ".gif";

            /// <summary>
            /// *.ico
            /// </summary>
            public const string ICO = ".ico";

            /// <summary>
            /// .template
            /// </summary>
            public const string TEMPLATE = ".template";

            /// <summary>
            /// .eot
            /// </summary>
            public const string EOT = ".eot";

            /// <summary>
            /// .ttf
            /// </summary>
            public const string TTF = ".ttf";

            /// <summary>
            /// .woff
            /// </summary>
            public const string WOFF = ".woff";

            /// <summary>
            /// .svg
            /// </summary>
            public const string SVG = ".svg";
        }
    }
}
