﻿using NLog;

namespace YardRepro.dto
{
    /// <summary>
    /// DST情報ユーティリティクラス
    /// </summary>
    class DSTDtoUtil
    {
        /// <summary>
        /// ログ出力クラス
        /// </summary>
        private static readonly Logger log = LogManager.GetCurrentClassLogger();

        /// <summary>
        /// ステータス更新：エラー0x01
        /// </summary>
        private const string STATUS_ERROR_0X01 = "VIN読出し不可";
        /// <summary>
        /// ステータス更新：エラー0x02
        /// </summary>
        private const string STATUS_ERROR_0X02 = "ソフト品番読出し不可";
        /// <summary>
        /// ステータス更新：エラー0x03 2019.02
        /// </summary>
        private const string STATUS_ERROR_0X03 = "読み出したソフト品番から引きあたるリプロデータがDST-WiFi内に存在しない";
        /// <summary>
        /// ステータス更新：エラー0x04
        /// </summary>
        private const string STATUS_ERROR_0X04 = "リプロ書換え中のエラー";
        /// <summary>
        /// ステータス更新：エラー0x05
        /// </summary>
        private const string STATUS_ERROR_0X05 = "リプロ後のベリファイ時のエラー";
        /// <summary>
        /// ステータス更新：エラー0x06
        /// </summary>
        private const string STATUS_ERROR_0X06 = "バッテリ電圧が11.8V未満";
        /// <summary>
        /// ステータス更新：エラー0x07
        /// </summary>
        private const string STATUS_ERROR_0X07 = "定義されないエラー";
        /// <summary>
        /// ステータス更新：エラー0x08 2019.02
        /// </summary>
        private const string STATUS_ERROR_0X08 = "読み出したソフト品番がリプロ後のソフト品番と同一";
        /// <summary>
        /// ステータス更新：エラー0x09 2019.12
        /// </summary>
        private const string STATUS_ERROR_0X09 = "19PFCGWのツール認証(Key送信)に使用するKeyの受領待ち";
        /// <summary>
        /// ステータス更新：切断エラー
        /// </summary>
        private const string STATUS_ERROR_NOTCONNECT = "切断されました";

        /// <summary>
        /// ステータス更新：署名取得キャンセルエラー
        /// </summary>
        private const string STATUS_SIGNATURE_ERROR = "リプロ鍵認証エラー";

        /// <summary>
        /// ステータス更新：DTC消去実施中
        /// </summary>
        private const string STATUS_DTC_EXEC = "DTC消去実施中";
        /// <summary>
        /// ステータス更新：DTC消去エラー
        /// </summary>
        private const string STATUS_DTC_ERROR = "DTC消去エラー";
        /// <summary>
        /// ステータス更新：ログファイル取得中
        /// </summary>
        private const string STATUS_DTC_EXEC_LOG = "ログ取得中";
        /// <summary>
        /// ステータス更新：ログファイル取得エラー
        /// </summary>
        private const string STATUS_DTC_ERROR_LOG = "ログ取得エラー";
        /// <summary>
        /// ステータス更新：DTC消去完了
        /// </summary>
        private const string STATUS_DTC_SUCCESS = "DTC消去完了";

        /// <summary>
        /// DSTからの応答を元にDST情報を作成する
        /// </summary>
        /// <param name="ipAddress">IPアドレス</param>
        /// <param name="wl">WIFI接続情報応答データ</param>
        /// <returns>DST情報</returns>
        /// ### 機能説明 #######
        /// -# DST情報を新規作成
        ///         項目                                    | 設定値
        ///         ----------------------------------------| -------------
        ///         ステータス                              | アイドル状態
        ///         電波強度                                | 引数.WIFI接続情報応答データ.電波強度
        ///         色情報                                  | 引数.WIFI接続情報応答データ.色情報
        ///         シリアルNo                              | 引数.WIFI接続情報応答データ.シリアルNo
        ///         ホスト名                                | 引数.WIFI接続情報応答データ.ホスト名
        ///         IPアドレス                              | 引数.IPアドレス
        ///         進捗情報                                | 0
        ///         プログレスバーの色                      | 緑
        ///         活性・非活性フラグ                      | True
        ///         選択フラグ                              | False
        ///         リトライ可能フラグ                      | False
        ///         DTCステータス                           | DTC未実施
        ///         VinNo取得済みフラグ                     | False
        ///         リプロ前ソフトウェア品番取得済みフラグ  | False
        ///         リプロ後ソフトウェア品番取得済みフラグ  | False
        ///         DTC消去操作可能フラグ                   | False
        ///         DTC消去実行チェックフラグ               | False
        ///         
        /// -# DST情報を返却
        public static DSTDto createDstiDto(string ipAddress, DSTUtil.WifiConnect wl)
        {
            DSTDto dstiDto = new DSTDto();

            dstiDto.status = DSTDto.StatusMode.Idle;
            dstiDto.signalStrength = wl.signalStrength;
            dstiDto.color = wl.color;
            dstiDto.serialNo = DSTUtil.ByteToString(wl.SerialNo);
            dstiDto.hostName = DSTUtil.ByteToString(wl.hostName);
            dstiDto.ipAddress = ipAddress;
            dstiDto.progresValue = 0;
            dstiDto.progressColorForeground = DSTDto.ProgresColor.Green.Name();
            dstiDto.isEnabled = true;
            dstiDto.isSelected = false;
            dstiDto.isRetryEnabled = false;

            // 2019.02
            dstiDto.statusDtc = DSTDto.StatusModeDTC.DtcNotExec;
            dstiDto.getSoftNoBefore = false;
            dstiDto.getSoftNoAfter = false;
            dstiDto.isDtcEnabled = false;
            dstiDto.isDtcDeleteChecked = false;

            // 2019.12
            dstiDto.statusSignature = DSTDto.StatusModeSignature.SignatureNotExec;
            dstiDto.getSeedValue = false;

            return dstiDto;
        }

        /// <summary>
        /// DST選択情報からDST情報を作成する
        /// </summary>
        /// <param name="updatedata">DST選択情報</param>
        /// <returns>DST情報</returns>
        /// ### 機能説明 #######
        /// -# DST情報を新規作成
        ///         項目                                    | 設定値
        ///         ----------------------------------------| -------------
        ///         ステータス                              | アイドル状態
        ///         電波強度                                | 引数.WIFI接続情報応答データ.電波強度
        ///         色情報                                  | 引数.WIFI接続情報応答データ.色情報
        ///         シリアルNo                              | 引数.WIFI接続情報応答データ.シリアルNo
        ///         ホスト名                                | 引数.WIFI接続情報応答データ.ホスト名
        ///         IPアドレス                              | 引数.IPアドレス
        ///         進捗情報                                | 0
        ///         プログレスバーの色                      | 緑
        ///         活性・非活性フラグ                      | True
        ///         選択フラグ                              | 引数.WIFI接続情報応答データ.選択フラグ
        ///         リトライ可能フラグ                      | False
        ///         DTCステータス                           | DTC未実施
        ///         VinNo取得済みフラグ                     | False
        ///         リプロ前ソフトウェア品番取得済みフラグ  | False
        ///         リプロ後ソフトウェア品番取得済みフラグ  | False
        ///         DTC消去操作可能フラグ                   | False
        ///         DTC消去実行チェックフラグ               | False
        ///         
        /// -# DST情報を返却
        public static DSTDto createDstiDto(DSTDto updatedata)
        {
            DSTDto dstiDto = new DSTDto();

            dstiDto.status = DSTDto.StatusMode.Idle;
            dstiDto.signalStrength = updatedata.signalStrength;
            dstiDto.color = updatedata.color;
            dstiDto.serialNo = updatedata.serialNo;
            dstiDto.hostName = updatedata.hostName;
            dstiDto.ipAddress = updatedata.ipAddress;
            dstiDto.progresValue = 0;
            dstiDto.progressColorForeground = DSTDto.ProgresColor.Green.Name();
            dstiDto.isEnabled = true;
            dstiDto.isSelected = updatedata.isSelected;// 2019.02
            dstiDto.isRetryEnabled = false;

            // 2019.02
            dstiDto.statusDtc = DSTDto.StatusModeDTC.DtcNotExec;
            dstiDto.getSoftNoBefore = false;
            dstiDto.getSoftNoAfter = false;
            dstiDto.isDtcEnabled = false;
            dstiDto.isDtcDeleteChecked = false;

            // 2019.12
            dstiDto.statusSignature = DSTDto.StatusModeSignature.SignatureNotExec;
            dstiDto.getSeedValue = false;

            return dstiDto;
        }

        /// <summary>
        /// アイドル状態にDST情報を更新する
        /// </summary>
        /// <param name="dto">DST情報</param>
        /// ### 機能説明 #######
        /// -# DST情報を更新する
        ///         項目                                    | 設定値
        ///         ----------------------------------------| -------------
        ///         ステータス                              | アイドル状態
        ///         進捗情報                                | 0
        ///         メッセージ                              | 0%
        ///         エラーコード                            | 空文字
        ///         VIN                                     | 空文字
        ///         リプロ前ソフト品番リスト                | NULL
        ///         リプロ後ソフト品番リスト                | NULL
        ///         活性・非活性フラグ                      | True
        ///         リトライ可能フラグ                      | False
        ///         DTCステータス                           | DTC未実施
        ///         VinNo取得済みフラグ                     | False
        ///         リプロ前ソフトウェア品番取得済みフラグ  | False
        ///         リプロ後ソフトウェア品番取得済みフラグ  | False
        ///         DTC消去操作可能フラグ                   | False
        ///         DTC消去実行チェックフラグ               | False
        public static void updateIdle(DSTDto dto)
        {
            dto.status = DSTDto.StatusMode.Idle;
            dto.progresValue = 0;
            dto.message = "0%";
            dto.errorCode = string.Empty;
            dto.vinNo = string.Empty;
            dto.softNoBefore = null;  // 2019.02
            dto.softNoAfter = null;   // 2019.02
            dto.isEnabled = true;
            dto.isRetryEnabled = false;

            // 2019.02
            dto.statusDtc = DSTDto.StatusModeDTC.DtcNotExec;
            dto.getSoftNoBefore = false;
            dto.getSoftNoAfter = false;
            dto.isDtcEnabled = false;
            dto.isDtcDeleteChecked = false;

            // 2019.12
            dto.statusSignature = DSTDto.StatusModeSignature.SignatureNotExec;
            dto.getSeedValue = false;
        }

        /// <summary>
        /// 更新中状態にDST情報を更新
        /// </summary>
        /// <param name="dto">DST情報</param>
        /// <param name="progress">進捗率</param>
        /// ### 機能説明 #######
        /// -# DST情報を更新する
        ///         項目                | 設定値
        ///         --------------------| -------------
        ///         ステータス          | 更新中状態
        ///         進捗情報            | 引数.進捗率
        ///         メッセージ          | 引数.進捗率 + "%"
        ///         活性・非活性フラグ  | True
        ///         リトライ可能フラグ  | False
        ///         プログレスバーの色  | 緑
        public static void updateExec(DSTDto dto, int progress)
        {
            dto.status = DSTDto.StatusMode.Exec;
            dto.progresValue = progress;
            dto.message = progress + "%";
            dto.isEnabled = true;
            dto.isRetryEnabled = false;
            dto.progressColorForeground = DSTDto.ProgresColor.Green.Name();
        }

        /// <summary>
        /// エラー状態にDST情報を更新する
        /// </summary>
        /// <param name="dto">DST情報</param>
        /// <param name="errorCode">エラーコード</param>
        /// ### 機能説明 #######
        /// -# DST情報を更新する
        ///         項目                | 設定値
        ///         --------------------| -------------
        ///         ステータス          | エラー状態
        ///         メッセージ          | 下記表の通り
        ///         リトライ可能フラグ  | 下記表の通り
        ///         活性・非活性フラグ  | True
        ///         
        /// -# エラーコードによってリトライ可能フラグとメッセージを設定する
        ///         エラーコード        | リトライ可能フラグ |メッセージ
        ///         --------------------| -------------------|--------------
        ///         1                   | False              |VIN読出し不可
        ///         2                   | False              |ソフト品番読出し不可
        ///         3                   | False              |読み出したソフト品番から引きあたるリプロデータがDST-WiFi内に存在しない
        ///         4                   | True               |リプロ書換え中のエラー
        ///         5                   | True               |リプロ後のベリファイ時のエラー
        ///         6                   | True               |バッテリ電圧が11.8V未満
        ///         8                   | False              |読み出したソフト品番がリプロ後のソフト品番と同一
        ///         上記以外            | False              |定義されないエラー
        public static void updateError(DSTDto dto, string errorCode)
        {
            dto.status = DSTDto.StatusMode.Error;
            dto.errorCode = errorCode;
            dto.isEnabled = true;
            dto.isRetryEnabled = false;

            switch(errorCode)
            {
                case "1":
                    dto.message = STATUS_ERROR_0X01;
                    break;
                case "2":
                    dto.message = STATUS_ERROR_0X02;
                    break;
                case "3":
                    dto.message = STATUS_ERROR_0X03;
                    break;
                case "4":
                    dto.message = STATUS_ERROR_0X04;
                    dto.isRetryEnabled = true;
                    break;
                case "5":
                    dto.message = STATUS_ERROR_0X05;
                    dto.isRetryEnabled = true;
                    break;
                case "6":
                    dto.message = STATUS_ERROR_0X06;
                    //dto.isRetryEnabled = true; 2019.02
                    break;
                case "8":// 2019.02
                    dto.message = STATUS_ERROR_0X08;
                    break;
                default:// 7:定義されないエラー
                    dto.message = STATUS_ERROR_0X07;
                    break;
            }

        }

        /// <summary>
        /// 未接続状態にDST情報を更新する
        /// </summary>
        /// <param name="dto">DST情報</param>
        /// ### 機能説明 #######
        /// -# DST情報を更新する
        ///         項目                | 設定値
        ///         --------------------| -------------
        ///         ステータス          | 未接続状態
        ///         進捗情報            | 100
        ///         メッセージ          | 切断されました
        ///         活性・非活性フラグ  | False
        ///         リトライ可能フラグ  | False
        ///         プログレスバーの色  | 赤
        public static void updateNotConnect(DSTDto dto)
        {
            dto.status = DSTDto.StatusMode.Notconnect;
            dto.message = STATUS_ERROR_NOTCONNECT;
            dto.progresValue = 100;
            dto.isEnabled = false;
            dto.isRetryEnabled = false;
            dto.progressColorForeground = DSTDto.ProgresColor.Fuchsia.Name();

            dto.isDtcEnabled = false;
        }

        /// <summary>
        /// 成功状態にDST情報を更新する
        /// </summary>
        /// <param name="dto">DST情報</param>
        /// ### 機能説明 #######
        /// -# DST情報を更新する
        ///         項目                  | 設定値
        ///         ----------------------| -------------
        ///         ステータス            | 成功状態
        ///         メッセージ            | 100%
        ///         リトライ可能フラグ    | False
        ///         DTC消去操作可能フラグ | True
        ///         活性・非活性フラグ    | True
        ///         プログレスバーの色    | 緑
        public static void updateSuccess(DSTDto dto)
        {
            dto.status = DSTDto.StatusMode.Success;
            dto.progresValue = 100;
            dto.message = "100%";
            dto.isRetryEnabled = false;
            // 2019.02
            if (dto.statusDtc == DSTDto.StatusModeDTC.DtcNotExec || dto.statusDtc == DSTDto.StatusModeDTC.DtcExec || dto.statusDtc == DSTDto.StatusModeDTC.DtcError)
            {
                dto.isDtcEnabled = true;
            }
            dto.isEnabled = true;
            dto.progressColorForeground = DSTDto.ProgresColor.Green.Name();
        }

        /// <summary>
        /// DTC実行中状態にDST情報を更新する 2019.02
        /// </summary>
        /// <param name="dto">DST情報</param>
        /// ### 機能説明 #######
        /// -# DST情報を更新する
        ///     項目                  | 設定値
        ///     ----------------------| -------------
        ///     DTCステータス         | DTC実行中状態
        ///     DTC消去操作可能フラグ | False
        ///     DTCメッセージ         | DTC実行中
        public static void updateDtcExec(DSTDto dto)
        {
            dto.statusDtc = DSTDto.StatusModeDTC.DtcExec;
            dto.isDtcEnabled = false;
            dto.messageDTC = STATUS_DTC_EXEC;
        }

        /// <summary>
        /// DTC実行エラー状態にDST情報を更新する 2019.02
        /// </summary>
        /// <param name="dto">DST情報</param>
        /// ### 機能説明 #######
        /// -# DST情報を更新する
        ///     項目                  | 設定値
        ///     ----------------------| -------------
        ///     DTCステータス         | DTC実行エラー状態
        ///     DTC消去操作可能フラグ | True
        ///     DTCメッセージ         | DTC実行エラー
        public static void updateDtcError(DSTDto dto)
        {
            dto.statusDtc = DSTDto.StatusModeDTC.DtcError;
            dto.isDtcEnabled = true;
            dto.messageDTC = STATUS_DTC_ERROR;
        }

        /// <summary>
        /// ログファイル取得中状態にDST情報を更新する 2019.02
        /// </summary>
        /// <param name="dto">DST情報</param>
        /// ### 機能説明 #######
        /// -# DST情報を更新する
        ///     項目                  | 設定値
        ///     ----------------------| -------------
        ///     DTCステータス         | ログファイル取得中状態
        ///     DTC消去操作可能フラグ | False
        ///     DTCメッセージ         | ログ取得中
        public static void updateDtcExecLog(DSTDto dto)
        {
            dto.statusDtc = DSTDto.StatusModeDTC.DtcExecLog;
            dto.isDtcEnabled = false;
            dto.messageDTC = STATUS_DTC_EXEC_LOG;
        }

        /// <summary>
        /// ログファイル取得エラー状態にDST情報を更新する 2019.02
        /// </summary>
        /// <param name="dto">DST情報</param>
        /// ### 機能説明 #######
        /// -# DST情報を更新する
        ///     項目                  | 設定値
        ///     ----------------------| -------------
        ///     DTCステータス         | ログファイル取得エラー状態
        ///     DTC消去操作可能フラグ | True
        ///     DTCメッセージ         | ログファイル取得エラー
        public static void updateDtcErrorLog(DSTDto dto)
        {
            dto.statusDtc = DSTDto.StatusModeDTC.DtcErrorLog;
            dto.isDtcEnabled = false;
            dto.messageDTC = STATUS_DTC_ERROR_LOG;
        }

        /// <summary>
        /// DTC完了状態にDST情報を更新する 2019.02
        /// </summary>
        /// <param name="dto">DST情報</param>
        /// ### 機能説明 #######
        /// -# DST情報を更新する
        ///     項目                  | 設定値
        ///     ----------------------| -------------
        ///     DTCステータス         | DTC完了状態
        ///     DTC消去操作可能フラグ | false
        ///     DTCメッセージ         | DTC完了
        public static void updateDtcSuccess(DSTDto dto)
        {
            dto.statusDtc = DSTDto.StatusModeDTC.DtcSuccess;
            dto.isDtcEnabled = false;
            dto.messageDTC = STATUS_DTC_SUCCESS;
        }

        /// <summary>
        /// リプロツール差替え済み状態にDST情報を更新する 2019.02
        /// </summary>
        /// <param name="dto">DST情報</param>
        /// ### 機能説明 #######
        /// -# DST情報を更新する
        ///     項目                  | 設定値
        ///     ----------------------| -------------
        ///     DTCステータス         | リプロツール差替え済み状態
        ///     DTC消去操作可能フラグ | false
        ///     DTCメッセージ         | DTC完了
        public static void updateDtcReplaced(DSTDto dto)
        {
            dto.status = DSTDto.StatusMode.Replaced;
            dto.isEnabled = false;
            dto.isDtcEnabled = false;
            dto.isRetryEnabled = false;
        }

        /// <summary>
        /// 署名取得開始状態にDST情報を更新する 2019.12
        /// </summary>
        /// <param name="dto">DST情報</param>
        /// ### 機能説明 #######
        /// -# DST情報を更新する
        ///     項目                     | 設定値
        ///     -------------------------| -------------
        ///     リプロ鍵認証のステータス | 署名取得開始
        public static void updateSignatureExec(DSTDto dto)
        {
            dto.statusSignature = DSTDto.StatusModeSignature.SignatureExec;
            dto.signature = null;
        }

        /// <summary>
        /// 署名取得成功状態にDST情報を更新する 2019.12
        /// </summary>
        /// <param name="dto">DST情報</param>
        /// ### 機能説明 #######
        /// -# DST情報を更新する
        ///     項目                     | 設定値
        ///     -------------------------| -------------
        ///     リプロ鍵認証のステータス | 署名取得成功
        public static void updateSignatureSuccess(DSTDto dto)
        {
            dto.statusSignature = DSTDto.StatusModeSignature.SignatureSuccess;
        }

        /// <summary>
        /// 署名取得キャンセルエラー状態にDST情報を更新する 2019.12
        /// </summary>
        /// <param name="dto">DST情報</param>
        /// ### 機能説明 #######
        /// -# DST情報を更新する
        ///     項目                     | 設定値
        ///     -------------------------| -------------------------
        ///     リプロ鍵認証のステータス | 署名取得キャンセルエラー
        public static void updateSignatureError(DSTDto dto)
        {
            dto.statusSignature = DSTDto.StatusModeSignature.SignatureError;
            dto.signature = null;

            dto.status = DSTDto.StatusMode.Error;
            dto.isEnabled = true;
            dto.isRetryEnabled = true;
            dto.message = STATUS_SIGNATURE_ERROR;
        }

        /// <summary>
        /// 署名認証成功状態にDST情報を更新する 2019.12
        /// </summary>
        /// <param name="dto">DST情報</param>
        /// ### 機能説明 #######
        /// -# DST情報を更新する
        ///     項目                     | 設定値
        ///     -------------------------| -------------
        ///     リプロ鍵認証のステータス | 署名認証成功
        public static void updateAuthenticationSuccess(DSTDto dto)
        {
            dto.statusSignature = DSTDto.StatusModeSignature.AuthenticationSuccess;
        }

        /// <summary>
        /// 署名認証エラー状態にDST情報を更新する 2019.12
        /// </summary>
        /// <param name="dto">DST情報</param>
        /// ### 機能説明 #######
        /// -# DST情報を更新する
        ///     項目                     | 設定値
        ///     -------------------------| -------------------------
        ///     リプロ鍵認証のステータス | 署名認証エラー
        public static void updateAuthenticationError(DSTDto dto)
        {
            dto.statusSignature = DSTDto.StatusModeSignature.AuthenticationError;
            dto.signature = null;

            dto.status = DSTDto.StatusMode.Error;
            dto.isEnabled = true;
            dto.isRetryEnabled = false;
            dto.message = STATUS_ERROR_0X07;// エラーコードは仮
        }
    }
}
