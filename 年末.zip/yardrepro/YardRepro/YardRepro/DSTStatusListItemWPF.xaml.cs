﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;
using YardRepro.dto;
using NLog;

namespace YardRepro
{
    /// <summary>
    /// DSTステータスアイテムコントロール
    /// </summary>
    public partial class DSTStatusListItemWPF : UserControl
    {

        /// <summary>
        /// ログ出力クラス
        /// </summary>
        private static readonly Logger log = LogManager.GetCurrentClassLogger();

        /// <summary>
        /// リトライクリックイベント
        /// </summary>
        public event EventHandler RetryClick;

        /// <summary>
        /// DTC実行クリックイベント
        /// </summary>
        public event EventHandler DtcExecClick;

        /// <summary>
        /// コンストラクタ
        /// </summary>
        /// ### 機能説明 #######
        /// -# 画面コンポーネントの初期処理
        public DSTStatusListItemWPF()
        {
            InitializeComponent();
        }

        /// <summary>
        /// DSTステータスアイテムデータプロパティ
        /// </summary>
        public DSTDto DSTiDATA
        {
            get { return (DSTDto)GetValue(DstiDtoProperty); }
            set { SetValue(DstiDtoProperty, value); }
        }

        /// <summary>
        /// DSTステータスアイテムデータのデータバインディング用プロパティ
        /// </summary>
        public static readonly DependencyProperty DstiDtoProperty = DependencyProperty.Register("DSTiDATA", typeof(DSTDto), typeof(DSTStatusListItemWPF), new PropertyMetadata(default(DSTDto)));

        /// <summary>
        /// プログレスバー表示制御
        /// </summary>
        /// <param name="sender">発生元オブジェクト</param>
        /// <param name="e">イベント引数</param>
        /// ### 機能説明 #######
        /// -# DSTi情報-ステータスが実行中以外の場合
        ///     -# プログレスバーのアニメーションを停止
        private void progressBar1_Loaded(object sender, RoutedEventArgs e)
        {
            // DSTi情報-ステータスが実行中以外の場合
            if (DSTiDATA.status != DSTDto.StatusMode.Exec)
            {
                // アニメーションを停止
                var anim = progressBar1.Template.FindName("Animation", progressBar1) as FrameworkElement;
                if (anim != null) anim.Visibility = System.Windows.Visibility.Collapsed;
            }
        }

        /// <summary>
        /// プログレスバー（DTC）表示制御 2019.02
        /// </summary>
        /// <param name="sender">発生元オブジェクト</param>
        /// <param name="e">イベント引数</param>
        /// ### 機能説明 #######
        /// -# DSTi情報-ステータスが実行中以外の場合
        ///     -# プログレスバーのアニメーションを停止
        private void progressBarDTC_Loaded(object sender, RoutedEventArgs e)
        {
            // DSTi情報-ステータスが実行中以外の場合
            if (DSTiDATA.status != DSTDto.StatusMode.Exec)
            {
                // アニメーションを停止
                var anim = progressBar1.Template.FindName("Animation", progressBar1) as FrameworkElement;
                if (anim != null) anim.Visibility = System.Windows.Visibility.Collapsed;
            }
        }

        /// <summary>
        /// リトライボタン表示制御
        /// </summary>
        /// <param name="sender">発生元オブジェクト</param>
        /// <param name="e">イベント引数</param>
        /// ### 機能説明 #######
        /// -# DST情報.ステータスがエラー以外の場合
        ///         項目                        | 設定値
        ///         ----------------------------| -------------
        ///         リトライボタン.活性非活性   | DST情報.リトライ可能フラグ
        ///         メッセージ.マージン         | 10, 10, 0, 0
        ///         メッセージ.文字色           | 黒
        ///         プログレスバー.表示         | 表示
        ///         
        /// -# DST情報.ステータスがエラーの場合
        ///         項目                        | 設定値
        ///         ----------------------------| -------------
        ///         リトライボタン.活性非活性   | DST情報.リトライ可能フラグ
        ///         メッセージ.マージン         | 0, 5, 0, 0
        ///         メッセージ.文字色           | 赤
        ///         プログレスバー.表示         | 非表示
        private void btnRetry_Loaded(object sender, RoutedEventArgs e)
        {
            // DST情報-ステータスエラー以外
            if (DSTiDATA.status != DSTDto.StatusMode.Error)
            {
                btnRetry.IsEnabled = DSTiDATA.isRetryEnabled;
                btnRetry.FontWeight = FontWeights.Normal;
                btnRetry.BorderBrush = Brushes.Gray;
                textMessage.Margin = new Thickness(10, 10, 0, 0);
                textMessage.Foreground = new SolidColorBrush(Colors.Black);
                textMessage.FontWeight = FontWeights.Normal;
                progressBar1.Visibility = Visibility.Visible;
            }
            else
            {
                btnRetry.IsEnabled = DSTiDATA.isRetryEnabled;
                btnRetry.FontWeight = FontWeights.Bold;
                btnRetry.BorderBrush = Brushes.Lime;
                textMessage.Margin = new Thickness(0, 5, 0, 0);
                textMessage.Foreground = new SolidColorBrush(Colors.DeepPink);
                progressBar1.Visibility = Visibility.Collapsed;
            }
        }

        /// <summary>
        /// DTC消去操作表示制御 2019.02
        /// </summary>
        /// <param name="sender">発生元オブジェクト</param>
        /// <param name="e">イベント引数</param>
        /// ### 機能説明 #######
        /// -# DST情報.DTC消去操作可能フラグがDTC実行不能の場合
        ///     項目                                 | 設定値
        ///     -------------------------------------| -------------
        ///     メッセージ.文字色                    | 灰色
        ///     P-DTC消去操作済みチェック.活性非活性 | False
        ///     P-DTC消去操作済みチェック.チェック   | DST情報.DTC消去実行チェックフラグ
        ///     DTC実行ボタン.活性非活性             | False
        ///     
        /// -# DST情報.DTC消去操作可能フラグがDTC実行可能な場合
        ///     項目                                 | 設定値
        ///     -------------------------------------| -------------
        ///     P-DTC消去操作済みチェック.活性非活性 | DST情報.DTC消去操作可能フラグ
        ///     P-DTC消去操作済みチェック.チェック   | DST情報.DTC消去実行チェックフラグ
        ///     DTC実行ボタン.活性非活性             | DST情報.DTC消去実行チェックフラグ
        ///     
        ///     -# DST情報.ステータスがエラー以外の場合
        ///         項目                                 | 設定値
        ///         -------------------------------------| -------------
        ///         メッセージ.文字色                    | 黒
        ///     
        ///     -# DST情報.DTCステータスがエラーの場合
        ///         項目                                 | 設定値
        ///         -------------------------------------| -------------
        ///         メッセージ.文字色                    | 赤
        private void chkDtcDelete_Loaded(object sender, RoutedEventArgs e)
        {
            // DST情報-DTC実行不能の場合
            if (!DSTiDATA.isDtcEnabled)
            {
                textP_DTC.Foreground = Brushes.Gray;
                chkDtcDelete.IsEnabled = false;
                chkDtcDelete.IsChecked = DSTiDATA.isDtcDeleteChecked;
                btnDtcDelete.IsEnabled = false;
            }
            else
            {
                chkDtcDelete.IsEnabled = DSTiDATA.isDtcEnabled;
                chkDtcDelete.IsChecked = DSTiDATA.isDtcDeleteChecked;
                btnDtcDelete.IsEnabled = DSTiDATA.isDtcDeleteChecked;

                // DST情報-ステータスエラー以外
                if (DSTiDATA.statusDtc != DSTDto.StatusModeDTC.DtcError && DSTiDATA.statusDtc != DSTDto.StatusModeDTC.DtcErrorLog)
                {
                    textMessageDTC.Foreground = new SolidColorBrush(Colors.White);
                }
                else
                {
                    textMessageDTC.Foreground = new SolidColorBrush(Colors.DeepPink);
                }
            }
        }

        /// <summary>
        /// P-DTC消去操作済みチェック制御 2019.02
        /// </summary>
        /// <param name="sender">発生元オブジェクト</param>
        /// <param name="e">イベント引数</param>
        /// ### 機能説明 #######
        /// -# DTC消去ボタンを活性化
        /// -# DST情報.P-DTC消去操作済みフラグを更新
        private void chkDtcDelete_Checked(object sender, RoutedEventArgs e)
        {
            btnDtcDelete.IsEnabled = true;
            DSTiDATA.isDtcDeleteChecked = true;
            btnDtcDelete.FontWeight = FontWeights.Bold;
            btnDtcDelete.BorderBrush = Brushes.Lime;
        }

        /// <summary>
        /// P-DTC消去操作済みアンチェック制御 2019.02
        /// </summary>
        /// <param name="sender">発生元オブジェクト</param>
        /// <param name="e">イベント引数</param>
        /// ### 機能説明 #######
        /// -# DTC消去ボタンを非活性化
        /// -# DST情報.P-DTC消去操作済みフラグを更新
        private void chkDtcDelete_Unchecked(object sender, RoutedEventArgs e)
        {
            btnDtcDelete.IsEnabled = false;
            DSTiDATA.isDtcDeleteChecked = false;
            btnDtcDelete.FontWeight = FontWeights.Normal;
            btnDtcDelete.BorderBrush = Brushes.Gray;
        }

        /// <summary>
        /// リストのタイトル表示処理
        /// </summary>
        /// <param name="sender">発生元オブジェクト</param>
        /// <param name="e">イベント引数</param>
        /// ### 機能説明 #######
        /// -# DST情報.活性の場合
        ///         項目                        | 設定値
        ///         ----------------------------| -------------
        ///         タイトルテキスト.文字色     | 水色(0x33, 0xB6, 0xEF)
        ///         
        /// -# DST情報.非活性の場合
        ///         項目                        | 設定値
        ///         ----------------------------| -------------
        ///         タイトルテキスト.文字色     | 灰色
        private void titleText_Loaded(object sender, RoutedEventArgs e)
        {
            if (DSTiDATA.isEnabled)
            {
                // メッセージフォント色を水色
                //((TextBlock)sender).Foreground = new SolidColorBrush(Color.FromArgb(0xff, 0x33, 0xB6, 0xEF));
                ((TextBlock)sender).Foreground = Brushes.White;
            }
            else
            {
                // SerialNoフォント色を灰色
                ((TextBlock)sender).Foreground = Brushes.Gray;
            }

        }

        /// <summary>
        /// リストのデータ表示処理
        /// </summary>
        /// <param name="sender">発生元オブジェクト</param>
        /// <param name="e">イベント引数</param>
        /// ### 機能説明 #######
        /// -# DST情報.活性の場合
        ///         項目                        | 設定値
        ///         ----------------------------| -------------
        ///         データテキスト.文字色       | 黒色
        ///         
        /// -# DST情報.非活性の場合
        ///         項目                        | 設定値
        ///         ----------------------------| -------------
        ///         データテキスト.文字色       | 灰色
        private void text_Loaded(object sender, RoutedEventArgs e)
        {
            if (DSTiDATA.isEnabled)
            {
                // メッセージフォント色を白
                ((TextBlock)sender).Foreground = Brushes.White;
            }
            else
            {
                // SerialNoフォント色を灰色
                ((TextBlock)sender).Foreground = Brushes.Gray;
            }

        }

        /// <summary>
        /// リトライボタン押下
        /// </summary>
        /// <param name="sender">発生元オブジェクト</param>
        /// <param name="e">イベント引数</param>
        /// ### 機能説明 #######
        /// -# IGのOFF/ON確認メッセージを表示
        /// -# OK押下の場合
        ///     -# リトライ要求APIを呼び出し（DST情報.IPアドレス）
        ///     -# 処理結果が正常以外の場合
        ///         -# エラーメッセージを表示
        ///             項目         | 設定値
        ///             -------------| -------------
        ///             メッセージ   | リトライ要求が失敗したか、既にリトライ実行中です。
        ///             ウィンドウ名 | ヤードリプロ
        ///             ボタン       | OKのみ
        ///             アイコン     | エラーアイコン
        ///         
        ///         -# 処理終了
        ///     -# アイドル状態にDST情報を更新する。
        /// -# API呼び出しで例外が発生した場合
        ///     -# 切断状態にDST情報を更新する。
        /// -# リトライボタン押下イベントを発生させる。
        private void btnRetry_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // 署名認証エラーではない場合
                if (DSTiDATA.statusSignature != DSTDto.StatusModeSignature.SignatureError)
                {
                    // IG OFF/ON を促す
                    System.Windows.Forms.DialogResult result = System.Windows.Forms.MessageBox.Show(Consts.MESSAGE_IG_OFF_ON,
                                                                                                    Consts.SCREEN_MAIN_TITLE,
                                                                                                    System.Windows.Forms.MessageBoxButtons.OKCancel,
                                                                                                    System.Windows.Forms.MessageBoxIcon.Question);
                    // 「OK」ではない場合
                    if (result != System.Windows.Forms.DialogResult.OK)
                    {
                        return;
                    }
                }

                // リトライ要求を送信
                DSTUtil.ReproRetry reproRetry = DSTUtil.SendSocketUDPReproRetry(DSTiDATA.ipAddress);
                if (DSTUtil.ByteToInt(reproRetry.result) != 0)
                {
                    // エラーメッセージを表示
                    System.Windows.Forms.MessageBox.Show(Consts.MESSAGE_ERROR_RETRY,
                                    Consts.SCREEN_MAIN_TITLE,
                                    System.Windows.Forms.MessageBoxButtons.OK,
                                    System.Windows.Forms.MessageBoxIcon.Error);
                    return;
                }
                // アイドル状態にDST情報を更新する。
                DSTDtoUtil.updateIdle(DSTiDATA);
            }
            catch
            {
                // 切断状態にDST情報を更新する。
                DSTDtoUtil.updateNotConnect(DSTiDATA);
            }
            // リトライボタン押下イベントを発生させる。
            if (RetryClick != null) RetryClick(this, EventArgs.Empty);
        }

        /// <summary>
        /// DTC消去ボタン押下 2019.02
        /// </summary>
        /// <param name="sender">発生元オブジェクト</param>
        /// <param name="e">イベント引数</param>
        /// ### 機能説明 #######
        /// -# DTC消去ボタン押下イベントを発生させる。
        /// -# DTC実行中状態にDST情報を更新する。
        /// -# DTC実行ボタン押下イベントを発生させる。
        private void btnDtcDelete_Click(object sender, RoutedEventArgs e)
        {
            // DTC実行中状態にDST情報を更新する。
            DSTDtoUtil.updateDtcExec(DSTiDATA);

            //DTC消去ボタン押下イベントを発生させる。
            if (DtcExecClick != null) DtcExecClick(this, EventArgs.Empty);
        }

        /// <summary>
        /// ユーザコントロール読み込み後イベント
        /// </summary>
        /// <param name="sender">発生元オブジェクト</param>
        /// <param name="e">イベント引数</param>
        /// ### 機能説明 #######
        /// -# リプロ前ソフト品番がNULL以外の場合
        ///     -# DST情報のソフト品番リスト分ループ
        ///         -# ループの初回以外で、ループ回数が６で割り切れる場合
        ///             -# ソフト品番のテキストフィールドに改行を追加
        ///         -# ソフト品番のテキストフィールドにソフト品番を左寄せデリミタ空白で追加
        ///     -# コントロールの高さを120+(行数*22)を設定
        /// -# リプロ後ソフト品番がNULL以外の場合
        ///     -# DST情報のソフト品番リスト分ループ
        ///         -# ループの初回以外で、ループ回数が６で割り切れる場合
        ///             -# ソフト品番のテキストフィールドに改行を追加
        ///         -# ソフト品番のテキストフィールドにソフト品番を左寄せデリミタ空白で追加
        ///     -# リプロ後ソフト品番がリプロ前ソフト品番より表示行数が多い場合
        ///         -# コントロールの高さを120+(行数*22)を設定
        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            // 高さ Min値
            this.Height = 120 + (1 * 22);

            // リプロ前ソフト品番
            if (DSTiDATA.softNoBefore != null)
            {
                int indexBefore = 0;
                int rowBefore = 1;
                foreach (string softno in DSTiDATA.softNoBefore)
                {
                    if (indexBefore != 0 && indexBefore % 2 == 0)
                    {
                        textSoftNoBefore.Inlines.Add(new LineBreak());
                        rowBefore++;
                    }
                    // ソフト品番を左寄せデリミタ空白で追加
                    textSoftNoBefore.Inlines.Add(string.Format("{0, -17}", softno) + " ");
                    indexBefore++;
                }
                this.Height = 120 + (rowBefore * 22);
            }

            // リプロ後ソフト品番
            if (DSTiDATA.softNoAfter != null)
            {
                int indexAfter = 0;
                int rowAfter = 1;
                foreach (string softno in DSTiDATA.softNoAfter)
                {
                    if (indexAfter != 0 && indexAfter % 2 == 0)
                    {
                        textSoftNoAfter.Inlines.Add(new LineBreak());
                        rowAfter++;
                    }

                    textSoftNoAfter.Inlines.Add(new Run());
                    // ソフト品番を左寄せデリミタ空白で追加
                    textSoftNoAfter.Inlines.Add(string.Format("{0, -17}", softno) + " ");
                    indexAfter++;
                }

                // リプロ前ソフト品番よりリプロ後ソフト品番のほうが取得件数が多い場合
                // 取得件数は同じはずであるが念のため
                if (120 + (rowAfter * 22) > this.Height)
                {
                    this.Height = 120 + (rowAfter * 22);
                }
            }
        }
    }
}
