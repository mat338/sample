﻿using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace YardRepro
{
    /// <summary>
    /// プログラム開始処理クラス
    /// </summary>
    static class Program
    {
        /// <summary>
        /// ヤードリプロメイン画面クラス
        /// </summary>
        public static YardReproMain mainForm;

        /// <summary>
        /// アプリケーションのメイン エントリ ポイントです。
        /// </summary>
        /// ### 機能説明 #######
        /// -# 二重起動防止
        /// -# 同名のプロセスが起動中処理を呼ぶ、同名のプロセスが起動中の場合は処理終了。
        /// -# ヤードリプロメイン画面を生成する。
        /// -# ヤードリプロメイン画面を生成処理中にエラーの場合は処理終了。
        /// -# アプリケーションスタート
        [STAThread]
        static void Main()
        {
            // 二重起動防止
            // 同じプロセス起動中
            if (ShowPrevProcess())
            {
                return;
            }

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // コンストラクタ実行)
            mainForm = null;
            try
            {
                mainForm = new YardReproMain();
            }
            catch (Exception)
            {
                //コンストラクタで発生した例外はここでcatchする
                return;
            }

            //　アプリケーションスタート
            Application.Run(mainForm);
        }


        /// <summary>
        /// 同名のプロセスが起動中の場合、メイン ウィンドウをアクティブにします。
        /// </summary>
        /// <returns>既に起動中であれば true。それ以外は false。</returns>
        /// ### 機能説明 #######
        /// -# カレントのプロセス取得
        /// -# カレントのプロセス名から全てのプロセスリスト取得
        /// -# プロセスリストループ
        ///     -# カレントプロセスIDと違う場合
        ///         -# 既に起動中のプロセスをアクティブ
        ///         -# 戻り値Trueで返却
        /// -# 戻り値Falseで返却
        private static bool ShowPrevProcess()
        {
            // カレントのプロセス取得
            Process hThisProcess = Process.GetCurrentProcess();
            // カレントのプロセス名から全てのプロセスリスト取得
            Process[] hProcesses = Process.GetProcessesByName(hThisProcess.ProcessName);
            int iThisProcessId = hThisProcess.Id;

            // プロセスリストループ
            foreach (Process hProcess in hProcesses)
            {
                // カレントプロセスIDと違う場合
                if (hProcess.Id != iThisProcessId)
                {
                    // 既に起動中のプロセスをアクティブ
                    NativeMethods.ShowWindow(hProcess.MainWindowHandle, 1);
                    NativeMethods.SetForegroundWindow(hProcess.MainWindowHandle);
                    return true;
                }
            }
            // 戻り値Falseで返却
            return false;
        }
    }

    /// <summary>
    /// アンマネージ コード アクセス許可クラス
    /// </summary>
    internal static class NativeMethods
    {
        /// <summary>
        /// 指定されたウィンドウの表示状態を設定します。
        /// </summary>
        /// <param name="hWnd">ウィンドウのハンドル</param>
        /// <param name="nCmdShow">表示状態</param>
        /// <returns>ウィンドウが以前から表示されていた場合は、0 以外の値が返ります。</returns>
        [DllImport("USER32.DLL", CharSet = CharSet.Auto)]
        internal static extern int ShowWindow(
            System.IntPtr hWnd,
            int nCmdShow
        );

        /// <summary>
        /// 指定されたウィンドウを作成したスレッドをフォアグラウンドにし、そのウィンドウをアクティブにします。
        /// </summary>
        /// <param name="hWnd">ウィンドウのハンドル</param>
        /// <returns>ウィンドウがフォアグラウンドになったら、0 以外の値が返ります。</returns>
        [DllImport("USER32.DLL", CharSet = CharSet.Auto)]
        internal static extern bool SetForegroundWindow(
            System.IntPtr hWnd
        );
    }
}
