﻿using System;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;
using YardRepro.dto;
using NLog;
using System.Collections.Generic;

namespace YardRepro
{
    /// <summary>
    /// ヤードリプロメイン画面
    /// </summary>
    public partial class YardReproMain : Form
    {
        #region クラス変数

        /// <summary>
        /// ログ出力クラス
        /// </summary>
        private static readonly Logger log = LogManager.GetCurrentClassLogger();

        /// <summary>
        /// ログ出力パス
        /// </summary>
        private const String LOGPATHNAME = "Log";

        /// <summary>
        /// ログ出力ファイル名
        /// </summary>
        private const String LOGFILENAME = "YardRepro";

        /// <summary>
        /// トライアル(メッセージ表示Only)モードフラグ
        /// </summary>
        private static readonly bool isTrialMode = false;

        /// <summary>
        /// 例外処理用ロックオブジェクト
        /// </summary>
        private Object exceptionLock = new Object();

        /// <summary>
        /// 接続リスト画面
        /// </summary>
        private YardReproConnect yardReproConnect = new YardReproConnect();

        /// <summary>
        /// DSTリスト
        /// </summary>
        public DSTDtoList DstList { get; set; }
        #endregion クラス変数

        #region コンストラクタ
        /// <summary>
        /// 静的コンストラクタ
        /// </summary>
        /// ### 機能説明 #######
        /// -# トライアルモードチェック
        static YardReproMain()
        {
            // トライアルモードチェック
            isTrialMode = YardReproUtil.checkTrialMode();
        }

        /// <summary>
        /// コンストラクタ
        /// </summary>
        /// ### 機能説明 #######
        /// -# 画面コンポーネントの初期処理
        /// -# フォント設定
        ///     -# ログ出力パス設定
        ///     -# ログ出力先動的変更
        ///     
        ///     -# 定義ファイルが存在しない場合
        ///         -# 初期値で定義ファイルを作成する
        ///             キー        | 値
        ///             ------------| -------------
        ///             TIMEOUT     | 10
        ///             SAVE_FOLDER | C:\Users\[UserName]\Documents\YardRepro
        ///             
        ///     -# 後処理開始API受信タイムアウト値が数値の場合
        ///         -# DSTステータスリストユーザコントロールに後処理開始API受信タイムアウト値を設定
        ///     -# 後処理開始API受信タイムアウト値が数値ではない場合
        ///         -# DSTステータスリストユーザコントロールに初期値を設定
        ///     -# DTCログファイル保存先がPCに存在しない場合
        ///         -# DTCログファイル保存先ディレクトリを作成
        ///         -# DTCログファイル保存先ディレクトリの作成に失敗した場合
        ///             -# DTCログファイル保存先ディレクトリを初期値を設定
        ///     -# DTCログファイル保存先がPCに存在する場合
        ///         -# アクセス権限確認用ファイルをDTCログファイル保存先ディレクトリに出力
        ///         -# DTCログファイル保存先ディレクトリに作成にアクセス権限確認用ファイルの出力が失敗した場合
        ///             -# DTCログファイル保存先ディレクトリを初期値を設定
        ///         -# アクセス権限確認用ファイルが作成されている場合は削除する
        ///         
        ///     -# DSTステータスリストユーザコントロールにDTCログファイル保存先を設定
        /// 
        ///     -# 画面に文言を設定する
        ///         コントロール     | 文言
        ///         -------------    | -------------
        ///         フォームタイトル | ヤードリプロ
        ///         選択なしラベル   | 選択されていません。
        ///         閉じるボタン     | 閉じる
        ///         DST選択ボタン    | DST選択
        ///         CSV出力ボタン    | CSV出力
        ///         
        ///     -# 例外発生時のイベントを追加
        /// -# 例外が発生時した場合
        ///     -# エラーログ出力
        ///     -# スタックトレースログ出力
        ///     -# 例外をスロー
        public YardReproMain()
        {
            InitializeComponent();

            // フォント設定
            this.lblSearching.Font = new System.Drawing.Font(this.Font.FontFamily, 15.75F);
            this.btnTrialF2.Font = new System.Drawing.Font(this.Font.FontFamily, 8F);
            this.btnTrialF1.Font = new System.Drawing.Font(this.Font.FontFamily, 8F);

            try
            {
                // ログ出力パス設定
                String logPath = LOGPATHNAME + @"\" + LOGFILENAME;
                // ログ出力先動的変更
                NLog.Targets.FileTarget target = (NLog.Targets.FileTarget)LogManager.Configuration.FindTargetByName("LogToFile");
                if (!string.IsNullOrEmpty(target.FileName.ToString()))
                {
                    target.FileName = logPath + ".log";
                    target.ArchiveFileName = logPath + "_{#}.log";
                }
                log.Debug("----------");
                log.Debug("START");

                // [yardrepro.ini]を読込み設定値を取得する
                Ini ini = new Ini(Consts.INI_FILEPATH);

                // 設定ファイルがない場合
                if (!System.IO.File.Exists(Consts.INI_FILEPATH))
                {
                    // 初期値で定義ファイルを作成する
                    ini[Consts.INI_SECTION_NAME, Consts.INI_TIMEOUT_KEY] = Consts.INI_TIMEOUT_VALUE.ToString();
                    ini[Consts.INI_SECTION_NAME, Consts.INI_SAVE_FOLDER_KEY] = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + Consts.INI_SAVE_FOLDER_VALUE;
                }

                // 後処理開始API受信タイムアウト値取得
                int ret = 0;
                if (int.TryParse(ini[Consts.INI_SECTION_NAME, Consts.INI_TIMEOUT_KEY], out ret))
                {
                    this.dsTiList1.iniTimeout = ret * 1000;
                }
                else
                {
                    this.dsTiList1.iniTimeout = Consts.INI_TIMEOUT_VALUE * 1000;
                }
                log.Debug("ini -TIMEOUT[" + this.dsTiList1.iniTimeout + "]");


                // DTCログファイル保存先の確認
                if (!System.IO.Directory.Exists(ini[Consts.INI_SECTION_NAME, Consts.INI_SAVE_FOLDER_KEY]))
                {
                    try
                    {
                        // ディレクトリがない場合は作成する
                        System.IO.Directory.CreateDirectory(ini[Consts.INI_SECTION_NAME, Consts.INI_SAVE_FOLDER_KEY]);
                    }
                    catch (Exception)
                    {
                        try
                        {
                            // 未設定or無効なパスの場合は初期値で設定ファイルに書き込む
                            ini[Consts.INI_SECTION_NAME, Consts.INI_SAVE_FOLDER_KEY] = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + Consts.INI_SAVE_FOLDER_VALUE;
                            // ディレクトリがない場合は作成する
                            System.IO.Directory.CreateDirectory(ini[Consts.INI_SECTION_NAME, Consts.INI_SAVE_FOLDER_KEY]);
                        }
                        catch(Exception ioe)
                        {
                            // 例外が発生時した場合

                            // エラーログ出力
                            log.Error(ioe.Message);
                            // スタックトレースログ出力
                            log.Error(ioe.StackTrace);
                            // 例外をスロー
                            throw;
                        }
                    }
                }
                else
                {
                    string path = ini[Consts.INI_SECTION_NAME, Consts.INI_SAVE_FOLDER_KEY] + @"\YardRepro_test_output.log";
                    // 書き込み権限があるかチェックする。
                    try
                    {
                        // アクセス権限確認用ファイルをDTCログファイル保存先に出力
                        using (var sw = new System.IO.StreamWriter(path, true))
                        {
                        }
                    }
                    catch
                    {
                        // アクセス権限のないパスの場合は初期値で設定ファイルに書き込む
                        ini[Consts.INI_SECTION_NAME, Consts.INI_SAVE_FOLDER_KEY] = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + Consts.INI_SAVE_FOLDER_VALUE;
                    }
                    finally
                    {
                        if (System.IO.File.Exists(path))
                        {
                            System.IO.File.Delete(path);
                        }
                    }
                }
                this.dsTiList1.iniSaveFolder = ini[Consts.INI_SECTION_NAME, Consts.INI_SAVE_FOLDER_KEY];
                log.Debug("ini -SAVE_FOLDER[" + this.dsTiList1.iniSaveFolder + "]");

                // 画面に文言を設定する
                this.Text = Consts.SCREEN_MAIN_TITLE;
                this.lblSearching.Text = Consts.SCREEN_MAIN_LBL_SEARCHING;
                this.btnClose.Text = Consts.SCREEN_MAIN_BTN_CLOSE;
                this.btnDSTSelect.Text = Consts.SCREEN_MAIN_BTN_DSTSELECT;
                this.btnCsv.Text = Consts.SCREEN_MAIN_BTN_CSV;

                // 例外発生時のイベントを追加
                Application.ThreadException += new ThreadExceptionEventHandler(CatchThreadException);
                Thread.GetDomain().UnhandledException += new UnhandledExceptionEventHandler(CatchUnhandledException);
            }
            catch (Exception e1)
            {
                // 例外が発生時した場合

                // エラーログ出力
                log.Error(e1.Message);
                // スタックトレースログ出力
                log.Error(e1.StackTrace);
                // 例外をスロー
                throw;
            }
            log.Debug("END");
        }
        #endregion コンストラクタ

        #region フォームイベント

        /// <summary>
        /// 画面表示完了後、DST-WiFi一覧を表示する
        /// </summary>
        /// <param name="sender">発生元オブジェクト</param>
        /// <param name="e">イベント引数</param>
        /// ### 機能説明 #######
        /// -# トライアルモードの場合は、トライアル初期画面処理を呼出し
        /// -# DSTiリストを初期化エラーの場合
        ///     -# 画面閉じる
        ///     -# メソッド終了
        /// -# DST選択画面をダイアログ表示
        /// -# DST選択画面で選択リストが更新された場合
        ///     -# 選択リストを全て追加
        /// -# トライアルモードの場合、終了
        /// -# 画面更新処理を呼出し
        private void ConnectionManager_Shown(object sender, EventArgs e)
        {
            log.Debug("START");

            // トライアルモードの場合は、トライアル初期画面処理を呼出し
            if (isTrialMode) initTrial();

            // DSTiリストを初期化エラーの場合
            if (!this.dsTiList1.init())
            {
                // 画面閉じる
                this.Close();
                // メソッド終了
                return;
            }

            // DST選択画面をダイアログ表示
            this.DstList = null;
            yardReproConnect.ShowDialog(this);
            // DST選択画面で選択リストが更新された場合
            if (this.DstList != null)
            {
                // 選択リストを全て追加
                this.dsTiList1.addAll(this.DstList);
            }

            // トライアルモードの場合、終了
            if (isTrialMode) return;

            // 画面更新処理を呼出し
            this.RefreshForm();

            log.Debug("END");
        }

        /// <summary>
        /// 画面更新処理
        /// </summary>
        /// ### 機能説明 #######
        /// -# 選択なしメッセージをリストが0件の場合表示、それ以外の場合は非表示に設定
        /// -# CSVボタンをリストが1件以上の場合活性、それ以外の場合は非活性に設定
        private void RefreshForm()
        {
            // 選択なしメッセージをリストが0件の場合表示、それ以外の場合は非表示に設定
            lblSearching.Visible = dsTiList1.list.Count == 0;
            // CSVボタンをリストが1件以上の場合活性、それ以外の場合は非活性に設定
            btnCsv.Enabled = dsTiList1.list.Count > 0;
        }

        /// <summary>
        /// フォームクローズ処理
        /// </summary>
        /// <param name="sender">発生元オブジェクト</param>
        /// <param name="e">イベント引数</param>
        /// ### 機能説明 #######
        /// -# リストの更新スレッドを全て停止
        private void YardReproMain_FormClosed(object sender, FormClosedEventArgs e)
        {
            // リストの更新スレッドを全て停止
            dsTiList1.taskAllStop();
            dsTiList1.taskRequestSignatureStop();
        }


        #endregion フォームイベント

        #region ボタンイベント

        /// <summary>
        /// DST選択ボタン
        /// </summary>
        /// <param name="sender">発生元オブジェクト</param>
        /// <param name="e">イベント引数</param>
        /// ### 機能説明 #######
        /// -# DST選択画面をダイアログ表示
        /// -# DST選択画面で選択リストが更新された場合
        ///     -# 選択されたDSTを全て画面のリストへ追加
        /// -# 画面更新処理を呼出し
        private void btnDSTSelect_Click(object sender, EventArgs e)
        {
            log.Debug("START");
            // DST選択画面をダイアログ表示
            this.DstList = null;
            yardReproConnect.ShowDialog(this);
            // DST選択画面で選択リストが更新された場合
            if (this.DstList != null)
            {
                // 選択されたDSTを全て画面のリストへ追加
                this.dsTiList1.addAll(this.DstList);
            }
            // 画面更新処理を呼出し
            this.RefreshForm();
            log.Debug("END");
        }

        /// <summary>
        /// CSV出力ボタン
        /// </summary>
        /// <param name="sender">発生元オブジェクト</param>
        /// <param name="e">イベント引数</param>
        /// ### 機能説明 #######
        /// -# SaveFileDialogクラスのインスタンスを生成
        /// 項目                       | 設定値
        /// -------------              | -------------
        /// ファイル名                 | newfile.csv
        /// 初期フォルダ               | マイドキュメント
        /// ファイルの種類の選択肢     | CSVファイル(*.csv) *.csv,すべてのファイル(*.*) *.*
        /// ファイルの種類の初期選択   | CSVファイル(*.csv)
        /// ウィンドウタイトル         | 保存先のファイルを選択してください
        /// フォルダ復元設定           | True
        /// 上書き確認                 | True
        /// フォルダ確認               | True
        /// 
        /// -# ダイアログを表示する
        /// -# OKボタンがクリックされた場合
        ///     -# 指定ファイルを書込みオープン
        ///     -# ファイルにCSVタイトルを追加
        ///     -# ファイルに表示リスト分のデータをカンマ区切りで出力
        ///         項目          | 設定値
        ///         ------------- | -------------
        ///         1番目         | シリアルNo
        ///         2番目         | VIN
        ///         3番目         | リプロ前ソフト品番をスペース区切り
        ///         3番目         | リプロ後ソフト品番をスペース区切り
        ///         4番目         | リプロ状況
        ///         
        ///     -# ファイル出力中にエラーが発生した場合、エラーメッセージを表示
        ///         項目         | 設定値
        ///         -------------| -------------
        ///         メッセージ   | 書込みに失敗しました。\n出力先を確認して再度実行してください。
        ///         ウィンドウ名 | ヤードリプロ
        ///         ボタン       | OKのみ
        ///         アイコン     | エラーアイコン
        ///             
        private void btnCsv_Click(object sender, EventArgs e)
        {
            log.Debug("START");

            // SaveFileDialogクラスのインスタンスを生成
            SaveFileDialog sfd = new SaveFileDialog();

            // SaveFileDialogクラスのインスタンスを設定
            sfd.FileName = Consts.CSV_DEFAULT_FILENAME;
            sfd.InitialDirectory = System.Environment.GetFolderPath(Environment.SpecialFolder.Personal);
            sfd.Filter = Consts.CSV_FILTER;
            sfd.FilterIndex = 1;
            sfd.Title = Consts.CSV_TITLE;
            sfd.RestoreDirectory = true;
            sfd.OverwritePrompt = true;
            sfd.CheckPathExists = true;

            // ダイアログを表示する
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                // OKボタンがクリックされた場合、CSVファイルを作成する
                log.Debug(sfd.FileName);
                try
                {
                    // 指定ファイルを書込みオープン
                    using (var sw = new System.IO.StreamWriter(sfd.FileName, false))
                    {
                        // ファイルにCSVタイトルを追加
                        sw.WriteLine(Consts.CSV_HEADER);
                        foreach (DSTDto dto in dsTiList1.list)
                        {
                            // ファイルに表示リスト分のデータをカンマ区切りで出力
                            string softNoListBefore = string.Empty;
                            if (dto.softNoBefore != null)
                            {
                                foreach (string softno in dto.softNoBefore)
                                {
                                    softNoListBefore += softno + ' ';
                                }
                                softNoListBefore = softNoListBefore.Trim();
                            }
                            // 2019.02
                            string softNoListAfter = string.Empty;
                            if (dto.softNoAfter != null)
                            {
                                foreach (string softno in dto.softNoAfter)
                                {
                                    softNoListAfter += softno + ' ';
                                }
                                softNoListAfter = softNoListAfter.Trim();
                            }

                            // CSV出力内容
                            sw.WriteLine(Consts.CSV_FORMAT, dto.serialNo, dto.vinNo, softNoListBefore, softNoListAfter, dto.message);
                        }
                    }
                }
                catch
                {
                    // ファイル出力中にエラーが発生した場合

                    // エラーメッセージを表示
                    MessageBox.Show(Consts.MESSAGE_ERROR_CSV,
                                    this.Text,
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Error);
                }
            }
            log.Debug("END");
        }


        /// <summary>
        /// 「閉じる」ボタン押下処理
        /// </summary>
        /// <param name="sender">発生元オブジェクト</param>
        /// <param name="e">イベント引数</param>
        /// ### 機能説明 #######
        /// -# フォームを閉じる
        private void btnClose_Click(object sender, EventArgs e)
        {
            log.Debug("START");
            // フォームを閉じる
            this.Close();
            log.Debug("END");
        }
        #endregion ボタンイベント

        #region DSTiリストイベント

        /// <summary>
        /// DSTiリスト更新イベント
        /// </summary>
        /// <param name="sender">発生元オブジェクト</param>
        /// <param name="e">イベント引数</param>
        /// ### 機能説明 #######
        /// -# 画面更新処理を呼出し
        private void DstiList_OnRefresh(object sender, EventArgs e)
        {
            // 画面更新処理を呼出し
            this.RefreshForm();
        }

        #endregion DSTiリストイベント

        #region 例外処理

        /// <summary>
        /// 例外処理
        /// </summary>
        /// <param name="sender">発生元オブジェクト</param>
        /// <param name="e">イベント引数</param>
        /// ### 機能説明 #######
        /// -# 例外処理ロック
        /// -# 発生した例外がNULL以外の場合
        ///     -# エラーログ出力
        ///     -# スタックトレースログ出力
        /// -# エラーメッセージを表示
        /// 項目         | 設定値
        /// -------------| -------------
        /// メッセージ   | システムエラーが発生しました。\nシステム管理者に問い合わせてください。
        /// ウィンドウ名 | ヤードリプロ
        /// ボタン       | OKのみ
        /// アイコン     | エラーアイコン
        /// 
        /// -# プロセスを終了
        public void CatchThreadException(object sender, ThreadExceptionEventArgs e)
        {
            // 例外処理ロック
            lock (exceptionLock)
            {
                log.Debug("start");
                // 発生した例外がNULL以外の場合
                if (e.Exception != null)
                {
                    // エラーログ出力
                    log.Error(e.Exception.Message);
                    // スタックトレースログ出力
                    log.Error(e.Exception.StackTrace);
                }
                // エラーメッセージを表示

                MessageBox.Show(Consts.MESSAGE_ERROR_SYSTEM,
                                this.Text,
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);

                // プロセスを終了
                Environment.Exit(1);
            }
        }

        /// <summary>
        /// 例外処理
        /// </summary>
        /// <param name="sender">発生元オブジェクト</param>
        /// <param name="e">イベント引数</param>
        /// ### 機能説明 #######
        /// -# 例外処理ロック
        /// -# 発生した例外がNULL以外の場合
        ///     -# エラーログ出力
        ///     -# スタックトレースログ出力
        /// -# エラーメッセージを表示
        /// 項目         | 設定値
        /// -------------| -------------
        /// メッセージ   | システムエラーが発生しました。\nシステム管理者に問い合わせてください。
        /// ウィンドウ名 | ヤードリプロ
        /// ボタン       | OKのみ
        /// アイコン     | エラーアイコン
        /// 
        /// -# プロセスを終了
        public void CatchUnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            // 例外処理ロック
            lock (exceptionLock)
            {
                log.Debug("start");
                Exception ex = e.ExceptionObject as Exception;
                // 発生した例外がNULL以外の場合
                if (ex != null)
                {
                    // エラーログ出力
                    log.Error(ex.Message);
                    // スタックトレースログ出力
                    log.Error(ex.StackTrace);
                }
                // エラーメッセージを表示
                MessageBox.Show(Consts.MESSAGE_ERROR_SYSTEM,
                                this.Text,
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);

                // プロセスを終了
                Environment.Exit(1);
            }
        }

        #endregion 例外処理

        #region トライアルモード関数

        /// <summary>
        /// トライアルモード種別
        /// </summary>
        private enum TrialMode { init, idel, scan, exec, exec2, exec3, cancel, comp}
        /// <summary>
        /// トライアルモード
        /// </summary>
        private TrialMode trialMode;
        /// <summary>
        /// トライアルモードタイトル
        /// </summary>
        private string trialTitle;

        /// <summary>
        /// トライアルモード時の初期表示処理
        /// </summary>
        /// ### 機能説明 #######
        /// -# トライアル用で使用するボタンを表示する
        /// -# 画面の表示位置設定
        /// -# 画面のリフレッシュ
        /// -# タイトル変更
        /// -# 自画面をアクティブに設定
        private void initTrial()
        {
            // トライアル用で使用するボタンを表示する
            btnTrialF1.Visible = true;
            btnTrialF2.Visible = true;

            // 画面の表示位置設定
            this.StartPosition = FormStartPosition.Manual;
            this.Location = new Point(50, 150);

            trialMode = TrialMode.init;

            dsTiList1.isTrial = true;

            // 画面のリフレッシュ
            //dstiList.Refresh();
            RefreshForm();
            this.lblSearching.Visible = true;

            // タイトル変更
            this.trialTitle = this.Text;
            this.Text = " Trial Mode:" + trialMode + " " + this.trialTitle;

            // 自分を前面に
            this.Activate();
        }

        /// <summary>
        /// トライアルボタン（リスト表示)
        /// </summary>
        /// <param name="sender">発生元オブジェクト</param>
        /// <param name="e">イベント引数</param>
        /// ### 機能説明 #######
        /// -# トライアル用モード切替処理
        private void btnTrialF1_Click(object sender, EventArgs e)
        {
            this.trialMode++;
            if (Enum.GetNames(typeof(TrialMode)).Length <= (int)this.trialMode)
            {
                this.trialMode = TrialMode.init;
            }
            this.Text = " Trial Mode:" + trialMode + " " + this.trialTitle;
            this.lblSearching.Visible = false;
            switch (this.trialMode)
            {
                case TrialMode.init:
                    // 初期画面

                    dsTiList1.list.Clear();
                    dsTiList1.ItemsRefresh();
                    RefreshForm();
                    this.lblSearching.Visible = true;
                    break;

                case TrialMode.idel:
                    // 一覧更新
                    dsTiList1.AddDstiItemForTrial();
                    dsTiList1.ItemsRefresh();
                    RefreshForm();
                    this.lblSearching.Visible = false;
                    break;

                case TrialMode.scan:
                    // スキャン中
                    RefreshForm();
                    break;

                case TrialMode.exec:
                    // 実行中

                    // 選択を非活性
                    foreach (DSTDto dto in dsTiList1.list) dto.isSelectEnabled = false;

                    // 成功
                    dsTiList1.list[0].isSelected = true;
                    dsTiList1.list[0].progresValue = 100;
                    dsTiList1.list[0].vinNo = "000000000000000001";
                    List<string> softNoList = new List<string>();
                    softNoList.Add("10000000000000001");
                    dsTiList1.list[0].softNoBefore = softNoList;
                    DSTDtoUtil.updateSuccess(dsTiList1.list[0]);
                    // 処理中
                    dsTiList1.list[1].isSelected = true;
                    DSTDtoUtil.updateExec(dsTiList1.list[1], 50);
                    // 失敗
                    dsTiList1.list[2].isSelected = true;
                    DSTDtoUtil.updateError(dsTiList1.list[2], "4");

                    dsTiList1.ItemsRefresh();

                    RefreshForm();
                    break;

                case TrialMode.exec2:
                    // 実行中

                    // 選択を非活性
                    foreach (DSTDto dto in dsTiList1.list) dto.isSelectEnabled = false;

                    // 成功
                    dsTiList1.list[0].isSelected = true;
                    dsTiList1.list[0].progresValue = 100;
                    dsTiList1.list[0].vinNo = "000000000000000001";
                    List<string> softNoList1 = new List<string>();
                    softNoList1.Add("10000000000000001");
                    dsTiList1.list[0].softNoBefore = softNoList1;
                    DSTDtoUtil.updateSuccess(dsTiList1.list[0]);
                    // 切断
                    DSTDtoUtil.updateNotConnect(dsTiList1.list[1]);
                    // 失敗
                    dsTiList1.list[2].isSelected = true;
                    DSTDtoUtil.updateError(dsTiList1.list[2], "4");

                    dsTiList1.ItemsRefresh();

                    RefreshForm();
                    break;

                case TrialMode.exec3:
                    // 実行中

                    // 選択を非活性
                    foreach (DSTDto dto in dsTiList1.list) dto.isSelectEnabled = false;

                    // 成功
                    dsTiList1.list[0].isSelected = true;
                    dsTiList1.list[0].progresValue = 100;
                    dsTiList1.list[0].vinNo = "000000000000000001";
                    List<string> softNoList2 = new List<string>();
                    softNoList2.Add("10000000000000001");
                    dsTiList1.list[0].softNoBefore = softNoList2;
                    DSTDtoUtil.updateSuccess(dsTiList1.list[0]);
                    // 切断
                    DSTDtoUtil.updateNotConnect(dsTiList1.list[1]);
                    // リトライ開始
                    DSTDtoUtil.updateIdle(dsTiList1.list[2]);

                    dsTiList1.ItemsRefresh();

                    RefreshForm();
                    break;


                case TrialMode.cancel:
                    // キャンセル中
                    RefreshForm();

                    break;

                case TrialMode.comp:
                    // 実行完了

                    // 選択を活性
                    foreach (DSTDto dto in dsTiList1.list)
                    {
                        dto.isSelectEnabled = true;
                        if (String.IsNullOrEmpty(dto.hostName)) dto.isEnabled = true;
                    }

                    // 処理中→完了
                    dsTiList1.list[5].progresValue = 6;
                    DSTDtoUtil.updateSuccess(dsTiList1.list[5]);
                    // 待機中→完了
                    dsTiList1.list[6].progresValue = 6;
                    DSTDtoUtil.updateSuccess(dsTiList1.list[6]);

                    dsTiList1.ItemsRefresh();
                    RefreshForm();
                    this.lblSearching.Visible = false;

                    break;

            }
        }

        /// <summary>
        /// トライアルボタン（メッセージ表示)
        /// </summary>
        /// <param name="sender">発生元オブジェクト</param>
        /// <param name="e">イベント引数</param>
        /// ### 機能説明 #######
        /// -# LAN AutoConfigサービスエラー表示
        /// -# WiFiモジュールエラー表示
        /// -# システムエラー表示
        private void btnTrialF2_Click(object sender, EventArgs e)
        {

            // LAN AutoConfigサービスエラー表示
            MessageBox.Show(Consts.MESSAGE_ERROR_WLAN_SERVICE,
                            this.Text,
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error);
            // WiFiモジュールエラー表示
            MessageBox.Show(Consts.MESSAGE_ERROR_WLAN_NOT,
                            this.Text,
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error);
            // システムエラー表示
            MessageBox.Show(Consts.MESSAGE_ERROR_SYSTEM,
                            this.Text,
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error);
        }

        private void YardReproMain_KeyDown(object sender, KeyEventArgs e)
        {
            if (!isTrialMode) return;
            if (e.Alt == true)
            {
                btnTrialF1.Visible = false;
                btnTrialF2.Visible = false;
            }
        }

        private void YardReproMain_KeyUp(object sender, KeyEventArgs e)
        {
            if (!isTrialMode) return;
            btnTrialF1.Visible = true;
            btnTrialF2.Visible = true;
        }
        #endregion

    }
}
