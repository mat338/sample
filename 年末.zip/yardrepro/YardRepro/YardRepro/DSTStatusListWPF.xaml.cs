﻿using System;
using System.Windows.Controls;
using YardRepro.dto;
using NLog;

namespace YardRepro
{
    /// <summary>
    /// DSTステータスリストコントロール
    /// </summary>
    public partial class DSTStatusListWPF : UserControl
    {
        /// <summary>
        /// ログ出力クラス
        /// </summary>
        private static readonly Logger log = LogManager.GetCurrentClassLogger();

        /// <summary>
        /// リトライクリックイベント
        /// </summary>
        public event EventHandler RetryClick;

        /// <summary>
        /// DTC実行クリックイベント
        /// </summary>
        public event EventHandler DtcExecClick;

        /// <summary>
        /// コンストラクタ
        /// </summary>
        /// ### 機能説明 #######
        /// -# 画面コンポーネントの初期処理
        /// -# リストデータを初期化
        public DSTStatusListWPF()
        {
            InitializeComponent();
            this.DataContext = this;
            DstiList = new DSTDtoList();

        }

        /// <summary>
        /// DSTiリスト
        /// </summary>
        public DSTDtoList DstiList { get; set; }

        /// <summary>
        /// DSTステータスリストコントロール選択イベント
        /// </summary>
        /// ### 機能説明 #######
        /// -# リスト選択の選択INDEXを-1に設定して選択を無効化する。
        private void listBox1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // 選択を無効化
            listBox1.SelectedIndex = -1;
        }

        /// <summary>
        /// DSTステータスアイテムコントロールリトライ押下イベント
        /// </summary>
        /// ### 機能説明 #######
        /// -# リトライ押下イベントを発生させる
        private void DSTStutusListItemWPF_RetryClick(object sender, EventArgs e)
        {
            if (RetryClick != null)
            {
                RetryClick(this, EventArgs.Empty);
            }
        }

        /// <summary>
        /// DSTステータスアイテムコントロール DTC消去押下イベント
        /// </summary>
        /// ### 機能説明 #######
        /// -# DTC消去押下イベントを発生させる
        private void DSTStutusListItemWPF_DtcExecClick(object sender, EventArgs e)
        {
            if (DtcExecClick != null)
            {
                DtcExecClick(this, EventArgs.Empty);
            }
        }
    }
}
