﻿using System;
using System.Windows.Controls;
using YardRepro.dto;
using NLog;

namespace YardRepro
{
    /// <summary>
    /// DST接続リストコントロール
    /// </summary>
    public partial class DSTConnectListWPF : UserControl
    {
        /// <summary>
        /// ログ出力クラス
        /// </summary>
        private static readonly Logger log = LogManager.GetCurrentClassLogger();

        /// <summary>
        /// 選択チェンジイベント
        /// </summary>
        public event EventHandler OnSelectedChange;

        /// <summary>
        /// コンストラクタ
        /// </summary>
        /// ### 機能説明 #######
        /// -# 画面コンポーネントの初期処理
        /// -# リストデータを初期化
        public DSTConnectListWPF()
        {
            InitializeComponent();
            this.DataContext = this;
            DstiList = new DSTDtoList();
        }

        /// <summary>
        /// DST接続リストデータ
        /// </summary>
        public DSTDtoList DstiList { get; set; }

        /// <summary>
        /// DST接続リストコントロール選択イベント
        /// </summary>
        /// <param name="sender">発生元オブジェクト</param>
        /// <param name="e">イベント引数</param>
        /// ### 機能説明 #######
        /// -# リスト選択の選択INDEXを-1に設定して選択を無効化する。
        private void listBox1_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // 選択を無効化
            listBox1.SelectedIndex = -1;
        }

        /// <summary>
        /// DST接続アイテムコントロール選択チェック変更イベント
        /// </summary>
        /// <param name="sender">発生元オブジェクト</param>
        /// <param name="e">イベント引数</param>
        /// ### 機能説明 #######
        /// -# 選択チェンジイベントを発生させる
        private void DSTConnectListItemWPF_OnSelectedChange(object sender, EventArgs e)
        {
            if (OnSelectedChange != null)
            {
                OnSelectedChange(this, EventArgs.Empty);
            }
        }
    }
}
