﻿using System;
using System.Linq;
using System.Windows.Forms;
using YardRepro.dto;

namespace YardRepro
{
    /// <summary>
    /// ヤードリプロ選択画面
    /// </summary>
    public partial class YardReproConnect : Form
    {

        #region クラス変数
        /// <summary>
        /// トライアル(メッセージ表示Only)モードフラグ
        /// </summary>
        private static readonly bool isTrialMode = false;
        #endregion

        #region コンストラクタ
        /// <summary>
        /// コンストラクタ
        /// </summary>
        /// ### 機能説明 #######
        /// -# トライアルモードチェック
        static YardReproConnect()
        {
            //トライアルモードチェック
            isTrialMode = YardReproUtil.checkTrialMode();
        }

        /// <summary>
        /// コンストラクタ
        /// </summary>
        /// ### 機能説明 #######
        /// -# 画面コンポーネントの初期処理
        /// -# 画面に文言を設定する
        /// 画面項目設定
        /// コントロール     | 文言
        /// -------------    | -------------
        /// タイトル         | DST選択
        /// 検索中ラベル     | 検索中
        /// 次へボタン       | 次へ
        public YardReproConnect()
        {
            InitializeComponent();
            // 画面に文言を設定する
            this.Text = Consts.SCREEN_CONNECT_TITLE;
            this.btnNext.Text = Consts.SCREEN_CONNECT_BTN_NEXT;
            this.lblSearching.Text = Consts.SCREEN_CONNECT_LBL_SEARCHING;
        }
        #endregion

        #region フォームイベント
        /// <summary>
        /// フォーム表示イベント
        /// </summary>
        /// <param name="sender">発生元オブジェクト</param>
        /// <param name="e">イベント引数</param>
        /// ### 機能説明 #######
        /// -# フォームの更新
        /// -# トライアルモードの場合
        ///     -# トライアルモード用の画面初期処理を呼び出し
        ///     -# メソッド終了
        /// -# スキャン開始
        private void YardReproConnect_Shown(object sender, EventArgs e)
        {
            // フォームの更新
            this.RefreshForm();

            // トライアルモードの場合
            if (isTrialMode)
            {
                // トライアルモード用の画面初期処理を呼び出し
                initTrial();
                // メソッド終了
                return;
            }
            // スキャン開始
            dstConnectList1.Start();
        }

        /// <summary>
        /// フォーム非表示イベント
        /// </summary>
        /// <param name="sender">発生元オブジェクト</param>
        /// <param name="e">イベント引数</param>
        /// ### 機能説明 #######
        /// -# リストのスキャン停止
        private void YardReproConnect_FormClosed(object sender, FormClosedEventArgs e)
        {
            //スキャン停止
            dstConnectList1.Stop();
        }

        /// <summary>
        /// フォームの表示文言・有効無効を切り替える
        /// </summary>
        /// ### 機能説明 #######
        /// -# 検索中メッセージをリストが0件の場合表示、それ以外の場合は非表示に設定
        /// -# 次へボタンをリストが１つ以上選択されている場合は活性、それ以外の場合は非活性に設定
        private void RefreshForm()
        {
            // 検索中メッセージをリストが0件の場合表示、それ以外の場合は非表示に設定
            this.lblSearching.Visible = dstConnectList1.list.Count == 0;

            // 次へボタンをリストが１つ以上選択されている場合は活性、それ以外の場合は非活性に設定
            this.btnNext.Enabled = dstConnectList1.isSelectedItem();
        }

        /// <summary>
        /// 次へボタン押下イベント
        /// </summary>
        /// <param name="sender">発生元オブジェクト</param>
        /// <param name="e">イベント引数</param>
        /// ### 機能説明 #######
        /// -# リスト中の選択されている項目が５つを超えている場合
        ///     -# エラーメッセージを表示
        ///     項目         | 設定値
        ///     -------------| -------------
        ///     メッセージ   | 選択できるDSTは５つまでです。
        ///     ウィンドウ名 | ヤードリプロ
        ///     ボタン       | OKのみ
        ///     アイコン     | エラーアイコン
        /// 
        /// -# リストの中から選択されたDSTを追加更新する。
        ///     -# 選択されているDSTのみプロパティリストに追加
        /// -# メインフォームへリストを設定
        /// -# スキャン停止
        private void btnNext_Click(object sender, EventArgs e)
        {
            // リスト中の選択されている項目が５つを超えている場合
            if (dstConnectList1.list.Where(d => d.isSelected == true).Count() > 5)
            {
                // エラーメッセージを表示
                MessageBox.Show("選択できるDSTは５つまでです。",
                    this.Text,
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return;
            }
            // 選択されたDSTを追加更新する。
            DSTDtoList dstList = new DSTDtoList();
            foreach (DSTDto dto in dstConnectList1.list)
            {
                // 選択されているDSTのみプロパティリストに追加
                if (dto.isSelected)
                {
                    dstList.Add(DSTDtoUtil.createDstiDto(dto));
                }
            }
            // メインフォームへリストを設定
            Program.mainForm.DstList = dstList;
            // スキャン停止
            dstConnectList1.Stop();
            this.Hide();
        }

        /// <summary>
        /// リストのチェックボックス変更イベント
        /// </summary>
        /// <param name="sender">発生元オブジェクト</param>
        /// <param name="e">イベント引数</param>
        /// ### 機能説明 #######
        /// -# 画面更新処理を呼出し
        private void dstConnectList1_OnSelectedChange(object sender, EventArgs e)
        {
            this.RefreshForm();
        }

        /// <summary>
        /// リスト更新イベント
        /// </summary>
        /// <param name="sender">発生元オブジェクト</param>
        /// <param name="e">イベント引数</param>
        /// ### 機能説明 #######
        /// -# 画面更新処理を呼出し
        private void dstConnectList1_OnRefreshList(object sender, EventArgs e)
        {
            this.RefreshForm();
        }
        #endregion

        #region トライアルモード関数

        /// <summary>
        /// トライアルモード種類
        /// </summary>
        private enum TrialMode { init, one, three, multi }

        /// <summary>
        /// トライアルモード
        /// </summary>
        private TrialMode trialMode;

        /// <summary>
        /// トライアルモード時の初期表示処理
        /// </summary>
        /// ### 機能説明 #######
        /// -# トライアル用で使用するボタンを表示する
        /// -# 自画面をアクティブに設定 
        private void initTrial()
        {
            //トライアル用で使用するボタンを表示する
            btnTrialF1.Visible = true;
            RefreshForm();

            //自分を前面に
            this.Activate();
        }

        /// <summary>
        /// トライアルモードF1ボタンクリックイベント
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// <param name="sender">発生元オブジェクト</param>
        /// <param name="e">イベント引数</param>
        /// ### 機能説明 #######
        /// -# トライアルモードの画面を切り替える
        private void btnTrialF1_Click(object sender, EventArgs e)
        {
            this.trialMode++;
            if (Enum.GetNames(typeof(TrialMode)).Length <= (int)this.trialMode)
            {
                this.trialMode = TrialMode.init;
            }
            this.Text = " Trial Mode:" + trialMode + " ";
            this.lblSearching.Visible = false;
            switch (this.trialMode)
            {
                case TrialMode.init:
                    // 初期画面
                    dstConnectList1.list.Clear();
                    dstConnectList1.ItemsRefresh();

                    RefreshForm();
                    break;

                case TrialMode.one:

                    dstConnectList1.AddDstiItemForTrial(1);
                    dstConnectList1.ItemsRefresh();
                    this.lblSearching.Visible = false;
                    break;

                case TrialMode.three:

                    dstConnectList1.AddDstiItemForTrial(3);
                    dstConnectList1.ItemsRefresh();
                    RefreshForm();
                    this.lblSearching.Visible = false;
                    break;

                case TrialMode.multi:

                    dstConnectList1.AddDstiItemForTrial(10);
                    dstConnectList1.ItemsRefresh();
                    RefreshForm();
                    this.lblSearching.Visible = false;
                    break;
            }
        }

        #endregion

    }
}
