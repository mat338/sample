﻿//#define NO_PROFILES

using System;
using NLog;

namespace YardRepro
{
    /// <summary>
    /// ヤードリプロ用ユーティリティクラス
    /// </summary>
    class YardReproUtil
    {
        /// <summary>
        /// ログ出力クラス
        /// </summary>
        private static readonly Logger log = LogManager.GetCurrentClassLogger();

        #region トライアルモード関数
        /// <summary>
        /// トライアルモードチェック
        /// </summary>
        /// <returns>トライアルモードフラグ</returns>
        /// ### 機能説明 #######
        /// -# コマンドライン引数取得
        /// -# コマンドライン引数の数が２件で、文字列が「trial」の場合
        ///     -# 戻り値Trueを返却
        /// -# 戻り値Falseを返却
        public static bool checkTrialMode()
        {
            const string trialStr = "trial";

            //コマンドライン引数取得
            string[] args = Environment.GetCommandLineArgs();
            if (args.Length == 2 && trialStr.Equals(args[1]))
            {
                return true;
            }
            return false;
        }
        #endregion

    }
}
