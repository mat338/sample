﻿namespace DSTWiFiSimulator
{
    partial class DSTWiFiSimulator
    {
        /// <summary>
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースを破棄する場合は true を指定し、その他の場合は false を指定します。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナーで生成されたコード

        /// <summary>
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DSTWiFiSimulator));
            this.label1 = new System.Windows.Forms.Label();
            this.textWifiinfo = new System.Windows.Forms.TextBox();
            this.textSerialNo = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.trackBar1 = new System.Windows.Forms.TrackBar();
            this.textStatus = new System.Windows.Forms.TextBox();
            this.lblStatus = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textVin = new System.Windows.Forms.TextBox();
            this.textSoftBefore = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textRetry = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.cnbDSTSelect = new System.Windows.Forms.ComboBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textSoftAfter = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.textDtcExec = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.textDtcExecLog = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.textDtcExecSleep = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.textSeed = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.textKeySend = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "WiFi情報取得";
            // 
            // textWifiinfo
            // 
            this.textWifiinfo.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.textWifiinfo.Location = new System.Drawing.Point(12, 74);
            this.textWifiinfo.Name = "textWifiinfo";
            this.textWifiinfo.Size = new System.Drawing.Size(1125, 19);
            this.textWifiinfo.TabIndex = 5;
            this.textWifiinfo.Text = "03A40000000000000450FF504453545769466953696D3030310000000000000000000000000000000" +
    "00000000000000000000000000000000000000000000000000000000000000000000000000000000" +
    "00000000000000000000000";
            this.textWifiinfo.TextChanged += new System.EventHandler(this.textWifiinfo_TextChanged);
            // 
            // textSerialNo
            // 
            this.textSerialNo.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.textSerialNo.Location = new System.Drawing.Point(12, 49);
            this.textSerialNo.MaxLength = 16;
            this.textSerialNo.Name = "textSerialNo";
            this.textSerialNo.Size = new System.Drawing.Size(160, 19);
            this.textSerialNo.TabIndex = 2;
            this.textSerialNo.Text = "DSTWiFiSim001";
            this.textSerialNo.TextChanged += new System.EventHandler(this.textSerialNo_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 99);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 12);
            this.label2.TabIndex = 3;
            this.label2.Text = "ステータス取得";
            // 
            // trackBar1
            // 
            this.trackBar1.Location = new System.Drawing.Point(3, 111);
            this.trackBar1.Maximum = 100;
            this.trackBar1.Name = "trackBar1";
            this.trackBar1.Size = new System.Drawing.Size(591, 45);
            this.trackBar1.TabIndex = 6;
            this.trackBar1.Scroll += new System.EventHandler(this.trackBar1_Scroll);
            // 
            // textStatus
            // 
            this.textStatus.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.textStatus.Location = new System.Drawing.Point(454, 148);
            this.textStatus.MaxLength = 22;
            this.textStatus.Name = "textStatus";
            this.textStatus.Size = new System.Drawing.Size(163, 19);
            this.textStatus.TabIndex = 8;
            this.textStatus.Text = "1104000000000000000000";
            this.textStatus.TextChanged += new System.EventHandler(this.textStatus_TextChanged);
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Location = new System.Drawing.Point(600, 130);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(17, 12);
            this.lblStatus.TabIndex = 6;
            this.lblStatus.Text = "0%";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 172);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 12);
            this.label3.TabIndex = 7;
            this.label3.Text = "VIN取得";
            // 
            // textVin
            // 
            this.textVin.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.textVin.Location = new System.Drawing.Point(12, 187);
            this.textVin.Name = "textVin";
            this.textVin.Size = new System.Drawing.Size(315, 19);
            this.textVin.TabIndex = 9;
            this.textVin.Text = "1212000000000056494E303030303030303030303030303031";
            this.textVin.TextChanged += new System.EventHandler(this.textVin_TextChanged);
            // 
            // textSoftBefore
            // 
            this.textSoftBefore.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.textSoftBefore.Location = new System.Drawing.Point(12, 232);
            this.textSoftBefore.Multiline = true;
            this.textSoftBefore.Name = "textSoftBefore";
            this.textSoftBefore.Size = new System.Drawing.Size(1125, 32);
            this.textSoftBefore.TabIndex = 10;
            this.textSoftBefore.Text = resources.GetString("textSoftBefore.Text");
            this.textSoftBefore.TextChanged += new System.EventHandler(this.textSoftBefore_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 216);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(140, 12);
            this.label4.TabIndex = 7;
            this.label4.Text = "リプロ前ソフトウェア品番取得";
            // 
            // textRetry
            // 
            this.textRetry.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.textRetry.Location = new System.Drawing.Point(12, 341);
            this.textRetry.Name = "textRetry";
            this.textRetry.Size = new System.Drawing.Size(100, 19);
            this.textRetry.TabIndex = 12;
            this.textRetry.Text = "14000000000000";
            this.textRetry.TextChanged += new System.EventHandler(this.textRetry_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 325);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(61, 12);
            this.label5.TabIndex = 7;
            this.label5.Text = "リトライ要求";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "0x00 正常",
            "0x01 VIN読出し不可",
            "0x02 ソフト品番読出し不可",
            "0x03 読み出したソフト品番から引きあたるリプロデータがDST-WiFi内に存在しない",
            "0x04 リプロ書換え中のエラー",
            "0x05 リプロ後のベリファイ時のエラー",
            "0x06 バッテリ電圧が11.8V未満",
            "0x07 定義されないエラー",
            "0x08 読み出したソフト品番がリプロ後のソフト品番と同一",
            "0x09 認証エラー"});
            this.comboBox1.Location = new System.Drawing.Point(12, 147);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(418, 20);
            this.comboBox1.TabIndex = 7;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(228, 45);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 3;
            this.button1.Text = "接続";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(309, 45);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 4;
            this.button2.Text = "切断";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // cnbDSTSelect
            // 
            this.cnbDSTSelect.FormattingEnabled = true;
            this.cnbDSTSelect.Location = new System.Drawing.Point(12, 6);
            this.cnbDSTSelect.Name = "cnbDSTSelect";
            this.cnbDSTSelect.Size = new System.Drawing.Size(215, 20);
            this.cnbDSTSelect.TabIndex = 1;
            this.cnbDSTSelect.SelectedIndexChanged += new System.EventHandler(this.cnbDSTSelect_SelectedIndexChanged);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(121, 510);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 19);
            this.textBox1.TabIndex = 17;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(227, 510);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 19);
            this.textBox2.TabIndex = 18;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(333, 509);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(723, 19);
            this.textBox3.TabIndex = 19;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(1062, 508);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 20;
            this.button3.Text = "送信";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(12, 510);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(100, 19);
            this.textBox4.TabIndex = 16;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(13, 269);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(140, 12);
            this.label6.TabIndex = 18;
            this.label6.Text = "リプロ後ソフトウェア品番取得";
            // 
            // textSoftAfter
            // 
            this.textSoftAfter.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.textSoftAfter.Location = new System.Drawing.Point(13, 285);
            this.textSoftAfter.Multiline = true;
            this.textSoftAfter.Name = "textSoftAfter";
            this.textSoftAfter.Size = new System.Drawing.Size(1124, 30);
            this.textSoftAfter.TabIndex = 11;
            this.textSoftAfter.Text = resources.GetString("textSoftAfter.Text");
            this.textSoftAfter.TextChanged += new System.EventHandler(this.textSoftAfter_TextChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 374);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(124, 12);
            this.label7.TabIndex = 20;
            this.label7.Text = "後処理開始（DTC実行）";
            // 
            // textDtcExec
            // 
            this.textDtcExec.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.textDtcExec.Location = new System.Drawing.Point(12, 390);
            this.textDtcExec.Name = "textDtcExec";
            this.textDtcExec.Size = new System.Drawing.Size(100, 19);
            this.textDtcExec.TabIndex = 13;
            this.textDtcExec.Text = "15000000000000";
            this.textDtcExec.TextChanged += new System.EventHandler(this.textDtcExec_TextChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(13, 415);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(81, 12);
            this.label8.TabIndex = 22;
            this.label8.Text = "ログファイル取得";
            // 
            // textDtcExecLog
            // 
            this.textDtcExecLog.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.textDtcExecLog.Location = new System.Drawing.Point(13, 428);
            this.textDtcExecLog.Multiline = true;
            this.textDtcExecLog.Name = "textDtcExecLog";
            this.textDtcExecLog.Size = new System.Drawing.Size(1124, 74);
            this.textDtcExecLog.TabIndex = 15;
            this.textDtcExecLog.Text = resources.GetString("textDtcExecLog.Text");
            this.textDtcExecLog.TextChanged += new System.EventHandler(this.textDtcExecLog_TextChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(162, 374);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(128, 12);
            this.label9.TabIndex = 24;
            this.label9.Text = "応答フレーム遅延（ミリ秒）";
            // 
            // textDtcExecSleep
            // 
            this.textDtcExecSleep.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.textDtcExecSleep.Location = new System.Drawing.Point(162, 390);
            this.textDtcExecSleep.MaxLength = 5;
            this.textDtcExecSleep.Name = "textDtcExecSleep";
            this.textDtcExecSleep.Size = new System.Drawing.Size(42, 19);
            this.textDtcExecSleep.TabIndex = 14;
            this.textDtcExecSleep.Text = "1000";
            this.textDtcExecSleep.TextChanged += new System.EventHandler(this.textDtcExecSleep_TextChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(145, 325);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(54, 12);
            this.label10.TabIndex = 25;
            this.label10.Text = "Seed取得";
            // 
            // textSeed
            // 
            this.textSeed.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.textSeed.Location = new System.Drawing.Point(145, 341);
            this.textSeed.MaxLength = 46;
            this.textSeed.Name = "textSeed";
            this.textSeed.Size = new System.Drawing.Size(293, 19);
            this.textSeed.TabIndex = 26;
            this.textSeed.Text = "1810000000000053454544303030303030303030303031";
            this.textSeed.TextChanged += new System.EventHandler(this.textSeed_TextChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(466, 325);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(48, 12);
            this.label11.TabIndex = 27;
            this.label11.Text = "Key送信";
            // 
            // textKeySend
            // 
            this.textKeySend.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.textKeySend.Location = new System.Drawing.Point(466, 341);
            this.textKeySend.MaxLength = 14;
            this.textKeySend.Name = "textKeySend";
            this.textKeySend.Size = new System.Drawing.Size(101, 19);
            this.textKeySend.TabIndex = 28;
            this.textKeySend.Text = "19000000000000";
            this.textKeySend.TextChanged += new System.EventHandler(this.textKeySend_TextChanged);
            // 
            // DSTWiFiSimulator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1147, 539);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.textKeySend);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.textSeed);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.textDtcExecSleep);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.textDtcExecLog);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.textDtcExec);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.textSoftAfter);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.cnbDSTSelect);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.textRetry);
            this.Controls.Add(this.textSoftBefore);
            this.Controls.Add(this.textVin);
            this.Controls.Add(this.textStatus);
            this.Controls.Add(this.trackBar1);
            this.Controls.Add(this.textSerialNo);
            this.Controls.Add(this.textWifiinfo);
            this.Controls.Add(this.label1);
            this.Name = "DSTWiFiSimulator";
            this.Text = "Key送信";
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textWifiinfo;
        private System.Windows.Forms.TextBox textSerialNo;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TrackBar trackBar1;
        private System.Windows.Forms.TextBox textStatus;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textVin;
        private System.Windows.Forms.TextBox textSoftBefore;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textRetry;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ComboBox cnbDSTSelect;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textSoftAfter;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textDtcExec;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textDtcExecLog;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textDtcExecSleep;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textSeed;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textKeySend;
    }
}

