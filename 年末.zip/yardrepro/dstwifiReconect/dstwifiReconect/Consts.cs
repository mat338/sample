﻿using System;

namespace dstwifiReconect
{
    /// <summary>
    /// 定数クラス
    /// </summary>
    public class Consts
    {
        //インスタンス生成禁止
        private Consts(){ }

        /// <summary>
        /// デフォルト仕向け
        /// </summary>
        public const String DEFAULT_MARKET = "JAPAN";

        /// <summary>
        /// バージョン表示時の接頭辞
        /// </summary>
        public const String VER_PREFIX = " ver.";

        /// <summary>
        /// DST-iのミューテックスキー
        /// </summary>
        public const String DSTI_MUTEX = "DST-i";

        /// <summary>
        /// 定義ファイル相対パス
        /// </summary>
        public const String DEF_PATH = "connectionmanager.def";

        /// <summary>
        /// 接続モード列挙型（数値はエージェント機能との連携用）
        /// </summary>
        public enum ConnectMode : int { INFRA = 0, ADHOC = 1, P2P = 2 };

        /// <summary>
        /// WLAN AutoConfigのサービス名
        /// </summary>
        public const string WLAN_AUTOCONFIG_SERVICE = "Wlansvc";

        /// <summary>
        /// Wireless Zero Configurationのサービス名
        /// </summary>
        public const string WIRELESS_ZERO_CONFIGURATION = "WZCSVC";

        /// <summary>
        /// DST-i接続用のポート番号
        /// </summary>
        public const int DSTI_PORT_TCP = 60704;

        /// <summary>
        /// DST-iとソケット通信するためのポート番号
        /// </summary>
        public const int DSTI_SOCKET_PORT_TCP = DSTI_PORT_TCP + 1;

        /// <summary>
        /// DST-i接続用のポート番号
        /// </summary>
        public const int DSTI_PORT_UDP = 60700;

        /// <summary>
        /// DST-iとソケット通信するためのポート番号
        /// </summary>
        public const int DSTI_SOCKET_PORT_UDP = DSTI_PORT_UDP + 1;

        /// <summary>
        /// タイムアウト時間（ミリ秒）
        /// </summary>
        public const int TIMEOUT = 1000;

        /// <summary>
        /// WindowsXPで同時に接続を試みるTCP接続数（10以下）
        /// </summary>
        public const int TCP_MAX = 8;

        /// <summary>
        /// 言語ファイル格納相対パス
        /// </summary>
        public const string LANGUAGE_PATH = @"Language\";

        /// <summary>
        /// 言語ファイル拡張子(ピリオド付き)
        /// </summary>
        public const string LANGUAGE_EXTENTION = ".xml";

        /// <summary>
        /// 通常使用するシリアルNo.を保持するレジストリキー
        /// </summary>
        public const string REGNAME_DEFAULT_SERIAL_NO = "DefaultSerialNo";

        /// <summary>
        /// 接続先IPアドレスを保持するレジストリキー
        /// </summary>
        public const string REGNAME_TARGET_IP_ADDRESS = "WLANAddress";

        /// <summary>
        /// 接続中のDST-iのシリアルNo.を保持するレジストリキー
        /// </summary>
        public const string REGNAME_TARGET_SERIAL_NO = "WLANSerialNo";

        /// <summary>
        /// エージェント機能連携用　WiFi接続モードのレジストリキー
        /// </summary>
        public const string REGNAME_AGENT_WIFI_MODE = "WLANConnectMode";
        
        /// <summary>
        /// エージェント機能連携用　SSIDのレジストリキー
        /// </summary>
        public const string REGNAME_AGENT_SSID = "WLANSSID";

        /// <summary>
        /// エージェント機能連携用　WiFi優先設定のレジストリキー
        /// </summary>
        public const string REGNAME_AGENT_PRIORITY = "WiFi_priority";

        // -------------------------------------------------------------------------------
        // DST-iとソケット通信する際のコマンドID
        // -------------------------------------------------------------------------------
        /// <summary>
        /// DST-iとソケット通信する際のコマンドID：WiFi接続モード強制変更
        /// </summary>
        public const byte SOCKET_ID_CHANGE_CONNECT_MODE = 1;
        /// <summary>
        /// DST-iとソケット通信する際のコマンドID：WiFi情報読出し
        /// </summary>
        public const byte SOCKET_ID_GET_WIFI_DATA = 2;
        /// <summary>
        /// DST-iとソケット通信する際のコマンドID：WiFi接続情報読出し
        /// </summary>
        public const byte SOCKET_ID_GET_CONNECTION_DATA = 3;
        /// <summary>
        /// DST-iとソケット通信する際のコマンドID：WiFi接続ホスト情報登録
        /// </summary>
        public const byte SOCKET_ID_UPDATE_HOSTNAME = 4;
        /// <summary>
        /// DST-iとソケット通信する際のコマンドID：ブザー
        /// </summary>
        public const byte SOCKET_ID_BUZZER = 5;
        // -------------------------------------------------------------------------------

        /// <summary>
        /// ソケット通信処理結果：OK
        /// </summary>
        public static byte[] SOCKET_RESULT_OK = {0, 0, 0, 0};

        /// <summary>
        /// 接続モード：インフラ
        /// </summary>
        public const byte CONNECT_MODE_INFRA = 1;

        /// <summary>
        /// 接続モード：アドホック
        /// </summary>
        public const byte CONNECT_MODE_ADHOC = 2;

        /// <summary>
        /// 接続モード：ピアツーピア
        /// </summary>
        public const byte CONNECT_MODE_P2P = 2;

        /// <summary>
        /// アドホック情報：アドホック有効
        /// </summary>
        public const string ADHOC_VALID = "1";

        /// <summary>
        /// WiFi接続情報：接続中
        /// </summary>
        public const string WIFI_CONNECTION_CONNECTED = "1";

        /// <summary>
        /// WiFi接続ホスト情報登録処理要求：登録
        /// </summary>
        public const byte COMMAND_REGIST_HOSTNAME = 1;

        /// <summary>
        /// WiFi接続ホスト情報登録処理要求：削除
        /// </summary>
        public const byte COMMAND_DELETE_HOSTNAME = 0;

        /// <summary>
        /// ブザーON指示
        /// </summary>
        public const string BUZZER_FLG_ON = "1";
        
        /// <summary>
        /// リトライ回数
        /// </summary>
        public const int RETRY_COUNT = 5;

        /// <summary>
        /// タイマーの時間（秒）
        /// </summary>
        public const int TIMER_DEFAULT = 60 * 60;

        /// <summary>
        /// コネクションマネージャ画面の画面リフレッシュ時間（ミリ秒）
        /// </summary>
        public const int CONNECTION_MANAGER_REFRESH_TIME = 10000;

        /// <summary>
        /// ダッシュボード画面の画面リフレッシュ時間（ミリ秒）
        /// </summary>
        public const int DASHBOARD_REFRESH_TIME = 5000;

        /// <summary>
        /// 認証・暗号化方式　Open-Disable
        /// </summary>
        public const int AUTHENTICATION_OPEN_DISABLE = 1;

        /// <summary>
        /// 認証・暗号化方式　Open-WEP64
        /// </summary>
        public const int AUTHENTICATION_OPEN_WEP64 = 2;

        /// <summary>
        /// 認証・暗号化方式　Open-WEP128
        /// </summary>
        public const int AUTHENTICATION_OPEN_WEP128 = 3;

        /// <summary>
        /// 認証・暗号化方式　WPA-PSK-TKIP
        /// </summary>
        public const int AUTHENTICATION_WPA_PSK_TKIP = 7;

        /// <summary>
        /// 認証・暗号化方式　WPA2-PSK-AES
        /// </summary>
        public const int AUTHENTICATION_WPA2_PSK_AES = 8;

        /// <summary>
        /// 認証・暗号化方式　WL WPA-PSK-TKIP
        /// </summary>
        public const int AUTHENTICATION_WL_WPA_PSK_TKIP = 1;

        /// <summary>
        /// 認証・暗号化方式　WL WPA-PSK-AES
        /// </summary>
        public const int AUTHENTICATION_WL_WPA_PSK_AES = 2;

        /// <summary>
        /// 認証・暗号化方式　WL WPA2-PSK-AES
        /// </summary>
        public const int AUTHENTICATION_WL_WPA2_PSK_AES = 3;

        /// <summary>
        /// DHCP有効
        /// </summary>
        public const int DHCP_ENABLE = 1;

        /// <summary>
        /// WiFi非優先設定
        /// </summary>
        public const String PRIORITY_USB = "0";

        /// <summary>
        /// WIFI優先設定
        /// </summary>
        public const String PRIORITY_WIFI = "1";

        #region UDP対応評価版
        /// <summary>
        /// ソケットの受信バッファサイズ
        /// </summary>
        // ブロードキャストに対する応答を格納するのに十分なサイズを指定すること
        // 目安はデータサイズ×255
        public const int SOCKET_RECEIVE_BUFFER_SIZE = 65535;

        /// <summary>
        /// ソケットの応答待ち時間（ミリ秒単位）
        /// </summary>
        //public const int SOCKET_RECEIVE_WAIT_TIME = 1000;
        public const int SOCKET_RECEIVE_WAIT_TIME = 2000;

        /// <summary>
        /// 通信方式
        /// </summary>
        public enum CommunicationMode : byte { UDP = 1, ICMP = 2 };
        #endregion

    }
}
