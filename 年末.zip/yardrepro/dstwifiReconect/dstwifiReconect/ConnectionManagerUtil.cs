﻿//#define NO_PROFILES

using System;
using System.Collections;
using System.Collections.Generic;
using System.Management;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using dstwifiReconect.dto;
using NativeWifi;
using NLog;
using DSTiCommon;
using System.Runtime.InteropServices;

namespace dstwifiReconect
{
    /// <summary>
    /// コネクションマネージャ用ユーティリティクラス
    /// </summary>
    class ConnectionManagerUtil
    {
        /// <summary>
        /// Win32エラー(プロファイルが既に存在したため上書きしなかった場合)
        /// </summary>
        private const int ERROR_ALREADY_EXISTS = 183;

        /// <summary>
        /// ログ出力クラス
        /// </summary>
        private static readonly Logger log = LogManager.GetCurrentClassLogger();

        /// <summary>
        /// デフォルト文字エンコード
        /// </summary>
        private static Encoding DEFAULT_ENC = Encoding.ASCII;

        /// <summary>
        /// PING確認：1回
        /// </summary>
        private static int SEND_PING_COUNT_ONCE = 1;

        /// <summary>
        /// 設定ファイル格納クラス
        /// </summary>
        private static DefinitionDetailDto defDetailDto;

        /// <summary>
        /// DST-iに対してソケットを送信し、結果を返す
        /// </summary>
        /// <param name="ipAddress">送信先IPアドレス</param>
        /// <param name="id">コマンドID</param>
        /// <returns>応答データ</returns>
        internal static byte[] SendSocket(string ipAddress, byte id, Consts.CommunicationMode commMode)
        {
            return SendSocket(ipAddress, id, "", commMode);
        }

        /// <summary>
        /// OSがWindowsXPか否かを判定する
        /// </summary>
        /// <returns>WindowsXPの場合true</returns>
        internal static bool IsWindowsXP()
        {
            //メジャーバージョン5の場合、Windows2000, Windows Server 2003の可能性もあるが
            //非対応のため考慮しない
            return Environment.OSVersion.Version.Major == 5;
        }

        /// <summary>
        /// アドホック機能がサポートされているかを判定する
        /// </summary>
        /// <returns>アドホック機能がある場合true</returns>
        internal static bool IsAdhocSupported()
        {
            //Windows 7     6.1
            //Windows 8     6.2
            //Windows 8.1   6.3
            if (Environment.OSVersion.Version.Major == 6
                && Environment.OSVersion.Version.Minor >= 3)
            {
                //Windows8.1以降の場合、falseを返す
                return false;
            }
            return true;
        }

        /// <summary>
        /// DST-iに対してソケットを送信し、結果を返す
        /// </summary>
        /// <param name="ipAddress">送信先IPアドレス</param>
        /// <param name="id">コマンドID</param>
        /// <param name="param">パラメータ</param>
        /// <returns>応答データ</returns>
        internal static byte[] SendSocket(string ipAddress, byte id, byte param, Consts.CommunicationMode commMode)
        {
            byte[] bytes = new byte[1];
            bytes[0] = param;

            return SendSocket(ipAddress, id, bytes, commMode);
        }

        /// <summary>
        /// DST-iに対してソケットを送信し、結果を返す
        /// </summary>
        /// <param name="ipAddress">送信先IPアドレス</param>
        /// <param name="id">コマンドID</param>
        /// <param name="param">パラメータ</param>
        /// <returns>応答データ</returns>
        internal static byte[] SendSocket(string ipAddress, byte id, string param, Consts.CommunicationMode commMode)
        {
            byte[] byteParam = Encoding.ASCII.GetBytes(param);
            if (BitConverter.IsLittleEndian)
            {
                Array.Reverse(byteParam);
            }
            return SendSocket(ipAddress, id, byteParam, commMode);
        }

        /// <summary>
        /// DST-iに対してソケットを送信し、結果を返す
        /// </summary>
        /// <param name="ipAddress">送信先IPアドレス</param>
        /// <param name="id">コマンドID</param>
        /// <param name="param">パラメータ</param>
        /// <param name="pingSendCount">PING確認回数</param>
        /// <returns>応答データ</returns>
        internal static byte[] SendSocket(string ipAddress, byte id, string param, Consts.CommunicationMode commMode, int pingSendCount)
        {
            byte[] byteParam = Encoding.ASCII.GetBytes(param);
            if (BitConverter.IsLittleEndian)
            {
                Array.Reverse(byteParam);
            }
            return SendSocket(ipAddress, id, byteParam, commMode, pingSendCount);
        }

        /// <summary>
        /// DST-iに対してソケットを送信し、結果を返す
        /// </summary>
        /// <param name="ipAddress">送信先IPアドレス</param>
        /// <param name="id">コマンドID</param>
        /// <param name="param">パラメータ</param>
        /// <returns>応答データ</returns>
        internal static byte[] SendSocket(string ipAddress, byte id, byte[] param, Consts.CommunicationMode commMode, int? sendPingCount = null)
        {
            /*
            // リフレッシュ中の可能性もあるためロック必須
            bool contains;
            lock(udpTableLock)
            {
                // UDP対応IPアドレステーブルに格納されているIPであればUDPで、それ以外はTCPで送る
                // タイミングによっては一覧とテーブルに差異が出る可能性があるが（端末抜き差し、同一IP別端末など）
                // その場合はどちらにせよ不整合になるので一旦考えないこととする
                contains = udpTable.Contains(ipAddress);
            }
            if (contains)
            {
                return SendSocketUDP(ipAddress, id, param, sendPingCount);
            }
            else
            {
                return SendSocketTCP(ipAddress, id, param, sendPingCount);
            }
            */
            byte[] ret = null;
            switch (commMode)
            {
                case Consts.CommunicationMode.UDP:
                    ret = SendSocketUDP(ipAddress, id, param, sendPingCount);
                    break;
                case Consts.CommunicationMode.ICMP:
                    ret = SendSocketTCP(ipAddress, id, param, sendPingCount);
                    break;
            }
            return ret;
        }

        /// <summary>
        /// DST-iに対してTCPでソケットを送信し、結果を返す
        /// </summary>
        /// <param name="ipAddress">送信先IPアドレス</param>
        /// <param name="id">コマンドID</param>
        /// <param name="param">パラメータ</param>
        /// <returns>応答データ</returns>
        internal static byte[] SendSocketTCP(string ipAddress, byte id, byte[] param, int? sendPingCount = null)
        {
            ManualResetEvent connect = new ManualResetEvent(false);
            TcpClient client = null;
            NetworkStream stream = null;

            try
            {
                //定義ファイル取得
                defDetailDto = ConnectionManagerXmlReader.GetDefinitionDetailDto(Properties.Settings.Default.EncryptedDefinition);
                client = new TcpClient();
                client.SendTimeout = Consts.TIMEOUT;
                client.ReceiveTimeout = Consts.TIMEOUT;
                log.Debug("in SendSocket ipAddress: " + ipAddress.ToString());
                // PING送信の要否確認
                if (defDetailDto.pingSendFlg)
                {
                    bool ping_res = true;
                    if (null == sendPingCount)
                    {
                        // PING送信が必要の場合
                        CheckConnectWifi chkPing = new CheckConnectWifi();
                        ping_res = chkPing.CheckWifiConnectPing(ipAddress, defDetailDto.pingRetryCount, defDetailDto.pingRetryInterval, defDetailDto.pingTimeout);
                        if (!ping_res)
                        {
                            log.Debug("( send Normal PING ERROR )begin connection Failed because of not connected - ipAddress[" + ipAddress + "], id[" + id + "]");
                            return null;
                        }
                    }
                    else if (SEND_PING_COUNT_ONCE == sendPingCount)
                    {
                        // PING確認1回のみ
                        CheckConnectWifi chkPing = new CheckConnectWifi();
                        ping_res = chkPing.CheckWifiConnectPing(ipAddress, SEND_PING_COUNT_ONCE, defDetailDto.pingRetryInterval, defDetailDto.pingTimeout);
                        if (!ping_res)
                        {
                            log.Debug("( send Once PING ERROR )begin connection Failed because of not connected - ipAddress[" + ipAddress + "], id[" + id + "]");
                            return null;
                        }
                    }

                }

                client.BeginConnect(System.Net.IPAddress.Parse(ipAddress), Consts.DSTI_SOCKET_PORT_TCP, new AsyncCallback(ConnectCallback), connect);

                if (!connect.WaitOne(Consts.TIMEOUT))
                {
                    log.Debug("begin connection Failed because of timeout - ipAddress[" + ipAddress + "], id[" + id + "]");
                    return null;
                }
                if (!client.Connected)
                {
                    log.Debug("begin connection Failed because of not connected - ipAddress[" + ipAddress + "], id[" + id + "]");
                    return null;
                }

                string logParam = "";
                foreach (byte b in param)
                {
                    if (logParam.Length > 0)
                    {
                        logParam += ",";
                    }
                    logParam += Convert.ToString(b);
                }
                log.Debug("begin connection SUCCESS - ipAddress[" + ipAddress + "], id[" + id + "], param[" + logParam + "]");

                //送信データを作成
                List<byte> sendByteList = new List<byte>();
                sendByteList.Add(id);

                //パラメータの長さを指定
                //現状ではbyteの最大値（255）を超えることはないため、1バイト目は0固定とする
                sendByteList.Add(0);
                sendByteList.Add((byte)param.Length);

                sendByteList.AddRange(param);

                byte[] sendByte = sendByteList.ToArray();

                stream = client.GetStream();
                stream.Write(sendByte, 0, sendByte.Length);
                stream.Flush();

                System.IO.MemoryStream memory = new System.IO.MemoryStream();

                byte[] buffBytes = new byte[256];
                do
                {
                    int size = stream.Read(buffBytes, 0, buffBytes.Length);
                    if (size == 0)
                    {
                        break;
                    }
                    memory.Write(buffBytes, 0, size);

                } while (stream.DataAvailable);

                byte[] res = null;
                try
                {
                    res = memory.ToArray();
                    log.Debug("receive - ipAddress[" + ipAddress + "], id[" + id + "], byte[" + BitConverter.ToString(res).Replace("00", "0") + "]");
                }
                catch
                {
                    log.Debug("END - ipAddress[" + ipAddress + "], id[" + id + "]");
                }

                return res;
            }
            catch (Exception ex)
            {
                //通信失敗時
                log.Error(ex);
                log.Error(ex.InnerException);
                return null;
            }
            finally
            {
                if (stream != null)
                {
                    stream.Close();
                }

                if (client != null)
                {
                    client.Close();
                }
            }
        }
        
        /// <summary>
        /// 接続タイムアウト時のコールバック関数
        /// </summary>
        /// <param name="result"></param>
        private static void ConnectCallback(IAsyncResult result)
        {
            ManualResetEvent connect = (ManualResetEvent)result.AsyncState;
            connect.Set();
        }

        /// <summary>
        /// ソケット通信結果を判定する
        /// </summary>
        /// <param name="response">応答データ</param>
        /// <returns>処理結果が正常の場合、true</returns>
        internal static bool IsSocketSuccess(byte[] response)
        {
            if (response == null || response.Length < 7)
            {
                log.Error("response is null or less than 7 bytes");
                return false;
            }

            byte[] result = new byte[4];
            Array.Copy(response, 3, result, 0, 4);

            for (int i = 0; i < Consts.SOCKET_RESULT_OK.Length; i++)
            {
                if (Consts.SOCKET_RESULT_OK[i] != result[i])
                {
                    log.Error("result [" + result[0] + ", " + result[1] + ", " + result[2] + ", " + result[3] + "]");
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// DST-iからの応答を元にDST-i情報を作成する
        /// </summary>
        /// <param name="response">応答データ</param>
        /// <returns>DST-i情報</returns>
        internal static DSTiDto getDSTiDTO(byte[] response)
        {
            //レスポンス内容のログ
            //log.Debug("response = ");
            //for (int i = 0; i < response.Length; i++)
            //{
            //    log.Debug("[" + i + "]:" + response[i]);
            //}

            DSTiDto dto = new DSTiDto();

            //7バイト目からがWiFi接続情報
            //[7] Connection(1)
            dto.connection = response[7];

            //[8] Rssi(1)
            dto.signalStrength = response[8];

            //[9] RGB(3)
            dto.color = new byte[3];
            Array.Copy(response, 9, dto.color, 0, 3);

            //[12] SerialNo(16)
            dto.serialNo = SubString(response, 12, 16);

            //[28] hostname(64)
            // #269 修正
            // dto.hostName = SubString(response, 28, 63);
            dto.hostName = SubString(response, 28, 64);

            return dto;
        }

        /// <summary>
        /// DST-iから取得したWiFi情報をDST-i情報に追加する
        /// </summary>
        /// <param name="baseDTO">追加する対象</param>
        /// <param name="response">応答データ</param>
        /// <returns>WiFi情報を追加したDST-i情報</returns>
        internal static DSTiDto addWifiData(DSTiDto baseDTO, byte[] response)
        {
            //DST-iから取得した情報で接続モードを上書きする
            //[8]起動時ネットワークタイプ（バイナリ）　　インフラストラクチャ=1、アドホック=2
            if (response[8] == 1)
            {
                baseDTO.connectMode = Consts.ConnectMode.INFRA;
            }
            else
            {
                baseDTO.connectMode = Consts.ConnectMode.ADHOC;
            }

            // -------------------------------------------------------------------------------
            // インフラストラクチャモードの設定
            // -------------------------------------------------------------------------------
            //[9]インフラストラクチャ設定有効/無効フラグ
            byte infraAvailable = response[9];

            //フラグが有効（＝1）の場合のみ書き込む
            if (infraAvailable == 1)
            {
                //[23]SSID文字数
                int infraSsidCharCnt = response[23];
                //[24]認証・暗号化方式
                baseDTO.infraEncMethod = response[24];
                //[25]PSK文字数（暗号化キー文字数）
                int pskCharCnt = response[25];
                //[26]DHCP有効/無効
                baseDTO.dhcp = response[26];
                //[27]IPアドレス
                byte[] infraIpResponse = new byte[4];
                Array.Copy(response, 27, infraIpResponse, 0, 4);
                baseDTO.infraIpAddress = ConvertIpAddressString(infraIpResponse);

                //インフラストラクチャモードの場合
                if (baseDTO.connectMode == Consts.ConnectMode.INFRA)
                {
                    //DHCP有効の場合
                    if (baseDTO.dhcp == Consts.DHCP_ENABLE)
                    {
                        //インフラストラクチャモードでDHCPの場合は、
                        //EEPROMに設定されていないため、接続時のIPアドレスを設定する
                        baseDTO.infraIpAddress = baseDTO.ipAddress;
                    }
                }
                //[39]SSID（文字数はSSID文字数による）
                baseDTO.infraSsid = SubString(response, 39, infraSsidCharCnt);
                //[71]暗号化キー（文字数はPSK文字数による）
                string infraKey = SubString(response, 71, pskCharCnt);
                Encoding infraKeyEncoding = getEncoding(baseDTO.infraEncMethod);
                if (infraKeyEncoding.Equals(DEFAULT_ENC))
                {
                    baseDTO.infraKey = infraKey;
                }
                else
                {
                    baseDTO.infraKey = infraKeyEncoding.GetString(convertByteData(infraKey));
                }
            }

            // -------------------------------------------------------------------------------
            // アドホックモードの設定
            // -------------------------------------------------------------------------------
            //[10]アドホック設定有効/無効フラグ
            byte adhocAvailable = response[10];

            //フラグが有効（＝1）の場合のみ書き込む
            if (adhocAvailable == 1)
            {
                //[135]SSID文字数
                int adhocSsidCharCnt = response[135];
                //[136]認証・暗号化方式
                baseDTO.adhocEncMethod = response[136];
                //[137]WEPキー文字数（暗号化キー文字数）
                int wepKeyCharCnt = response[137];
                //[139]IPアドレス
                byte[] adhocIpResponse = new byte[4];
                Array.Copy(response, 139, adhocIpResponse, 0, 4);
                baseDTO.adhocIpAddress = ConvertIpAddressString(adhocIpResponse);
                //[151]SSID（文字数はSSID文字数による）
                baseDTO.adhocSsid = SubString(response, 151, adhocSsidCharCnt);
                //[183]暗号化キー（文字数はPSK文字数による）
                string adhocKey = SubString(response, 183, wepKeyCharCnt);
                Encoding adhocKeyEncoding = getEncoding(baseDTO.adhocEncMethod);
                if (adhocKeyEncoding.Equals(DEFAULT_ENC))
                {
                    baseDTO.adhocKey = adhocKey;
                }
                else
                {
                    baseDTO.adhocKey = adhocKeyEncoding.GetString(convertByteData(adhocKey));
                }
            }

            return baseDTO;
        }

        /// <summary>
        /// 認証・暗号化方式によって、エンコード形式を返す（暗号化キーの変換に使用）
        /// </summary>
        /// <param name="encMethod">認証・暗号化方式</param>
        /// <returns>エンコード形式</returns>
        private static Encoding getEncoding(int encMethod)
        {
            if (Consts.AUTHENTICATION_WPA_PSK_TKIP == encMethod || Consts.AUTHENTICATION_WPA2_PSK_AES == encMethod)
            {
                return DEFAULT_ENC;
            }
            else
            {
                return Encoding.UTF8;
            }
        }

        /// <summary>
        /// HEX文字列をByte配列にする
        /// </summary>
        /// <param name="str">HEX文字列</param>
        /// <returns>Byte配列</returns>
        private static byte[] convertByteData(string str)
        {

            byte[] b = new byte[str.Length / 2];
            int byteCount = 0;

            //2ケタずつ
            for (int i = 0; i < str.Length; i += 2)
            {
                b[byteCount] = Convert.ToByte(str.Substring(i, 2), 16);
                byteCount++;
            }

            return b;
        }

        /// <summary>
        /// バイト配列から文字列を切り出す
        /// </summary>
        /// <param name="source">元データ</param>
        /// <param name="index">開始位置</param>
        /// <param name="length">長さ</param>
        /// <returns>切り出した文字列</returns>
        private static string SubString(byte[] source, int index, int length)
        {
            List<byte> result = new List<byte>();

            for (int i = 0; i < length; i++)
            {
                byte b = source[index + i];
                if (b == 0x00)
                {
                    break;
                }

                result.Add(b);
            }

            return DEFAULT_ENC.GetString(result.ToArray());
        }

        /// <summary>
        /// IPアドレスを文字列として変換する
        /// </summary>
        /// <param name="b"></param>
        /// <returns></returns>
        private static string ConvertIpAddressString(byte[] b)
        {
            return string.Format("{0}.{1}.{2}.{3}", b[0], b[1], b[2], b[3]);
        }

        /// <summary>
        /// SSIDを文字列として変換する
        /// </summary>
        /// <param name="ssid"></param>
        /// <returns>SSID</returns>
        static string GetStringForSSID(Wlan.Dot11Ssid ssid)
        {
            return Encoding.ASCII.GetString(ssid.SSID, 0, (int)ssid.SSIDLength);
        }

        /// <summary>
        /// ホスト名更新処理
        /// </summary>
        /// <param name="ipAddress">更新対象DST-iのIPアドレス</param>
        /// <param name="command">Consts.COMMAND_REGIST_HOSTNAME または Consts.COMMAND_DELETE_HOSTNAME</param>
        /// <returns>正常終了した場合、true</returns>
        internal static bool UpdateHostname(string ipAddress, byte command, Consts.CommunicationMode commMode)
        {
            log.Debug("START - ipAddress[" + ipAddress + "], command[" + command + "]");

            //パラメータを作成
            List<byte> param = new List<byte>();

            //コマンドはそのまま
            param.Add(command);

            //ホスト名をバイト配列化してエンディアン変換
            // #269 64バイトに変更 byte[] paramHostName = new byte[63];
            byte[] paramHostName = new byte[64];
            byte[] machineName = DEFAULT_ENC.GetBytes(Environment.MachineName);

            Array.Copy(machineName, 0, paramHostName, 0, machineName.Length);

            param.AddRange(paramHostName);

            byte[] response = ConnectionManagerUtil.SendSocket(
                                    ipAddress,
                                    Consts.SOCKET_ID_UPDATE_HOSTNAME,
                                    param.ToArray(),
                                    commMode
                                    );

            if (IsSocketSuccess(response))
            {
                log.Debug("Successful END");
                return true;
            }
            return false;
        }

        /// <summary>
        /// DTOの情報に基づき、プロファイルを作成して無線LAN接続する
        /// </summary>
        /// <param name="dto">DST-i情報</param>
        /// <param name="connectMode">インフラ／アドホック</param>
        /// <param name="client">WlanClient</param>
        /// <param name="profileAlreadyExists">既存のプロファイルを使用して接続した場合、true</param>
        /// <returns>接続に成功した場合、true</returns>
        internal static bool WiFiConnect(DSTiDto dto, Consts.ConnectMode connectMode, WlanClient client, out bool profileAlreadyExists)
        {
            log.Debug("START");

            profileAlreadyExists = false;

            //DST-i情報からSSIDを取得
            string ssid = getSsid(dto, connectMode);

            foreach (WlanClient.WlanInterface wlanInterface in client.Interfaces)
            {
                //ハンドルを取得
                IntPtr clientHandle;
                uint NegotiatedVersion;
                int result = Wlan.WlanOpenHandle(2, IntPtr.Zero, out NegotiatedVersion, out clientHandle);
                if (result != 0 || clientHandle == null)
                {
                    log.Debug("OpenHandle FAILED");
                    return false;
                }

                try
                {
                    Wlan.WlanAvailableNetwork targetnetwork = new Wlan.WlanAvailableNetwork();
                    Wlan.WlanAvailableNetwork[] networks = wlanInterface.GetAvailableNetworkList(0);
                    foreach (Wlan.WlanAvailableNetwork network in networks)
                    {
                        if (ssid.Equals(GetStringForSSID(network.dot11Ssid)))
                        {
                            targetnetwork = network;
                            break;
                        }
                    }

                    //プロファイル作成
                    string profileXml = WLANProfile.CreateWLANProfileXML(dto, connectMode, targetnetwork);

#if NO_PROFILES
#else
                    Wlan.WlanProfileFlags profileFlag;
                    if (IsWindowsXP())
                    {
                        //WindowsXPの場合はAllUserのみ指定可能
                        profileFlag = Wlan.WlanProfileFlags.AllUser;
                    }
                    else
                    {
                        //それ以外の場合は自ユーザ向けに作成
                        profileFlag = Wlan.WlanProfileFlags.User;
                    }

                    Wlan.WlanReasonCode reasonCode;

                    //プロファイルをセット
                    int setProfileResult = Wlan.WlanSetProfile(
                                                clientHandle,
                                                wlanInterface.InterfaceGuid,
                                                profileFlag,
                                                profileXml,
                                                null,
                                                false,  //上書きしない
                                                IntPtr.Zero,
                                                out reasonCode);
                    log.Debug("setProfileResult [" + setProfileResult + "]");
                    log.Debug("reasonCode [" + reasonCode + "]");

                    if (setProfileResult == ERROR_ALREADY_EXISTS)
                    {
                        profileAlreadyExists = true;
                    }
#endif
                    //パラメータ作成
                    Wlan.WlanConnectionParameters connectParams = new Wlan.WlanConnectionParameters();

#if NO_PROFILES
                    connectParams.wlanConnectionMode = Wlan.WlanConnectionMode.TemporaryProfile;
                    connectParams.profile = profileXml;
#else
                    connectParams.wlanConnectionMode = Wlan.WlanConnectionMode.Profile;
                    connectParams.profile = ssid;
#endif
                    connectParams.desiredBssidListPtr = IntPtr.Zero;

                    //BSSタイプとフラグはインフラとアドホックで異なる
                    Wlan.Dot11BssType bssType;
                    Wlan.WlanConnectionFlags flags;
                    if (connectMode == Consts.ConnectMode.ADHOC)
                    {
                        bssType = Wlan.Dot11BssType.Independent;

                        if (ConnectionManagerUtil.IsWindowsXP())
                        {
                            flags = 0;

                            //WindowsXPかつアドホック接続の場合、末尾に"-adhoc"を付与する必要がある
                            connectParams.profile = ssid + "-adhoc";
                        }
                        else
                        {
                            flags = Wlan.WlanConnectionFlags.AdhocJoinOnly;
                        }
                    }
                    else
                    {
                        bssType = Wlan.Dot11BssType.Infrastructure;
                        flags = 0;
                    }
                    connectParams.dot11BssType = bssType;
                    connectParams.flags = flags;

                    //接続
                    result = Wlan.WlanConnect(clientHandle, wlanInterface.InterfaceGuid, ref connectParams, IntPtr.Zero);

                    if (result == 0)
                    {
                        log.Debug("WLAN Connect SUCCESS");
                        return true;
                    }
                    else
                    {
                        log.Debug("WLAN Connect ERROR [" + result + "]");
                        return false;
                    }
                }
                finally
                {
                    Wlan.WlanCloseHandle(clientHandle, IntPtr.Zero);
                }
            }

            log.Debug("END");
            return false;
        }

        /// <summary>
        /// DTOの情報に基づき、既存のプロファイルを使用して無線LAN接続する
        /// </summary>
        /// <param name="dto">DST-i情報</param>
        /// <param name="connectMode">インフラ／アドホック</param>
        /// <param name="client">WlanClient</param>
        /// <returns>接続に成功した場合、true</returns>
        internal static bool WiFiConnectRetry(DSTiDto dto, Consts.ConnectMode connectMode, WlanClient client)
        {
            log.Debug("START");

            if (!IsAdhocRetryRequired(client))
            {
                //接続済の場合は処理なし（成功扱い）
                log.Debug("Already connected");
                return true;
            }

            //DST-i情報からSSIDを取得
            string ssid = getSsid(dto, connectMode);

            foreach (WlanClient.WlanInterface wlanInterface in client.Interfaces)
            {
                //ハンドルを取得
                IntPtr clientHandle;
                uint NegotiatedVersion;
                int result = Wlan.WlanOpenHandle(2, IntPtr.Zero, out NegotiatedVersion, out clientHandle);
                if (result != 0 || clientHandle == null)
                {
                    log.Debug("OpenHandle FAILED");
                    return false;
                }

                try
                {
                    //パラメータ作成
                    Wlan.WlanConnectionParameters connectParams = new Wlan.WlanConnectionParameters();

#if NO_PROFILES
                    connectParams.wlanConnectionMode = Wlan.WlanConnectionMode.TemporaryProfile;
                    connectParams.profile = WLANProfile.CreateWLANProfileXML(dto, connectMode);
#else
                    connectParams.wlanConnectionMode = Wlan.WlanConnectionMode.Profile;
                    connectParams.profile = ssid;
#endif
                    connectParams.desiredBssidListPtr = IntPtr.Zero;

                    //BSSタイプとフラグはインフラとアドホックで異なる
                    Wlan.Dot11BssType bssType;
                    Wlan.WlanConnectionFlags flags;
                    if (connectMode == Consts.ConnectMode.ADHOC)
                    {
                        bssType = Wlan.Dot11BssType.Independent;
                        if (ConnectionManagerUtil.IsWindowsXP())
                        {
                            flags = 0;
                        }
                        else
                        {
                            flags = Wlan.WlanConnectionFlags.AdhocJoinOnly;
                        }
                    }
                    else
                    {
                        bssType = Wlan.Dot11BssType.Infrastructure;
                        flags = 0;
                    }
                    connectParams.dot11BssType = bssType;
                    connectParams.flags = flags;

                    //接続
                    result = Wlan.WlanConnect(clientHandle, wlanInterface.InterfaceGuid, ref connectParams, IntPtr.Zero);

                    if (result == 0)
                    {
                        log.Debug("WLAN Connect SUCCESS");
                        return true;
                    }
                    else
                    {
                        log.Debug("WLAN Connect ERROR [" + result + "]");
                        return false;
                    }
                }
                finally
                {
                    Wlan.WlanCloseHandle(clientHandle, IntPtr.Zero);
                }
            }
            log.Debug("END");
            return false;
        }

        /// <summary>
        /// アドホックモードに切替時、DST-iへの接続処理を再実施する必要があるかを判定する
        /// </summary>
        /// <param name="client">WlanClientオブジェクト</param>
        /// <returns>再接続が必要な場合、true</returns>
        private static bool IsAdhocRetryRequired(WlanClient client)
        {
            foreach (WlanClient.WlanInterface wlanInterface in client.Interfaces)
            {
                if (wlanInterface.InterfaceState == Wlan.WlanInterfaceState.AdHocNetworkFormed  //アドホック待受中
                    || wlanInterface.InterfaceState == Wlan.WlanInterfaceState.Disconnected)    //切断
                {
                    //状態が上記いずれかに当てはまる場合は再接続必要
                    return true;
                }
                else if (wlanInterface.InterfaceState == Wlan.WlanInterfaceState.Connected)
                {
                    if (wlanInterface.CurrentConnection.isState == Wlan.WlanInterfaceState.Connected
                        && wlanInterface.CurrentConnection.wlanAssociationAttributes.dot11BssType != Wlan.Dot11BssType.Independent)
                    {
                        //接続先がアドホックではない場合、再接続必要
                        return true;
                    }
                }
            }
            return false;
        }

        /// <summary>
        /// SSIDを取得する
        /// </summary>
        /// <param name="dto">DST-i情報</param>
        /// <returns>SSID</returns>
        public static string getSsid(DSTiDto dto, Consts.ConnectMode searchMode)
        {
            if (Consts.ConnectMode.INFRA.Equals(searchMode))
            {
                //インフラストラクチャモードの場合
                return dto.infraSsid;
            }
            else
            {
                //アドホックモードの場合
                return dto.adhocSsid;
            }
        }

        /// <summary>
        /// PCのIPアドレスを取得する。
        /// 取得に失敗した場合は空の文字列を返す。
        /// </summary>
        /// <param name="client">WlanClient</param>
        /// <returns>IPアドレス</returns>
        internal static string getIpAddress(WlanClient client, string ssid)
        {
            log.Debug("getIpAddress start");

            string myIpAddress = "";

            try
            {
                foreach (WlanClient.WlanInterface wlanInterface in client.Interfaces)
                {

                    String settingId = wlanInterface.InterfaceGuid.ToString();


                    log.Debug("settingId [" + settingId + "]");
                    log.Debug("profileName [" + wlanInterface.CurrentConnection.profileName + "]");
                    
                    if (!ssid.Equals(wlanInterface.CurrentConnection.profileName)) {
                        return "";
                    }

                    ManagementObjectSearcher oMOS = new ManagementObjectSearcher();
                    ManagementObjectCollection oMOC;

                    oMOS.Query.QueryString = "SELECT * FROM Win32_NetworkAdapterConfiguration WHERE SettingID='{" + settingId + "}'";

                    log.Debug("oMOS.Query.QueryString [" + oMOS.Query.QueryString + "]");

                    oMOC = oMOS.Get();

                    foreach (ManagementObject oMO in oMOC)
                    {
                        if (oMO["IPAddress"] != null)
                        {

                            string[] sIpAddress = (string[])oMO["IPAddress"];

                            for (int i = 0; i < sIpAddress.Length; i++)
                            {
                                log.Debug("sIpAddress[" + i + "] [" + sIpAddress[i] + "]");
                                // IPv6とIPv4が両方とれる場合はIPv4を取得する
                                if (sIpAddress[i] != null && sIpAddress[i].IndexOf("fe80:") == -1)
                                {
                                    myIpAddress = sIpAddress[i];
                                }
                            }
                        }
                    }
                }
                log.Debug("getIpAddress end - myIpAddress[" + myIpAddress + "]");

                return myIpAddress;
            }
            catch (Exception e)
            {
                return "";
            }
        }

        /// <summary>
        /// HDS仕向けを取得
        /// </summary>
        /// <param name="defDetailDto">共通定義ファイル(デフォルト仕向け)</param>
        /// <returns></returns>
        public static String getHDSMarket(DefinitionDetailDto defDetailDto)
        {

            String marketLACKey = "";
            String marketLACValue = "";
            String marketKey = "";
            String marketValue = "";
            String market = "";
            String marketLAC = "";

            if (!String.IsNullOrEmpty(defDetailDto.hdsinfo.lacmarketregistry))
            {
                // キーとバリューに分割
                spritRegKeyVal(defDetailDto.hdsinfo.lacmarketregistry, ref marketLACKey, ref marketLACValue);
                // LACを確認
                marketLAC = (String)Microsoft.Win32.Registry.GetValue(marketLACKey, marketLACValue, null);
            }

            if (String.IsNullOrEmpty(marketLAC))
            {
                // 存在しなければ他仕向けレジストリを取得
                if (!String.IsNullOrEmpty(defDetailDto.hdsinfo.marketregistry))
                {
                    spritRegKeyVal(defDetailDto.hdsinfo.marketregistry, ref marketKey, ref marketValue);
                    market = (String)Microsoft.Win32.Registry.GetValue(marketKey, marketValue, null);

                    if (String.IsNullOrEmpty(market))
                    {
                        market = "";
                    }
                }

                return market;
            }
            else
            {
                return marketLAC;
            }

        }

        /// <summary>
        /// HDS言語情報取得
        /// </summary>
        /// <param name="def"></param>
        /// <param name="useDefault">デフォルトの言語を使用する場合true</param>
        /// <returns></returns>
        public static String getHDSLanguage(DefinitionDetailDto def, out bool useDefault)
        {

            String languageKey = "";
            String languageValue = "";
            String language = "";
            useDefault = true;  // 初期値：デフォルト言語を使用する

            if (String.IsNullOrEmpty(def.hdsinfo.languageregistry))
            {
                return def.hdsinfo.language_default;
            }

            // キーとバリューに分割
            spritRegKeyVal(def.hdsinfo.languageregistry, ref languageKey, ref languageValue);
            // LACを確認
            language = (string)Microsoft.Win32.Registry.GetValue(languageKey, languageValue, null);

            if (String.IsNullOrEmpty(language))
            {
                return def.hdsinfo.language_default;
            }

            // レジストリを取得できた場合、デフォルト言語を使用しない
            useDefault = false;

            return language;

        }

        /// <summary>
        /// 定義ファイルのレジストリパスをキーとバリューに分割する
        /// </summary>
        /// <param name="target">定義ファイルのレジストリパス</param>
        /// <param name="key">キー</param>
        /// <param name="value">バリュー</param>
        public static void spritRegKeyVal(String target, ref String key, ref String value)
        {
            key = target.Substring(1, target.IndexOf("]") - 1);
            value = target.Substring(target.IndexOf("]") + 1);

        }

        /// <summary>
        /// 仕向け先がカナダかどうか判定する
        /// </summary>
        /// <param name="market">仕向け先</param>
        /// <returns>true：カナダ、false：カナダ以外</returns>
        public static Boolean isCanada(String market)
        {
            //Settings.settingsに記述されているパラメータから取得するカナダの仕向け先コードと一致する場合
            if (Properties.Settings.Default.MarketCanada.Equals(market))
            {
                return true;
            }

            return false;
        }

        /// <summary>
        /// 接続先IPアドレスをレジストリに設定する
        /// </summary>
        /// <param name="ipAddress">登録するIPアドレス</param>
        public static void SetTargetIpAddress(string ipAddress, Consts.CommunicationMode commMode)
        {
            //キー名が無かったら作成する
            Microsoft.Win32.RegistryKey regKey = Microsoft.Win32.Registry.CurrentUser.CreateSubKey(DSTiCommon.CommonConst.DSTI_ROOT_REGKEY);

            //ポート番号を付与
            if (ipAddress != null && ipAddress.Length > 0)
            {
                /*
                bool contains;
                lock (udpTableLock)
                {
                    contains = udpTable.Contains(ipAddress);
                }
                if (contains)
                {
                    ipAddress += ":" + Consts.DSTI_PORT_UDP;
                }
                else
                {
                    ipAddress += ":" + Consts.DSTI_PORT_TCP;
                }
                */
                switch (commMode)
                {
                    case Consts.CommunicationMode.UDP:
                        ipAddress += ":" + Consts.DSTI_PORT_UDP;
                        break;
                    case Consts.CommunicationMode.ICMP:
                        ipAddress += ":" + Consts.DSTI_PORT_TCP;
                        break;
                }
            }

            //レジストリ書き換え
            SetRegValue(regKey, Consts.REGNAME_TARGET_IP_ADDRESS, ipAddress);
        }

        /// <summary>
        /// 接続先IPアドレスをレジストリに設定する
        /// </summary>
        public static void ClearTargetIpAddress()
        {
            //キー名が無かったら作成する
            Microsoft.Win32.RegistryKey regKey = Microsoft.Win32.Registry.CurrentUser.CreateSubKey(DSTiCommon.CommonConst.DSTI_ROOT_REGKEY);

            //レジストリ書き換え
            SetRegValue(regKey, Consts.REGNAME_TARGET_IP_ADDRESS, "");
        }

        /// <summary>
        /// レジストリに登録されている接続先IPアドレスを返す
        /// </summary>
        /// <returns>IPアドレス</returns>
        public static string GetTargetIpAddress()
        {
            try
            {
                string ipAddress = GetRegValue(Consts.REGNAME_TARGET_IP_ADDRESS);

                if (ipAddress == null)
                {
                    //取得失敗時はブランクを返す
                    ipAddress = "";
                }
                else
                {
                    //ポート番号を除いた値を返す
                    ipAddress = ipAddress.Split(":".ToCharArray())[0];
                }

                return ipAddress;
            }
            catch (Exception e)
            {
                return "";
            }
        }

        /// <summary>
        /// 接続したDST-iのシリアルNo.をレジストリに設定する
        /// </summary>
        /// <param name="ipAddress">登録するシリアルNo.</param>
        public static void SetTargetSerialNo(string serialNo)
        {
            //キー名が無かったら作成する
            Microsoft.Win32.RegistryKey regKey = Microsoft.Win32.Registry.CurrentUser.CreateSubKey(DSTiCommon.CommonConst.DSTI_ROOT_REGKEY);

            //レジストリ書き換え
            SetRegValue(regKey, Consts.REGNAME_TARGET_SERIAL_NO, serialNo);
        }

        /// <summary>
        /// レジストリに登録されている値を返す
        /// </summary>
        /// <param name="name">値名</param>
        /// <returns>値</returns>
        public static string GetRegValue(string name)
        {
            Microsoft.Win32.RegistryKey regKey = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(DSTiCommon.CommonConst.DSTI_ROOT_REGKEY);

            // 取得できなかった場合、空白を返す
            if (regKey == null)
            {
                return "";
            }

            return (string)regKey.GetValue(name, "");
        }

        /// <summary>
        /// レジストリに値を設定する
        /// </summary>
        /// <param name="regKey">レジストリサブキー</param>
        /// <param name="name">値名</param>
        /// <param name="value">値</param>
        public static void SetRegValue(Microsoft.Win32.RegistryKey regKey, string name, string value)
        {
            regKey.SetValue(name, value);
        }

        /// <summary>
        /// アドホック接続済か否かを判定する
        /// </summary>
        /// <param name="client">WlanClientオブジェクト</param>
        /// <returns>アドホック接続済の場合、true</returns>
        internal static bool IsAdhocConnected(WlanClient client)
        {
            foreach (WlanClient.WlanInterface wlanInterface in client.Interfaces)
            {
                // CurrentConnectionが取得できるかを判断するためにInterfaceStateをチェックする。
                // ・「AdHocNetworkFormed（ユーザ待機中）」の場合もCurrentConnectionは取得可能だが
                //   DST-iが検出されることはないので、無駄な判定を避けるためにインフラ扱いとする。
                // ・接続が確立したにもかかわらず「Authenticating（認証中）」となるケースがあるため
                //   「Authenticating」の場合もdot11BssTypeを判定する。
                if (wlanInterface.InterfaceState == Wlan.WlanInterfaceState.Connected
                    || wlanInterface.InterfaceState == Wlan.WlanInterfaceState.Authenticating)
                {
                    if (wlanInterface.CurrentConnection.wlanAssociationAttributes.dot11BssType == Wlan.Dot11BssType.Independent)
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        /// <summary>
        /// ネットワーク接続中か否かを判定する
        /// </summary>
        /// <param name="client">WlanClientオブジェクト</param>
        /// <returns>ネットワーク接続中の場合、true</returns>
        internal static bool IsConnected(WlanClient client)
        {
            foreach (WlanClient.WlanInterface wlanInterface in client.Interfaces)
            {
                if (wlanInterface.InterfaceState == Wlan.WlanInterfaceState.Disconnected)
                {
                    return false;
                }
            }

            return true;
        }

        #region トライアルモード関数
        /// <summary>
        /// トライアルモードチェック
        /// </summary>
        /// <returns>トライアルモードフラグ</returns>
        public static bool checkTrialMode()
        {
            const string trialStr = "trial";

            //コマンドライン引数取得
            string[] args = Environment.GetCommandLineArgs();
            if (args.Length != 2)
            {
                return false;
            }

            bool ret = false;
            //文字列照合
            if (trialStr.Equals(args[1]))
            {
                ret = true;
            }
            else
            {
                ret = false;
            }

            return ret;
        }
        #endregion

        #region UDP対応評価版
        // DSTiCommonからのコピペ(staticにしたくらい） Start -->
        /// <summary>
        /// IPアドレスを取得する
        /// </summary>
        /// <returns></returns>
        private static String GetSeltIPAddress()
        {
            String ret = "";

            try
            {
                using (WlanClient client = new WlanClient())
                {
                    foreach (WlanClient.WlanInterface wlanIface in client.Interfaces)
                    {
                        //log.Debug("wlanIFace:" + wlanIface.InterfaceName);
                        ret = getIpAdd(wlanIface.InterfaceGuid.ToString());

                        if (String.Empty != ret)
                        {
                            break;
                        }
                    }
                }

                return ret;

            }
            catch (Exception e)
            {
                throw e;
            }
        }

        private static string getIpAdd(string settingid)
        {
            ManagementObjectSearcher oMS = new ManagementObjectSearcher();
            ManagementObjectCollection oMC;
            string ipAdd = "";

            oMS.Query.QueryString = "SELECT * FROM Win32_NetworkAdapterConfiguration WHERE SettingID='{" + settingid + "}'";
            oMC = oMS.Get();

            foreach (ManagementObject oMO in oMC)
            {

                if (oMO["IPAddress"] != null)
                {

                    foreach (string ip in (string[])oMO["IPAddress"])
                    {
                        // IPv6とIPv4が両方とれる場合はIPv4を取得する
                        if (ip.IndexOf("fe80:") == -1)
                        {
                            ipAdd = ip;
                        }
                    }
                }
            }
            return ipAdd;
        }

        [DllImport("iphlpapi.dll")]
        extern static int GetIpNetTable(IntPtr pTcpTable, ref int pdwSize, bool bOrder);

        /// <summary>
        /// PING送信用関数定義
        /// </summary>
        [DllImport("icmp.dll", SetLastError = true)]
        static extern IntPtr IcmpCreateFile();

        /// <summary>
        /// PING送信用関数定義
        /// </summary>
        [DllImport("icmp.dll", SetLastError = true)]
        static extern bool IcmpCloseHandle(IntPtr handle);

        /// <summary>
        /// PING送信用関数定義
        /// </summary>
        [DllImport("icmp.dll", SetLastError = true)]
        static extern Int32 IcmpSendEcho(IntPtr icmpHandle, Int32 destinationAddress, String requestData,
                                     Int16 requestSize, ref ICMP_OPTIONS requestOptions, ref ICMP_ECHO_REPLY replyBuffer,
                                     Int32 replySize, Int32 timeout);

        /// <summary>
        /// PING送信用関数定義
        /// </summary>
        [DllImport("ws2_32.dll", ExactSpelling = true)]
        static extern Int32 inet_addr(string cp);


        [StructLayout(LayoutKind.Sequential)]
        public struct MIB_IPNETROW
        {
            public int Index;
            public int PhysAddrLen;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
            public byte[] PhysAddr;
            public int Addr;
            public int Type;
        }

        /// <summary>
        /// PING送信用構造体定義
        /// </summary>
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
        private struct ICMP_OPTIONS
        {
            public Byte Ttl;
            public Byte Tos;
            public Byte Flags;
            public Byte OptionsSize;
            public IntPtr OptionsData;
        };

        /// <summary>
        /// PING送信用構造体定義
        /// </summary>
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
        private struct ICMP_ECHO_REPLY
        {
            public Int32 Address;
            public Int32 Status;
            public Int32 RoundTripTime;
            public Int16 DataSize;
            public Int16 Reserved;
            public IntPtr DataPtr;
            public ICMP_OPTIONS Options;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 250)]
            public String Data;
        }
        private static string ipstr(int addr)
        {
            var b = BitConverter.GetBytes(addr);
            return string.Format("{0}.{1}.{2}.{3}", b[0], b[1], b[2], b[3]);
        }

        /// <summary>
        /// ロック取得用オブジェクト
        /// </summary>
        private static readonly object lockObj = new object();

        /// <summary>
        /// PING実施済確認用カウンタ
        /// </summary>
        private static int PingCnter = 0;

        /// <summary>
        /// PING送信スレッド処理
        /// </summary>
        /// <param name="IPAddress">IPアドレス</param>
        private static void SendPingThread(object IPAddress)
        {
            //初期化
            ICMP_ECHO_REPLY reply = new ICMP_ECHO_REPLY();
            ICMP_OPTIONS option = new ICMP_OPTIONS();
            option.Ttl = 255;
            string data = string.Empty;
            int timeout = 10;                     //タイムアウト値(ミリ秒)
            string ipStr = IPAddress.ToString();    //IPアドレス
            IntPtr handle = IcmpCreateFile();

            int result = 0;
            //Ping送信
            result = IcmpSendEcho(handle, inet_addr(ipStr), data, (Int16)data.Length
                    , ref option, ref reply, Marshal.SizeOf(reply), timeout);

            //マルチスレッドで実施する為ロックをかけて排他制御実施
            lock (lockObj)
            {
                //PING実施済みカウンタ更新
                PingCnter++;
            }

            //ハンドルを閉じる
            IcmpCloseHandle(handle);

        }
        // <-- DSTiCommonからのコピペ(staticにしたくらい） End  

        // DSTiCommonからのコピペ + 修正(キャンセル機能追加,Pingブロードキャスト方式変更も含む) Start -->
        /// <summary>
        /// PING送信メイン処理
        /// </summary>
        /// <param name="IPAddress">IPアドレス</param>
        /// <param name="worker">画面のワーカスレッド。キャンセル要求チェック用</param>
        //private static void SendPingAfterUDPBroadcast(String IPAddress, Hashtable ipTable, int interval, System.ComponentModel.BackgroundWorker worker, int startNumber, int endNumber)
        private static void SendPingAfterUDPBroadcast(ArrayList availableIPAddressList, Hashtable ipTable, int interval, System.ComponentModel.BackgroundWorker worker, int startNumber, int endNumber)
        {
            //const int HOST_COUNT = 255;
            //String RootIP = IPAddress.Substring(0, IPAddress.LastIndexOf(".") + 1);
            String TargetIP = String.Empty;
            int hitCount = 0;
            int sendCount = endNumber - startNumber;
        

            //X.X.X.255はブロードキャストアドレスの為実施しない
            //for (int i = 0; i < HOST_COUNT; i++)
            for (int i = startNumber; i < endNumber; i++)
            {
                //画面からキャンセル要求があれば新規スレッドは立てない
                if (worker.CancellationPending)
                {
                    break;
                }

                //TargetIP = RootIP + i.ToString();
                TargetIP = availableIPAddressList[i].ToString();

                if (ipTable.Contains(TargetIP))
                {
                    hitCount++;
                    continue;
                }

                //スレッド生成
                Thread thPing = new Thread(new ParameterizedThreadStart(SendPingThread));
                //スレッド開始
                thPing.Start(TargetIP);

                // 次のスレッド起動までに設定時間分間をあける
                Thread.Sleep(interval);
            }

            //全スレッド終了まで待機
            //while (PingCnter < (HOST_COUNT - hitCount))
            while (PingCnter < (sendCount - hitCount))
            {
                //画面からキャンセル要求があれば即終了
                if (worker.CancellationPending)
                {
                    break;
                }
            }
            //スレッド強制終了は危険なので一旦起動済みは自然に終わってもらう想定
        }

        //public static ArrayList getIpAddressListAfterUDPBroadcast(ArrayList broadcastReply, int interval, System.ComponentModel.BackgroundWorker worker, int startNumber, int endNumber)
        public static ArrayList getIpAddressListAfterUDPBroadcast(ArrayList broadcastReply, ArrayList availableIPAddressList, int interval, System.ComponentModel.BackgroundWorker worker, int startNumber, int endNumber)
        {
            ArrayList resultList = new ArrayList();
            Hashtable ipTable = new Hashtable();

            try
            {
                // 画面側でマージするのでここでは不要の想定

                foreach (BroadcastReply reply in broadcastReply)
                {
                    ipTable[reply.ip] = true;
                }

                // IPアドレスを取得する
                String IPAddress = GetSeltIPAddress();
                if (IPAddress.Equals(String.Empty))
                {
                    return resultList;
                }

                //PINGをとばす
                //SendPingAfterUDPBroadcast(IPAddress, ipTable, interval, worker, startNumber, endNumber);
                SendPingAfterUDPBroadcast(availableIPAddressList, ipTable, interval, worker, startNumber, endNumber);
                //キャンセルされても取得済みは表示する為、以降の処理は止めない想定

                int targetCnt = endNumber - startNumber;
                ArrayList targetIPAddressList = new ArrayList(targetCnt);
                for (int idx = startNumber; idx < endNumber; idx++)
                {
                    targetIPAddressList.Add(availableIPAddressList[idx]);
                }

                int size = 0;

                GetIpNetTable(IntPtr.Zero, ref size, true);//必要サイズの取得
                var p = Marshal.AllocHGlobal(size);//メモリ割当て
                if (GetIpNetTable(p, ref size, true) == 0)
                {//データの取得
                    var num = Marshal.ReadInt32(p);//MIB_IPNETTABLE.dwNumEntries(データ数)
                    //var ptr = IntPtr.Add(p, 4);
                    var ptr = new IntPtr(p.ToInt32() + 4);
                    for (int i = 0; i < num; i++)
                    {
                        var temp = (MIB_IPNETROW)Marshal.PtrToStructure(ptr, typeof(MIB_IPNETROW));

                        if (temp.Type != 2)
                        {
                            //種類が「無効」でないもののみ対象とする
                            string addr = ipstr(temp.Addr);

                            //インターフェイスが複数存在する場合、IPアドレスが重複する可能性があるのでチェックする
                            if (!ipTable.Contains(addr))
                            {
                                bool doAdd = true;
                                /*
                                String RootIP = IPAddress.Substring(0, IPAddress.LastIndexOf(".") + 1);
                                String ArpRootIP = addr.Substring(0, addr.LastIndexOf(".") + 1);
                                if (RootIP.Equals(ArpRootIP))
                                {
                                    //TCP版(startNumber～endNumber以外は今回Ping送信対象外なので除外)
                                    String number = addr.Substring(addr.LastIndexOf(".") + 1);
                                    int iNumber;
                                    bool bNumber = int.TryParse(number, out iNumber);
                                    if (bNumber)
                                    {
                                        if (iNumber < startNumber
                                        || iNumber > endNumber)
                                        {
                                            doAdd = false;
                                        }
                                    }
                                }
                                */
                                if (availableIPAddressList.Contains(addr))
                                {
                                    if (!targetIPAddressList.Contains(addr))
                                    {
                                        doAdd = false;
                                    }
                                }
                                if (doAdd)
                                {
                                    BroadcastReply reply = new BroadcastReply();
                                    reply.ip = addr;
                                    reply.reply = null;
                                    reply.commMode = Consts.CommunicationMode.ICMP;
                                    resultList.Add(reply);
                                    ipTable[addr] = true;
                                }
                            }
                        }

                        ptr = new IntPtr(ptr.ToInt32() + Marshal.SizeOf(typeof(MIB_IPNETROW)));
                    }
                    Marshal.FreeHGlobal(p);  //メモリ開放
                }

                return resultList;
            }
            catch (Exception e)
            {
                resultList = new ArrayList();
                return resultList;
            }
        }
        // <-- DSTiCommonからのコピペ + 修正(キャンセル機能追加も含む) End  
        /// <summary>
        /// ブロードキャストIPアドレスを取得する
        /// </summary>
        /// <returns></returns>
        private static String GetSeltBroadcastIPAddress()
        {
            String ret = "";

            try
            {
                using (WlanClient client = new WlanClient())
                {
                    foreach (WlanClient.WlanInterface wlanIface in client.Interfaces)
                    {
                        //log.Debug("wlanIFace:" + wlanIface.InterfaceName);
                        ret = getBroadcastIpAdd(wlanIface.InterfaceGuid.ToString());

                        if (String.Empty != ret)
                        {
                            break;
                        }
                    }
                }

                return ret;

            }
            catch (Exception e)
            {
                throw e;
            }
        }

        private static string getBroadcastIpAdd(string settingid)
        {
            ManagementObjectSearcher oMS = new ManagementObjectSearcher();
            ManagementObjectCollection oMC;
            string ipAdd = "";

            oMS.Query.QueryString = "SELECT * FROM Win32_NetworkAdapterConfiguration WHERE SettingID='{" + settingid + "}'";
            oMC = oMS.Get();

            foreach (ManagementObject oMO in oMC)
            {

                if (oMO["IPAddress"] != null)
                {
                    for (int i = 0; i < ((string[])oMO["IPAddress"]).Length; i++)
                    {
                        string ip = ((string[])oMO["IPAddress"])[i];
                        // IPv6とIPv4が両方とれる場合はIPv4を取得する
                        if (ip.IndexOf("fe80:") == -1)
                        {
                            IPAddress self = IPAddress.Parse(ip);
                            
                            //サブネットマスク
                            string subnet = ((string[])oMO["IPSubnet"])[i];
                            IPAddress mask = IPAddress.Parse(subnet);

                            //ブロードキャストアドレス(サブネットマスク反転、IPアドレスとOR)
                            byte[] bSelf = self.GetAddressBytes();
                            byte[] bMask = mask.GetAddressBytes();
                            byte[] rMask = new byte[bMask.Length];
                            byte[] bBroad = new byte[bSelf.Length];
                            for (int j = 0; j < bMask.Length; j++)
                            {
                                rMask[j] = (byte)~bMask[j];
                                bBroad[j] = (byte)(rMask[j] | bSelf[j]);
                            }

                            ipAdd = new IPAddress(bBroad).ToString();
                        }
                    }
                }
            }
            return ipAdd;
        }

        /// <summary>
        /// 有効範囲の最初のIPアドレスを取得する
        /// </summary>
        /// <returns></returns>
        private static String GetSeltFirstIPAddress()
        {
            String ret = "";

            try
            {
                using (WlanClient client = new WlanClient())
                {
                    foreach (WlanClient.WlanInterface wlanIface in client.Interfaces)
                    {
                        //log.Debug("wlanIFace:" + wlanIface.InterfaceName);
                        ret = getFirstIpAdd(wlanIface.InterfaceGuid.ToString());

                        if (String.Empty != ret)
                        {
                            break;
                        }
                    }
                }

                return ret;

            }
            catch (Exception e)
            {
                throw e;
            }
        }

        private static string getFirstIpAdd(string settingid)
        {
            ManagementObjectSearcher oMS = new ManagementObjectSearcher();
            ManagementObjectCollection oMC;
            string ipAdd = "";

            oMS.Query.QueryString = "SELECT * FROM Win32_NetworkAdapterConfiguration WHERE SettingID='{" + settingid + "}'";
            oMC = oMS.Get();

            foreach (ManagementObject oMO in oMC)
            {

                if (oMO["IPAddress"] != null)
                {
                    for (int i = 0; i < ((string[])oMO["IPAddress"]).Length; i++)
                    {
                        string ip = ((string[])oMO["IPAddress"])[i];
                        // IPv6とIPv4が両方とれる場合はIPv4を取得する
                        if (ip.IndexOf("fe80:") == -1)
                        {
                            IPAddress self = IPAddress.Parse(ip);

                            //サブネットマスク
                            string subnet = ((string[])oMO["IPSubnet"])[i];
                            IPAddress mask = IPAddress.Parse(subnet);

                            //ブロードキャストアドレス(IPアドレスとサブネットマスクAND)
                            byte[] bSelf = self.GetAddressBytes();
                            byte[] bMask = mask.GetAddressBytes();
                            byte[] bBroad = new byte[bSelf.Length];
                            for (int j = 0; j < bMask.Length; j++)
                            {
                                bBroad[j] = (byte)(bMask[j] & bSelf[j]);
                            }

                            ipAdd = new IPAddress(bBroad).ToString();
                        }
                    }
                }
            }
            return ipAdd;
        }

        public static ArrayList getAvailableIPAddressListInNetwork()
        {
            string startIPAddress = GetSeltFirstIPAddress();
            string endIPAddress = GetSeltBroadcastIPAddress();
            ArrayList avaliableList;
            
            try
            {
                IPAddress start = IPAddress.Parse(startIPAddress);
                IPAddress end = IPAddress.Parse(endIPAddress);

                const int HOST_COUNT = 255;
                const int OCTET_COUNT = 4;
                byte[] bStart = start.GetAddressBytes();
                byte[] bEnd = end.GetAddressBytes();

                int availableCount = 0;//理論的には4,311,810,304IP有、longじゃないと収まらないが現実的にはそこまでにはならない想定。
                int pow = 0;//256のn乗
                int div = 0;//同一オクテット差異

                for (int oct = 0; oct < OCTET_COUNT; oct++)
                {
                    if (bEnd[oct] > bStart[oct])
                    {
                        pow = (int)Math.Pow((double)(HOST_COUNT + 1), (double)(OCTET_COUNT - oct - 1));
                        div = bEnd[oct] - bStart[oct] + 1;
                        availableCount += pow * div;
                    }
                }
                if (availableCount > 0)
                {
                    availableCount -= 2;//ネットワークアドレス、ブロードキャストアドレスを除く
                }

                avaliableList = new ArrayList(availableCount);
                byte[] bTmp = new byte[OCTET_COUNT];
                bStart.CopyTo(bTmp, 0);
                for (int i = 0; i < availableCount; i++)
                {
                    if (bTmp[3] == HOST_COUNT)
                    {
                        bTmp[3] = 0;
                        if (bTmp[2] == HOST_COUNT)
                        {
                            bTmp[2] = 0;
                            if (bTmp[1] == HOST_COUNT)
                            {
                                bTmp[1] = 0;
                                bTmp[0]++;
                            }
                            else
                            {
                                bTmp[1]++;
                            }
                        }
                        else
                        {
                            bTmp[2]++;
                        }
                    }
                    else
                    {
                        bTmp[3]++;
                    }
                    avaliableList.Add(new IPAddress(bTmp).ToString());
                }
                return avaliableList;
            }
            catch (Exception e)
            {
                avaliableList = new ArrayList();
                return avaliableList;
            }
        }

        /// <summary>
        /// UDP対応IPアドレス保護用のインスタンス
        /// </summary>
        private static readonly object udpTableLock = new object();

        /// <summary>
        /// UDP対応IPアドレス格納用Hashtable
        /// このテーブルはSendSocketでTCP/UDPを判断するのに使用する
        /// アクセス時はかならずudpTableLockのロックを取得すること
        /// </summary>
        private static Hashtable udpTable = new Hashtable();

        /// <summary>
        /// コマンドをブロードキャストし、応答を返したIPアドレスとその応答データのペアをリストで返す
        /// </summary>
        /// <returns>IPアドレスとその応答データのリスト</returns>
        public static ArrayList getIpAddressListUDP()
        {
            ArrayList array = new ArrayList();
            Socket s = null;
            try {
                // ブロードキャストアドレス作成
                string myIPString = GetSeltIPAddress();
                //string broadcastString = String.Format("{0}.255", myIPString.Substring(0, myIPString.LastIndexOf(".")));
                string broadcastString = GetSeltBroadcastIPAddress();
                IPAddress broadcastAddress = IPAddress.Parse(broadcastString);
                //IPAddress broadcastAddress = IPAddress.Broadcast;
                //string broadcastString = broadcastAddress.ToString();

                // エンドポイント設定の作成
                IPEndPoint endPoint = new IPEndPoint(broadcastAddress, Consts.DSTI_SOCKET_PORT_UDP);

                // ソケット作成
                s = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);

                // 受信バッファサイズの設定
                s.ReceiveBufferSize = Consts.SOCKET_RECEIVE_BUFFER_SIZE;

                // 送信データ編集（3:WiFi接続情報読出しコマンド）
                List<byte> sendByteList = new List<byte>();
                sendByteList.Add(Consts.SOCKET_ID_GET_CONNECTION_DATA);
                sendByteList.Add(0);
                sendByteList.Add(0);
                byte[] sendByte = sendByteList.ToArray();

                log.Debug("UDP Broadcast[{0}->{1}] Send Start.", myIPString, broadcastString);

                // ブロードキャスト許可
                s.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.Broadcast, 1);//1: 許可

                // コマンドブロードキャスト
                s.SendTo(sendByte, endPoint);

                // 受信
                //スレッド生成
                BroadcastReplyReceiver worker = new BroadcastReplyReceiver();
                Thread thread = new Thread(new ParameterizedThreadStart(worker.receiveBroadcastReply));
                thread.IsBackground = true;

                // パラメータ設定
                BroadcastReplyReceiverParam param = new BroadcastReplyReceiverParam();
                param.sock = s;
                param.array = array;
 
                //スレッド開始
                thread.Start(param);

                // 待ち合わせ
                Thread.Sleep(Consts.SOCKET_RECEIVE_WAIT_TIME);

                // 終了リクエスト
                worker.requestStop();

                // 待ち合わせ
                thread.Join();

                log.Debug("UDP Broadcast[{0}->{1}] Recieve TimeOut[{2}ms].", myIPString, broadcastString, Consts.SOCKET_RECEIVE_WAIT_TIME);

                // UDP対応IPアドレステーブルを更新する
                lock (udpTableLock)
                {
                    udpTable.Clear();
                    foreach(BroadcastReply reply in array)
                    {
                        udpTable[reply.ip] = true;
                    }
                }

                // IPアドレスのリストを返す
                return array;
            }
            catch (Exception ex)
            {
                //通信失敗時
                log.Error(ex);
                log.Error(ex.InnerException);
                return array;
            }
            finally
            {
                if (s != null)
                {
                    s.Close();
                }
            }
        }

        public class BroadcastReply
        {
            public string ip { get; set; }
            public byte[] reply { get; set; }
            public Consts.CommunicationMode commMode { get; set; }
        }

        private class BroadcastReplyReceiverParam
        {
            public Socket sock { get; set; }
            public ArrayList array { get; set;}
        }

        private class BroadcastReplyReceiver
        {
            private volatile bool _shouldStop = false;

            /// <summary>
            /// スレッドの終了をリクエストする
            /// </summary>
            public void requestStop()
            {
                _shouldStop = true;
            }

            /// <summary>
            /// ブロードキャストの応答を受信し、IPアドレスをリストに保存する
            /// </summary>
            /// <param name="name">値名</param>
            /// <returns>応答を返したIPアドレスのリスト</returns>
            public void receiveBroadcastReply(Object param)
            {
                BroadcastReplyReceiverParam p = (BroadcastReplyReceiverParam)param;
                ArrayList array = p.array;
                Socket sock = p.sock;
                Hashtable ipTable = new Hashtable();
                byte[] buffer = new Byte[1024];
                IPEndPoint endPoint = new IPEndPoint(IPAddress.Any, 0);
                EndPoint senderRemote = (EndPoint)endPoint;
                ArrayList listenList = new ArrayList();
                int recvSize = 0;

                while (!_shouldStop)
                {
                    try
                    {
                        // タイムアウト10ミリ秒
                        listenList.Clear();
                        listenList.Add(sock);
                        Socket.Select(listenList, null, null, 10000);

                        if (listenList.Count > 0)
                        {
                            recvSize = sock.ReceiveFrom(buffer, ref senderRemote);
                            string remote = senderRemote.ToString();
                            string remoteIP = remote.Substring(0, remote.LastIndexOf(":"));

                            // UDPなので念のため重複排除
                            if (!ipTable.Contains(remoteIP))
                            {
                                BroadcastReply reply = new BroadcastReply();
                                byte[] newBuffer = new Byte[recvSize];
                                Array.Copy(buffer, 0, newBuffer, 0, recvSize);
                                reply.ip = remoteIP;
                                reply.reply = newBuffer;
                                reply.commMode = Consts.CommunicationMode.UDP;
                                array.Add(reply);
                                ipTable[remoteIP] = true;
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        //通信失敗時、ループ終了
                        log.Error(ex);
                        log.Error(ex.InnerException);
                        break;
                    }
                }
            }
        }

        /// <summary>
        /// モード切替時のIPアドレス変更に対応するため
        /// UDP対応IPアドレステーブルのエントリを再設定する
        /// </summary>
        /// <param name="oldIpAddress">変更前IPアドレス</param>
        /// <param name="newIpAddress">変更後IPアドレス</param>
        public static void resetUDPIpAddressTable(string oldIpAddress, string newIpAddress)
        {
            lock (udpTableLock)
            {
                // モード切替前がUDPであれば切替後もUDP
                bool contains = true;
                if (oldIpAddress != null)
                {
                    contains = udpTable.Contains(oldIpAddress);
                }

                // 一旦全クリア
                udpTable.Clear();

                // 変更前IPアドレス指定なし、またはテーブルに含まれている場合
                if (contains)
                {
                    udpTable[newIpAddress] = true;
                }
            }
        }

        /// <summary>
        /// DST-iに対してソケットを送信し、結果を返す
        /// </summary>
        /// <param name="ipAddress">送信先IPアドレス</param>
        /// <param name="id">コマンドID</param>
        /// <param name="param">パラメータ</param>
        /// <returns>応答データ</returns>
        internal static byte[] SendSocketUDP(string ipAddress, byte id, byte[] param, int? sendPingCount = null)
        {
            ManualResetEvent connect = new ManualResetEvent(false);
            UdpClient client = null;
            NetworkStream stream = null;

            try
            {
                //定義ファイル取得
                client = new UdpClient();
                client.Client.SendTimeout = Consts.TIMEOUT;
                client.Client.ReceiveTimeout = Consts.TIMEOUT;
                log.Debug("in SendSocket ipAddress: " + ipAddress.ToString());

                // エンドポイント設定
                IPEndPoint endPoint = new IPEndPoint(IPAddress.Parse(ipAddress), Consts.DSTI_SOCKET_PORT_UDP);

                string logParam = "";
                foreach (byte b in param)
                {
                    if (logParam.Length > 0)
                    {
                        logParam += ",";
                    }
                    logParam += Convert.ToString(b);
                }
                log.Debug("begin connection SUCCESS - ipAddress[" + ipAddress + "], id[" + id + "], param[" + logParam + "]");

                //送信データを作成
                List<byte> sendByteList = new List<byte>();
                sendByteList.Add(id);

                //パラメータの長さを指定
                //現状ではbyteの最大値（255）を超えることはないため、1バイト目は0固定とする
                sendByteList.Add(0);
                sendByteList.Add((byte)param.Length);

                sendByteList.AddRange(param);

                // 送信
                byte[] sendByte = sendByteList.ToArray();
                client.Send(sendByte, sendByte.Length, endPoint);

                System.IO.MemoryStream memory = new System.IO.MemoryStream();

                byte[] buffBytes;

                // 受信
                // UDPではアプリが意図的に分割しない限りデータは分割されない
                buffBytes = client.Receive(ref endPoint);
                memory.Write(buffBytes, 0, buffBytes.Length);

                byte[] res = null;
                try
                {
                    res = memory.ToArray();
                    log.Debug("receive - ipAddress[" + ipAddress + "], id[" + id + "], byte[" + BitConverter.ToString(res).Replace("00", "0") + "]");
                }
                catch
                {
                    log.Debug("END - ipAddress[" + ipAddress + "], id[" + id + "]");
                }

                return res;
            }
            catch (Exception ex)
            {
                //通信失敗時
                log.Error(ex);
                log.Error(ex.InnerException);
                return null;
            }
            finally
            {
                if (stream != null)
                {
                    stream.Close();
                }

                if (client != null)
                {
                    client.Close();
                }
            }
        }

        /// <summary>
        /// 現在接続中のWireless LANのプロファイルを取得する
        /// </summary>
        /// <param name="client"></param>
        /// <returns></returns>
        public static string GetCurrentProfile(WlanClient client)
        {
            string profile = null;

            foreach (WlanClient.WlanInterface wlanInterface in client.Interfaces)
            {
                if (wlanInterface.InterfaceState == Wlan.WlanInterfaceState.Connected
                    || wlanInterface.InterfaceState == Wlan.WlanInterfaceState.Authenticating)
                {
                    profile = wlanInterface.CurrentConnection.profileName;
                    break;
                }
            }

            return profile;
        }
        #endregion
    }
}
