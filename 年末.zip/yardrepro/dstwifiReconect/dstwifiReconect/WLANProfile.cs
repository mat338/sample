﻿using System;
using System.Text;
using dstwifiReconect.dto;
using NativeWifi;
using dstwifiReconect;

namespace dstwifiReconect
{
    /// <summary>
    /// 無線LANプロファイル作成用ユーティリティクラス
    /// </summary>
    class WLANProfile
    {
        // -------------------------------------------------------------------------------
        // プロファイルXML要素関連
        // -------------------------------------------------------------------------------

        /// <summary>
        /// XMLファイルバージョン
        /// </summary>
        private const string ELEMENT_XML_VERSION = "<?xml version=\"1.0\"?>";

        /// <summary>
        /// WLANProfile（開始タグ）
        /// </summary>
        private const string ELEMENT_WLAN_PROFILE_START = "<WLANProfile xmlns=\"http://www.microsoft.com/networking/WLAN/profile/v1\">";

        /// <summary>
        /// WLANProfile（終了タグ）
        /// </summary>
        private const string ELEMENT_WLAN_PROFILE_END = "</WLANProfile>";

        /// <summary>
        /// name
        /// </summary>
        private const string ELEMENT_NAME = "name";

        /// <summary>
        /// SSIDConfig
        /// </summary>
        private const string ELEMENT_SSID_CONFIG = "SSIDConfig";

        /// <summary>
        /// SSID
        /// </summary>
        private const string ELEMENT_SSID = "SSID";

        /// <summary>
        /// nonBroadcast
        /// </summary>
        private const string ELEMENT_NON_BROADCAST = "nonBroadcast";

        /// <summary>
        /// connectionType
        /// </summary>
        private const string ELEMENT_CONNECTION_TYPE = "connectionType";

        /// <summary>
        /// connectionMode
        /// </summary>
        private const string ELEMENT_CONNECTION_MODE = "connectionMode";

        /// <summary>
        /// MSM
        /// </summary>
        private const string ELEMENT_MSM = "MSM";

        /// <summary>
        /// security
        /// </summary>
        private const string ELEMENT_SECURITY = "security";

        /// <summary>
        /// authEncryption
        /// </summary>
        private const string ELEMENT_AUTH_ENCRYPTION = "authEncryption";

        /// <summary>
        /// authentication
        /// </summary>
        private const string ELEMENT_AUTHENTICATION = "authentication";

        /// <summary>
        /// encryption
        /// </summary>
        private const string ELEMENT_ENCRYPTION = "encryption";

        /// <summary>
        /// useOneX
        /// </summary>
        private const string ELEMENT_USE_ONE_X = "useOneX";

        /// <summary>
        /// sharedKey
        /// </summary>
        private const string ELEMENT_SHARED_KEY = "sharedKey";

        /// <summary>
        /// keyType
        /// </summary>
        private const string ELEMENT_KEY_TYPE = "keyType";

        /// <summary>
        /// protected
        /// </summary>
        private const string ELEMENT_PROTECTED = "protected";

        /// <summary>
        /// keyMaterial
        /// </summary>
        private const string ELEMENT_KEY_MATERIAL = "keyMaterial";

        // -------------------------------------------------------------------------------
        // プロファイルXML設定値関連
        // -------------------------------------------------------------------------------
        
        /// <summary>
        /// フラグ共通（TRUE）
        /// </summary>
        private const string PARAM_BOOL_TRUE = "true";
        
        /// <summary>
        /// フラグ共通（FALSE）
        /// </summary>
        private const string PARAM_BOOL_FALSE = "false";

        /// <summary>
        /// connectionType = ESS（インフラストラクチャ時）
        /// </summary>
        private const string PARAM_CONNECTION_TYPE_ESS = "ESS";

        /// <summary>
        /// connectionType = IBSS（アドホック時）
        /// </summary>
        private const string PARAM_CONNECTION_TYPE_IBSS = "IBSS";

        /// <summary>
        /// connectionMode = Manual
        /// </summary>
        private const string PARAM_CONNECTION_MODE_MANUAL = "manual";

        /// <summary>
        /// authentication = Open
        /// </summary>
        private const string PARAM_AUTHENTICATION_OPEN = "open";

        /// <summary>
        /// authentication = WPAPSK
        /// </summary>
        private const string PARAM_AUTHENTICATION_WPAPSK = "WPAPSK";

        /// <summary>
        /// authentication = WPA2PSK
        /// </summary>
        private const string PARAM_AUTHENTICATION_WPA2PSK = "WPA2PSK";

        /// <summary>
        /// encryption = none
        /// </summary>
        private const string PARAM_ENCRYPTION_NONE = "none";

        /// <summary>
        /// encryption = WEP
        /// </summary>
        private const string PARAM_ENCRYPTION_WEP = "WEP";

        /// <summary>
        /// encryption = TKIP
        /// </summary>
        private const string PARAM_ENCRYPTION_TKIP = "TKIP";

        /// <summary>
        /// encryption = AES
        /// </summary>
        private const string PARAM_ENCRYPTION_AES = "AES";

        /// <summary>
        /// keyType = passPhrase
        /// </summary>
        private const string PARAM_KEY_TYPE_PASS_PHRASE = "passPhrase";

        /// <summary>
        /// keyType = networkKey
        /// </summary>
        private const string PARAM_KEY_TYPE_NETWORK_KEY = "networkKey";

        /// <summary>
        /// 無線LANプロファイルを作成する
        /// </summary>
        /// <param name="dto">DST-i情報</param>
        /// <param name="searchMode">検索モード</param>
        /// <returns>無線LANプロファイル（XML形式）</returns>
        public static string CreateWLANProfileXML(DSTiDto dto, Consts.ConnectMode searchMode, Wlan.WlanAvailableNetwork network)
        {
            
            StringBuilder xmlStrBld = new StringBuilder();

            //xml version
            xmlStrBld.Append(ELEMENT_XML_VERSION);

            //WLANProfile（開始タグ）
            xmlStrBld.Append(ELEMENT_WLAN_PROFILE_START);

            //name
            String ssid = ConnectionManagerUtil.getSsid(dto, searchMode);
            xmlStrBld.Append(createElement(ELEMENT_NAME, ssid));

            //SSIDConfig（開始タグ）
            xmlStrBld.Append(createTag(ELEMENT_SSID_CONFIG, true));
            //SSID（開始タグ）
            xmlStrBld.Append(createTag(ELEMENT_SSID, true));
            //name
            xmlStrBld.Append(createElement(ELEMENT_NAME, ssid));
            //SSID（終了タグ）
            xmlStrBld.Append(createTag(ELEMENT_SSID, false));
            //nonBroadcast
            xmlStrBld.Append(createElement(ELEMENT_NON_BROADCAST, PARAM_BOOL_FALSE));
            //SSIDConfig（終了タグ）
            xmlStrBld.Append(createTag(ELEMENT_SSID_CONFIG, false));

            //connectionType
            xmlStrBld.Append(createElement(ELEMENT_CONNECTION_TYPE, getConnectionType(dto, searchMode)));

            //connectionMode
            xmlStrBld.Append(createElement(ELEMENT_CONNECTION_MODE, PARAM_CONNECTION_MODE_MANUAL));

            //MSM（開始タグ）
            xmlStrBld.Append(createTag(ELEMENT_MSM, true));
            //security（開始タグ）
            xmlStrBld.Append(createTag(ELEMENT_SECURITY, true));
            //authEncryption（開始タグ）
            xmlStrBld.Append(createTag(ELEMENT_AUTH_ENCRYPTION, true));
            //authentication
            xmlStrBld.Append(createElement(ELEMENT_AUTHENTICATION, getAuthentication(dto, searchMode)));
            //encryption
            xmlStrBld.Append(createElement(ELEMENT_ENCRYPTION, getEncryption(dto, searchMode, network)));
            //useOneX
            xmlStrBld.Append(createElement(ELEMENT_USE_ONE_X, PARAM_BOOL_FALSE));
            //authEncryption（終了タグ）
            xmlStrBld.Append(createTag(ELEMENT_AUTH_ENCRYPTION, false));
            //認証・暗号化方式　Open-Disable以外の場合 or DST-WLの場合
            //sharedKey（開始タグ）
            xmlStrBld.Append(createTag(ELEMENT_SHARED_KEY, true));
            //keyType
            xmlStrBld.Append(createElement(ELEMENT_KEY_TYPE, getKeyType(dto, searchMode)));
            //protected（暗号化はしない）
            xmlStrBld.Append(createElement(ELEMENT_PROTECTED, PARAM_BOOL_FALSE));
            //keyMaterial
            xmlStrBld.Append(createElement(ELEMENT_KEY_MATERIAL, getKeyMaterial(dto, searchMode)));
            //sharedKey（終了タグ）
            xmlStrBld.Append(createTag(ELEMENT_SHARED_KEY, false));

            //security（終了タグ）
            xmlStrBld.Append(createTag(ELEMENT_SECURITY, false));
            //MSM（終了タグ）
            xmlStrBld.Append(createTag(ELEMENT_MSM, false));

            //WLANProfile（終了タグ）
            xmlStrBld.Append(ELEMENT_WLAN_PROFILE_END);

            return xmlStrBld.ToString();
        }

        /// <summary>
        /// 要素を作成する
        /// </summary>
        /// <param name="elementName">要素名</param>
        /// <param name="value">値</param>
        /// <returns>要素文字列</returns>
        private static string createElement(string elementName, string value)
        {
            StringBuilder strBld = new StringBuilder();

            //開始タグ
            strBld.Append(createTag(elementName, true));
            //値
            strBld.Append(value);
            //終了タグ
            strBld.Append(createTag(elementName, false));

            return strBld.ToString();
        }
     
        /// <summary>
        /// XMLのタグを作成する
        /// </summary>
        /// <param name="tagname">タグ名</param>
        /// <param name="isStart">true：開始タグ　false：終了タグ</param>
        /// <returns>タグ文字列</returns>
        private static string createTag(string tagname, Boolean isStart)
        {
            StringBuilder strBld = new StringBuilder();
            
            strBld.Append("<");

            if (!isStart)
            {
                strBld.Append("/");
            }
            
            strBld.Append(tagname);

            strBld.Append(">");

            return strBld.ToString();
        }

        /// <summary>
        /// connectionTypeを取得する
        /// </summary>
        /// <param name="dto">DST-i情報</param>
        /// <param name="searchMode">検索モード</param>
        /// <returns>connectionType</returns>
        private static string getConnectionType(DSTiDto dto, Consts.ConnectMode searchMode)
        {
            if (searchMode.Equals(Consts.ConnectMode.INFRA) || searchMode.Equals(Consts.ConnectMode.P2P))
            {
                //インフラストラクチャモードの場合
                return PARAM_CONNECTION_TYPE_ESS;
            }
            else
            {
                //アドホックモードの場合
                return PARAM_CONNECTION_TYPE_IBSS;
            }
        }

        /// <summary>
        /// authenticationを取得する
        /// </summary>
        /// <param name="dto">DST-i情報</param>
        /// <param name="searchMode">検索モード</param>
        /// <returns>authentication</returns>
        private static string getAuthentication(DSTiDto dto, Consts.ConnectMode searchMode)
        {
            //認証・暗号化方式の取得
            int encMethod = getEncMethod(dto, searchMode);

            switch (encMethod)
            {
                case Consts.AUTHENTICATION_WL_WPA_PSK_TKIP:
                case Consts.AUTHENTICATION_WL_WPA_PSK_AES:
                    return PARAM_AUTHENTICATION_WPAPSK;

                case Consts.AUTHENTICATION_WL_WPA2_PSK_AES:
                    return PARAM_AUTHENTICATION_WPA2PSK;

                default:
                    return PARAM_AUTHENTICATION_OPEN;
            }
        }

        /// <summary>
        /// encryptionを取得する
        /// </summary>
        /// <param name="dto">DST-i情報</param>
        /// <param name="searchMode">検索モード</param>
        /// <param name="network">無線LAN設定</param>
        /// <returns>encryption</returns>
        private static string getEncryption(DSTiDto dto, Consts.ConnectMode searchMode, Wlan.WlanAvailableNetwork network)
        {
            //認証・暗号化方式の取得
            int encMethod = getEncMethod(dto, searchMode);
            switch (encMethod)
            {
                case Consts.AUTHENTICATION_WL_WPA_PSK_TKIP:
                    return PARAM_ENCRYPTION_TKIP;

                case Consts.AUTHENTICATION_WL_WPA_PSK_AES:
                case Consts.AUTHENTICATION_WL_WPA2_PSK_AES:
                    switch (searchMode)
                    {
                        case Consts.ConnectMode.P2P:
                            return PARAM_ENCRYPTION_AES;
                        default:
                            return getEncyptionAuto(network);
                    }
                default:
                    return PARAM_ENCRYPTION_NONE;
            }
        }

        /// <summary>
        /// encryptionを無線LAN設定から取得する
        /// </summary>
        /// <param name="network">無線LAN設定</param>
        /// <returns>encryption</returns>
        private static string getEncyptionAuto(Wlan.WlanAvailableNetwork network)
        {
            switch (network.dot11DefaultCipherAlgorithm)
            {
                case Wlan.Dot11CipherAlgorithm.TKIP:
                    return PARAM_ENCRYPTION_TKIP;
                default:
                    return PARAM_ENCRYPTION_AES;
            }
        }


        /// <summary>
        /// 認証・暗号化方式の取得
        /// </summary>
        /// <param name="dto">DST-i情報</param>
        /// <param name="searchMode">検索モード</param>
        /// <returns>認証・暗号化方式</returns>
        private static int getEncMethod(DSTiDto dto, Consts.ConnectMode searchMode)
        {
            //認証・暗号化方式の取得
            if (searchMode.Equals(Consts.ConnectMode.INFRA))
            {
                //インフラストラクチャモードの場合
                return dto.infraEncMethod;
            }
            else
            {
                return dto.p2pEncMethod;
            }
        }

        /// <summary>
        /// keyTypeの取得(WEPはnetworkKeyを返す)
        /// </summary>
        /// <param name="dto">DST-i情報</param>
        /// <param name="searchMode">検索モード</param>
        /// <returns>keyType</returns>
        private static string getKeyType(DSTiDto dto, Consts.ConnectMode searchMode)
        {
            //認証・暗号化方式の取得
            int encMethod = getEncMethod(dto, searchMode);

            switch (encMethod)
            {
                case Consts.AUTHENTICATION_WL_WPA_PSK_TKIP:
                case Consts.AUTHENTICATION_WL_WPA_PSK_AES:
                case Consts.AUTHENTICATION_WL_WPA2_PSK_AES:
                    if (getKeyMaterial(dto, searchMode).Length < 64)
                    {
                        //63文字以下の場合はpassPhrase
                        return PARAM_KEY_TYPE_PASS_PHRASE;
                    }
                    else
                    {
                        //64文字の場合はハッシュ化済みの文字列とみなしてnetworkKeyを指定
                        return PARAM_KEY_TYPE_NETWORK_KEY;
                    }

                default:
                    return PARAM_KEY_TYPE_NETWORK_KEY;
            }

        }

        /// <summary>
        /// keyMaterialを取得する
        /// </summary>
        /// <param name="dto">DST-i情報</param>
        /// <param name="searchMode">検索モード</param>
        /// <returns>keyMaterial</returns>
        private static string getKeyMaterial(DSTiDto dto, Consts.ConnectMode searchMode)
        {
            //認証・暗号化方式の取得
            if (searchMode.Equals(Consts.ConnectMode.INFRA))
            {
                //インフラストラクチャモードの場合
                return dto.infraKey;
            }
            else if (searchMode.Equals(Consts.ConnectMode.P2P))
            {
                //P2Pモードの場合
                return dto.p2pKey;
            }
            else
            {
                //アドホックモードの場合
                return dto.adhocKey;
            }
        }

    }
}
