﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using dstwifiReconect.dto;
using System.Threading;
using NativeWifi;
using NLog;
using System.IO;
using System.Collections.Generic;

namespace dstwifiReconect
{
    public partial class Form1 : Form
    {
        private static readonly Logger log = LogManager.GetCurrentClassLogger();

        /// <summary>
        /// 検索モード
        /// </summary>
        private Consts.ConnectMode searchMode;

        /// <summary>
        /// 通常使用するDST-iのシリアルNo.
        /// </summary>
        private String defaultSerialNo = null;

        /// <summary>
        /// 接続中のDST-i表示アイテム
        /// </summary>
        private DSTiItem connectedItem;

        /// <summary>
        /// PING確認：なし
        /// </summary>
        private const int SEND_PING_COUNT_NONE = 0;

        /// <summary>
        /// PING確認：1回
        /// </summary>
        private const int SEND_PING_COUNT_ONCE = 1;

        private CancellationTokenSource cancel = new CancellationTokenSource();

        public Form1()
        {
            InitializeComponent();

            // ログ出力先動的変更
            NLog.Targets.FileTarget target = (NLog.Targets.FileTarget)LogManager.Configuration.FindTargetByName("dstwifiReconect");
            Console.SetOut(new MultiTextWriter(new ControlWriter(textBox1), Console.Out));

        }

        private void button1_Click(object sender, EventArgs e)
        {

            button1.Enabled = false;
            DSTiDto dto5F999001 = new DSTiDto();
            DSTiDto dto5F999002 = new DSTiDto();
            WlanClient client = new WlanClient();

            log.Debug("Start test");

            log.Debug("Start Set dto");
            //setDtoDSTWL00025(dto5F999001);
            //setDtoDSTWL00024(dto5F999002);
            setDto5F999001(dto5F999001);
            setDto5F999002(dto5F999002);
            log.Debug("Finish Set dto");

            List<DSTiDto> connectList = new List<DSTiDto>();

            connectList.Add(dto5F999001);
            connectList.Add(dto5F999002);

            try
            {
                for (int cnt = 0; cnt < 10; cnt++)
                {
                    foreach (DSTiDto dtoTarget in connectList)
                    {
                        DateTime startTime = DateTime.Now;
                        bool profileExists = false;
                        Console.WriteLine("接続開始時間:" + startTime.ToString("HH時mm分ss秒"));
                        Console.WriteLine("Start Connect:" + dtoTarget.infraSsid);
                        log.Debug("Start 5F999001 Connect");
                        bool result1 =
                            ConnectionManagerUtil.WiFiConnect(dtoTarget, dtoTarget.connectMode, client, out profileExists);

                        String myIp = "";

                        log.Debug("Start self IpAdress");

                        while (String.IsNullOrEmpty(myIp))
                        {
                            myIp = ConnectionManagerUtil.getIpAddress(client, dtoTarget.infraSsid);
                            cancel.Token.WaitHandle.WaitOne(500);
                            Application.DoEvents();
                            if (cancel.IsCancellationRequested) return;
                        }
                        Console.WriteLine("MyPC IP Address:" + myIp);
                        log.Debug("End self IpAdress");

                        log.Debug("Start WifiConnectInfo");

                        int dot = myIp.LastIndexOf(".");
                        String tempIp = myIp.Substring(0, dot);
                        StringBuilder ipSb = new StringBuilder();
                        ipSb.Append(tempIp);
                        ipSb.Append(".1");

                        DSTiDto dto = null;
                        while (dto == null)
                        {
                            dto = GetWiFiConnectInfo(ipSb.ToString(), Consts.CommunicationMode.UDP);
                            if (dto == null) cancel.Token.WaitHandle.WaitOne(1000);
                            Application.DoEvents();
                            if (cancel.IsCancellationRequested) return;
                        }

                        Console.WriteLine(dto.ToString());

                        log.Debug("End WifiConnectInfo");
                        DateTime endTime = DateTime.Now;
                        Console.WriteLine("接続終了時間:" + endTime.ToString("HH時mm分ss秒"));
                        Console.WriteLine("処理時間:" + (endTime - startTime).TotalSeconds + "秒");
                        Console.WriteLine("");
                        if (cancel.IsCancellationRequested) return;
                    }
                
                }

            }
            catch (Exception ee)
            {
                log.Debug(ee.Message);
                Console.WriteLine(ee.Message);
            }
            button1.Enabled = true;
        }
        
        private void setDtoDSTWL00025(DSTiDto dto)
        {
            dto.connectMode = Consts.ConnectMode.INFRA;
            dto.defaultConnect = false;
            dto.dhcp = Consts.DHCP_ENABLE;
            //dto.infraIpAddress = "";
            dto.infraSsid = "DSTWL00025";
            dto.infraEncMethod = Consts.AUTHENTICATION_WL_WPA_PSK_TKIP;
            dto.infraKey = "f3150f3150";
        }

        private void setDtoDSTWL00024(DSTiDto dto)
        {
            dto.connectMode = Consts.ConnectMode.INFRA;
            dto.defaultConnect = false;
            dto.dhcp = Consts.DHCP_ENABLE;
            //dto.infraIpAddress = "";
            dto.infraSsid = "P2PPort58675";
            dto.infraEncMethod = Consts.AUTHENTICATION_WPA2_PSK_AES;
            dto.infraKey = "f3150f3150";
        }

        private void setDto5F999001(DSTiDto dto)
        {
            dto.connectMode = Consts.ConnectMode.INFRA;
            dto.defaultConnect = false;
            dto.dhcp = Consts.DHCP_ENABLE;
            //dto.infraIpAddress = "";
            dto.infraSsid = "AP-5F999001";
            dto.infraEncMethod = Consts.AUTHENTICATION_WPA2_PSK_AES;
            dto.infraKey = "5F999001";
        }

        private void setDto5F999002(DSTiDto dto)
        {
            dto.connectMode = Consts.ConnectMode.INFRA;
            dto.defaultConnect = false;
            dto.dhcp = Consts.DHCP_ENABLE;
            //dto.infraIpAddress = "";
            dto.infraSsid = "AP-5F999002";
            dto.infraEncMethod = Consts.AUTHENTICATION_WPA2_PSK_AES;
            dto.infraKey = "5F999002";
        }

        /// <summary>
        /// WiFi接続情報取得
        /// </summary>
        /// <remarks>
        /// 取得できなかった場合はnullを返す。
        /// </remarks>
        /// <param name="ipAddress">IPアドレス</param>
        /// <returns>取得したDST-i情報</returns>
        private DSTiDto GetWiFiConnectInfo(string ipAddress, Consts.CommunicationMode commMode, byte[] reply = null, int? retryCount = null)
        {
            byte[] response = null;

            if (reply == null)
            {
                if (null == retryCount)
                {
                    //ソケット通信を実行し、DST-iから情報を取得する
                    response = ConnectionManagerUtil.SendSocket(ipAddress, Consts.SOCKET_ID_GET_CONNECTION_DATA, commMode);
                }
                else if (0 == retryCount)
                {
                    //PING確認を1回行い、ソケット通信を実行し、DST-iから情報を取得する
                    response = ConnectionManagerUtil.SendSocket(ipAddress, Consts.SOCKET_ID_GET_CONNECTION_DATA, "", commMode, SEND_PING_COUNT_ONCE);
                }
                else
                {
                    //PING確認を行わず、ソケット通信を実行し、DST-iから情報を取得する
                    response = ConnectionManagerUtil.SendSocket(ipAddress, Consts.SOCKET_ID_GET_CONNECTION_DATA, "", commMode, SEND_PING_COUNT_NONE);
                }

                if (response == null)
                {
                    return null;
                }
            }
            else if (!ConnectionManagerUtil.IsSocketSuccess(reply))
            {
                //replyが7byte未満で来てしまう場合がある(例:3,0,0)
                return null;
            }
            else
            {
                response = reply;
            }

            DSTiDto dstiDto = ConnectionManagerUtil.getDSTiDTO(response);

            if (dstiDto.serialNo == GetDefaultSerialNo())
            {
                dstiDto.defaultConnect = true;
            }
            dstiDto.ipAddress = ipAddress;
            dstiDto.connectMode = this.searchMode;
            dstiDto.communicationMode = commMode;

            if (dstiDto.hostName == Environment.MachineName && connectedItem == null && dstiDto.connection == 0)
            {
                //未接続状態 かつ 自PC名が登録ホスト名として登録されている場合、削除する
                ConnectionManagerUtil.UpdateHostname(ipAddress, Consts.COMMAND_DELETE_HOSTNAME, commMode);
                dstiDto.hostName = "";

                if (dstiDto.serialNo != GetDefaultSerialNo())
                {
                    //通常使用に設定されていない場合、接続情報を削除する
                    Microsoft.Win32.RegistryKey regKey
                        = Microsoft.Win32.Registry.CurrentUser.CreateSubKey(DSTiCommon.CommonConst.DSTI_ROOT_REGKEY);

                    //IPアドレス削除
                    ConnectionManagerUtil.ClearTargetIpAddress();

                    //接続方法削除
                    ConnectionManagerUtil.SetRegValue(regKey, Consts.REGNAME_AGENT_WIFI_MODE, "");

                    //シリアルNo.削除
                    ConnectionManagerUtil.SetTargetSerialNo("");

                    //SSID削除
                    ConnectionManagerUtil.SetRegValue(regKey, Consts.REGNAME_AGENT_SSID, "");

                    //WIFI優先削除
                    ConnectionManagerUtil.SetRegValue(regKey, Consts.REGNAME_AGENT_PRIORITY, Consts.PRIORITY_USB);
                }
            }

            log.Debug(dstiDto);

            return dstiDto;
        }

        /// <summary>
        /// 通常使用するDST-iのシリアルNo.を返す
        /// </summary>
        /// <returns>通常使用するDST-iのシリアルNo.</returns>
        private string GetDefaultSerialNo()
        {
            if (this.defaultSerialNo == null)
            {
                this.defaultSerialNo = ConnectionManagerUtil.GetRegValue(Consts.REGNAME_DEFAULT_SERIAL_NO);
            }
            return this.defaultSerialNo;
        }


        public class ControlWriter : TextWriter
        {
            private TextBox textbox;
            public ControlWriter(TextBox textbox)
            {
                this.textbox = textbox;
            }

            public override void Write(char value)
            {
                textbox.AppendText("" + value);
            }

            public override void Write(string value)
            {
                textbox.AppendText(value);
            }

            public override Encoding Encoding
            {
                get { return Encoding.ASCII; }
            }
        }
        public class MultiTextWriter : TextWriter
        {
            private IEnumerable<TextWriter> writers;
            public MultiTextWriter(IEnumerable<TextWriter> writers)
            {
                this.writers = writers.ToList();
            }
            public MultiTextWriter(params TextWriter[] writers)
            {
                this.writers = writers;
            }

            public override void Write(char value)
            {
                foreach (var writer in writers)
                    writer.Write(value);
            }

            public override void Write(string value)
            {
                foreach (var writer in writers)
                    writer.Write(value);
            }

            public override void Flush()
            {
                foreach (var writer in writers)
                    writer.Flush();
            }

            public override void Close()
            {
                foreach (var writer in writers)
                    writer.Close();
            }

            public override Encoding Encoding
            {
                get { return Encoding.ASCII; }
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            cancel.Cancel();
        }

    
    }

}
