﻿using System.Xml.Serialization;

namespace dstwifiReconect.dto
{
    [XmlRoot("root")]
    public class DefinitionDto
    {
        public DefinitionDetailDto detail { get; set; }
    }
}
