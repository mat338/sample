﻿using System.Xml.Serialization;

namespace dstwifiReconect.dto
{
    /// <summary>
    /// 文言データ
    /// </summary>
    [XmlRoot("root")]
    public class LanguageDto
    {
        /// <summary>
        /// コネクションマネージャ画面
        /// </summary>
        public LanguageConnectionManagerDTO connectionManager { get; set; }

        /// <summary>
        /// ダッシュボード画面
        /// </summary>
        public LanguageDashboardDTO dashboard { get; set; }

        /// <summary>
        /// 共通メッセージ
        /// </summary>
        public LanguageMessage message { get; set; }

        /// <summary>
        /// モード切替失敗用メッセージ
        /// </summary>
        public SwitchErrorMessage switchErrorMessage { get; set; }

        /// <summary>
        /// コネクションマネージャの説明文(HTML)
        /// </summary>
        public string connectionManagerDescription { get; set; }
    }

    /// <summary>
    /// コネクションマネージャ画面用文言データ
    /// </summary>
    public class LanguageConnectionManagerDTO
    {
        /// <summary>
        /// フォームタイトル
        /// </summary>
        public string title { get; set; }

        /// <summary>
        /// 説明文
        /// </summary>
        public string description { get; set; }

        /// <summary>
        /// シリアルNo.表示用プレフィックス
        /// </summary>
        public string serialNoPrefix { get; set; }

        /// <summary>
        /// DST-i一覧タイトル
        /// </summary>
        public string listTitle { get; set; }

        /// <summary>
        /// ボタン表示名
        /// </summary>
        public LanguageConnectionManagerButtonDTO button { get; set; }

        /// <summary>
        /// 接続状態表示名
        /// </summary>
        public LanguageConnectionManagerConnectStatusDTO connectStatus { get; set; }
    }

    /// <summary>
    /// コネクションマネージャ - ボタン表示名
    /// </summary>
    public class LanguageConnectionManagerButtonDTO
    {
        /// <summary>
        /// 通常使用に設定する
        /// </summary>
        public string setDefault { get; set; }

        /// <summary>
        /// 通常使用を解除する
        /// </summary>
        public string deleteDefault { get; set; }

        /// <summary>
        /// 識別確認
        /// </summary>
        public string identify { get; set; }

        /// <summary>
        /// 閉じる
        /// </summary>
        public string close { get; set; }

        /// <summary>
        /// スキャン
        /// </summary>
        public string scan { get; set; }

        /// <summary>
        /// 接続
        /// </summary>
        public string connect { get; set; }
    }

    /// <summary>
    /// コネクションマネージャ - 接続状態表示名
    /// </summary>
    public class LanguageConnectionManagerConnectStatusDTO
    {
        /// <summary>
        /// 接続可
        /// </summary>
        public string connectable { get; set; }

        /// <summary>
        /// 接続不可
        /// </summary>
        public string unconnectable { get; set; }
    }

    /// <summary>
    /// ダッシュボード画面用文言データ
    /// </summary>
    public class LanguageDashboardDTO
    {
        /// <summary>
        /// フォームタイトル
        /// </summary>
        public string title { get; set; }

        /// <summary>
        /// SSID表示用プレフィックス
        /// </summary>
        public string ssidPrefix { get; set; }

        /// <summary>
        /// シリアルNo.表示用プレフィックス
        /// </summary>
        public string serialNoPrefix { get; set; }

        /// <summary>
        /// 接続モード：インフラ
        /// </summary>
        public string infra { get; set; }

        /// <summary>
        /// 接続モード：アドホック
        /// </summary>
        public string adhoc { get; set; }
    }

    /// <summary>
    /// メッセージ用文言データ
    /// </summary>
    public class LanguageMessage
    {
        /// <summary>
        /// 検出中
        /// </summary>
        public string searchingDSTi { get; set; }

        /// <summary>
        /// WLAN AutoConfig未起動エラー
        /// </summary>
        public string noWLanAutoConfigError { get; set; }

        /// <summary>
        /// 無線インターフェースなしエラー
        /// </summary>
        public string noWLanInterfaceError { get; set; }

        /// <summary>
        /// 接続エラー
        /// </summary>
        public string connectionError { get; set; }

        /// <summary>
        /// 使用中エラー
        /// </summary>
        public string inUseError { get; set; }

        /// <summary>
        /// 接続待ちメッセージ
        /// </summary>
        public string waitConnecting { get; set; }

        /// <summary>
        /// ダッシュボードタイムアウト切断メッセージ
        /// </summary>
        public string timeoutDisconnect { get; set; }

        /// <summary>
        /// システムエラーメッセージ
        /// </summary>
        public string systemError { get; set; }

        /// <summary>
        /// デフォルト言語定義を使用する場合のメッセージ
        /// </summary>
        public string useDefaultLanguage { get; set; }
    }

    /// <summary>
    /// ダッシュボードメッセージ
    /// </summary>
    public class SwitchErrorMessage
    {
        /// <summary>
        /// モード切替失敗共通メッセージ
        /// </summary>
        public string common { get; set; }

        /// <summary>
        /// 接続モード切替失敗
        /// </summary>
        public string changeConnectModeError { get; set; }

        /// <summary>
        /// 接続失敗（プロファイル使用）
        /// </summary>
        public string connectErrorWithProfile { get; set; }

        /// <summary>
        /// 接続失敗（プロファイル不使用）
        /// </summary>
        public string connectErrorWithWifiInfo { get; set; }

        /// <summary>
        /// 接続タイムアウト
        /// </summary>
        public string connectTimeout { get; set; }

        /// <summary>
        /// 動的IPアドレスが見つけられない場合
        /// </summary>
        public string dhcpIpAddressNotFoundError { get; set; }

        /// <summary>
        /// 接続エラー
        /// </summary>
        public string connectError { get; set; }

        /// <summary>
        /// 他ユーザ使用中
        /// </summary>
        public string inUseError { get; set; }
    }
}
