﻿
namespace dstwifiReconect.dto
{
    /// <summary>
    /// DST-iの情報を保持する
    /// </summary>
    public class DSTiDto
    {
        /// <summary>
        /// 接続モード
        /// </summary>
        public Consts.ConnectMode connectMode { get; set; }

        /// <summary>
        /// 通常接続するデバイスか
        /// </summary>
        public bool defaultConnect { get; set; }

        /// <summary>
        /// シリアルNo.
        /// </summary>
        public string serialNo { get; set; }

        /// <summary>
        /// IPアドレス
        /// </summary>
        public string ipAddress { get; set; }

        /// <summary>
        /// ポート番号
        /// </summary>
        public int port { get; set; }

        /// <summary>
        /// 電波強度
        /// </summary>
        public int signalStrength { get; set; }

        /// <summary>
        /// 使用中ホスト名
        /// </summary>
        public string hostName { get; set; }

        /// <summary>
        /// 接続フラグ
        /// </summary>
        public int connection { get; set; }

        /// <summary>
        /// 言語
        /// </summary>
        public string language { get; set; }

        // -------------------------------------------------------------------------------
        // インフラストラクチャモードの設定
        // -------------------------------------------------------------------------------

        /// <summary>
        /// インフラストラクチャ時のIPアドレス
        /// </summary>
        public string infraIpAddress { get; set; }
        
        /// <summary>
        /// インフラストラクチャ時の認証・暗号化方式
        /// </summary>
        public int infraEncMethod { get; set; }

        /// <summary>
        /// インフラストラクチャ時の接続先ルータSSID
        /// </summary>
        public string infraSsid { get; set; }

        /// <summary>
        /// インフラストラクチャ時の暗号化キー
        /// </summary>
        public string infraKey { get; set; }

        /// <summary>
        /// DHCP有効/無効
        /// </summary>
        public int dhcp { get; set; }

        // -------------------------------------------------------------------------------
        // アドホックモードの設定
        // -------------------------------------------------------------------------------

        /// <summary>
        /// アドホック時のIPアドレス
        /// </summary>
        public string adhocIpAddress { get; set; }

        /// <summary>
        /// アドホック時の認証・暗号化方式
        /// </summary>
        public int adhocEncMethod { get; set; }

        /// <summary>
        /// アドホック時のSSID
        /// </summary>
        public string adhocSsid { get; set; }

        /// <summary>
        /// アドホック時の暗号化キー
        /// </summary>
        public string adhocKey { get; set; }

        /// <summary>
        /// 色情報
        /// </summary>
        public byte[] color { get; set; }

        public override string ToString()
        {
            return "connectMode["+ connectMode + "]"
                + ", defaultConnect[" + defaultConnect + "]"
                + ", serialNo[" + serialNo + "]"
                + ", ipAddress[" + ipAddress + "]"
                + ", port[" + port + "]"
                + ", signalStrength[" + signalStrength + "]"
                + ", hostName[" + hostName + "]"
                + ", infraIpAddress[" + infraIpAddress + "]"
                + ", infraEncMethod[" + infraEncMethod + "]"
                + ", infraSsid[" + infraSsid + "]"
                + ", infraKey[" + ToAsterisk(infraKey) + "]"
                + ", infraDHCP[" + dhcp + "]"
                + ", adhocIpAddress[" + adhocIpAddress + "]"
                + ", adhocEncMethod[" + adhocEncMethod + "]"
                + ", adhocSsid[" + adhocSsid + "]"
                + ", adhocKey[" + ToAsterisk(adhocKey) + "]"
                + ", color[" + color[0] + ":" + color[1] + ":" + color[2] + "]";
        }

        /// <summary>
        /// 文字列を同じ長さの*に変換して返す
        /// </summary>
        /// <param name="str">変換対象</param>
        /// <returns>変換後文字列</returns>
        private string ToAsterisk(string str)
        {
            string outStr = "";
            if (!string.IsNullOrEmpty(str))
            {
                for (int i = 0; i < str.Length; i++)
                {
                    outStr += "*";
                }
            }
            return outStr;
        }

        // -------------------------------------------------------------------------------
        // ピアツーピアの設定
        // -------------------------------------------------------------------------------

        /// <summary>
        /// ピアツーピア時のIPアドレス
        /// </summary>
        public string p2pIpAddress { get; set; }

        /// <summary>
        /// ピアツーピア時の認証・暗号化方式
        /// </summary>
        public int p2pEncMethod { get; set; }

        /// <summary>
        /// ピアツーピア時の接続先ルータSSID
        /// </summary>
        public string p2pSsid { get; set; }

        /// <summary>
        /// ピアツーピア時の暗号化キー
        /// </summary>
        public string p2pKey { get; set; }

        /// <summary>
        /// DHCP有効/無効
        /// </summary>
        public int p2pDhcp { get; set; }

        /// <summary>
        /// チャンネルID
        /// </summary>
        public int p2pChannel { get; set; }

        // -------------------------------------------------------------------------------
        // 独自設定
        // -------------------------------------------------------------------------------
        /// <summary>
        /// 取得通信方式
        /// </summary>
        public Consts.CommunicationMode communicationMode { get; set; }
    }
}
