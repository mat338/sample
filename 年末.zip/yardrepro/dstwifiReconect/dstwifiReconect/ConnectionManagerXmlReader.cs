﻿using System;
using System.Xml.Serialization;

using dstwifiReconect.dto;

using DSTiCommon;

namespace dstwifiReconect
{
    /// <summary>
    /// XMLファイル取得用ユーティリティクラス
    /// </summary>
    class ConnectionManagerXmlReader : CommonXmlReader
    {
        /// <summary>
        /// 定義ファイル
        /// </summary>
        private const string APP_DEF_PATH = "connectionmanager.def";

        /// <summary>
        /// XML取得パラメータ
        /// </summary>
        private static byte[] xmlParam = { 0x44, 0x45, 0x4e, 0x53, 0x4f, 0x5f, 0x44, 0x53, 0x54, 0x2d, 0x69, 0x41, 0x67, 0x65, 0x6e, 0x74 };

        /// <summary>
        /// XmlAttributeOverrides取得メソッド
        /// </summary>
        /// <param name="elementName">detailを取得するエレメントを指定</param>
        /// <returns>XmlAttributeOverrides</returns>
        private static XmlAttributeOverrides GetXmlAttributeOverrides(string elementName)
        {
            XmlAttributes attrs = new XmlAttributes();
            XmlElementAttribute attr = new XmlElementAttribute();
            attr.ElementName = elementName;
            attr.Type = typeof(DefinitionDetailDto);
            attrs.XmlElements.Add(attr);
            XmlAttributeOverrides attrOverrides = new XmlAttributeOverrides();
            attrOverrides.Add(typeof(DefinitionDto), "detail", attrs);
            return attrOverrides;
        }

        /// <summary>
        /// 定義ファイル取得
        /// </summary>
        /// <returns>定義ファイルオブジェクト</returns>
        public static DefinitionDetailDto GetDefinitionDetailDto(string ship = CommonConst.DEFAULT_MARKET)
        {
            return GetDefinitionDetailDto(false, ship);
        }

        /// <summary>
        /// 定義ファイル取得
        /// </summary>
        /// <returns>定義ファイルオブジェクト</returns>
        public static DefinitionDetailDto GetDefinitionDetailDto(bool decrypt = false, string ship = CommonConst.DEFAULT_MARKET)
        {
            if (decrypt)
            {
                string param = System.Text.Encoding.UTF8.GetString(xmlParam, 0, xmlParam.Length);

                XmlAttributeOverrides attrOverridesDef = GetXmlAttributeOverrides("default");
                XmlSerializer xsDef = new XmlSerializer(typeof(DefinitionDto), attrOverridesDef);
                XmlAttributeOverrides attrOverridesShip = GetXmlAttributeOverrides(ship);
                XmlSerializer xsShip = new XmlSerializer(typeof(DefinitionDto), attrOverridesShip);

                DefinitionDto def = DecryptDeserializeDefinition(xsDef, APP_DEF_PATH, param) as DefinitionDto;
                DefinitionDto shipment = DecryptDeserializeDefinition(xsShip, APP_DEF_PATH, param) as DefinitionDto;

                // デフォルトを取得
                return DtoUtil.MergeDto(def.detail, shipment.detail, typeof(DefinitionDetailDto)) as DefinitionDetailDto;
            }
            else
            {
                XmlAttributeOverrides attrOverridesDef = GetXmlAttributeOverrides("default");
                XmlSerializer xsDef = new XmlSerializer(typeof(DefinitionDto), attrOverridesDef);
                DefinitionDto def = DeserializeDefinition(xsDef, APP_DEF_PATH) as DefinitionDto;

                DefinitionDetailDto shipDetail = null;
                if (!string.IsNullOrEmpty(ship))
                {
                    XmlAttributeOverrides attrOverridesShip = GetXmlAttributeOverrides(ship);
                    XmlSerializer xsShip = new XmlSerializer(typeof(DefinitionDto), attrOverridesShip);
                    DefinitionDto shipment = DeserializeDefinition(xsShip, APP_DEF_PATH) as DefinitionDto;
                    shipDetail = shipment.detail;
                }

                // デフォルトを取得
                return DtoUtil.MergeDto(def.detail, shipDetail, typeof(DefinitionDetailDto)) as DefinitionDetailDto;
            }
        }

        /// <summary>
        /// 言語ファイル取得
        /// </summary>
        /// <param name="language">ファイル名</param>
        /// <param name="decrypt">復号有無 true:復号実施 false:平文取得</param>
        /// <returns></returns>
        public static LanguageDto GetLanguageDef(String language, bool decrypt = false)
        {
            XmlSerializer xs = new XmlSerializer(typeof(LanguageDto));

            try
            {
                LanguageDto ret;
                if (decrypt)
                {
                    ret = GetDecryptedLanguageXml(xs, language,
                        System.Text.Encoding.UTF8.GetString(xmlParam, 0, xmlParam.Length)) as LanguageDto;
                }
                else
                {
                    ret = getLanguageXml(xs, language) as LanguageDto;
                }

                return ret;
            }
            catch (Exception e1)
            {

                throw e1;
            }
        }
    }
}
