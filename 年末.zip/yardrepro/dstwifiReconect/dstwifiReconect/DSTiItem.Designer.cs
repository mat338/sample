﻿namespace dstwifiReconect
{
    partial class DSTiItem
    {
        /// <summary> 
        /// 必要なデザイナー変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region コンポーネント デザイナーで生成されたコード

        /// <summary> 
        /// デザイナー サポートに必要なメソッドです。このメソッドの内容を 
        /// コード エディターで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.lblStatus = new System.Windows.Forms.Label();
            this.lblColor = new System.Windows.Forms.Label();
            this.lblSerialNo = new System.Windows.Forms.Label();
            this.pbDefaultConnect = new System.Windows.Forms.PictureBox();
            this.pbConnectMode = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbDefaultConnect)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbConnectMode)).BeginInit();
            this.SuspendLayout();
            // 
            // lblStatus
            // 
            this.lblStatus.AutoEllipsis = true;
            this.lblStatus.Location = new System.Drawing.Point(51, 4);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(290, 12);
            this.lblStatus.TabIndex = 2;
            this.lblStatus.Text = "(Status)";
            // 
            // lblColor
            // 
            this.lblColor.AutoSize = true;
            this.lblColor.Location = new System.Drawing.Point(297, 40);
            this.lblColor.Name = "lblColor";
            this.lblColor.Size = new System.Drawing.Size(45, 12);
            this.lblColor.TabIndex = 3;
            this.lblColor.Text = "          ";
            // 
            // lblSerialNo
            // 
            this.lblSerialNo.AutoSize = true;
            this.lblSerialNo.Font = new System.Drawing.Font(this.Font.FontFamily, 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblSerialNo.Location = new System.Drawing.Point(89, 18);
            this.lblSerialNo.Name = "lblSerialNo";
            this.lblSerialNo.Size = new System.Drawing.Size(118, 24);
            this.lblSerialNo.TabIndex = 0;
            this.lblSerialNo.Text = "(Serial No.)";
            // 
            // pbDefaultConnect
            // 
            //this.pbDefaultConnect.Image = global::dstwifiReconect.Properties.Resources.defaultConnect;
            this.pbDefaultConnect.Location = new System.Drawing.Point(61, 20);
            this.pbDefaultConnect.Name = "pbDefaultConnect";
            this.pbDefaultConnect.Size = new System.Drawing.Size(21, 21);
            this.pbDefaultConnect.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbDefaultConnect.TabIndex = 8;
            this.pbDefaultConnect.TabStop = false;
            // 
            // pbConnectMode
            // 
            //this.pbConnectMode.Image = global::dstwifiReconect.Properties.Resources.adhoc;
            this.pbConnectMode.Location = new System.Drawing.Point(9, 11);
            this.pbConnectMode.Name = "pbConnectMode";
            this.pbConnectMode.Size = new System.Drawing.Size(35, 37);
            this.pbConnectMode.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbConnectMode.TabIndex = 6;
            this.pbConnectMode.TabStop = false;
            // 
            // DSTiItem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Controls.Add(this.pbDefaultConnect);
            this.Controls.Add(this.lblSerialNo);
            this.Controls.Add(this.lblColor);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.pbConnectMode);
            this.Cursor = System.Windows.Forms.Cursors.Default;
            this.Name = "DSTiItem";
            this.Size = new System.Drawing.Size(350, 60);
            ((System.ComponentModel.ISupportInitialize)(this.pbDefaultConnect)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbConnectMode)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.Label lblColor;
        private System.Windows.Forms.Label lblSerialNo;
        private System.Windows.Forms.PictureBox pbConnectMode;
        private System.Windows.Forms.PictureBox pbDefaultConnect;
    }
}
