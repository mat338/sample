# coding:utf-8
import sys
import logging
from flask import Flask, jsonify
from flask.globals import request

# # Logger
# Logger Instance
logger = logging.getLogger()
for handler in logger.handlers:
    logger.removeHandler(handler)

# Log Level
logger.setLevel(logging.INFO)

# Console Log
stream_handler = logging.StreamHandler(sys.stdout)
logger.addHandler(stream_handler)

# File Log
file_handler = logging.FileHandler(filename='./CommunicationCheckRestApi.log', mode='a')
logger.addHandler(file_handler)

# Log Format
formatter = logging.Formatter('%(asctime)s - %(module)s.%(lineno)d [Thread-%(thread)d][%(levelname)s]: %(message)s')
stream_handler.setFormatter(formatter)
file_handler.setFormatter(formatter)

# API
api = Flask(__name__)


# #
# - Post API
#
@api.route('/api/communication/post', methods=['POST'])
def post_api_tgd():
    logger.info('Received a request post.')

    return post_api_core()


# #
# - Get API
#
@api.route('/api/communication/get', methods=['GET'])
def post_api_gts():
    logger.info('Received a request get.')

    return post_api_core()


# #
# - Post API Core
#
def post_api_core():
    return jsonify({ 'check OK':'200' }), 200


# #
# - Main
#
if __name__ == '__main__':
    api.run(host='0.0.0.0', port=80)
