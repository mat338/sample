/*
 * Copyright 2011-2019 GatlingCorp (https://gatling.io)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *  http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package rdc

import io.gatling.core.Predef._
import io.gatling.http.Predef._
import scala.concurrent.duration._

class Rdc_PerformanceTest_obs1 extends Simulation {

  ///////////////////////
  // httpの定義
  ///////////////////////
  val httpProtocol = http
    // API GatewayのURL
    .baseUrl("http://nlb-rihds-int-inspection-env-948470a48b461399.elb.ap-southeast-1.amazonaws.com/api/converter/v1") // Here is the root for all relative URLs
    .acceptHeader("text/html,application/xhtml+xml,application/xml,application/json;q=0.9,*/*;q=0.8") // Here are the common headers
    .doNotTrackHeader("1")
    .acceptLanguageHeader("ja,en-US;q=0.9,en;q=0.8")
    .acceptEncodingHeader("gzip, deflate, br")
    .userAgentHeader("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/75.0.3770.80 Safari/537.36")

  ///////////////////////
  // 各URLの定義
  ///////////////////////
  val health_check = scenario("Health Check") // A scenario is a chain of requests and pauses
    .exec(http("healthcheck")
      .get("/healthcheck")
      .check(status is 200))
      .pause(5)

  val bcan = scenario("Bcan DTC") // A scenario is a chain of requests and pauses
    .exec(http("bcanDTC")
      .post("/bcanDTC")
      .headers(Map(HttpHeaderNames.ContentType -> "application/json; charset=UTF-8"))
      .body(RawFileBody("BCANDTC_Input_1.json"))
      .check(status is 200))
      .pause(5)

  val fcan = scenario("Fcan DTC") // A scenario is a chain of requests and pauses
    .exec(http("fcanDTC")
      .post("/fcanDTC")
      .headers(Map(HttpHeaderNames.ContentType -> "application/json; charset=UTF-8"))
      .body(RawFileBody("FCANDTC_Input_1.json"))
      .check(status is 200))
      .pause(5)

  val ffd = scenario("FFD") // A scenario is a chain of requests and pauses
    .exec(http("ffd")
      .post("/ffd")
      .headers(Map(HttpHeaderNames.ContentType -> "application/json; charset=UTF-8"))
      .body(RawFileBody("Input_FFD_CANFI.json"))
      .check(status is 200))
      .pause(5)

  val snp = scenario("SNP") // A scenario is a chain of requests and pauses
    .exec(http("snp")
      .post("/snp")
      .headers(Map(HttpHeaderNames.ContentType -> "application/json; charset=UTF-8"))
      .body(RawFileBody("Input_SNP_CANFI.json"))
      .check(status is 200))
      .pause(5)

  val obs = scenario("OBS") // A scenario is a chain of requests and pauses
    .exec(http("obs")
      .post("/obs")
      .headers(Map(HttpHeaderNames.ContentType -> "application/json; charset=UTF-8"))
      .body(RawFileBody("OBS_Input_1.json"))
      .check(status is 200))
      .pause(5)


  ///////////////////////
  // 負荷テスト実行
  ///////////////////////
  /*
    // 負荷パターンの仕様
    setUp(
      scn.inject(
        nothingFor(4 seconds), // 1
        atOnceUsers(10), // 2
        rampUsers(10) during (5 seconds), // 3
        constantUsersPerSec(20) during (15 seconds), // 4
        constantUsersPerSec(20) during (15 seconds) randomized, // 5
        rampUsersPerSec(10) to 20 during (10 minutes), // 6
        rampUsersPerSec(10) to 20 during (10 minutes) randomized, // 7
        heavisideUsers(1000) during (20 seconds) // 8
      ).protocols(httpProtocol)
    )

     1.nothingFor(duration): Pause for a given duration.
     2.atOnceUsers(nbUsers): Injects a given number of users at once.
     3.rampUsers(nbUsers) during(duration): Injects a given number of users with a linear ramp over a given duration.
     4.constantUsersPerSec(rate) during(duration): Injects users at a constant rate, defined in users per second, during a given duration. Users will be injected at regular intervals.
     5.constantUsersPerSec(rate) during(duration) randomized: Injects users at a constant rate, defined in users per second, during a given duration. Users will be injected at randomized intervals.
     6.rampUsersPerSec(rate1) to (rate2) during(duration): Injects users from starting rate to target rate, defined in users per second, during a given duration. Users will be injected at regular intervals.
     7.rampUsersPerSec(rate1) to(rate2) during(duration) randomized: Injects users from starting rate to target rate, defined in users per second, during a given duration. Users will be injected at randomized intervals.
     8.heavisideUsers(nbUsers) during(duration): Injects a given number of users following a smooth approximation of the heaviside step function stretched to a given duration.
   */

/*
  // １時間に2520リクエストを送信
  setUp(
    bcan.inject(
      rampUsers(2520) during (60 minutes)
    )
    .protocols(httpProtocol)
  )
*/

  // OBSを0.15/sec固定で5分間リクエストを送信
  setUp(
    obs.inject(constantUsersPerSec(0.15) during(5 minutes))
    )
    .protocols(httpProtocol)

/*
  // BCAN,FCANをそれぞれ0.7/sec固定で5分間リクエストを送信
  setUp(
    bcan.inject(constantUsersPerSec(0.7) during(5 minutes)),
    fcan.inject(constantUsersPerSec(0.7) during(5 minutes))
    )
    .protocols(httpProtocol)
*/
/*
  // 180秒かけて10/sec～100/secに負荷を増やしながらリクエストを送信
  setUp(
    bcan.inject(
      rampUsersPerSec(10) to (100) during (180 seconds)
    )
    .protocols(httpProtocol)
  )
*/

/*
  // 40秒かけて10/sec～50/secに負荷を増やしながらリクエストを送信
  // その後、50/secのリクエストを30秒キープ
  setUp(
    bcan.inject(
      rampUsersPerSec(10) to (50) during (40 seconds),
      constantUsersPerSec(50) during(30 seconds)
    )
    .protocols(httpProtocol)
  )
*/

/*
  // 10分間に6000回リクエストを送信
  val rampInjections = Seq(
    rampUsers(6000) during (10 minutes)
  )

  // 各URLに対して10分間に6000回リクエストを送信 - 並列送信（6000/10min × 5(bcan、fcan、ffd、snp、obs) = 30000リクエスト/10min）
  setUp(
    bcan.inject(rampInjections),
    fcan.inject(rampInjections),
    ffd.inject(rampInjections),
    snp.inject(rampInjections),
    obs.inject(rampInjections)
    )
    .protocols(httpProtocol)
*/




}
