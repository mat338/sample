﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using NLog;
using System.Collections;
using System.Threading;
using YardRepro.dto;
using System.Threading.Tasks;
using System.IO;
using System.Text;

namespace YardRepro
{
    /// <summary>
    /// DSTステータスリストユーザコントロールクラス
    /// </summary>
    public partial class DSTStatusList : UserControl
    {

        /// <summary>
        /// ログ出力クラス
        /// </summary>
        private static readonly Logger log = LogManager.GetCurrentClassLogger();

        /// <summary>
        /// 定期リフレッシュ停止フラグ
        /// </summary>
        public bool isStop { get; set; }

        /// <summary>
        /// トライアルフラグ
        /// </summary>
        public bool isTrial { get; set; }

        /// <summary>
        /// iniファイル定義タイムアウト値
        /// </summary>
        public int iniTimeout { get; set; }

        /// <summary>
        /// iniファイル定義ログファイル保存先
        /// </summary>
        public string iniSaveFolder { get; set; }

        /// <summary>
        /// WlanClient
        /// </summary>
        private WLANClient client = null;

        /// <summary>
        /// タスクリスト
        /// </summary>
        private List<StatusTask> tasks;

        /// <summary>
        /// タスクファクトリ
        /// </summary>
        private TaskFactory factory;

        /// <summary>
        /// DSTステータスリストデータ
        /// </summary>
        public DSTDtoList list
        {
            get { return dsTiListWPF1.DstiList; }
            set { dsTiListWPF1.DstiList = value; }
        }

        /// <summary>
        /// リスト更新イベント
        /// </summary>
        public event EventHandler OnRefreshList;

        /// <summary>
        /// コンストラクタ
        /// </summary>
        /// ### 機能説明 #######
        /// -# 画面コンポーネントの初期処理
        /// -# DSTステータスリストコントロールのリトライ押下イベントにリトライ押下イベントメソッドを追加
        /// -# DSTステータスリストコントロールのDTC消去押下イベントにDTC消去押下イベントメソッドを追加
        /// -# ステータスタスクリストを初期化
        /// -# タスクファクトリを初期化
        public DSTStatusList()
        {
            InitializeComponent();
            dsTiListWPF1.RetryClick += new EventHandler(dsTiListWPF1_RetryClick);
            dsTiListWPF1.DtcExecClick += new EventHandler(dsTiListWPF1_DtcExecClick);

            tasks = new List<StatusTask>();
            factory = new TaskFactory();
        }

        /// <summary>
        /// 初期処理
        /// </summary>
        /// <returns>エラー情報</returns>
        /// ### 機能説明 #######
        /// -# WLANClientのLAN AutoConfigサービス起動チェックがFalseの場合
        ///     -# エラーメッセージを表示
        ///         項目         | 設定値
        ///         -------------| -------------
        ///         メッセージ   | WLAN AutoConfigが起動されていません。\n設定を確認して再度実行してください。
        ///         ウィンドウ名 | ヤードリプロ
        ///         ボタン       | OKのみ
        ///         アイコン     | エラーアイコン
        ///         
        ///     -# Falseを返却
        /// -# WLANClientを生成
        /// -# WLANClientのWiFiモジュール有無をチェックがFalseの場合
        ///     -# エラーメッセージを表示
        ///         項目         | 設定値
        ///         -------------| -------------
        ///         メッセージ   | ワイヤレスLANが使用できません。\n設定確認して再度実行してください。
        ///         ウィンドウ名 | ヤードリプロ
        ///         ボタン       | OKのみ
        ///         アイコン     | エラーアイコン
        ///         
        ///     -# Falseを返却
        /// -# Trueを返却
        public bool init()
        {
            // LAN AutoConfigサービスが起動している
            if (!WLANClient.IsWLanAutoConfigAlive())
            {
                // エラーメッセージを表示
                MessageBox.Show(Consts.MESSAGE_ERROR_WLAN_SERVICE,
                                this.Text,
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
                return false;
            }

            // WLANClientを生成
            client = new WLANClient();

            // WiFiモジュール有無をチェック
            if (!client.IsWLanInterfaces())
            {
                // エラーメッセージを表示
                MessageBox.Show(Consts.MESSAGE_ERROR_WLAN_NOT,
                               this.Text,
                               MessageBoxButtons.OK,
                               MessageBoxIcon.Error);
                return false;
            }
            return true;
        }

        /// <summary>
        /// DSTDTOリストを全て設定する。
        /// </summary>
        /// <param name="souceList">選択画面で選択したDST情報リスト</param>
        /// ### 機能説明 #######
        /// -# 現在表示しているDSTリストのIP削除
        ///     -# 差替え済みではないIPの場合
        ///         -# 現在表示しているDSTリストのIPが選択画面で選択が外された場合はDSTリストから削除
        /// -# 現在表示しているDSTリストのIP追加
        ///     -# 現在表示しているDSTリストにないIPが選択画面で選択された場合はDSTリストに追加
        public void addAll(DSTDtoList souceList)
        {
            List<string> ipList = list.Select(d => d.ipAddress).ToList();
            //List<string> chkDTCList = new List<string>();
            foreach (string ipaddress in ipList)
            {
                // DTCチェック済みの状態を保持
                //if (list.Cast<DSTDto>().Any(d => d.ipAddress.Equals(ipaddress) && d.isDtcDeleteChecked))
                //{
                //    chkDTCList.Add(ipaddress);
                //}

                // 差替え済みの表示情報は削除対象外
                if (list.Cast<DSTDto>().Any(d => d.ipAddress.Equals(ipaddress) && d.status != DSTDto.StatusMode.Replaced))
                {
                    // 現在表示しているDSTリストのIPが選択画面で選択が外された場合はDSTリストから削除
                    if (!souceList.Cast<DSTDto>().Any(d => d.ipAddress.Equals(ipaddress) && d.isSelected))
                    {
                        // 対象IPのリストを削除
                        delete(ipaddress);
                    }
                }
            }
            // 選択されたDSTを追加する。
            foreach (DSTDto dto in souceList)
            {
                // DTCチェック済みの状態を反映
                //if (chkDTCList.Any(d => d.Equals(dto.ipAddress)))
                //{
                //    dto.isDtcDeleteChecked = true;
                //}

                // 現在表示しているDSTリストにないIPが選択画面で選択された場合はDSTリストに追加
                if (!list.Cast<DSTDto>().Any(d => d.ipAddress.Equals(dto.ipAddress) && d.status != DSTDto.StatusMode.Replaced))
                {
                    // 現表示リストに無い選択IPを追加
                    add(dto);
                }
            }
        }

        /// <summary>
        /// DSTステータスリストに追加する。（デリゲートメソッド)
        /// </summary>
        /// <param name="dto">追加対象のDST情報</param>
        delegate void DelegateAdd(DSTDto dto);

        /// <summary>
        /// DSTステータスリストに追加する。
        /// </summary>
        /// <param name="dto">追加対象のDST情報</param>
        /// -# 追加対象のDST情報.ソート順に「1：リプロ中＋リプロ開始時刻」
        /// -# DST接続ステータスリストデータに引数.追加対象のDST情報を追加
        /// -# DST接続ステータスリストデータをシリアルNo昇順にソート
        /// -# リスト更新イベントを発生させる
        /// -# リスト表示を更新
        private void add(DSTDto dto)
        {
            // ソート順設定（1：リプロ中＋リプロ開始時刻）
            dto.sortNo = Consts.REPRO_EXEC + DateTime.Now.ToString("yyyyMMddHHmmssfff");
            log.Debug(string.Format("ソート順:{0}", dto.sortNo));
            // リストに追加
            list.Add(dto);
            // リストをシリアルNo昇順にソート
            ArrayList.Adapter(list).Sort(new DSTListSorter());
            // ステータス更新スレッド開始
            if (!isTrial) taskStart(dto);
            // リスト更新イベントを発生させる
            if (OnRefreshList != null) OnRefreshList(this, EventArgs.Empty);
            // リスト表示を更新
            ItemsRefresh();
        }

        /// <summary>
        /// DSTステータスリストから削除する（デリゲートメソッド）。
        /// </summary>
        /// <param name="ipAddress">削除対象のIPアドレス</param>
        delegate void DelegateDelete(string ipAddress);

        /// <summary>
        /// DSTステータスリストから削除する。
        /// </summary>
        /// <param name="ipAddress">削除対象のIPアドレス</param>
        /// ### 機能説明 #######
        /// -# DSTステータスリスト内の引数と同じIPのDST情報を取得
        /// -# DST情報が取得出来た場合
        ///     -# リストから削除
        ///     -# リスト更新イベントを発生させる
        ///     -# リスト表示を更新
        private void delete(string ipAddress)
        {
            // DSTiリスト中の同じIPのデータを取得
            DSTDto targetDto = (DSTDto)list.Select(d => d).Where(d => d.ipAddress == ipAddress).FirstOrDefault();
            // 取得できた場合
            if (targetDto != null)
            {
                // ステータス更新スレッド停止
                if (!isTrial) taskStop(targetDto);
                // リストから削除
                list.Remove(targetDto);
                // リスト更新イベントを発生させる
                if (OnRefreshList != null) OnRefreshList(this, EventArgs.Empty);
                // リスト表示を更新
                ItemsRefresh();
            }
        }

        /// <summary>
        /// リトライボタンクリックイベント
        /// </summary>
        /// <param name="sender">発生元オブジェクト</param>
        /// <param name="e">イベント引数</param>
        /// ### 機能説明 #######
        /// -# リスト表示を更新
        private void dsTiListWPF1_RetryClick(object sender, EventArgs e)
        {
            ItemsRefresh();
        }

        /// <summary>
        /// DTC実行ボタンクリックイベント
        /// </summary>
        /// <param name="sender">発生元オブジェクト</param>
        /// <param name="e">イベント引数</param>
        /// ### 機能説明 #######
        /// -# リスト表示を更新
        private void dsTiListWPF1_DtcExecClick(object sender, EventArgs e)
        {
            ItemsRefresh();
        }

        /// <summary>
        /// DSTステータスリストコントロールのビューを再作成（デリゲートメソッド）
        /// </summary>
        delegate void DelegateItemsRefresh();

        /// <summary>
        /// DSTステータスリストコントロールのビューを再作成
        /// </summary>
        /// ### 機能説明 #######
        /// -# DSTステータスリストコントロールのビューを再作成
        private void dItemsRefresh()
        {
            dsTiListWPF1.listBox1.Items.Refresh();
        }
        /// <summary>
        /// DSTステータスリストコントロールのビューを再作成
        /// </summary>
        /// ### 機能説明 #######
        /// -# DST接続リストコントロールのビューを再作成をデリゲート実行
        public void ItemsRefresh()
        {
            Invoke((DelegateItemsRefresh)dItemsRefresh);
        }

        #region "更新スレッド"
        /// <summary>
        /// 更新スレッドタスククラス
        /// </summary>
        private class StatusTask
        {
            /// <summary>
            /// DST情報
            /// </summary>
            public DSTDto dstdto { get; set; }

            /// <summary>
            /// スレッドタスク
            /// </summary>
            public Task task { get; set; }

            /// <summary>
            /// スレッドキャンセルオブジェクト
            /// </summary>
            public CancellationTokenSource cancel { get; set; }
        }


        /// <summary>
        /// スレッドを作成し、更新処理を実行
        /// </summary>
        /// <param name="dto">DST情報</param>
        /// ### 機能説明 #######
        /// -# キャンセルオブジェクトのインスタンス生成
        /// -# タスクを生成し実行
        ///     -# 更新スレッド処理呼び出し
        /// -# 更新スレッドタスククラスのインスタンス生成
        ///         項目            | 設定値
        ///         ----------------| -------------
        ///         DST情報         | 引数.DST情報
        ///         スレッドタスク  | 生成したタスク
        ///         キャンセル      | 生成したキャンセルオブジェクト
        /// 
        /// -# 更新スレッドタスクリストに更新スレッドタスクインスタンスを追加
        private void taskStart(DSTDto dto)
        {
            CancellationTokenSource cts = new CancellationTokenSource();
            StatusTask statusTask = new StatusTask();
            statusTask.dstdto = dto;
            statusTask.cancel = cts;
            Task t = factory.StartNew(obj =>
            {
                this.dtoUpdateStatus((StatusTask)obj);
            }, statusTask, cts.Token);
            statusTask.task = t;
            tasks.Add(statusTask);
        }

        /// <summary>
        /// 指定されたDST情報のスレッドを停止する。
        /// </summary>
        /// <param name="dto">DST情報</param>
        /// ### 機能説明 #######
        /// -# 更新スレッドタスクリストの中から引数.DST情報と同じインスタンスを持っている更新スレッドタスクを取得
        /// -# 更新スレッドタスクのキャンセルオブジェクトのキャンセルを呼ぶ
        /// -# タスクが完了するまで待機
        private void taskStop(DSTDto dto)
        {
            StatusTask task = (StatusTask)tasks.Where(d => d.dstdto.Equals(dto)).FirstOrDefault();
            task.cancel.Cancel();
            task.task.Wait(3000);
        }

        /// <summary>
        /// 全てのスレッドを停止させる。
        /// </summary>
        /// ### 機能説明 #######
        /// -# タスクリストを新規作成
        /// -# 更新スレッドタスクリスト分ループ
        ///     -# 更新スレッドタスクのキャンセルオブジェクトのキャンセルを呼ぶ
        ///     -# タスクリストに更新スレッドタスクのタスクを追加
        /// -# タスクリストのタスクが全て完了するまで待機
        public void taskAllStop()
        {
            List<Task> tasklist = new List<Task>();
            foreach (StatusTask task in tasks)
            {
                task.cancel.Cancel();
                tasklist.Add(task.task);
            }
            Task.WaitAll(tasklist.ToArray(), 3000);
        }

        /// <summary>
        /// 更新スレッド処理
        /// </summary>
        /// <param name="task">更新スレッドタスクインスタンス</param>
        /// ### 機能説明 #######
        /// -# 接続エラー回数を初期化
        /// -# 更新スレッドタスクのキャンセルオブジェクトがキャンセルされるまでループ
        ///     -# 更新スレッドタスク.DST情報.ステータスがエラー以外の場合
        ///     	-# VIN取得処理の呼び出し（更新スレッドタスク）
        ///             -# VINが取得済みかつ前回取得時とは別のVINナンバーの場合
        ///                 -# Wifi接続情報の取得
        ///                 -# 差替え前の情報更新
        ///                     項目                | 設定値
        ///                     --------------------| -------------
        ///                     ステータス          | 差替え済み状態
        ///                     ソート順            | 0：リプロ終了＋リプロ開始時刻
        ///                     活性・非活性フラグ  | False
        ///                 -# 差替え後の情報生成
        ///                     項目                                    | 設定値
        ///                     ----------------------------------------| -------------
        ///                     ステータス                              | アイドル状態
        ///                     電波強度                                | 引数.WIFI接続情報応答データ.電波強度
        ///                     色情報                                  | 引数.WIFI接続情報応答データ.色情報
        ///                     シリアルNo                              | 引数.WIFI接続情報応答データ.シリアルNo
        ///                     ホスト名                                | 引数.WIFI接続情報応答データ.ホスト名
        ///                     IPアドレス                              | 引数.IPアドレス
        ///                     進捗情報                                | 0
        ///                     プログレスバーの色                      | 緑
        ///                     活性・非活性フラグ                      | True
        ///                     選択フラグ                              | False
        ///                     リトライ可能フラグ                      | False
        ///                     DTCステータス                           | DTC未実施
        ///                     VinNo取得済みフラグ                     | False
        ///                     リプロ前ソフトウェア品番取得済みフラグ  | False
        ///                     リプロ後ソフトウェア品番取得済みフラグ  | False
        ///                     DTC消去操作可能フラグ                   | False
        ///                     DTC消去実行チェックフラグ               | False
        ///                     ソート順                                | 1：リプロ実行中＋リプロ開始時刻
        ///                     VIN                                     | VIN取得処理で取得したVIN
        ///                 -# 差替え後のスレッド生成
        ///                 -# 差替え前のスレッド終了
        ///                 
        ///     	-# 更新スレッドタスク.DST情報.リプロ前ソフト品番取得済みフラグが未取得の場合
        ///             -# リプロ前ソフト品番取得処理の呼び出し（更新スレッドタスク）
        ///                 
        ///         -# ステータス取得APIの呼び出し（更新スレッドタスク.DST情報.IPアドレス）
        ///         -# 接続エラー回数を0回に設定
        ///         -# 更新スレッドタスク.DST情報.ステータスがアイドル中またはリプロ実施中、通信切断の場合
        ///             -# 処理結果が正常の場合
        ///                 -# 更新中状態にDST情報を更新する。(ステータス取得API結果.リプロ処理の進捗率)
        ///                     項目                | 設定値
        ///                     --------------------| -------------
        ///                     ステータス          | 更新中状態
        ///                     進捗情報            | ステータス取得API結果.リプロ処理の進捗率
        ///                     メッセージ          | ステータス取得API結果.リプロ処理の進捗率 + "%"
        ///                     活性・非活性フラグ  | True
        ///                     リトライ可能フラグ  | False
        ///                     プログレスバーの色  | 緑
        ///                 
        ///                 -# ステータス取得API結果.リプロ処理の進捗率が100の場合
        ///                     -# リプロ完了状態にDST情報を更新する。
        ///                         項目                  | 設定値
        ///                         ----------------------| -------------
        ///                         ステータス            | 成功状態
        ///                         メッセージ            | 100%
        ///                         リトライ可能フラグ    | False
        ///                         DTC消去操作可能フラグ | True
        ///                 
        ///     	        -# 更新スレッドタスク.DST情報.リプロ後ソフト品番取得済みフラグが未取得かつ更新スレッドタスク.DST情報.ステータスが成功の場合
        ///                     -# リプロ後ソフト品番取得処理の呼び出し（更新スレッドタスク）
        ///                         
        ///             -# 処理結果が正常以外の場合
        ///                 -# エラー状態にDST情報を更新する。(ステータス取得API結果.処理結果)
        ///                      項目                | 設定値
        ///                     --------------------| -------------
        ///                     ステータス          | エラー状態
        ///                     メッセージ          | 下記表の通り
        ///                     リトライ可能フラグ  | 下記表の通り
        ///                     活性・非活性フラグ  | True
        ///         
        ///             -# エラーコードによってリトライ可能フラグとメッセージを設定する
        ///                     エラーコード        | リトライ可能フラグ |メッセージ
        ///                     --------------------| -------------------|--------------
        ///                     1                   | False              |VIN読出し不可
        ///                     2                   | False              |ソフト品番読出し不可
        ///                     3                   | False              |読み出したソフト品番から引きあたるリプロデータがDST-WiFi内に存在しない
        ///                     4                   | True               |リプロ書換え中のエラー
        ///                     5                   | True               |リプロ後のベリファイ時のエラー
        ///                     6                   | True               |バッテリ電圧が11.8V未満
        ///                     8                   | False              |読み出したソフト品番がリプロ後のソフト品番と同一
        ///                     上記以外            | False              |定義されないエラー
        ///         
        ///         -# 更新スレッドタスク.DST情報.DTCステータスがDTC実行中の場合
        ///             -# 後処理開始処理の呼び出し（更新スレッドタスク）
        ///         
        ///         -# 更新スレッドタスク.DST情報.DTCステータスがログファイル取得中の場合
        ///             -# ログファイル取得処理の呼び出し（更新スレッドタスク）
        ///         
        ///         -# API呼び出しで例外が発生した場合
        ///             -# 接続エラー回数をインクリメント
        ///             -# 接続エラー回数が３回以上で更新スレッドタスクのキャンセルオブジェクトがキャンセルされてない場合
        ///                 -# 切断状態にDST情報を更新する。
        ///                     項目                | 設定値
        ///                     --------------------| -------------
        ///                     ステータス          | 未接続状態
        ///                     進捗情報            | 100
        ///                     メッセージ          | 切断されました
        ///                     活性・非活性フラグ  | False
        ///                     リトライ可能フラグ  | False
        ///                     プログレスバーの色  | 赤
        ///                 
        ///                 -# 更新スレッドタスク.DST情報.DTCステータスがDTC実行中の場合
        ///                     -# DTC実行エラー状態にDST情報.DTCステータスを更新する。
        ///                         項目                  | 設定値
        ///                         ----------------------| -------------
        ///                         DTCステータス         | DTC実行エラー状態
        ///                         DTC消去操作可能フラグ | True
        ///                         DTCメッセージ         | DTC実行エラー
        ///                 
        ///                 -# 更新スレッドタスク.DST情報.DTCステータスがログファイル取得中の場合
        ///                     -# ログファイル取得エラー状態にDST情報.DTCステータスを更新する。
        ///                         項目                  | 設定値
        ///                         ----------------------| -------------
        ///                         DTCステータス         | DTC実行エラー状態
        ///                         DTC消去操作可能フラグ | False
        ///                         DTCメッセージ         | DTC実行エラー
        ///                 
        ///     -# 更新スレッドタスクのキャンセルオブジェクトがキャンセルされてない場合
        ///         -# DSTステータスリストコントロールのビューを再作成
        ///         -# 更新スレッドタスク.キャンセルオブジェクトのスリープ処理を呼ぶ(3000ミリ秒)
        private void dtoUpdateStatus(StatusTask task)
        {
            log.Debug(string.Format("start dtoUpdateStatus:SerialNo:{0}", task.dstdto.serialNo));
            // 接続エラー回数初期化
            int connectErrorCount = 0;
            while (!task.cancel.IsCancellationRequested)
            {
                try
                {
                    // VIN情報取得
                    // VINを取得することで通信の切断確認とツールの車両差替えが行われたかを判断する
                    string vinNo = getVIN(task);
                    // 接続エラー回数をリセット
                    connectErrorCount = 0;
                    // 取得したvinNoが空の場合は実行結果がエラー
                    if (!string.IsNullOrEmpty(vinNo))
                    {
                        // VINが取得済みかつ前回取得時とは別のVINナンバーの場合はツールの差替え有りと判断する
                        if (!string.IsNullOrEmpty(task.dstdto.vinNo) && task.dstdto.vinNo != vinNo)
                        {
                            // Wifi接続情報取得
                            DSTUtil.WifiConnect wifiConnectInfo = DSTUtil.SendSocketUDPWifiConnectInfo(task.dstdto.ipAddress);
                            if (DSTUtil.ByteToInt(wifiConnectInfo.result) == 0)
                            {
                                // ソート順再設定（0：リプロ終了＋リプロ開始時刻）
                                task.dstdto.sortNo = Consts.REPRO_REPLACED + task.dstdto.sortNo.Substring(1);
                                task.dstdto.isEnabled = false;
                                // リプロツール差替え済みに更新する
                                DSTDtoUtil.updateDtcReplaced(task.dstdto);

                                // 差替え後の情報を初期化
                                DSTDto dto = DSTDtoUtil.createDstiDto(task.dstdto.ipAddress, wifiConnectInfo);
                                dto.vinNo = vinNo;
                                // ソート順設定（1：リプロ中＋リプロ開始時刻）
                                dto.sortNo = Consts.REPRO_EXEC + DateTime.Now.ToString("yyyyMMddHHmmssfff");
                                Invoke((DelegateAdd)add, dto);

                                // 差替え前のスレッドは終了する
                                break;
                            }
                        }
                        else
                        {
                            task.dstdto.vinNo = vinNo;
                        }
                    }

                    // ステータスがエラー以外の場合、ステータス取得処理を行う
                    if (task.dstdto.status != DSTDto.StatusMode.Error)
                    {
                        // リプロ前ソフト品番未取得の場合（リプロが実施されるまでは再取得）
                        if (!task.dstdto.getSoftNoBefore && task.dstdto.status == DSTDto.StatusMode.Idle)
                        {
                            getSoftNoBefore(task);
                        }

                        // ステータスがアイドル中またはリプロ実施中、通信切断の場合は処理を行う
                        if (task.dstdto.status == DSTDto.StatusMode.Idle || task.dstdto.status == DSTDto.StatusMode.Exec
                            || task.dstdto.status == DSTDto.StatusMode.Notconnect)
                        {
                            // ステータス取得
                            DSTUtil.StatusInfo status = DSTUtil.SendSocketUDPStatusInfo(task.dstdto.ipAddress);
                            int result = DSTUtil.ByteToInt(status.result);
                            if (result == 0)
                            {
                                int progress = DSTUtil.ByteToInt(status.progress);
                                // リストを実行中で更新
                                DSTDtoUtil.updateExec(task.dstdto, progress);

                                // リプロ完了
                                if (progress == 100)
                                {
                                    // リストを完了で更新
                                    DSTDtoUtil.updateSuccess(task.dstdto);
                                }

                                // リプロ完了かつリプロ後ソフト品番未取得の場合
                                if (!task.dstdto.getSoftNoAfter && task.dstdto.status == DSTDto.StatusMode.Success)
                                {
                                    getSoftNoAfter(task);
                                }
                            }
                            else
                            {
                                // ステータスエラー
                                DSTDtoUtil.updateError(task.dstdto, result.ToString());
                            }
                        }

                        // DTC実行中の場合
                        if (task.dstdto.statusDtc == DSTDto.StatusModeDTC.DtcExec)
                        {
                            execDTC(task);
                        }

                        // ログファイル取得中の場合
                        if (task.dstdto.statusDtc == DSTDto.StatusModeDTC.DtcExecLog)
                        {
                            getLogFile(task);
                        }
                    }
                }
                catch (Exception)
                {
                    // 接続エラー回数をインクリメント
                    connectErrorCount++;
                    log.Debug(string.Format("ConnectErrorCount:{0}", connectErrorCount));

                    if (!task.cancel.IsCancellationRequested && (connectErrorCount >= 3))
                    {
                        // 通信切断で更新
                        DSTDtoUtil.updateNotConnect(task.dstdto);

                        // DTC実行中の場合
                        if (task.dstdto.statusDtc == DSTDto.StatusModeDTC.DtcExec)
                        {
                            // DTC実行エラーで更新
                            DSTDtoUtil.updateDtcError(task.dstdto);
                        }

                        // ログファイル取得中の場合
                        if (task.dstdto.statusDtc == DSTDto.StatusModeDTC.DtcExecLog)
                        {
                            // ログファイル取得エラーで更新
                            DSTDtoUtil.updateDtcErrorLog(task.dstdto);
                        }
                    }
                }

                // キャンセルされてない場合
                if (!task.cancel.IsCancellationRequested)
                {
                    // リスト更新
                    ItemsRefresh();
                    // スリープ
                    task.cancel.Token.WaitHandle.WaitOne(Consts.STATUS_REFRESH_TIME);
                }
            }
            log.Debug(string.Format("stop dtoUpdateStatus:SerialNo:{0}", task.dstdto.serialNo));
        }

        /// <summary>
        /// VIN取得処理
        /// </summary>
        /// <param name="task">更新スレッドタスクインスタンス</param>
        /// ### 機能説明 #######
        /// -# VIN取得APIを呼び出し（更新スレッドタスク.DST情報.IPアドレス）
        /// -# 処理結果が正常の場合
        ///     -# 更新スレッドタスク.DST情報.VinNoにVIN取得API.VinNoを設定
        ///         項目                | 設定値
        ///         --------------------| -------------
        ///         VinNo               | VIN取得API.VinNo
        ///         
        ///     -# 更新スレッドタスク.DST情報.VinNo取得済みフラグを取得済みに設定
        ///         項目                | 設定値
        ///         --------------------| -------------
        ///         VinNo取得済みフラグ | True
        private string getVIN(StatusTask task)
        {
            // VIN取得（ECUからVINを読み出す前に本機能を実施した場合はエラーが返る。）
            DSTUtil.VinInfo vininfo = DSTUtil.SendSocketUDPVinInfo(task.dstdto.ipAddress);
            if (DSTUtil.ByteToInt(vininfo.result) == 0)
            {
                return DSTUtil.ByteToString(vininfo.vin);
            }
            return "";
        }

        /// <summary>
        /// リプロ前ソフト品番取得処理
        /// </summary>
        /// <param name="task">更新スレッドタスクインスタンス</param>
        /// ### 機能説明 #######
        /// -# ソフト品番取得APIを呼び出し（更新スレッドタスク.DST情報.IPアドレス）
        /// -# 処理結果が正常の場合
        ///     -# リプロ前ソフト品番リストを生成
        ///     -# ソフト品番取得API.ソフト品番の数分ループ
        ///         -# リプロ前ソフト品番リストにソフト品番取得API.ソフト品番を追加
        ///     -# 更新スレッドタスク.DST情報.リプロ前ソフト品番リストにソフト品番リストを設定
        ///         項目                             | 設定値
        ///         ---------------------------------| -------------
        ///         リプロ前ソフト品番リスト         | 生成したソフト品番リスト
        ///         
        ///     -# 更新スレッドタスク.DST情報.リプロ前ソフト品番取得済みフラグを取得済みに設定
        ///         項目                             | 設定値
        ///         ---------------------------------| -------------
        ///         リプロ前ソフト品番取得済みフラグ | True
        private void getSoftNoBefore(StatusTask task)
        {
            DSTUtil.SoftNoInfo softnoinfoBefore = DSTUtil.SendSocketUDPSoftNoInfo(task.dstdto.ipAddress);
            if (DSTUtil.ByteToInt(softnoinfoBefore.result) == 0)
            {
                List<string> softNoListBefore = new List<string>();
                for (int i = 0; i < DSTUtil.ByteToInt(softnoinfoBefore.numOfId); i++)
                {
                    softNoListBefore.Add(DSTUtil.ByteToString(softnoinfoBefore.softnoList[i].Softno));
                }
                task.dstdto.softNoBefore = softNoListBefore;
                task.dstdto.getSoftNoBefore = true;
            }
        }

        /// <summary>
        /// リプロ後ソフト品番取得処理
        /// </summary>
        /// <param name="task">更新スレッドタスクインスタンス</param>
        /// ### 機能説明 #######
        /// -# ソフト品番取得APIを呼び出し（更新スレッドタスク.DST情報.IPアドレス）
        /// -# 処理結果が正常の場合
        ///     -# リプロ後ソフト品番リストを生成
        ///     -# ソフト品番取得API.ソフト品番の数分ループ
        ///         -# リプロ後ソフト品番リストにソフト品番取得API.ソフト品番を追加
        ///     -# 更新スレッドタスク.DST情報.リプロ後ソフト品番リストにソフト品番リストを設定
        ///         項目                             | 設定値
        ///         ---------------------------------| -------------
        ///         リプロ後ソフト品番リスト         | 生成したソフト品番リスト
        ///         
        ///     -# 更新スレッドタスク.DST情報.リプロ後ソフト品番取得済みフラグを取得済みに設定
        ///         項目                             | 設定値
        ///         ---------------------------------| -------------
        ///         リプロ後ソフト品番取得済みフラグ | True
        private void getSoftNoAfter(StatusTask task)
        {
            DSTUtil.SoftNoInfo softnoinfoAfter = DSTUtil.SendSocketUDPSoftNoInfo(task.dstdto.ipAddress);
            if (DSTUtil.ByteToInt(softnoinfoAfter.result) == 0)
            {
                List<string> softNoListAfter = new List<string>();
                for (int i = 0; i < DSTUtil.ByteToInt(softnoinfoAfter.numOfId); i++)
                {
                    softNoListAfter.Add(DSTUtil.ByteToString(softnoinfoAfter.softnoList[i].Softno));
                }
                task.dstdto.softNoAfter = softNoListAfter;
            }
            task.dstdto.getSoftNoAfter = true;
        }

        /// <summary>
        /// 後処理開始処理
        /// </summary>
        /// <param name="task">更新スレッドタスクインスタンス</param>
        /// ### 機能説明 #######
        /// -# 後処理開始APIを呼び出し（更新スレッドタスク.DST情報.IPアドレス）
        /// -# 処理結果がエラーの場合
        ///     -# エラーメッセージを表示（DTC消去要求に失敗しました。\nDSTのLEDが全点灯しているか確認してください。）
        ///     -# DTC実行エラー状態にDTC情報を更新する。
        ///         項目                  | 設定値
        ///         ----------------------| -------------
        ///         DTCステータス         | DTC実行エラー状態
        ///         DTC消去操作可能フラグ | True
        ///         DTCメッセージ         | DTC実行エラー
        ///         
        ///     -# ログファイル取得中状態にDTC情報を更新する。
        ///         項目                  | 設定値
        ///         ----------------------| -------------
        ///         DTCステータス         | ログファイル取得中状態
        ///         DTC消去操作可能フラグ | False
        ///         DTCメッセージ         | ログ取得中
        private void execDTC(StatusTask task)
        {
            try
            {
                // DTC消去要求を送信
                DSTUtil.DtcExec dtcExec = DSTUtil.SendSocketUDPDtcExec(task.dstdto.ipAddress, iniTimeout);
                // 実行結果がエラーの場合
                if (DSTUtil.ByteToInt(dtcExec.result) != 0)
                {
                    // エラーメッセージを表示
                    System.Windows.Forms.MessageBox.Show(Consts.MESSAGE_ERROR_DTC_EXEC,
                                    Consts.SCREEN_MAIN_TITLE,
                                    System.Windows.Forms.MessageBoxButtons.OK,
                                    System.Windows.Forms.MessageBoxIcon.Error);
                    // DTC実行エラーで更新
                    DSTDtoUtil.updateDtcError(task.dstdto);
                }
                else
                {
                    // ログファイル取得中状態にDST情報を更新する。
                    DSTDtoUtil.updateDtcExecLog(task.dstdto);
                }
            }
            catch(Exception)
            {
                // DTC実行エラーで更新
                DSTDtoUtil.updateDtcError(task.dstdto);
            }
        }

        /// <summary>
        /// ログファイル取得処理
        /// </summary>
        /// <param name="task">更新スレッドタスクインスタンス</param>
        /// ### 機能説明 #######
        /// -# 取得完了するまでループ
        ///     -# ログファイル取得APIを呼び出し（更新スレッドタスク.DST情報.IPアドレス）
        ///     -# 処理結果がエラーの場合
        ///         -# ログファイル取得エラー状態にDTC情報を更新する。
        ///             項目                  | 設定値
        ///             ----------------------| -------------
        ///             DTCステータス         | ログファイル取得エラー状態
        ///             DTC消去操作可能フラグ | True
        ///             DTCメッセージ         | ログファイル取得エラー
        ///                 
        ///     -# ログファイル取得API.通信ログデータを文字列に変換後、ログデータ文字列に連結して格納
        ///     
        ///     -# ログファイル取得API.残りデータサイズを取得
        ///     -# 残りデータサイズが0の場合
        ///         -# DTC完了で更新状態にDTC情報を更新する。
        ///             項目                  | 設定値
        ///             ----------------------| -------------
        ///             DTCステータス         | DTC完了状態
        ///             DTC消去操作可能フラグ | false
        ///             DTCメッセージ         | DTC完了
        ///         -# 取得完了のためループを抜ける
        ///     
        ///     -# 取得したログファイルのデータを出力する
        ///         項目                  | 設定値
        ///         ----------------------| -------------
        ///         出力先                | 定義ファイル.SAVE_FOLDER \ YardRepro_DTC.log
        private void getLogFile(StatusTask task)
        {
            string logData = "";
            int remainSize = 0;
            bool first = true;
            byte[] paramContinue = { 0x00 };
            byte[] paramFirst = { 0x01 };
            DSTUtil.DtcExecLog dtcExecLog;

            while (true)
            {
                // ログファイル取得要求を送信
                // ログデータを最初から取得
                if(first)
                {
                    dtcExecLog = DSTUtil.SendSocketUDPDtcExecLog(task.dstdto.ipAddress, paramFirst);
                    first = false;
                }
                // ログデータを続きから取得
                else
                {
                    dtcExecLog = DSTUtil.SendSocketUDPDtcExecLog(task.dstdto.ipAddress, paramContinue);
                }
                // 実行結果がエラーの場合
                if (DSTUtil.ByteToInt(dtcExecLog.result) != 0)
                {
                    // ログファイル取得エラーで更新
                    DSTDtoUtil.updateDtcErrorLog(task.dstdto);
                    break;
                }

                // ログデータ格納
                logData += DSTUtil.ByteToString(dtcExecLog.logFileData);

                // 残りデータサイズ
                remainSize = DSTUtil.ByteToInt(dtcExecLog.remainDataSize);
                log.Debug("DTC LOG Remain Data Size: " + remainSize.ToString());

                // 取得完了の場合
                if (remainSize == 0)
                {
                    break;
                }

            }

            try
            {
                if (task.dstdto.statusDtc == DSTDto.StatusModeDTC.DtcExecLog)
                {
                    // ログファイルを保存
                    using (var sw = new System.IO.StreamWriter(iniSaveFolder + Consts.DTC_LOG_FILE_NAME + "_" + task.dstdto.serialNo + "_" +
                                                               DateTime.Now.ToString("yyyyMMddHHmmss") + ".log", false))
                    {
                        // 取得したログデータをそのまま出力
                        sw.WriteLine(logData);
                    }
                    // DTC完了で更新
                    DSTDtoUtil.updateDtcSuccess(task.dstdto);
                }
            }
            catch (Exception e)
            {
                // ログファイル取得エラーで更新
                DSTDtoUtil.updateDtcErrorLog(task.dstdto);
                log.Debug("DTC LOG ERROR: " + e.ToString());
            }
        }
        #endregion

        #region "ダミーデータ"
        /// <summary>
        /// DSTステータスリストの情報（ダミー）を一覧に登録する
        /// </summary>
        public void AddDstiItemForTrial()
        {
            DSTDtoList dstiDtoList = new DSTDtoList();
            for (int i = 0; i < 3; i++)
            {
                DSTDto dto = createDstiDtoDummyData(i);
                Invoke((DelegateAdd)add, dto);
            }
        }

        /// <summary>
        /// DSTステータスリストの情報（ダミー）を作成する
        /// </summary>
        /// <returns>情報（ダミー）</returns>
        private DSTDto createDstiDtoDummyData(int index)
        {
            DSTDto dstiDto = new DSTDto();

            dstiDto.ipAddress = "192.168.11." + index;
            dstiDto.serialNo = "5D11100" + index;
            dstiDto.progresValue = 0;
            dstiDto.isEnabled = true;
            dstiDto.isSelectEnabled = true;
            dstiDto.isSelected = false;
            dstiDto.message = "0%";
            dstiDto.progressColorForeground = DSTDto.ProgresColor.Green.Name();
            return dstiDto;
        }
        #endregion "ダミーデータ"

    }
}
