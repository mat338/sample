﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Net.Sockets;
using NLog;
using System.Collections;
using NativeWifi;
using System.Management;
using System.Net;
using System.Runtime.InteropServices;

namespace YardRepro
{
    /// <summary>
    /// DST通信用ユーティリティクラス
    /// </summary>
    class DSTUtil
    {

        /// <summary>
        /// ログ出力クラス
        /// </summary>
        private static readonly Logger log = LogManager.GetCurrentClassLogger();
        
        /// <summary>
        /// UDP対応IPアドレス保護用のインスタンス
        /// </summary>
        private static readonly object udpTableLock = new object();

        /// <summary>
        /// UDP対応IPアドレス格納用Hashtable
        /// このテーブルはSendSocketでTCP/UDPを判断するのに使用する
        /// アクセス時はかならずudpTableLockのロックを取得すること
        /// </summary>
        private static Hashtable udpTable = new Hashtable();

        /// <summary>
        /// バイト配列から数値に変換
        /// </summary>
        /// <param name="bytes">バイト配列</param>
        /// <returns>数値データ</returns>
        /// ### 機能説明 #######
        /// -# 引数.バイト配列を32ビット符号付整数を返却
        public static int ByteToInt(byte[] bytes)
        {
            return BitConverter.ToInt32(bytes.ToArray(), 0);
        }

        /// <summary>
        /// バイト配列から文字列に変換
        /// </summary>
        /// <param name="bytes">バイト配列</param>
        /// <returns>文字列</returns>
        /// ### 機能説明 #######
        /// -# 引数.バイト配列をASCII文字にエンコードして返却文字列に格納
        /// -# ASCII文字にエンコードした値のNULL'\0'のインデックスを取得
        /// -# NULL'\0'のインデックスが0より大きい場合
        ///     -# ASCII文字にエンコードした値からNULL'\0'のインデックスまでを返却文字列に格納
        /// -# 返却文字列を返却
        public static string ByteToString(byte[] bytes)
        {
            string ret = System.Text.Encoding.ASCII.GetString(bytes);
            int zeroIndex = ret.IndexOf('\0');
            if (zeroIndex > 0)
            {
                ret = ret.Substring(0, zeroIndex);
            }
            return ret;
        }

        /// <summary>
        /// Wifi接続情報構造体
        /// </summary>
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
        public struct WifiConnect
        {
            /// <summary>
            /// ダミーデータ 3バイト
            /// </summary>
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
            byte[] abyDummy1;
            /// <summary>
            /// 実行結果 4バイト
            /// </summary>
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
            public byte[] result;
            /// <summary>
            /// WiFi接続状態(0:未接続、1:接続中) 1バイト
            /// </summary>
            public byte connection;
            /// <summary>
            /// WiFi電波強度(4:強、3:中、2:弱、1:微弱、0:圏外) 1バイト
            /// </summary>
            public byte signalStrength;
            /// <summary>
            /// 色情報(RGB) 3バイト
            /// </summary>
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
            public byte[] color;
            /// <summary>
            /// シリアルNo. 16バイト
            /// </summary>
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
            public byte[] SerialNo;
            /// <summary>
            /// ホスト名 64バイト
            /// </summary>
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 64)]
            public byte[] hostName;             // ホスト名
        }

        /// <summary>
        /// ステータス情報構造体
        /// </summary>
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
        public struct StatusInfo
        {
            /// <summary>
            /// ダミーデータ 3バイト
            /// </summary>
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
            byte[] abyDummy1;
            /// <summary>
            /// 実行結果 4バイト
            /// </summary>
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
            public byte[] result;
            /// <summary>
            /// リプロ処理の進捗率(0~100) 4バイト
            /// </summary>
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
            public byte[] progress;
        }

        /// <summary>
        /// VIN情報構造体
        /// </summary>
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
        public struct VinInfo
        {
            /// <summary>
            /// ダミーデータ 3バイト
            /// </summary>
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
            byte[] abyDummy1;
            /// <summary>
            /// 実行結果 4バイト
            /// </summary>
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
            public byte[] result;
            /// <summary>
            /// VIN 18バイト
            /// </summary>
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 18)]
            public byte[] vin;
        }

        /// <summary>
        /// ソフトウェア品番情報構造体
        /// </summary>
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
        public struct SoftNoInfo
        {
            /// <summary>
            /// ダミーデータ 1バイト 2019.02
            /// </summary>
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
            byte[] abyDummy1;
            /// <summary>
            /// データ長 2バイト 2019.02
            /// </summary>
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
            public byte[] len;
            /// <summary>
            /// 実行結果 4バイト
            /// </summary>
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
            public byte[] result;
            /// <summary>
            /// ソフト品番の数(上限32) 4バイト
            /// </summary>
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
            public byte[] numOfId;
            /// <summary>
            /// ソフトウェア品番構造体配列(上限32)
            /// </summary>
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
            public SoftNo[] softnoList;
        }

        /// <summary>
        /// ソフトウェア品番構造体
        /// </summary>
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
        public struct SoftNo
        {
            /// <summary>
            /// ソフトウェア品番 17バイト
            /// </summary>
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 17)]
            public byte[] Softno;             // Softno
        }

        /// <summary>
        /// リプロリトライ要求構造体
        /// </summary>
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
        public struct ReproRetry
        {
            /// <summary>
            /// ダミーデータ 3バイト
            /// </summary>
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
            byte[] abyDummy1;
            /// <summary>
            /// 実行結果 4バイト
            /// </summary>
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
            public byte[] result;
        }

        /// <summary>
        /// 後処理開始（DTC実行）要求構造体
        /// </summary>
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
        public struct DtcExec
        {
            /// <summary>
            /// ダミーデータ 3バイト
            /// </summary>
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
            byte[] abyDummy1;
            /// <summary>
            /// 実行結果 4バイト
            /// </summary>
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
            public byte[] result;
        }

        /// <summary>
        /// ログファイル情報構造体 2019.02
        /// </summary>
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
        public struct DtcExecLog
        {
            /// <summary>
            /// ダミーデータ 1バイト
            /// </summary>
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
            byte[] abyDummy1;
            /// <summary>
            /// データ長 2バイト
            /// </summary>
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
            public byte[] len;
            /// <summary>
            /// 実行結果 4バイト
            /// </summary>
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
            public byte[] result;
            /// <summary>
            /// 残りデータサイズ 4バイト
            /// </summary>
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
            public byte[] remainDataSize;
            /// <summary>
            /// 通信ログデータサイズ Max501バイト
            /// </summary>
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 501)]
            public byte[] logFileData;
        }


        /// <summary>
        /// 無線LANのIPアドレスを取得する
        /// </summary>
        /// <returns>IPアドレス</returns>
        /// ### 機能説明 #######
        /// -# 無線LANクライアントを生成
        /// -# 無線LANクライアントのインターフェース分ループ
        ///     -# 指定のインターフェースIDから現在のIPアドレスを取得
        ///     -# 取得した結果が空以外の場合、ループを抜ける
        /// -# IPアドレスを返却
        private static String GetSeltIPAddress()
        {
            String ret = "";

            // 無線LANクライアントを生成
            using (WlanClient client = new WlanClient())
            {
                // 無線LANクライアントのインターフェース分ループ
                foreach (WlanClient.WlanInterface wlanIface in client.Interfaces)
                {
                    // 指定のインターフェースから現在のIPアドレスを取得
                    ret = getIpAdd(wlanIface.InterfaceGuid.ToString());
                    // 取得した結果が空以外の場合、ループを抜ける
                    if (String.Empty != ret) break;
                }
            }
            // IPアドレスを返却
            return ret;
        }

        /// <summary>
        /// 指定のインターフェースから現在のIPアドレスを取得する
        /// </summary>
        /// <param name="settingid">インターフェースID</param>
        /// <returns>IPアドレス</returns>
        /// ### 機能説明 #######
        /// -# WMIアクセスインスタンスを生成
        /// -# WMIのWin32_NetworkAdapterConfigurationテーブルからインターフェースIDをキーにIPアドレスを取得するクエリを設定
        /// -# クエリを実行
        /// -# IPv6とIPv4が両方とれる場合はIPv4を取得する
        /// -# IPアドレスを返却
        private static string getIpAdd(string settingid)
        {
            // WMIアクセスインスタンスを生成
            ManagementObjectSearcher oMS = new ManagementObjectSearcher();
            ManagementObjectCollection oMC;
            string ipAdd = "";

            // WMIのWin32_NetworkAdapterConfigurationテーブルからインターフェースIDをキーにIPアドレスを取得するクエリを設定
            oMS.Query.QueryString = "SELECT IPAddress FROM Win32_NetworkAdapterConfiguration WHERE SettingID='{" + settingid + "}'";
            oMC = oMS.Get();

            foreach (ManagementObject oMO in oMC)
            {
                if (oMO["IPAddress"] != null)
                {
                    foreach (string ip in (string[])oMO["IPAddress"])
                    {
                        // IPv6とIPv4が両方とれる場合はIPv4を取得する
                        if (ip.IndexOf("fe80:") == -1) ipAdd = ip;
                    }
                }
            }
            // IPアドレスを返却
            return ipAdd;
        }
        /// <summary>
        /// 無線LANのブロードキャストIPアドレスを取得する
        /// </summary>
        /// <returns>ブロードキャストIPアドレス</returns>
        /// ### 機能説明 #######
        /// -# 無線LANクライアントを生成
        /// -# 無線LANクライアントのインターフェース分ループ
        ///     -# 指定のインターフェースIDからブロードキャストIPアドレスを取得
        ///     -# 取得した結果が空以外の場合、ループを抜ける
        /// -# IPアドレスを返却
        private static String GetSeltBroadcastIPAddress()
        {
            String ret = "";

            using (WlanClient client = new WlanClient())
            {
                foreach (WlanClient.WlanInterface wlanIface in client.Interfaces)
                {
                    //log.Debug("wlanIFace:" + wlanIface.InterfaceName);
                    ret = getBroadcastIpAdd(wlanIface.InterfaceGuid.ToString());
                    if (String.Empty != ret) break;
                }
            }
            return ret;
        }

        /// <summary>
        /// 指定のインターフェースからブロードキャストIPアドレスを取得する
        /// </summary>
        /// <param name="settingid">インターフェースID</param>
        /// <returns>ブロードキャストIPアドレス</returns>
        /// ### 機能説明 #######
        /// -# WMIアクセスインスタンスを生成
        /// -# WMIのWin32_NetworkAdapterConfigurationテーブルからインターフェースIDをキーにIPアドレスを取得するクエリを設定
        /// -# クエリを実行
        /// -# IPv6とIPv4が両方とれる場合はIPv4を取得する
        /// -# サブネットマスクを取得する
        /// -# IPアドレスをブネットマスクで反転させる
        /// -# IPアドレスを返却
        private static string getBroadcastIpAdd(string settingid)
        {
            // WMIアクセスインスタンスを生成
            ManagementObjectSearcher oMS = new ManagementObjectSearcher();
            ManagementObjectCollection oMC;
            string ipAdd = "";

            // WMIのWin32_NetworkAdapterConfigurationテーブルからインターフェースIDをキーにテーブルデータを取得するクエリを設定
            oMS.Query.QueryString = "SELECT * FROM Win32_NetworkAdapterConfiguration WHERE SettingID='{" + settingid + "}'";
            oMC = oMS.Get();

            foreach (ManagementObject oMO in oMC)
            {

                if (oMO["IPAddress"] != null)
                {
                    for (int i = 0; i < ((string[])oMO["IPAddress"]).Length; i++)
                    {
                        string ip = ((string[])oMO["IPAddress"])[i];
                        // IPv6とIPv4が両方とれる場合はIPv4を取得する
                        if (ip.IndexOf("fe80:") == -1)
                        {
                            IPAddress self = IPAddress.Parse(ip);

                            //サブネットマスク
                            string subnet = ((string[])oMO["IPSubnet"])[i];
                            IPAddress mask = IPAddress.Parse(subnet);

                            //ブロードキャストアドレス(サブネットマスク反転、IPアドレスとOR)
                            byte[] bSelf = self.GetAddressBytes();
                            byte[] bMask = mask.GetAddressBytes();
                            byte[] rMask = new byte[bMask.Length];
                            byte[] bBroad = new byte[bSelf.Length];
                            for (int j = 0; j < bMask.Length; j++)
                            {
                                rMask[j] = (byte)~bMask[j];
                                bBroad[j] = (byte)(rMask[j] | bSelf[j]);
                            }

                            ipAdd = new IPAddress(bBroad).ToString();
                        }
                    }
                }
            }
            return ipAdd;
        }

        /// <summary>
        /// WiFi接続情報読出しコマンドをブロードキャスト送信
        /// </summary>
        /// <returns>IPアドレスとその応答データのリスト</returns>
        /// ### 機能説明 #######
        /// -# 無線LANのIPアドレスを取得する
        /// -# 無線LANのブロードキャストIPアドレスを取得する
        /// -# エンドポイント設定の作成
        ///         項目                | 設定値
        ///         --------------------| -------------
        ///         IPアドレス          | ブロードキャストIPアドレス
        ///         ポート              | DST-WiFiポート(60701)
        ///         
        /// -# ソケット作成
        ///         項目                | 設定値
        ///         --------------------| -------------
        ///         アドレスファミリ    | IPv4
        ///         ソケットタイプ      | Dgram
        ///         プロトコルタイプ    | UDP
        ///         
        /// -# 受信バッファサイズの設定
        /// -# 送信データ編集（3:WiFi接続情報読出しコマンド）
        /// -# ブロードキャスト許可に設定
        /// -# コマンドブロードキャスト
        /// -# ブロードキャスト応答スレッド生成
        /// -# ブロードキャストパラメータ設定
        /// -# スレッド開始
        /// -# ソケットの応答待ち時間スリープ(2s)
        /// -# スレッドを停止リクエスト送信
        /// -# スレッドが停止するまで待機
        /// -# UDP対応IPアドレステーブルを更新する
        ///     -# UDP対応IPアドレス格納用Hashtableに応答があったIPアドレスはTrueを設定
        /// -# IPアドレスのリストを返却
        /// -# ソケット処理で例外が発生した場合
        ///     -# エラーログ出力
        ///     -# スタックトレースログ出力
        ///     -# IPアドレスのリストを返却
        public static ArrayList sendWifiConnectBroadcast()
        {
            ArrayList array = new ArrayList();
            try
            {
                // ブロードキャストアドレス作成
                string myIPString = GetSeltIPAddress();
                string broadcastString = GetSeltBroadcastIPAddress();
                IPAddress broadcastAddress = IPAddress.Parse(broadcastString);

                //エンドポイント設定の作成
                IPEndPoint endPoint_WL = new IPEndPoint(broadcastAddress, Consts.DSTWL_SOCKET_PORT);

                // ソケット作成
                using (Socket s = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp))
                {
                    // 受信バッファサイズの設定
                    s.ReceiveBufferSize = Consts.SOCKET_RECEIVE_BUFFER_SIZE;

                    // 送信データ編集（3:WiFi接続情報読出しコマンド）
                    List<byte> sendByteList = new List<byte>();
                    sendByteList.Add(Consts.SOCKET_ID_GET_CONNECTION_DATA);
                    sendByteList.Add(0);
                    sendByteList.Add(0);
                    byte[] sendByte = sendByteList.ToArray();

                    log.Debug("UDP Broadcast[{0}->{1}] Send Start.", myIPString, broadcastString);

                    // ブロードキャスト許可
                    s.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.Broadcast, 1);//1: 許可
                    // コマンドブロードキャスト
                    s.SendTo(sendByte, endPoint_WL);

                    // 受信
                    //スレッド生成
                    BroadcastReplyReceiver worker = new BroadcastReplyReceiver();
                    Thread thread = new Thread(new ParameterizedThreadStart(worker.receiveBroadcastReply));
                    thread.IsBackground = true;

                    // パラメータ設定
                    BroadcastReplyReceiverParam param = new BroadcastReplyReceiverParam();
                    param.sock = s;
                    param.array = array;

                    //スレッド開始
                    thread.Start(param);

                    // 待ち合わせ
                    Thread.Sleep(Consts.SOCKET_RECEIVE_WAIT_TIME);

                    // 終了リクエスト
                    worker.requestStop();

                    // 待ち合わせ
                    thread.Join();

                    log.Debug("UDP Broadcast[{0}->{1}] Recieve TimeOut[{2}ms].", myIPString, broadcastString, Consts.SOCKET_RECEIVE_WAIT_TIME);

                    // UDP対応IPアドレステーブルを更新する
                    lock (udpTableLock)
                    {
                        udpTable.Clear();
                        foreach (WifiConnectBroadcastReply reply in array)
                        {
                            udpTable[reply.ip] = true;
                        }
                    }
                    // IPアドレスのリストを返す
                    return array;
                }

            }
            catch (Exception ex)
            {
                //通信失敗時
                log.Error(ex);
                log.Error(ex.InnerException);
                return array;
            }
        }

        /// <summary>
        /// WiFi接続情報読出しコマンドのブロードキャスト応答データのペアクラス
        /// </summary>
        public class WifiConnectBroadcastReply
        {
            /// <summary>
            /// IPアドレス
            /// </summary>
            public string ip { get; set; }
            /// <summary>
            /// WiFi接続情報応答データ
            /// </summary>
            public WifiConnect reply { get; set; }
        }

        /// <summary>
        /// ブロードキャスト応答のパラメータクラス
        /// </summary>
        private class BroadcastReplyReceiverParam
        {
            /// <summary>
            /// ソケットインスタンス
            /// </summary>
            public Socket sock { get; set; }
            /// <summary>
            /// ソケット応答データ
            /// </summary>
            public ArrayList array { get; set; }
        }

        /// <summary>
        /// ブロードキャスト応答クラス
        /// </summary>
        private class BroadcastReplyReceiver
        {
            /// <summary>
            /// スレッドの終了フラグ
            /// </summary>
            private volatile bool _shouldStop = false;

            /// <summary>
            /// スレッドの終了をリクエストする
            /// </summary>
            public void requestStop()
            {
                _shouldStop = true;
            }

            /// <summary>
            /// ブロードキャストの応答を受信し、IPアドレスをリストに保存する
            /// </summary>
            /// <param name="param">ブロードキャスト応答パラメータ</param>
            /// <returns>応答を返したIPアドレスのリスト</returns>
            /// ### 機能説明 #######
            /// -# 引数.ブロードキャスト応答パラメータから応答リストをを取得
            /// -# スレッド終了フラグがFalseの間ループ
            ///     -# ソケットのステータスをタイムアウト10ミリ秒に設定
            ///     -# ソケットリストが0件以上の場合
            ///         -# ソケットからデータグラムを受信してデータバッファーに格納します。さらに、エンドポイントを格納します。
            ///         -# エンドポイントから送信元IPを取得
            ///         -# 重複IPチェックテーブルに送信元IPがない場合
            ///             -# WiFi接続情報応答データクラスにデータバッファーをマーシャル
            ///             -# 応答リストのWiFi接続情報読出しコマンドのブロードキャスト応答データのペアクラスにWiFi接続情報応答データを設定
            ///             -# 重複IPチェックテーブルに送信元IPを設定
            ///     -# ソケット処理で例外が発生した場合
            ///         -# エラーログ出力
            ///         -# スタックトレースログ出力
            ///         -# ループを抜ける
            public void receiveBroadcastReply(Object param)
            {
                BroadcastReplyReceiverParam p = (BroadcastReplyReceiverParam)param;
                ArrayList array = p.array;
                Socket sock = p.sock;
                Hashtable ipTable = new Hashtable();
                byte[] buffer = new Byte[1024];
                IPEndPoint endPoint = new IPEndPoint(IPAddress.Any, 0);
                EndPoint senderRemote = (EndPoint)endPoint;
                ArrayList listenList = new ArrayList();
                int recvSize = 0;

                while (!_shouldStop)
                {
                    try
                    {
                        // タイムアウト10ミリ秒
                        listenList.Clear();
                        listenList.Add(sock);
                        Socket.Select(listenList, null, null, 10000);

                        if (listenList.Count > 0)
                        {
                            recvSize = sock.ReceiveFrom(buffer, ref senderRemote);
                            string remote = senderRemote.ToString();
                            string remoteIP = remote.Substring(0, remote.LastIndexOf(":"));

                            // UDPなので念のため重複排除
                            if (!ipTable.Contains(remoteIP))
                            {
                                WifiConnectBroadcastReply reply = new WifiConnectBroadcastReply();
                                byte[] newBuffer = new Byte[recvSize];
                                Array.Copy(buffer, 0, newBuffer, 0, recvSize);
                                GCHandle gch = GCHandle.Alloc(newBuffer, GCHandleType.Pinned);
                                WifiConnect wl = new WifiConnect();
                                wl = (WifiConnect)Marshal.PtrToStructure(gch.AddrOfPinnedObject(), typeof(WifiConnect));
                                gch.Free();
                                reply.ip = remoteIP;
                                reply.reply = wl;
                                array.Add(reply);
                                ipTable[remoteIP] = true;
                                log.Debug("receive - ipAddress[" + remoteIP + "], reply[" + BitConverter.ToString(newBuffer).Replace("-", string.Empty) + "]");
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        //通信失敗時、ループ終了
                        log.Error(ex);
                        log.Error(ex.InnerException);
                        break;
                    }
                }
            }
        }

        /// <summary>
        /// ステータス取得API
        /// </summary>
        /// <param name="ipAddress">送信先IPアドレス</param>
        /// <returns>ステータス情報応答構造体</returns>
        /// ### 機能説明 #######
        /// -# 返却データを初期化
        /// -# DST-WiFiに対してソケットを送信
        ///         項目                | 設定値
        ///         --------------------| -------------
        ///         IPアドレス          | 引数.送信先IPアドレス
        ///         ID                  | ステータス取得(0x11)
        ///         パラメータ          | NULL(0x00)
        ///         タイムアウト値      | 1000
        ///         
        /// -# ステータス情報応答構造体にソケットの応答データをマーシャルして返却データに設定
        /// -# 返却データを返却
        public static WifiConnect SendSocketUDPWifiConnectInfo(string ipAddress)
        {
            WifiConnect ret = new WifiConnect();
            byte[] param = { 0x00 };
            byte[] res = SendRecSocketUDP(ipAddress, Consts.SOCKET_ID_GET_CONNECTION_DATA, param, Consts.TIMEOUT);
            GCHandle gch = GCHandle.Alloc(res, GCHandleType.Pinned);
            ret = (WifiConnect)Marshal.PtrToStructure(gch.AddrOfPinnedObject(), typeof(WifiConnect));
            gch.Free();
            return ret;
        }

        /// <summary>
        /// ステータス取得API
        /// </summary>
        /// <param name="ipAddress">送信先IPアドレス</param>
        /// <returns>ステータス情報応答構造体</returns>
        /// ### 機能説明 #######
        /// -# 返却データを初期化
        /// -# DST-WiFiに対してソケットを送信
        ///         項目                | 設定値
        ///         --------------------| -------------
        ///         IPアドレス          | 引数.送信先IPアドレス
        ///         ID                  | ステータス取得(0x11)
        ///         パラメータ          | NULL(0x00)
        ///         タイムアウト値      | 1000
        ///         
        /// -# ステータス情報応答構造体にソケットの応答データをマーシャルして返却データに設定
        /// -# 返却データを返却
        public static StatusInfo SendSocketUDPStatusInfo(string ipAddress)
        {
            StatusInfo ret = new StatusInfo();
            byte[] param = { 0x00 };
            byte[] res = SendRecSocketUDP(ipAddress, Consts.SOCKET_ID_STATUS, param, Consts.TIMEOUT);
            GCHandle gch = GCHandle.Alloc(res, GCHandleType.Pinned);
            ret = (StatusInfo)Marshal.PtrToStructure(gch.AddrOfPinnedObject(), typeof(StatusInfo));
            gch.Free();
            return ret;
        }

        /// <summary>
        /// VIN取得API
        /// </summary>
        /// <param name="ipAddress">送信先IPアドレス</param>
        /// <returns>VIN情報応答構造体</returns>
        /// ### 機能説明 #######
        /// -# 返却データを初期化
        /// -# DST-WiFiに対してソケットを送信
        ///         項目                | 設定値
        ///         --------------------| -------------
        ///         IPアドレス          | 引数.送信先IPアドレス
        ///         ID                  | VIN取得(0x12)
        ///         パラメータ          | NULL(0x00)
        ///         タイムアウト値      | 1000
        ///         
        /// -# VIN情報応答構造体にソケットの応答データをマーシャルして返却データに設定
        /// -# 返却データを返却
        public static VinInfo SendSocketUDPVinInfo(string ipAddress)
        {
            VinInfo ret = new VinInfo();
            byte[] param = { 0x00 };
            byte[] res = SendRecSocketUDP(ipAddress, Consts.SOCKET_ID_VIN, param, Consts.TIMEOUT);
            GCHandle gch = GCHandle.Alloc(res, GCHandleType.Pinned);
            ret = (VinInfo)Marshal.PtrToStructure(gch.AddrOfPinnedObject(), typeof(VinInfo));
            gch.Free();
            return ret;
        }

        /// <summary>
        /// ソフトウェア品番取得API 2019.02
        /// </summary>
        /// <param name="ipAddress">送信先IPアドレス</param>
        /// <returns>ソフトウェア品番応答構造体</returns>
        /// ### 機能説明 #######
        /// -# 返却データを初期化
        /// -# DST-WiFiに対してソケットを送信
        ///         項目                | 設定値
        ///         --------------------| -------------
        ///         IPアドレス          | 引数.送信先IPアドレス
        ///         ID                  | ソフトウェア品番取得(0x13)
        ///         パラメータ          | NULL(0x00)
        ///         タイムアウト値      | 1000
        ///         
        /// -# ソフトウェア品番応答構造体にソケットの応答データをマーシャルして返却データに設定
        /// -# 返却データを返却
        public static SoftNoInfo SendSocketUDPSoftNoInfo(string ipAddress)
        {
            SoftNoInfo ret = new SoftNoInfo();
            byte[] param = { 0x00 };
            byte[] res = SendRecSocketSoftNoUDP(ipAddress, Consts.SOCKET_ID_SOFTNO, param);
            GCHandle gch = GCHandle.Alloc(res, GCHandleType.Pinned);
            ret = (SoftNoInfo)Marshal.PtrToStructure(gch.AddrOfPinnedObject(), typeof(SoftNoInfo));
            gch.Free();

            return ret;
        }

        /// <summary>
        /// リトライ要求API
        /// </summary>
        /// <param name="ipAddress">送信先IPアドレス</param>
        /// <returns>リプロリトライ要求応答構造体</returns>
        /// ### 機能説明 #######
        /// -# 返却データを初期化
        /// -# DST-WiFiに対してソケットを送信
        ///         項目                | 設定値
        ///         --------------------| -------------
        ///         IPアドレス          | 引数.送信先IPアドレス
        ///         ID                  | リトライ要求(0x14)
        ///         パラメータ          | NULL(0x00)
        ///         タイムアウト値      | 1000
        ///         
        /// -# リプロリトライ要求応答構造体にソケットの応答データをマーシャルして返却データに設定
        /// -# 返却データを返却
        public static ReproRetry SendSocketUDPReproRetry(string ipAddress)
        {
            ReproRetry ret = new ReproRetry();
            byte[] param = { 0x00 };
            byte[] res = SendRecSocketUDP(ipAddress, Consts.SOCKET_ID_REPRORETRY, param, Consts.TIMEOUT);
            GCHandle gch = GCHandle.Alloc(res, GCHandleType.Pinned);
            ret = (ReproRetry)Marshal.PtrToStructure(gch.AddrOfPinnedObject(), typeof(ReproRetry));
            gch.Free();
            return ret;
        }

        /// <summary>
        /// 後処理開始要求API 2019.02
        /// </summary>
        /// <param name="ipAddress">送信先IPアドレス</param>
        /// <param name="timeout">定義ファイル設定タイムアウト値</param>
        /// <returns>後処理開始要求応答構造体</returns>
        /// ### 機能説明 #######
        /// -# 返却データを初期化
        /// -# DST-WiFiに対してソケットを送信
        ///         項目                | 設定値
        ///         --------------------| -------------
        ///         IPアドレス          | 引数.送信先IPアドレス
        ///         ID                  | リトライ要求(0x15)
        ///         パラメータ          | NULL(0x00)
        ///         タイムアウト値      | 定義ファイル.タイムアウト
        ///         
        /// -# 後処理開始要求応答構造体にソケットの応答データをマーシャルして返却データに設定
        /// -# 返却データを返却
        public static DtcExec SendSocketUDPDtcExec(string ipAddress, int timeout)
        {
            DtcExec ret = new DtcExec();
            byte[] param = { 0x00 };
            byte[] res = SendRecSocketUDP(ipAddress, Consts.SOCKET_ID_DTC_EXEC, param, timeout);
            GCHandle gch = GCHandle.Alloc(res, GCHandleType.Pinned);
            ret = (DtcExec)Marshal.PtrToStructure(gch.AddrOfPinnedObject(), typeof(DtcExec));
            gch.Free();
            return ret;
        }

        /// <summary>
        /// ログファイル取得要求API 2019.02
        /// </summary>
        /// <param name="ipAddress">送信先IPアドレス</param>
        /// <returns>ログファイル取得要求応答構造体</returns>
        /// ### 機能説明 #######
        /// -# 返却データを初期化
        /// -# DST-WiFiに対してソケットを送信
        ///         項目                | 設定値
        ///         --------------------| -------------
        ///         IPアドレス          | 引数.送信先IPアドレス
        ///         ID                  | リトライ要求(0x16)
        ///         パラメータ          | NULL(0x00)
        ///         タイムアウト値      | 1000
        ///         
        /// -# 後処理開始要求応答構造体にソケットの応答データをマーシャルして返却データに設定
        /// -# 残りデータサイズが0の場合
        ///     -# 返却データを返却
        /// -# 残りデータサイズが0の場合
        public static DtcExecLog SendSocketUDPDtcExecLog(string ipAddress, byte[] param)
        {
            DtcExecLog ret = new DtcExecLog();
            //byte[] param = { 0x00 };
            byte[] res = SendRecSocketUDP(ipAddress, Consts.SOCKET_ID_DTC_EXEC_LOG, param, Consts.TIMEOUT);
            GCHandle gch = GCHandle.Alloc(res, GCHandleType.Pinned);
            ret = (DtcExecLog)Marshal.PtrToStructure(gch.AddrOfPinnedObject(), typeof(DtcExecLog));
            gch.Free();

            return ret;
        }

        private static Mutex mutSocketUDP = new Mutex();
        /// <summary>
        /// DST-WiFiに対してソケットを送信し、結果を返す
        /// </summary>
        /// <param name="ipAddress">送信先IPアドレス</param>
        /// <param name="id">コマンドID</param>
        /// <param name="param">パラメータ</param>
        /// <param name="recTimeout">受信タイムアウト値</param>
        /// <returns>応答データ</returns>
        /// ### 機能説明 #######
        /// -# UDPクライアントを生成
        /// -# UDPクライアントの送信タイムアウトを設定（1000ミリ秒)
        /// -# UDPクライアントの受信タイムアウトを設定（1000ミリ秒or定義ファイル設定タイムアウト値)
        /// -# エンドポイント設定の作成
        ///         項目                | 設定値
        ///         --------------------| -------------
        ///         IPアドレス          | 引数.送信先IPアドレス
        ///         ポート              | DST-WiFiポート(60701)
        ///         
        /// -# 送信データ編集（引数.コマンドID,引数.パラメータの総数,0x00,引数.パラメータ）
        /// -# UDPクライアントの送信を実行
        /// -# UDPクライアントからデータグラムを受信してデータバッファーに格納します。さらに、エンドポイントを格納します。
        /// -# データバッファーを返却
        /// -# ソケット処理で例外が発生した場合
        ///     -# エラーログ出力
        ///     -# スタックトレースログ出力
        ///     -# 例外をスロー
        public static byte[] SendRecSocketUDP(string ipAddress, byte id, byte[] param, int recTimeout)
        {
            mutSocketUDP.WaitOne();
            using (UdpClient client = new UdpClient()) 
            {
                try
                {
                    // 定義ファイル取得
                    client.Client.SendTimeout = Consts.TIMEOUT;
                    client.Client.ReceiveTimeout = recTimeout;
                    log.Debug("in SendSocket ipAddress: " + ipAddress.ToString());

                    // エンドポイント設定
                    IPEndPoint endPoint_WL = new IPEndPoint(IPAddress.Parse(ipAddress), Consts.DSTWL_SOCKET_PORT);

                    log.Debug("begin connection SUCCESS - ipAddress[" + ipAddress + "], id[" + id + "], param[" + BitConverter.ToString(param).Replace("-", string.Empty) + "]");

                    // 送信データを作成
                    List<byte> sendByteList = new List<byte>();
                    sendByteList.Add(id);

                    // パラメータの長さを指定
                    // 現状ではbyteの最大値（255）を超えることはないため、1バイト目は0固定とする
                    sendByteList.Add((byte)param.Length);
                    sendByteList.Add(0);
                    sendByteList.AddRange(param);

                    // 送信
                    byte[] sendByte = sendByteList.ToArray();
                    client.Send(sendByte, sendByte.Length, endPoint_WL);


                    // 受信
                    System.IO.MemoryStream memory = new System.IO.MemoryStream();
                    byte[] buffBytes;
                    byte[] res = null;

                    // UDPではアプリが意図的に分割しない限りデータは分割されない
                    buffBytes = client.Receive(ref endPoint_WL);
                    memory.Write(buffBytes, 0, buffBytes.Length);

                    try
                    {
                        res = memory.ToArray();
                        log.Debug("receive - ipAddress[" + ipAddress + "], id[" + id + "], byte[" + BitConverter.ToString(res).Replace("-", string.Empty) + "]");
                    }
                    catch
                    {
                        log.Debug("END - ipAddress[" + ipAddress + "], id[" + id + "]");
                        throw new NullReferenceException();
                    }

                    return res;
                }
                catch (Exception ex)
                {
                    //通信失敗時
                    log.Error(ex);
                    log.Error(ex.InnerException);
                    throw;
                }
                finally
                {
                    mutSocketUDP.ReleaseMutex();
                }
            }
        }

        private static Mutex mutSocketSoftNoUDP = new Mutex();
        /// <summary>
        /// DST-WiFiに対してソケットを送信し、結果を返す（ソフト品番取得用） 2019.02
        /// </summary>
        /// <param name="ipAddress">送信先IPアドレス</param>
        /// <param name="id">コマンドID</param>
        /// <param name="param">パラメータ</param>
        /// <returns>応答データ</returns>
        /// ### 機能説明 #######
        /// -# UDPクライアントを生成
        /// -# UDPクライアントの送信タイムアウトを設定（1000ミリ秒)
        /// -# UDPクライアントの受信タイムアウトを設定（1000ミリ秒)
        /// -# エンドポイント設定の作成
        ///         項目                | 設定値
        ///         --------------------| -------------
        ///         IPアドレス          | 引数.送信先IPアドレス
        ///         ポート              | DST-WiFiポート(60701)
        ///         
        /// -# 送信データ編集（引数.コマンドID,引数.パラメータの総数,0x00,引数.パラメータ）
        /// -# UDPクライアントの送信を実行
        /// -# 分割データを全て受信するまでループ
        ///     -# UDPクライアントからデータグラムを受信してデータバッファーに格納します。さらに、エンドポイントを格納します。
        ///     -# 最初の応答フレームを受信した場合
        ///         -# データ長を取得
        ///     -# 受信したデータのデータ長が応答フレームから取得したデータ長以上の場合
        ///         -# 受信処理終了
        /// -# データバッファーを返却
        /// -# ソケット処理で例外が発生した場合
        ///     -# エラーログ出力
        ///     -# スタックトレースログ出力
        ///     -# 例外をスロー
        public static byte[] SendRecSocketSoftNoUDP(string ipAddress, byte id, byte[] param)
        {
            mutSocketSoftNoUDP.WaitOne();
            using (UdpClient client = new UdpClient())
            {
                try
                {
                    // 定義ファイル取得
                    client.Client.SendTimeout = Consts.TIMEOUT;
                    client.Client.ReceiveTimeout = Consts.TIMEOUT;
                    log.Debug("in SendSocket ipAddress: " + ipAddress.ToString());

                    // エンドポイント設定
                    IPEndPoint endPoint_WL = new IPEndPoint(IPAddress.Parse(ipAddress), Consts.DSTWL_SOCKET_PORT);

                    log.Debug("begin connection SUCCESS - ipAddress[" + ipAddress + "], id[" + id + "], param[" + BitConverter.ToString(param).Replace("-", string.Empty) + "]");

                    // 送信データを作成
                    List<byte> sendByteList = new List<byte>();
                    sendByteList.Add(id);

                    // パラメータの長さを指定
                    // 現状ではbyteの最大値（255）を超えることはないため、1バイト目は0固定とする
                    sendByteList.Add((byte)param.Length);
                    sendByteList.Add(0);
                    sendByteList.AddRange(param);

                    // 送信
                    byte[] sendByte = sendByteList.ToArray();
                    client.Send(sendByte, sendByte.Length, endPoint_WL);


                    // 受信
                    System.IO.MemoryStream memory = new System.IO.MemoryStream();
                    byte[] buffBytes;
                    byte[] res = null;
                    byte[] len = new byte[2];
                    int cnt = 0;

                    // 受信データの分割対応
                    while (true)
                    {
                        buffBytes = client.Receive(ref endPoint_WL);
                        memory.Write(buffBytes, 0, buffBytes.Length);

                        try
                        {
                            res = memory.ToArray();
                            log.Debug("receive - ipAddress[" + ipAddress + "], id[" + id + "], byte[" + BitConverter.ToString(res).Replace("-", string.Empty) + "]");
                        }
                        catch
                        {
                            log.Debug("END - ipAddress[" + ipAddress + "], id[" + id + "]");
                            throw new NullReferenceException();
                        }

                        // 初回受信データからデータ長を取得する
                        if (cnt == 0)
                        {
                            Array.Copy(res, 1, len, 0, 2);
                            cnt++;
                        }

                        // 受信データ長確認
                        //Console.WriteLine("len:" + BitConverter.ToInt16(len, 0));
                        if (res.Length >= BitConverter.ToInt16(len, 0) + Consts.RESPONSE_FRAME_HEADER_SIZE)
                        {
                            break;
                        }
                    }

                    return res;
                }
                catch (Exception ex)
                {
                    //通信失敗時
                    log.Error(ex);
                    log.Error(ex.InnerException);
                    throw;
                }
                finally
                {
                    mutSocketSoftNoUDP.ReleaseMutex();
                }
            }
        }
    }
}
