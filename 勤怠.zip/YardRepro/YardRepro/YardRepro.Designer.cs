﻿namespace YardRepro
{
    partial class YardReproMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(YardReproMain));
            this.pnlOutFrame = new System.Windows.Forms.Panel();
            this.lblSearching = new System.Windows.Forms.Label();
            this.dsTiList1 = new YardRepro.DSTStatusList();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnDSTSelect = new System.Windows.Forms.Button();
            this.btnCsv = new System.Windows.Forms.Button();
            this.btnTrialF2 = new System.Windows.Forms.Button();
            this.btnTrialF1 = new System.Windows.Forms.Button();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.pnlOutFrame.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlOutFrame
            // 
            this.pnlOutFrame.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tableLayoutPanel1.SetColumnSpan(this.pnlOutFrame, 6);
            this.pnlOutFrame.Controls.Add(this.lblSearching);
            this.pnlOutFrame.Controls.Add(this.dsTiList1);
            this.pnlOutFrame.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlOutFrame.Location = new System.Drawing.Point(4, 3);
            this.pnlOutFrame.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pnlOutFrame.Name = "pnlOutFrame";
            this.pnlOutFrame.Size = new System.Drawing.Size(1096, 495);
            this.pnlOutFrame.TabIndex = 3;
            // 
            // lblSearching
            // 
            this.lblSearching.BackColor = System.Drawing.Color.Gray;
            this.lblSearching.Font = new System.Drawing.Font("Meiryo UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.lblSearching.ForeColor = System.Drawing.Color.White;
            this.lblSearching.Location = new System.Drawing.Point(14, 109);
            this.lblSearching.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSearching.Name = "lblSearching";
            this.lblSearching.Size = new System.Drawing.Size(305, 41);
            this.lblSearching.TabIndex = 0;
            this.lblSearching.Text = "(検出中)";
            this.lblSearching.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // dsTiList1
            // 
            this.dsTiList1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dsTiList1.iniSaveFolder = null;
            this.dsTiList1.iniTimeout = 0;
            this.dsTiList1.isStop = false;
            this.dsTiList1.isTrial = false;
            this.dsTiList1.Location = new System.Drawing.Point(0, 0);
            this.dsTiList1.Margin = new System.Windows.Forms.Padding(0);
            this.dsTiList1.Name = "dsTiList1";
            this.dsTiList1.Size = new System.Drawing.Size(1094, 493);
            this.dsTiList1.TabIndex = 1;
            // 
            // btnClose
            // 
            this.btnClose.Font = new System.Drawing.Font("Meiryo UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnClose.Location = new System.Drawing.Point(974, 511);
            this.btnClose.Margin = new System.Windows.Forms.Padding(0, 10, 0, 0);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(118, 39);
            this.btnClose.TabIndex = 6;
            this.btnClose.Text = "(閉じる)";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            this.btnClose.KeyDown += new System.Windows.Forms.KeyEventHandler(this.YardReproMain_KeyDown);
            this.btnClose.KeyUp += new System.Windows.Forms.KeyEventHandler(this.YardReproMain_KeyUp);
            // 
            // btnDSTSelect
            // 
            this.btnDSTSelect.Font = new System.Drawing.Font("Meiryo UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnDSTSelect.Location = new System.Drawing.Point(714, 511);
            this.btnDSTSelect.Margin = new System.Windows.Forms.Padding(0, 10, 0, 0);
            this.btnDSTSelect.Name = "btnDSTSelect";
            this.btnDSTSelect.Size = new System.Drawing.Size(118, 39);
            this.btnDSTSelect.TabIndex = 4;
            this.btnDSTSelect.Text = "(DST選択)";
            this.btnDSTSelect.UseVisualStyleBackColor = true;
            this.btnDSTSelect.Click += new System.EventHandler(this.btnDSTSelect_Click);
            // 
            // btnCsv
            // 
            this.btnCsv.Enabled = false;
            this.btnCsv.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnCsv.Font = new System.Drawing.Font("Meiryo UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.btnCsv.Location = new System.Drawing.Point(844, 511);
            this.btnCsv.Margin = new System.Windows.Forms.Padding(0, 10, 0, 0);
            this.btnCsv.Name = "btnCsv";
            this.btnCsv.Size = new System.Drawing.Size(118, 39);
            this.btnCsv.TabIndex = 5;
            this.btnCsv.Text = "(CSV出力)";
            this.btnCsv.UseVisualStyleBackColor = true;
            this.btnCsv.Click += new System.EventHandler(this.btnCsv_Click);
            // 
            // btnTrialF2
            // 
            this.btnTrialF2.Font = new System.Drawing.Font("MS UI Gothic", 8F);
            this.btnTrialF2.Location = new System.Drawing.Point(58, 502);
            this.btnTrialF2.Margin = new System.Windows.Forms.Padding(1);
            this.btnTrialF2.Name = "btnTrialF2";
            this.btnTrialF2.Size = new System.Drawing.Size(25, 23);
            this.btnTrialF2.TabIndex = 0;
            this.btnTrialF2.TabStop = false;
            this.btnTrialF2.Text = "F2";
            this.btnTrialF2.UseVisualStyleBackColor = true;
            this.btnTrialF2.Visible = false;
            this.btnTrialF2.Click += new System.EventHandler(this.btnTrialF2_Click);
            // 
            // btnTrialF1
            // 
            this.btnTrialF1.Font = new System.Drawing.Font("MS UI Gothic", 8F);
            this.btnTrialF1.Location = new System.Drawing.Point(1, 502);
            this.btnTrialF1.Margin = new System.Windows.Forms.Padding(1);
            this.btnTrialF1.Name = "btnTrialF1";
            this.btnTrialF1.Size = new System.Drawing.Size(25, 23);
            this.btnTrialF1.TabIndex = 0;
            this.btnTrialF1.TabStop = false;
            this.btnTrialF1.Text = "F1";
            this.btnTrialF1.UseVisualStyleBackColor = true;
            this.btnTrialF1.Visible = false;
            this.btnTrialF1.Click += new System.EventHandler(this.btnTrialF1_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.DimGray;
            this.tableLayoutPanel1.ColumnCount = 6;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 37F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 620F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 130F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 130F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 130F));
            this.tableLayoutPanel1.Controls.Add(this.btnTrialF2, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.pnlOutFrame, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.btnClose, 5, 1);
            this.tableLayoutPanel1.Controls.Add(this.btnCsv, 4, 1);
            this.tableLayoutPanel1.Controls.Add(this.btnTrialF1, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.btnDSTSelect, 3, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1104, 561);
            this.tableLayoutPanel1.TabIndex = 9;
            // 
            // YardReproMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1104, 561);
            this.Controls.Add(this.tableLayoutPanel1);
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.MaximumSize = new System.Drawing.Size(1120, 1080);
            this.MinimumSize = new System.Drawing.Size(1120, 475);
            this.Name = "YardReproMain";
            this.Text = "(YardRepro)";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.YardReproMain_FormClosed);
            this.Shown += new System.EventHandler(this.ConnectionManager_Shown);
            this.pnlOutFrame.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlOutFrame;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnDSTSelect;
        private System.Windows.Forms.Button btnCsv;
        private System.Windows.Forms.Label lblSearching;
        private System.Windows.Forms.Button btnTrialF2;
        private System.Windows.Forms.Button btnTrialF1;
        private YardRepro.DSTStatusList dsTiList1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
    }
}