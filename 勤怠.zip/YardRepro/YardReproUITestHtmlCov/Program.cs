﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YardReproUITestHtmlCov
{
    class Program
    {
        static void Main(string[] args)
        {
            IEnumerable<string> files = System.IO.Directory.EnumerateFiles(args[0], "*.html", System.IO.SearchOption.AllDirectories);

            foreach (string f in files)
            {
                if (f.IndexOf("Index.html") > 0) continue;
                string html = System.IO.File.ReadAllText(f);
                string addhtml = Properties.Resources.addhtml;
                html = html.Replace("$('.dashboard .determinate').attr('style', 'width:' + passedPercentage);", "$('.dashboard .determinate').attr('style', 'width:' + passedPercentage);" + addhtml);
                System.IO.File.WriteAllText(f, html);
            }
        }
    }
}
