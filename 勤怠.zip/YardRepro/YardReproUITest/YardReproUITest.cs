﻿using System;
using System.Collections.Generic;
using System.Drawing;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Runtime.InteropServices;
using System.Drawing.Imaging;
using System.Linq;
using System.IO;

namespace YardReproUITest
{
    /// <summary>
    /// YardReproのUIテストクラス
    /// </summary>
    /// <remarks>
    /// <list type="table">
    /// <listheader><description>テストケース</description></listheader>
    /// <item><description>１．EXEファイル</description></item>
    /// <item><description>１．１．アイコン</description></item>
    /// <item><description>１．１．１．アイコンの外観を確認</description></item>
    /// <item><description>１．２．プロパティ</description></item>
    /// <item><description>１．２．１．ファイルプロパティを確認</description></item>
    /// <item><description>２．起動</description></item>
    /// <item><description>２．１．二重起動</description></item>
    /// <item><description>３．初期処理</description></item>
    /// <item><description>３．１．ログ</description></item>
    /// <item><description>３．１．１．出力</description></item>
    /// <item><description>３．１．１．１．EXEを起動</description></item>
    /// <item><description>３．２．DST選択画面</description></item>
    /// <item><description>３．２．１．画面レイアウト</description></item>
    /// <item><description>３．２．１．１．ウィンドウ位置</description></item>
    /// <item><description>３．２．１．２．ウィンドウタイトル</description></item>
    /// <item><description>３．２．１．３．ウィンドウ最小化ボタン</description></item>
    /// <item><description>３．２．１．４．ウィンドウ最大化ボタン</description></item>
    /// <item><description>３．２．１．５．ウィンドウ閉じるボタン</description></item>
    /// <item><description>３．２．１．６．検索メッセージ</description></item>
    /// <item><description>３．２．１．７．次へボタン</description></item>
    /// <item><description>３．３．進捗確認画面</description></item>
    /// <item><description>３．３．１．画面レイアウト</description></item>
    /// <item><description>３．３．１．１．ウィンドウ位置</description></item>
    /// <item><description>３．３．１．２．ウィンドウタイトル</description></item>
    /// <item><description>３．３．１．３．ウィンドウ最小化ボタン</description></item>
    /// <item><description>３．３．１．４．ウィンドウ最大化ボタン</description></item>
    /// <item><description>３．３．１．５．ウィンドウ閉じるボタン</description></item>
    /// <item><description>３．３．１．６．未選択メッセージ</description></item>
    /// <item><description>３．３．１．７．DST選択ボタン</description></item>
    /// <item><description>３．３．１．８．CSV出力ボタン</description></item>
    /// <item><description>３．３．１．９．閉じるボタン</description></item>
    /// <item><description>３．４．環境不備（WLAN Auto Config未起動）</description></item>
    /// <item><description>３．４．１．エラーメッセージ</description></item>
    /// <item><description>３．４．１．１．WLAN AutoConfigのサービスを停止した状態で画面を進捗確認画面表示する</description></item>
    /// <item><description>３．４．１．２．OKボタン押下</description></item>
    /// <item><description>※サービス停止→開始で再度アクセスポイントに接続する必要がある為、自動テスト化不可</description></item>
    /// <item><description>３．５．環境不備（WiFiモジュールなし）</description></item>
    /// <item><description>３．５．１．エラーメッセージ</description></item>
    /// <item><description>３．５．１．１．WiFiモジュールを無効にした状態で画面を進捗確認画面表示する</description></item>
    /// <item><description>３．５．１．２．OKボタン押下</description></item>
    /// <item><description>※WiFiモジュールの無効化は自動でできない為、自動テスト化不可</description></item>
    /// <item><description>３．６．その他エラー</description></item>
    /// <item><description>３．６．１．エラーメッセージ</description></item>
    /// <item><description>３．６．１．１．その他エラーが発生する状態で画面を進捗確認画面表示する</description></item>
    /// <item><description>３．６．１．２．OKボタン押下</description></item>
    /// <item><description>３．７．ini</description></item>
    /// <item><description>３．７．１．出力</description></item>
    /// <item><description>３．７．１．１．EXE直下に「yardrepro.ini」ファイルが作成される</description></item>
    /// <item><description>３．７．１．２．DTCログファイル保存先指定あり</description></item>
    /// <item><description>３．７．１．３．DTCログファイル保存先指定なし</description></item>
    /// <item><description>３．７．１．４．DTCログファイル保存先無効</description></item>
    /// <item><description>※その他エラーが自動では発生されられない為、自動テスト化不可</description></item>
    /// <item><description>４．DST選択画面</description></item>
    /// <item><description>４．１．DST-WiFi検出</description></item>
    /// <item><description>４．１．１．DST-WiFi1台ONの状態で起動</description></item>
    /// <item><description>４．１．２．DST-WiFi6台ONの状態で起動</description></item>
    /// <item><description>４．１．３．DST-WiFi6台OFFの状態で起動し、起動後にDST-WiFi6台ONにする</description></item>
    /// <item><description>４．１．４．DST-WiFi6台ON中の1台をOFFにする</description></item>
    /// <item><description>４．１．５．OFFにした1台をONにする</description></item>
    /// <item><description>４．１．６．DST-WiFi6台ON中の1台をOFFにして14秒以内にONにする</description></item>
    /// <item><description>４．２．リスト選択チェック</description></item>
    /// <item><description>４．２．１．選択を１つチェック</description></item>
    /// <item><description>４．２．２．選択を複数チェック</description></item>
    /// <item><description>４．２．３．選択をすべて外す</description></item>
    /// <item><description>４．２．４．選択を１つチェックし、選択したDST-WiFiをOFFにする</description></item>
    /// <item><description>４．２．５．選択を複数チェックし、選択したDST-WiFiをOFFにする</description></item>
    /// <item><description>４．３．次へボタン</description></item>
    /// <item><description>４．３．１．選択１つ選択</description></item>
    /// <item><description>４．３．２．選択を複数選択</description></item>
    /// <item><description>４．３．３．選択を６つ選択</description></item>
    /// <item><description>４．３．４．OKボタン押下</description></item>
    /// <item><description>４．４．進捗確認画面からの再表示</description></item>
    /// <item><description>４．４．１．選択１つ選択し次へボタンを押下し進捗画面遷移後にDST選択ボタン押下</description></item>
    /// <item><description>４．４．２．DST-WiFiを１台ONにする</description></item>
    /// <item><description>４．５．閉じるボタン</description></item>
    /// <item><description>４．５．１．選択を変更して閉じる</description></item>
    /// <item><description>５．進捗確認画面</description></item>
    /// <item><description>５．１．リスト、未選択メッセージ、CSV出力ボタン</description></item>
    /// <item><description>５．１．１．DST選択画面がWiFiを選択１つ選択し次へ押下</description></item>
    /// <item><description>５．２．リスト更新処理</description></item>
    /// <item><description>５．２．１．リストレイアウト</description></item>
    /// <item><description>５．２．１．１．リプロツール情報</description></item>
    /// <item><description>５．２．１．２．Vin</description></item>
    /// <item><description>５．２．１．３．リプロ状況</description></item>
    /// <item><description>５．２．１．４．リプロ</description></item>
    /// <item><description>５．２．１．５．リトライボタン</description></item>
    /// <item><description>５．２．２．ステータス取得中 10%→50%→100% ポーリング停止</description></item>
    /// <item><description>５．２．２．１．ステータス取得の返却値を変更(処理結果:0/進捗:10)</description></item>
    /// <item><description>５．２．２．２．ステータス取得の返却値を変更(処理結果:0/進捗:50)</description></item>
    /// <item><description>５．２．２．３．ステータス取得の返却値を変更(処理結果:0/進捗:100)</description></item>
    /// <item><description>５．２．２．４．ステータス取得の返却値を変更(処理結果:0/進捗:50)</description></item>
    /// <item><description>５．２．３．ステータス取得中 50%→エラー ポーリング停止</description></item>
    /// <item><description>５．２．３．１．ステータス取得の返却値を変更(処理結果:1/進捗:0)</description></item>
    /// <item><description>５．２．３．２．ステータス取得の返却値を変更(処理結果:2/進捗:0)</description></item>
    /// <item><description>５．２．３．３．ステータス取得の返却値を変更(処理結果:3/進捗:0)</description></item>
    /// <item><description>５．２．３．４．ステータス取得の返却値を変更(処理結果:4/進捗:0)</description></item>
    /// <item><description>５．２．３．５．ステータス取得の返却値を変更(処理結果:5/進捗:0)</description></item>
    /// <item><description>５．２．３．６．ステータス取得の返却値を変更(処理結果:6/進捗:0)</description></item>
    /// <item><description>５．２．３．７．ステータス取得の返却値を変更(処理結果:7/進捗:0)</description></item>
    /// <item><description>５．２．３．８．ステータス取得の返却値を変更(処理結果:8/進捗:0)</description></item>
    /// <item><description>５．２．４．ステータス取得中 切断(ポーリング継続) ポーリング停止</description></item>
    /// <item><description>５．２．４．１．ステータス取得の返却値を変更(返却エラー)</description></item>
    /// <item><description>５．２．４．２．切断表示後、ステータス取得の返却値を変更(処理結果:0/進捗:50)</description></item>
    /// <item><description>５．２．７．リプロ前</description></item>
    /// <item><description>５．２．７．１．ステータス取得の返却値を変更(処理結果:0/進捗:0) VIN取得情報処理結果:0 リプロ前ソフト品番処理結果:0</description></item>
    /// <item><description>５．２．７．２．ステータス取得の返却値を変更(処理結果:0/進捗:0) VIN取得情報処理結果:1 リプロ前ソフト品番処理結果:0</description></item>
    /// <item><description>５．２．７．３．ステータス取得の返却値を変更(処理結果:0/進捗:0) VIN取得情報処理結果:0 リプロ前ソフト品番処理結果:1</description></item>
    /// <item><description>５．２．７．４．ステータス取得の返却値を変更(処理結果:0/進捗:0) VIN取得情報処理結果:1 リプロ前ソフト品番処理結果:1</description></item>
    /// <item><description>５．２．７．５．ステータス取得の返却値を変更(処理結果:0/進捗:0) VIN取得情報処理結果:0 リプロ前ソフト品番処理結果:0が複数</description></item>
    /// <item><description>５．２．５．リプロ完了時</description></item>
    /// <item><description>５．２．５．１．ステータス取得の返却値を変更(処理結果:0/進捗:100) ソフト品番処理結果:0</description></item>
    /// <item><description>５．２．５．３．ステータス取得の返却値を変更(処理結果:0/進捗:100) ソフト品番処理結果:1</description></item>
    /// <item><description>５．２．６．リトライボタン</description></item>
    /// <item><description>５．２．６．１．リトライ要求の返却値を変更(処理結果:0) ステータス取得の返却値を変更(処理結果:0/進捗:0→リトライボタン押下→50)</description></item>
    /// <item><description>５．２．６．２．リトライ要求の返却値を変更(処理結果:1)</description></item>
    /// <item><description>５．２．８．DTC消去</description></item>
    /// <item><description>５．２．８．１．ステータス取得の返却値を変更(処理結果:0/進捗:100) P-DTC消去操作済みチェックをチェック済にする P-DTC消去操作済みチェックを未チェックにする</description></item>
    /// <item><description>５．２．８．２．後処理開始要求処理結果:0 後処理結果要求の受信タイムアウト値:10秒 後処理応答フレームの遅延:9秒
    ///                                    ログファイル出力先:C:\Users\カレントユーザ\Yardrepro 
    ///                                    ログファイル取得要求の返却値を変更(処理結果:0/データ長:505/残りデータサイズ:0)</description></item>
    /// <item><description>５．２．８．３．後処理開始要求処理結果:1 後処理結果要求の受信タイムアウト値:10秒 後処理応答フレームの遅延:9秒
    /// <item><description>５．２．８．４．後処理開始要求処理結果:0 後処理結果要求の受信タイムアウト値:10秒 後処理応答フレームの遅延:11秒
    /// <item><description>５．２．８．５．後処理開始要求処理結果:0 後処理結果要求の受信タイムアウト値:10秒 後処理応答フレームの遅延:9秒
    ///                                    ログファイル出力先:C:\Users\カレントユーザ\Yardrepro 
    ///                                    ログファイル取得要求の返却値を変更(処理結果:1/データ長:0/残りデータサイズ:0)</description></item>
    /// <item><description>５．２．８．６．後処理開始要求処理結果:0 後処理結果要求の受信タイムアウト値:10秒 後処理応答フレームの遅延:9秒
    ///                                    ログファイル出力先:C:\Users\カレントユーザ\Yardrepro 
    ///                                    ログファイル取得要求の返却値を変更(１回目：処理結果:0/データ長:505/残りデータサイズ:1)</description></item>
    ///                                    ログファイル取得要求の返却値を変更(２回目：処理結果:0/データ長:5/残りデータサイズ:0)
    /// <item><description>５．２．８．７．後処理開始要求処理結果:0 後処理結果要求の受信タイムアウト値:10秒 後処理応答フレームの遅延:9秒
    ///                                    ログファイル出力先:C:\Users\カレントユーザ\Yardrepro 
    ///                                    ログファイル取得要求の返却値を変更(１回目：処理結果:0/データ長:505/残りデータサイズ:501)</description></item>
    ///                                    ログファイル取得要求の返却値を変更(２回目：処理結果:0/データ長:505/残りデータサイズ:0)
    /// <item><description>５．２．８．８．後処理開始要求処理結果:0 後処理結果要求の受信タイムアウト値:10秒 後処理応答フレームの遅延:9秒
    ///                                    ログファイル出力先:C:\Users\カレントユーザ\Yardrepro 
    ///                                    ログファイル取得要求の返却値を変更(１回目：処理結果:0/データ長:505/残りデータサイズ:501)</description></item>
    ///                                    サーバ停止（通信切断）
    /// <item><description>５．２．８．９．後処理開始要求処理結果:0 後処理結果要求の受信タイムアウト値:10秒 後処理応答フレームの遅延:9秒
    ///                                    ログファイル出力先:C:\Users\カレントユーザ\Yardrepro 
    ///                                    ログファイル取得要求の返却値を変更(１回目：処理結果:0/データ長:505/残りデータサイズ:501)</description></item>
    ///                                    サーバ停止（通信切断）
    ///                                    ログファイル取得要求の返却値を変更(１回目：処理結果:0/データ長:505/残りデータサイズ:501)</description></item>
    ///                                    ログファイル取得要求の返却値を変更(２回目：処理結果:0/データ長:505/残りデータサイズ:0)
    /// <item><description>５．２．９．リプロ差替え</description></item>
    /// <item><description>５．２．９．１．VIN変更無</description></item>
    /// <item><description>５．２．９．２．リプロツール差替え中（接続エラー）</description></item>
    /// <item><description>５．２．９．３．ステータス取得の返却値を変更(処理結果:0/進捗:0) VIN取得情報処理結果:0/VIN:VIN000000000000011</description></item>
    /// <item><description>５．２．９．４．ステータス取得の返却値を変更(処理結果:0/進捗:50)</description></item>
    /// <item><description>５．３．DST選択ボタン</description></item>
    /// <item><description>５．３．１．DST選択ボタンをクリック</description></item>
    /// <item><description>５．３．２．選択チェックを追加して次へをクリック</description></item>
    /// <item><description>５．３．３．選択チェックを外して次へをクリック</description></item>
    /// <item><description>５．３．４．表示順（リプロ開始日時の降順）</description></item>
    /// <item><description>５．３．５．リプロツール差替え済み情報の削除不可</description></item>
    /// <item><description>５．４．CSVボタン</description></item>
    /// <item><description>５．４．１．保存ダイアログ</description></item>
    /// <item><description>５．４．１．１．保存ダイアログ</description></item>
    /// <item><description>５．４．１．２．タイトル</description></item>
    /// <item><description>５．４．１．３．フィルタ</description></item>
    /// <item><description>５．４．１．４．ファイル種別</description></item>
    /// <item><description>５．４．１．５．デフォルトファイル名</description></item>
    /// <item><description>５．４．１．６．上書き確認</description></item>
    /// <item><description>５．４．２．CSVファイル</description></item>
    /// <item><description>５．４．２．１．保存先</description></item>
    /// <item><description>５．４．２．２．ヘッダ</description></item>
    /// <item><description>５．４．２．３．フォーマット</description></item>
    /// <item><description>５．４．２．４．内容</description></item>
    /// <item><description>５．４．２．５．エンコード</description></item>
    /// <item><description>５．５．閉じるボタン</description></item>
    /// <item><description>５．５．１．閉じるボタンクリック</description></item>
    /// </list>
    /// </remarks>

    [CodedUITest]
    public class YardReproUITest
    {
        // 画面キャプチャ用
        private struct RECT
        {
            public int left;
            public int top;
            public int right;
            public int bottom;
        }
        [DllImport("User32.Dll")]
        static extern int GetWindowRect(IntPtr hWnd, out RECT rect);
        [DllImport("user32.dll")]
        extern static IntPtr GetForegroundWindow();

        // Simulator設定リクエスト構造体
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
        public struct SimulatorSettingRequest
        {
            // 機能 0:IPアドレスリスト取得 1:InIの更新 2:サーバ開始 3:サーバ停止
            public byte function;
            // セクション64バイト
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 64)]
            public string section;
            // パラメータキー64バイト
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 64)]
            public string key;
            // パラメータ値データ5120バイト
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 5120)]
            public string value;
        }

        // Simulator設定レスポンス構造体
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
        public struct SimulatorSettingResponse
        {
            // 実行結果 0:正常
            public byte status;
            // アドレスリスト128バイト
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)]
            public string addressList;
        }

        // キャプチャ保管場所
        private const string CAPTURE_DIR = @"..\..\capture";
        // workディレクトリ
        private const string WORK_DIRECTORY = @"..\..\..\YardRepro\bin\Release";
        // DSTWiFiSimulator.exe保管場所
        private const string SIM_EXE_PATH = WORK_DIRECTORY + @"\DSTWiFiSimulator.exe";
        // YardRepro.exe保管場所
        private const string YARDREPRO_EXE_PATH = WORK_DIRECTORY + @"\YardRepro.exe";

        public YardReproUITest()
        {
        }

        /// <summary>
        /// クラス実施前処理
        /// </summary>
        /// <param name="testContext"></param>
        [ClassInitialize()]
        public static void MyClassInitialize(TestContext testContext)
        {
            // キャプチャ画像保管フォルダ作成
            if (System.IO.Directory.Exists(CAPTURE_DIR))
            {
                //System.IO.Directory.Delete(CAPTURE_DIR, true);
            }
            System.IO.Directory.CreateDirectory(CAPTURE_DIR);
        }

        /// <summary>
        /// テスト実行前処理 
        /// </summary>
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}

        /// <summary>
        /// テスト実行後処理 
        /// </summary>
        [TestCleanup()]
        public void MyTestCleanup()
        {
            endSimulator();
            endYardRepro();
            endCaptureHtml();
            System.Threading.Thread.Sleep(2000);
        }

        /// <summary>
        /// Simulator.exe起動
        /// </summary>
        private void startSimulator()
        {
            System.Diagnostics.ProcessStartInfo hPsInfo = new System.Diagnostics.ProcessStartInfo();
            hPsInfo.FileName = SIM_EXE_PATH;
            hPsInfo.WorkingDirectory = WORK_DIRECTORY;
            hPsInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Minimized;
            System.Diagnostics.Process.Start(hPsInfo);
            System.Threading.Thread.Sleep(5000);
        }

        /// <summary>
        /// YardRepro.exe起動
        /// </summary>
        private void startYardRepro()
        {
            System.Diagnostics.ProcessStartInfo hPsInfo = new System.Diagnostics.ProcessStartInfo();
            hPsInfo.FileName = YARDREPRO_EXE_PATH;
            hPsInfo.WorkingDirectory = WORK_DIRECTORY;
            System.Diagnostics.Process.Start(hPsInfo);
            System.Threading.Thread.Sleep(4000);
        }

        /// <summary>
        /// Simulator.exe終了
        /// </summary>
        private void endSimulator()
        {
            System.Diagnostics.Process[] ps = System.Diagnostics.Process.GetProcessesByName("DSTWiFiSimulator");

            foreach (System.Diagnostics.Process p in ps)
            {
                p.Kill();
            }
        }

        /// <summary>
        /// YardRepro.exe終了
        /// </summary>
        private void endYardRepro()
        {
            System.Diagnostics.Process[] ps = System.Diagnostics.Process.GetProcessesByName("YardRepro");

            foreach (System.Diagnostics.Process p in ps)
            {
                p.Kill();
            }
        }

        /// <summary>
        /// iniファイル操作（Simulator）
        /// </summary>
        /// <param name="sendAddres">送信先IPアドレス(自PCで動かす場合はlocalhost)</param>
        /// <param name="func">機能 0:IPアドレスリスト取得 1:InIの更新 2:サーバ開始 3:サーバ停止</param>
        /// <param name="section">iniセクション名</param>
        /// <param name="key">iniキー名</param>
        /// <param name="value">iniバリュー名</param>
        /// <returns></returns>
        private SimulatorSettingResponse udpIniUpdateSend(string sendAddres, byte func, string section, string key, string value)
        {
            SimulatorSettingRequest senddata = new SimulatorSettingRequest();
            senddata.function = func;
            senddata.section = section;
            senddata.key = key;
            senddata.value = value;

            byte[] bytes = new byte[Marshal.SizeOf(senddata)];
            GCHandle gch = GCHandle.Alloc(bytes, GCHandleType.Pinned);
            Marshal.StructureToPtr(senddata, gch.AddrOfPinnedObject(), false);
            gch.Free();

            //UdpClientオブジェクトを作成する
            using (System.Net.Sockets.UdpClient udp = new System.Net.Sockets.UdpClient())
            {
                //リモートホストを指定してデータを送信する
                udp.Send(bytes, bytes.Length, sendAddres, 60801);
                // 受信
                System.Net.IPEndPoint remoteEP = null;
                byte[] buffBytes = udp.Receive(ref remoteEP);

                SimulatorSettingResponse ret = new SimulatorSettingResponse();
                GCHandle resgch = GCHandle.Alloc(buffBytes, GCHandleType.Pinned);
                ret = (SimulatorSettingResponse)Marshal.PtrToStructure(resgch.AddrOfPinnedObject(), typeof(SimulatorSettingResponse));
                resgch.Free();

                return ret;
            }
        }

        /// <summary>
        /// SimulatorのIPアドレスリスト取得
        /// </summary>
        /// <returns>IPアドレスリスト</returns>
        private string[] getIpAddressList()
        {
            // IPアドレスリスト取得
            SimulatorSettingResponse ipStr = udpIniUpdateSend("localhost", byte.Parse("0"), null, null, null);
            string[] iplist = ipStr.addressList.Split(',');
            return iplist;
        }

        /// <summary>
        /// UIMapの初期化
        /// </summary>
        private void refreshMap()
        {
            this.map = null;
        }

        /// <summary>
        /// 画面キャプチャ
        /// </summary>
        /// <param name="index">ファイル名連番</param>
        /// <param name="capStr">キャプチャ画像説明文</param>
        private void capture(int index, string capStr)
        {
            System.Threading.Thread.Sleep(500);
            RECT r;
            IntPtr active = GetForegroundWindow();
            GetWindowRect(active, out r);
            Rectangle rect = new Rectangle(r.left, r.top, r.right - r.left, r.bottom - r.top);
            Bitmap bmp = new Bitmap(rect.Width, rect.Height, PixelFormat.Format32bppArgb);

            using (Graphics g = Graphics.FromImage(bmp))
            {
                g.CopyFromScreen(rect.X, rect.Y, 0, 0, rect.Size, CopyPixelOperation.SourceCopy);
            }

            bmp.Save(CAPTURE_DIR + "\\" + this.TestContext.TestName + "-" + index.ToString() + ".png", ImageFormat.Png);

            if (!System.IO.File.Exists(CAPTURE_DIR + "\\" + this.TestContext.TestName + ".html"))
            {
                using (var sw = new System.IO.StreamWriter(CAPTURE_DIR + "\\" + this.TestContext.TestName + ".html", false))
                {
                    sw.WriteLine("<html><head><title>{0}</title></head><body><h1>{1}</h1><table>", this.TestContext.TestName, this.TestContext.TestName);
                }
            }
            using (var sw = new System.IO.StreamWriter(CAPTURE_DIR + "\\" + this.TestContext.TestName + ".html", true))
            {
                sw.WriteLine("<tr><td>{0}</td></tr><tr><td><img src = \"{1}\" onClick=window.open('{2}')></td></tr>", capStr, this.TestContext.TestName + "-" + index.ToString() + ".png", this.TestContext.TestName + "-" + index.ToString() + ".png");
            }
        }

        /// <summary>
        /// 画面キャプチャhtmlエンド
        /// </summary>
        private void endCaptureHtml()
        {
            if (System.IO.File.Exists(CAPTURE_DIR + "\\" + this.TestContext.TestName + ".html"))
            {
                using (var sw = new System.IO.StreamWriter(CAPTURE_DIR + "\\" + this.TestContext.TestName + ".html", true))
                {
                    sw.WriteLine("</table></html>");
                }
            }
        }

        /// <summary>
        /// １．EXEファイル<br>
        /// １．１．アイコン<br>
        /// １．１．１．アイコンの外観を確認<br>
        /// １．２．プロパティ<br>
        /// １．２．１．ファイルプロパティを確認<br>
        /// </summary>
        [TestMethod]
        public void TestMethod1_1_1()
        {
            // エクスプローラ表示
            System.Diagnostics.Process.Start("EXPLORER.EXE", @"/select,""" + System.IO.Path.GetFullPath(YARDREPRO_EXE_PATH) + @"""");
            // 表示されるまで待つ
            System.Threading.Thread.Sleep(2000);
            capture(1, "YardRepro.exeアイコン確認");
            // YardRepro.exeのプロパティを開く
            this.UIMap.yardReproPropertyOpen();
            // プロパティ確認
            this.UIMap.AssertMethod1_1_1_Assert1();
            capture(2, "YardRepro.exeバージョン情報確認");
            // プロパティ、エクスプローラを閉じる
            this.UIMap.yardReproPropertyClose();
            this.UIMap.explorerClose();
        }

        /// <summary>
        /// ２．起動<br>
        /// ２．１．二重起動<br>
        /// </summary>
        [TestMethod]
        public void TestMethod2_1()
        {
            // YardRepro起動
            startYardRepro();
            System.Threading.Thread.Sleep(3000);
            // YardRepro起動
            startYardRepro();
            capture(1, "二重起動後画面確認");
            // プロセスが複数存在しないことを確認
            System.Diagnostics.Process[] ps = System.Diagnostics.Process.GetProcessesByName("YardRepro");
            Assert.AreEqual(1, ps.Length);
        }

        /// <summary>
        /// ３．初期処理<br>
        /// ３．１．ログ<br>
        /// ３．１．１．出力<br>
        /// ３．１．１．１．EXEを起動<br>
        /// </summary>
        [TestMethod]
        public void TestMethod3_1_1_1()
        {
            string logDirPath = WORK_DIRECTORY + @"\Log";
            // logディレクトリ削除
            if (System.IO.Directory.Exists(logDirPath))
            {
                System.IO.Directory.Delete(logDirPath, true);
            }
            // YardRepro起動
            startYardRepro();
            System.Threading.Thread.Sleep(3000);
            capture(1, "YardRepro起動");
            System.Diagnostics.Process.Start("EXPLORER.EXE", @"/select,""" + System.IO.Path.GetFullPath(logDirPath) + @"""");
            System.Threading.Thread.Sleep(2000);
            capture(2, "Logフォルダ確認");
            // logディレクトリ表示
            this.UIMap.enterKeyDown();
            capture(3, "YardRepro.logファイル確認");
            this.UIMap.explorerClose();
            System.Threading.Thread.Sleep(2000);
            // log表示
            System.Diagnostics.Process p = System.Diagnostics.Process.Start("notepad.exe", System.IO.Path.GetFullPath(logDirPath + @"\YardRepro.log"));
            System.Threading.Thread.Sleep(2000);
            capture(4, "YardRepro.log確認");
            p.Kill();
            // 開始ログ出力確認
            List<string> lines = new List<string>();
            using (FileStream fs = new FileStream(logDirPath + @"\YardRepro.log", FileMode.Open, FileAccess.Read))
            {
                using (TextReader reader = new StreamReader(fs))
                {
                    while (reader.Peek() >= 0)
                    {
                        lines.Add(reader.ReadLine());
                    }
                }
            }
            Assert.IsTrue(lines[1].Contains("YardRepro.YardReproMain..ctor - START"));
        }

        /// <summary>
        /// ３．初期処理<br>
        /// ３．７．INI<br>
        /// ３．７．１．出力<br>
        /// ３．７．１．１．EXEを起動<br>
        /// </summary>
        [TestMethod]
        public void TestMethod3_7_1_1()
        {
            string iniFilePath = WORK_DIRECTORY + @"\YardRepro.ini";
            // iniファイル削除
            if (System.IO.File.Exists(iniFilePath))
            {
                System.IO.File.Delete(iniFilePath);
            }
            // YardRepro起動
            startYardRepro();
            System.Threading.Thread.Sleep(3000);
            capture(1, "YardRepro起動");
            // ini表示
            System.Diagnostics.Process p = System.Diagnostics.Process.Start("notepad.exe", System.IO.Path.GetFullPath(iniFilePath));
            System.Threading.Thread.Sleep(2000);
            capture(2, "YardRepro.ini確認");
            p.Kill();
            // ini出力確認
            List<string> lines = new List<string>();
            using (FileStream fs = new FileStream(iniFilePath, FileMode.Open, FileAccess.Read))
            {
                using (TextReader reader = new StreamReader(fs))
                {
                    while (reader.Peek() >= 0)
                    {
                        lines.Add(reader.ReadLine());
                    }
                }
            }
            Assert.AreEqual("[LOG_FILE]", lines[0]);
            Assert.AreEqual("TIMEOUT=10", lines[1]);
            Assert.AreEqual("SAVE_FOLDER=" + System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + @"\YardRepro", lines[2]);
        }

        /// <summary>
        /// ３．初期処理<br>
        /// ３．７．INI<br>
        /// ３．７．１．DTCログファイル保存先<br>
        /// ３．７．１．２．EXEを起動<br>
        /// </summary>
        [TestMethod]
        public void TestMethod3_7_1_2()
        {
            string iniFilePath = WORK_DIRECTORY + @"\YardRepro.ini";
            // [yardrepro.ini]を読込み設定値を取得する
            Ini ini = new Ini(iniFilePath);
            string logDirPath = WORK_DIRECTORY + @"\YardRepro";
            ini["LOG_FILE", "SAVE_FOLDER"] = logDirPath;
            // logディレクトリ削除
            if (System.IO.Directory.Exists(logDirPath))
            {
                System.IO.Directory.Delete(logDirPath, true);
            }
            // YardRepro起動
            startYardRepro();
            System.Threading.Thread.Sleep(3000);
            capture(1, "YardRepro起動");
            // ini表示
            System.Diagnostics.Process p = System.Diagnostics.Process.Start("notepad.exe", System.IO.Path.GetFullPath(iniFilePath));
            System.Threading.Thread.Sleep(2000);
            capture(2, "iniファイル確認");
            p.Kill();
            // logディレクトリ表示
            System.Diagnostics.Process.Start("EXPLORER.EXE", @"/select,""" + System.IO.Path.GetFullPath(ini["LOG_FILE", "SAVE_FOLDER"]) + @"""");
            System.Threading.Thread.Sleep(2000);
            capture(3, "Logフォルダ確認");
            // logディレクトリ表示
            this.UIMap.enterKeyDown();
            capture(4, "YardRepro_DTC.logファイル確認");
            this.UIMap.explorerClose();
        }

        /// <summary>
        /// ３．初期処理<br>
        /// ３．７．INI<br>
        /// ３．７．１．DTCログファイル保存先<br>
        /// ３．７．１．３．iniファイルのSAVE_FOLDERに不正フォルダを指定 EXEを起動<br>
        /// </summary>
        [TestMethod]
        public void TestMethod3_7_1_3()
        {
            string iniFilePath = WORK_DIRECTORY + @"\YardRepro.ini";
            // [yardrepro.ini]を読込み設定値を取得する
            Ini ini = new Ini(iniFilePath);
            string logDirPath = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + @"\YardRepro";
            // iniファイルのSAVE_FOLDERに何も設定しない
            ini["LOG_FILE", "SAVE_FOLDER"] = "";
            // logディレクトリ削除
            if (System.IO.Directory.Exists(logDirPath))
            {
                System.IO.Directory.Delete(logDirPath, true);
            }
            System.Threading.Thread.Sleep(1000);
            // YardRepro起動
            startYardRepro();
            System.Threading.Thread.Sleep(3000);
            capture(1, "YardRepro起動");
            // ini表示
            System.Diagnostics.Process p = System.Diagnostics.Process.Start("notepad.exe", System.IO.Path.GetFullPath(iniFilePath));
            System.Threading.Thread.Sleep(2000);
            capture(2, "iniファイル確認");
            p.Kill();
            // logディレクトリ表示
            System.Diagnostics.Process.Start("EXPLORER.EXE", @"/select,""" + System.IO.Path.GetFullPath(ini["LOG_FILE", "SAVE_FOLDER"]) + @"""");
            System.Threading.Thread.Sleep(2000);
            capture(3, "Logフォルダ確認");
            endYardRepro();
            this.UIMap.explorerClose_MyDocuments();
        }

        /// <summary>
        /// ３．初期処理<br>
        /// ３．７．INI<br>
        /// ３．７．１．DTCログファイル保存先<br>
        /// ３．７．１．４．iniファイルのSAVE_FOLDERに「C:\Program Files」を指定 EXEを起動<br>
        /// </summary>
        [TestMethod]
        public void TestMethod3_7_1_4()
        {
            string iniFilePath = WORK_DIRECTORY + @"\YardRepro.ini";
            // [yardrepro.ini]を読込み設定値を取得する
            Ini ini = new Ini(iniFilePath);
            string logDirPath = @"C:\Program Files\YardRepro";
            // SAVE_FOLDERに「C:\Program Files\YardRepro」を指定
            ini["LOG_FILE", "SAVE_FOLDER"] = logDirPath;
            // ini表示
            System.Diagnostics.Process q = System.Diagnostics.Process.Start("notepad.exe", System.IO.Path.GetFullPath(iniFilePath));
            System.Threading.Thread.Sleep(2000);
            capture(1, "iniファイル確認 - Program Files配下（アクセス権無）");
            q.Kill();
            // YardRepro起動
            startYardRepro();
            System.Threading.Thread.Sleep(3000);
            capture(2, "YardRepro起動");
            // ini表示
            System.Diagnostics.Process p = System.Diagnostics.Process.Start("notepad.exe", System.IO.Path.GetFullPath(iniFilePath));
            System.Threading.Thread.Sleep(2000);
            capture(3, "iniファイル確認 - 保存先変更");
            p.Kill();
            // logディレクトリ表示
            System.Diagnostics.Process.Start("EXPLORER.EXE", @"/select,""" + System.IO.Path.GetFullPath(ini["LOG_FILE", "SAVE_FOLDER"]) + @"""");
            System.Threading.Thread.Sleep(2000);
            capture(4, "Logフォルダ確認");
            endYardRepro();
            this.UIMap.explorerClose_MyDocuments();
        }

        /// <summary>
        /// ３．初期処理<br>
        /// ３．２．DST選択画面<br>
        /// ３．２．１．画面レイアウト<br>
        /// ３．２．１．１．ウィンドウ位置<br>
        /// ３．２．１．２．ウィンドウタイトル<br>
        /// ３．２．１．３．ウィンドウ最小化ボタン<br>
        /// ３．２．１．４．ウィンドウ最大化ボタン<br>
        /// ３．２．１．５．ウィンドウ閉じるボタン<br>
        /// ３．２．１．６．検索メッセージ<br>
        /// ３．２．１．７．次へボタン<br>
        /// </summary>
        [TestMethod]
        public void TestMethod3_2_1_1()
        {
            // YardRepro起動
            startYardRepro();
            // ボタン、メッセージ確認
            this.UIMap.AssertMethod3_2_1_1_Assert1();
            capture(1, "DST選択画面確認");
        }

        /// <summary>
        /// ３．初期処理<br>
        /// ３．３．進捗確認画面<br>
        /// ３．３．１．画面レイアウト<br>
        /// ３．３．１．１．ウィンドウ位置<br>
        /// ３．３．１．２．ウィンドウタイトル<br>
        /// ３．３．１．３．ウィンドウ最小化ボタン<br>
        /// ３．３．１．４．ウィンドウ最大化ボタン<br>
        /// ３．３．１．５．ウィンドウ閉じるボタン<br>
        /// ３．３．１．６．未選択メッセージ<br>
        /// ３．３．１．７．DST選択ボタン<br>
        /// ３．３．１．８．CSV出力ボタン<br>
        /// ３．３．１．９．閉じるボタン<br>
        /// </summary>
        [TestMethod]
        public void TestMethod3_3_1_1()
        {
            // YardRepro起動
            startYardRepro();
            capture(1, "YardRepro起動");
            // DST選択画面閉じる
            this.UIMap.dstWindowClose();
            // ボタン、メッセージ確認
            this.UIMap.AssertMethod3_3_1_1_Assert1();
            capture(2, "進捗確認画面確認");
        }

        /// <summary>
        /// ４．DST選択画面<br>
        /// ４．１．DST-WiFi検出<br>
        /// ４．１．１．DST-WiFi1台ONの状態で起動<br>
        /// </summary>
        [TestMethod]
        public void TestMethod4_1_1()
        {
            // Simulator起動
            startSimulator();
            // SimulatorのIPアドレス取得
            string[] ips = getIpAddressList();
            // 1台以外停止させる
            foreach (var ip in ips.Select((v, i) => new {v, i}))
            {
                if (ip.i == 0)
                {
                    continue;
                }
                udpIniUpdateSend("localhost", byte.Parse("3"), ip.v, null, null);
            }
            // YardRepro起動
            startYardRepro();
            // リスト確認
            this.UIMap.AssertMethod4_1_1_Assert1();
            this.UIMap.AssertMethod4_1_1_ListAssert();
            capture(1, "DST選択画面確認");
        }

        /// <summary>
        /// ４．DST選択画面<br>
        /// ４．１．DST-WiFi検出<br>
        /// ４．１．２．DST-WiFi6台ONの状態で起動<br>
        /// </summary>
        [TestMethod]
        public void TestMethod4_1_2()
        {
            // Simulator起動
            startSimulator();
            // YardRepro起動
            startYardRepro();
            // リスト確認
            this.UIMap.AssertMethod4_1_2_Assert1();
            this.UIMap.AssertMethod4_1_2_ListAssert();
            capture(1, "DST選択画面確認");
        }

        /// <summary>
        /// ４．DST選択画面<br>
        /// ４．１．DST-WiFi検出<br>
        /// ４．１．３．DST-WiFi6台OFFの状態で起動し、起動後にDST-WiFi6台ONにする<br>
        /// </summary>
        [TestMethod]
        public void TestMethod4_1_3()
        {
            // Simulator起動
            startSimulator();
            // SimulatorのIPアドレス取得
            string[] ips = getIpAddressList();
            // 全て停止させる
            foreach (string ip in ips)
            {
                udpIniUpdateSend("localhost", byte.Parse("3"), ip, null, null);
            }
            // YardRepro起動
            startYardRepro();
            capture(1, "YardRepro起動");
            // 全て起動させる
            foreach (string ip in ips)
            {
                udpIniUpdateSend("localhost", byte.Parse("2"), ip, null, null);
            }
            // 7秒待機
            System.Threading.Thread.Sleep(7000);
            // リスト確認
            this.UIMap.AssertMethod4_1_3_Assert1();
            this.UIMap.AssertMethod4_1_3_ListAssert();
            capture(2, "6台起動後、DST選択画面確認");
        }

        /// <summary>
        /// ４．DST選択画面<br>
        /// ４．１．DST-WiFi検出<br>
        /// ４．１．４．DST-WiFi6台ON中の1台をOFFにする<br>
        /// ４．１．５．OFFにした1台をONにする<br>
        /// </summary>
        [TestMethod]
        public void TestMethod4_1_4()
        {
            // Simulator起動
            startSimulator();
            // SimulatorのIPアドレス取得
            string[] ips = getIpAddressList();
            // YardRepro起動
            startYardRepro();
            capture(1, "YardRepro起動");
            // 1台停止させる
            udpIniUpdateSend("localhost", byte.Parse("3"), ips[0], null, null);
            // 13秒待機
            System.Threading.Thread.Sleep(13000);
            // リスト確認
            this.UIMap.AssertMethod4_1_4_Assert1();
            this.UIMap.AssertMethod4_1_4_ListAssert1();
            capture(2, "停止後、13秒経過");
            // 8秒待機
            System.Threading.Thread.Sleep(8000);
            // リスト確認
            this.UIMap.AssertMethod4_1_4_Assert2();
            this.UIMap.AssertMethod4_1_4_ListAssert2();
            capture(3, "停止後、21秒経過");
            // 1台開始させる
            udpIniUpdateSend("localhost", byte.Parse("2"), ips[0], null, null);
            // 7秒待機
            System.Threading.Thread.Sleep(7000);
            // リスト確認
            this.UIMap.AssertMethod4_1_4_Assert1();
            this.UIMap.AssertMethod4_1_4_ListAssert1();
            capture(4, "起動後、7秒経過");
        }

        /// <summary>
        /// ４．DST選択画面<br>
        /// ４．１．DST-WiFi検出<br>
        /// ４．１．６．DST-WiFi6台ON中の1台をOFFにして14秒以内にONにする<br>
        /// </summary>
        [TestMethod]
        public void TestMethod4_1_6()
        {
            // Simulator起動
            startSimulator();
            // SimulatorのIPアドレス取得
            string[] ips = getIpAddressList();
            // YardRepro起動
            startYardRepro();
            capture(1, "YardRepro起動");
            // 1台停止させる
            udpIniUpdateSend("localhost", byte.Parse("3"), ips[0], null, null);
            // 10秒待機
            System.Threading.Thread.Sleep(10000);
            // 1台開始させる
            udpIniUpdateSend("localhost", byte.Parse("2"), ips[0], null, null);
            // 21秒待機
            System.Threading.Thread.Sleep(21000);
            // リスト確認
            this.UIMap.AssertMethod4_1_6_Assert1();
            capture(2, "停止→起動し21秒経過");
        }

        /// <summary>
        /// ４．DST選択画面<br>
        /// ４．２．リスト選択チェック<br>
        /// ４．２．１．選択を１つチェック<br>
        /// ４．２．２．選択を複数チェック<br>
        /// ４．２．３．選択をすべて外す<br>
        /// </summary>
        [TestMethod]
        public void TestMethod4_2_1()
        {
            // Simulator起動
            startSimulator();
            // YardRepro起動
            startYardRepro();
            capture(1, "YardRepro起動");
            // 1台にチェックを入れる
            this.UIMap.dst1ItemSelect();
            // 次へボタン確認
            this.UIMap.AssertMethod4_2_1_Assert1();
            capture(2, "1台にチェックを入れる");
            // 6台にチェックを入れる
            this.UIMap.dstAllItemSelect();
            // 次へボタン確認
            this.UIMap.AssertMethod4_2_1_Assert1();
            capture(3, "6台にチェックを入れる");
            // 全てのチェックを外す
            this.UIMap.dstAllItemUnSelect();
            // 次へボタン確認
            this.UIMap.AssertMethod4_2_1_Assert2();
            capture(4, "全てのチェックを外す");
        }

        /// <summary>
        /// ４．DST選択画面<br>
        /// ４．２．リスト選択チェック<br>
        /// ４．２．４．選択を１つチェックし、選択したDST-WiFiをOFFにする<br>
        /// </summary>
        [TestMethod]
        public void TestMethod4_2_4()
        {
            // Simulator起動
            startSimulator();
            // SimulatorのIPアドレス取得
            string[] ips = getIpAddressList();
            // YardRepro起動
            startYardRepro();
            capture(1, "YardRepro起動");
            // 1台にチェックを入れる
            this.UIMap.dst1ItemSelect();
            // 次へボタン確認
            this.UIMap.AssertMethod4_2_4_Assert1();
            capture(2, "1台にチェックを入れる");
            // 1台停止させる
            udpIniUpdateSend("localhost", byte.Parse("3"), ips[0], null, null);
            // 22秒待機
            System.Threading.Thread.Sleep(22000);
            // リスト、次へボタン確認
            this.UIMap.AssertMethod4_2_4_Assert2();
            capture(3, "チェックを入れたデバイスを停止");
        }

        /// <summary>
        /// ４．DST選択画面<br>
        /// ４．２．リスト選択チェック<br>
        /// ４．２．５．選択を複数チェックし、選択したDST-WiFiをOFFにする<br>
        /// </summary>
        [TestMethod]
        public void TestMethod4_2_5()
        {
            // Simulator起動
            startSimulator();
            // SimulatorのIPアドレス取得
            string[] ips = getIpAddressList();
            // YardRepro起動
            startYardRepro();
            capture(1, "YardRepro起動");
            // 3台にチェックを入れる
            this.UIMap.dst3ItemSelect();
            // 次へボタン確認
            this.UIMap.AssertMethod4_2_5_Assert1();
            capture(2, "複数台にチェックを入れる");
            // 3台停止させる
            for (int i = 0; i < 3; i++)
            {
                udpIniUpdateSend("localhost", byte.Parse("3"), ips[i], null, null);
            }
            // 22秒待機
            System.Threading.Thread.Sleep(22000);
            // リスト、次へボタン確認
            this.UIMap.AssertMethod4_2_5_Assert2();
            capture(3, "チェックを入れたデバイスを停止");
        }

        /// <summary>
        /// ４．DST選択画面<br>
        /// ４．３．次へボタン<br>
        /// ４．３．１．選択１つ選択<br>
        /// </summary>
        [TestMethod]
        public void TestMethod4_3_1()
        {
            // Simulator起動
            startSimulator();
            // YardRepro起動
            startYardRepro();
            capture(1, "YardRepro起動");
            // 1台にチェックを入れる
            this.UIMap.dst1ItemSelect();
            capture(2, "1台選択し、次へボタン押下");
            // 次へボタン押下
            this.UIMap.nextBtnClick();
            // 進捗確認画面確認
            this.UIMap.AssertMethod4_3_1_Assert1();
            this.UIMap.AssertMethod4_3_1_ListAssert();
            // DST選択画面非表示確認
            this.UIMap.AssertMethod4_3_1_DisplayAssert();
            capture(3, "進捗確認画面確認");
        }

        /// <summary>
        /// ４．DST選択画面<br>
        /// ４．３．次へボタン<br>
        /// ４．３．２．選択を複数選択<br>
        /// </summary>
        [TestMethod]
        public void TestMethod4_3_2()
        {
            // Simulator起動
            startSimulator();
            // YardRepro起動
            startYardRepro();
            capture(1, "YardRepro起動");
            // 3台にチェックを入れる
            this.UIMap.dst3ItemSelect();
            capture(2, "複数台にチェックを入れ、次へボタン押下");
            // 次へボタン押下
            this.UIMap.nextBtnClick();
            // 進捗確認画面確認
            this.UIMap.AssertMethod4_3_2_Assert1();
            this.UIMap.AssertMethod4_3_2_ListAssert();
            // DST選択画面非表示確認
            this.UIMap.AssertMethod4_3_2_DisplayAssert();
            capture(3, "進捗確認画面確認");
        }

        /// <summary>
        /// ４．DST選択画面<br>
        /// ４．３．次へボタン<br>
        /// ４．３．３．選択を６つ選択<br>
        /// ４．３．４．OKボタン押下<br>
        /// </summary>
        [TestMethod]
        public void TestMethod4_3_3()
        {
            // Simulator起動
            startSimulator();
            // YardRepro起動
            startYardRepro();
            capture(1, "YardRepro起動");
            // 6台にチェックを入れる
            this.UIMap.dstAllItemSelect();
            capture(2, "6台にチェックを入れ、次へボタン押下");
            // 次へボタン押下
            this.UIMap.nextBtnClick();
            // エラーメッセージ確認
            this.UIMap.AssertMethod4_3_3_Assert1();
            capture(3, "エラーダイアログ確認");
            // エラーダイアログ閉じる
            this.UIMap.dstErrorDialogOKBtnClick();
            // DST選択画面表示確認
            this.UIMap.AssertMethod4_3_3_Assert2();
            capture(4, "エラーダイアログを閉じる");
        }

        /// <summary>
        /// ４．DST選択画面<br>
        /// ４．４．進捗確認画面からの再表示<br>
        /// ４．４．１．選択１つ選択し次へボタンを押下し進捗画面遷移後にDST選択ボタン押下<br>
        /// ４．４．２．DST-WiFiを１台ONにする<br>
        /// </summary>
        [TestMethod]
        public void TestMethod4_4_1()
        {
            // Simulator起動
            startSimulator();
            // SimulatorのIPアドレス取得
            string[] ips = getIpAddressList();
            // 1台停止させる
            udpIniUpdateSend("localhost", byte.Parse("3"), ips[1], null, null);
            // YardRepro起動
            startYardRepro();
            capture(1, "YardRepro起動");
            // 1台にチェックを入れる
            this.UIMap.dst1ItemSelect();
            capture(2, "1台選択し、次へボタン押下");
            // 次へボタン押下
            this.UIMap.nextBtnClick();
            capture(3, "進捗確認画面遷移後、DST選択ボタン押下");
            // DST選択ボタン押下
            this.UIMap.dstSelectBtnClick();
            // リスト確認
            this.UIMap.AssertMethod4_4_1_Assert1();
            capture(4, "DST選択画面確認");
            // 1台開始させる
            udpIniUpdateSend("localhost", byte.Parse("2"), ips[1], null, null);
            // 7秒待機
            System.Threading.Thread.Sleep(7000);
            // リスト確認
            this.UIMap.AssertMethod4_4_1_Assert2();
            capture(5, "1台開始後、7秒経過");
        }

        /// <summary>
        /// ４．DST選択画面<br>
        /// ４．５．閉じるボタン<br>
        /// ４．５．１．選択を変更して閉じる<br>
        /// </summary>
        [TestMethod]
        public void TestMethod4_5_1()
        {
            // Simulator起動
            startSimulator();
            // YardRepro起動
            startYardRepro();
            capture(1, "YardRepro起動");
            // 1台にチェックを入れる
            this.UIMap.dst1ItemSelect();
            capture(2, "1台選択し、次へボタン押下");
            // 次へボタン押下
            this.UIMap.nextBtnClick();
            // 進捗確認画面確認
            this.UIMap.AssertMethod4_5_1_Assert1();
            this.UIMap.AssertMethod4_5_1_ListAssert();
            capture(3, "進捗確認画面遷移後、DST選択ボタン押下");
            // DST選択ボタン押下
            this.UIMap.dstSelectBtnClick();
            // 3台にチェックを入れる
            this.UIMap.dst3ItemSelect();
            capture(4, "1台にチェックを入れ、DST選択画面を閉じる");
            // DST選択画面閉じる
            this.UIMap.dstWindowClose();
            // 進捗確認画面確認
            this.UIMap.AssertMethod4_5_1_Assert1();
            this.UIMap.AssertMethod4_5_1_ListAssert();
            capture(5, "進捗確認画面確認");
        }

        /// <summary>
        /// ５．進捗確認画面<br>
        /// ５．１．リスト、未選択メッセージ、CSV出力ボタン<br>
        /// ５．１．１．DST選択画面がWiFiを選択１つ選択し次へ押下<br>
        /// ５．２．リスト更新処理<br>
        /// ５．２．１．リストレイアウト<br>
        /// ５．２．１．１．リプロツール情報<br>
        /// ５．２．１．２．Vin<br>
        /// ５．２．１．３．リプロ状況<br>
        /// ５．２．１．４．リプロ<br>
        /// ５．２．１．５．リトライボタン<br>
        /// </summary>
        [TestMethod]
        public void TestMethod5_1_1()
        {
            // Simulator起動
            startSimulator();
            // SimulatorのIPアドレス取得
            string[] ips = getIpAddressList();
            // VIN情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Vin", "1212000000000056494E303030303030303030303030303031");
            // リプロ前ソフト品番情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "SoftBefore", "13150000000000010000003030303030303030303030303030303031");
            // YardRepro起動
            startYardRepro();
            capture(1, "YardRepro起動");
            // 1台にチェックを入れる
            this.UIMap.dst1ItemSelect();
            capture(2, "1台選択し、次へボタン押下");
            // 次へボタン押下
            this.UIMap.nextBtnClick();
            // 進捗確認画面確認
            this.UIMap.AssertMethod5_1_1_Assert1();
            this.UIMap.AssertMethod5_1_1_ListAssert();
            this.UIMap.AssertMethod5_1_1_DisplayAssert();
            this.UIMap.AssertMethod5_2_1_1_Assert1();
            capture(3, "進捗確認画面確認");
        }

        /// <summary>
        /// ５．進捗確認画面<br>
        /// ５．２．リスト更新処理<br>
        /// ５．２．２．ステータス取得中 10%→50%→100% ポーリング停止<br>
        /// ５．２．２．１．ステータス取得の返却値を変更(処理結果:0/進捗:10)<br>
        /// ５．２．２．２．ステータス取得の返却値を変更(処理結果:0/進捗:50)<br>
        /// ５．２．２．３．ステータス取得の返却値を変更(処理結果:0/進捗:100)<br>
        /// ５．２．２．４．ステータス取得の返却値を変更(処理結果:0/進捗:50)<br>
        /// </summary>
        [TestMethod]
        public void TestMethod5_2_2_1()
        {
            // Simulator起動
            startSimulator();
            // SimulatorのIPアドレス取得
            string[] ips = getIpAddressList();
            // YardRepro起動
            startYardRepro();
            capture(1, "YardRepro起動");
            // 1台にチェックを入れる
            this.UIMap.dst1ItemSelect();
            capture(2, "1台選択し、次へボタン押下");
            // 次へボタン押下
            this.UIMap.nextBtnClick();
            // 進捗、リトライボタン確認
            this.UIMap.AssertMethod5_2_2_1_Assert1();
            refreshMap();
            capture(3, "進捗確認画面表示");
            // 進捗を0%→10%に変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Status", "110400000000000A000000");
            // 3秒待機
            System.Threading.Thread.Sleep(3000);
            // 進捗、リトライボタン確認
            this.UIMap.AssertMethod5_2_2_1_Assert2();
            refreshMap();
            capture(4, "進捗を0%→10%に変更");
            // 進捗を10%→50%に変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Status", "1104000000000032000000");
            // 3秒待機
            System.Threading.Thread.Sleep(3000);
            // 進捗、リトライボタン確認
            this.UIMap.AssertMethod5_2_2_1_Assert3();
            refreshMap();
            capture(5, "進捗を10%→50%に変更");
            // 進捗を50%→100%に変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Status", "1104000000000064000000");
            // 3秒待機
            System.Threading.Thread.Sleep(3000);
            // 進捗、リトライボタン確認
            this.UIMap.AssertMethod5_2_2_1_Assert4();
            refreshMap();
            capture(6, "進捗を50%→100%に変更");
            // 進捗を100%→50%に変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Status", "1104000000000032000000");
            // 3秒待機
            System.Threading.Thread.Sleep(3000);
            // 進捗、リトライボタン確認
            this.UIMap.AssertMethod5_2_2_1_Assert4();
            capture(7, "進捗を100%→50%に変更(変わらないことを確認)");
        }

        /// <summary>
        /// ５．進捗確認画面<br>
        /// ５．２．リスト更新処理<br>
        /// ５．２．３．ステータス取得中 50%→エラー ポーリング停止<br>
        /// ５．２．３．１．ステータス取得の返却値を変更(処理結果:1/進捗:0)<br>
        /// </summary>
        [TestMethod]
        public void TestMethod5_2_3_1()
        {
            // Simulator起動
            startSimulator();
            // SimulatorのIPアドレス取得
            string[] ips = getIpAddressList();
            // VIN情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Vin", "1212000000000056494E303030303030303030303030303031");
            // リプロ前ソフト品番情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "SoftBefore", "13150000000000010000003030303030303030303030303030303031");

            // YardRepro起動
            startYardRepro();
            capture(1, "YardRepro起動");
            // 1台にチェックを入れる
            this.UIMap.dst1ItemSelect();
            capture(2, "1台選択し、次へボタン押下");
            // 次へボタン押下
            this.UIMap.nextBtnClick();
            capture(3, "進捗確認画面表示");
            // 進捗を0%→50%に変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Status", "1104000000000032000000");
            // 3秒待機
            System.Threading.Thread.Sleep(3000);
            // 進捗確認
            this.UIMap.AssertMethod5_2_3_1_Assert1();
            refreshMap();
            capture(4, "進捗を0%→50%に変更");
            // 進捗を50%→0x01 VIN読出し不可エラーに変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Status", "1104000100000000000000");
            // 3秒待機
            System.Threading.Thread.Sleep(3000);
            // 進捗、リトライボタン確認
            this.UIMap.AssertMethod5_2_3_1_Assert2();
            capture(5, "進捗50%→0x01 VIN読出し不可エラーに変更");
        }

        /// <summary>
        /// ５．進捗確認画面<br>
        /// ５．２．リスト更新処理<br>
        /// ５．２．３．ステータス取得中 50%→エラー ポーリング停止<br>
        /// ５．２．３．２．ステータス取得の返却値を変更(処理結果:2/進捗:0)<br>
        /// </summary>
        [TestMethod]
        public void TestMethod5_2_3_2()
        {
            // Simulator起動
            startSimulator();
            // SimulatorのIPアドレス取得
            string[] ips = getIpAddressList();
            // VIN情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Vin", "1212000000000056494E303030303030303030303030303031");
            // リプロ前ソフト品番情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "SoftBefore", "13150000000000010000003030303030303030303030303030303031");

            // YardRepro起動
            startYardRepro();
            capture(1, "YardRepro起動");
            // 1台にチェックを入れる
            this.UIMap.dst1ItemSelect();
            capture(2, "1台選択し、次へボタン押下");
            // 次へボタン押下
            this.UIMap.nextBtnClick();
            capture(3, "進捗確認画面表示");
            // 進捗を0%→50%に変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Status", "1104000000000032000000");
            // 3秒待機
            System.Threading.Thread.Sleep(3000);
            // 進捗確認
            this.UIMap.AssertMethod5_2_3_2_Assert1();
            refreshMap();
            capture(4, "進捗を0%→50%に変更");
            // 進捗を50%→0x02 ソフト品番読出し不可エラーに変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Status", "1104000200000000000000");
            // 3秒待機
            System.Threading.Thread.Sleep(3000);
            // 進捗、リトライボタン確認
            this.UIMap.AssertMethod5_2_3_2_Assert2();
            capture(5, "進捗50%→0x02 ソフト品番読出し不可エラーに変更");
        }

        /// <summary>
        /// ５．進捗確認画面<br>
        /// ５．２．リスト更新処理<br>
        /// ５．２．３．ステータス取得中 50%→エラー ポーリング停止<br>
        /// ５．２．３．３．ステータス取得の返却値を変更(処理結果:3/進捗:0)<br>
        /// </summary>
        [TestMethod]
        public void TestMethod5_2_3_3()
        {
            // Simulator起動
            startSimulator();
            // SimulatorのIPアドレス取得
            string[] ips = getIpAddressList();
            // VIN情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Vin", "1212000000000056494E303030303030303030303030303031");
            // リプロ前ソフト品番情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "SoftBefore", "13150000000000010000003030303030303030303030303030303031");

            // YardRepro起動
            startYardRepro();
            capture(1, "YardRepro起動");
            // 1台にチェックを入れる
            this.UIMap.dst1ItemSelect();
            capture(2, "1台選択し、次へボタン押下");
            // 次へボタン押下
            this.UIMap.nextBtnClick();
            capture(3, "進捗確認画面表示");
            // 進捗を0%→50%に変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Status", "1104000000000032000000");
            // 3秒待機
            System.Threading.Thread.Sleep(3000);
            // 進捗確認
            this.UIMap.AssertMethod5_2_3_3_Assert1();
            refreshMap();
            capture(4, "進捗を0%→50%に変更");
            // 進捗を50%→0x03 読み出したソフト品番から引きあたるリプロデータがDST-WiFi内に存在しないエラーに変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Status", "1104000300000000000000");
            // 3秒待機
            System.Threading.Thread.Sleep(3000);
            // 進捗、リトライボタン確認
            this.UIMap.AssertMethod5_2_3_3_Assert2();
            capture(5, "進捗50%→0x03 読み出したソフト品番から引きあたるリプロデータがDST-WiFi内に存在しないエラーに変更");
        }

        /// <summary>
        /// ５．進捗確認画面<br>
        /// ５．２．リスト更新処理<br>
        /// ５．２．３．ステータス取得中 50%→エラー ポーリング停止<br>
        /// ５．２．３．４．ステータス取得の返却値を変更(処理結果:4/進捗:0)<br>
        /// </summary>
        [TestMethod]
        public void TestMethod5_2_3_4()
        {
            // Simulator起動
            startSimulator();
            // SimulatorのIPアドレス取得
            string[] ips = getIpAddressList();
            // VIN情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Vin", "1212000000000056494E303030303030303030303030303031");
            // リプロ前ソフト品番情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "SoftBefore", "13150000000000010000003030303030303030303030303030303031");

            // YardRepro起動
            startYardRepro();
            capture(1, "YardRepro起動");
            // 1台にチェックを入れる
            this.UIMap.dst1ItemSelect();
            capture(2, "1台選択し、次へボタン押下");
            // 次へボタン押下
            this.UIMap.nextBtnClick();
            capture(3, "進捗確認画面表示");
            // 進捗を0%→50%に変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Status", "1104000000000032000000");
            // 3秒待機
            System.Threading.Thread.Sleep(3000);
            // 進捗確認
            this.UIMap.AssertMethod5_2_3_4_Assert1();
            refreshMap();
            capture(4, "進捗を0%→50%に変更");
            // 進捗を50%→0x04 リプロ書換え中のエラーに変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Status", "1104000400000000000000");
            // 3秒待機
            System.Threading.Thread.Sleep(3000);
            // 進捗、リトライボタン確認
            this.UIMap.AssertMethod5_2_3_4_Assert2();
            capture(5, "進捗50%→0x04 リプロ書換え中のエラーに変更");
        }

        /// <summary>
        /// ５．進捗確認画面<br>
        /// ５．２．リスト更新処理<br>
        /// ５．２．３．ステータス取得中 50%→エラー ポーリング停止<br>
        /// ５．２．３．５．ステータス取得の返却値を変更(処理結果:5/進捗:0)<br>
        /// </summary>
        [TestMethod]
        public void TestMethod5_2_3_5()
        {
            // Simulator起動
            startSimulator();
            // SimulatorのIPアドレス取得
            string[] ips = getIpAddressList();
            // VIN情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Vin", "1212000000000056494E303030303030303030303030303031");
            // リプロ前ソフト品番情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "SoftBefore", "13150000000000010000003030303030303030303030303030303031");

            // YardRepro起動
            startYardRepro();
            capture(1, "YardRepro起動");
            // 1台にチェックを入れる
            this.UIMap.dst1ItemSelect();
            capture(2, "1台選択し、次へボタン押下");
            // 次へボタン押下
            this.UIMap.nextBtnClick();
            capture(3, "進捗確認画面表示");
            // 進捗を0%→50%に変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Status", "1104000000000032000000");
            // 3秒待機
            System.Threading.Thread.Sleep(3000);
            // 進捗確認
            this.UIMap.AssertMethod5_2_3_5_Assert1();
            refreshMap();
            capture(4, "進捗を0%→50%に変更");
            // 進捗を50%→0x05 リプロ後のベリファイ時のエラーに変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Status", "1104000500000000000000");
            // 3秒待機
            System.Threading.Thread.Sleep(3000);
            // 進捗、リトライボタン確認
            this.UIMap.AssertMethod5_2_3_5_Assert2();
            capture(5, "進捗50%→0x05 リプロ後のベリファイ時のエラーに変更");
        }

        /// <summary>
        /// ５．進捗確認画面<br>
        /// ５．２．リスト更新処理<br>
        /// ５．２．３．ステータス取得中 50%→エラー ポーリング停止<br>
        /// ５．２．３．６．ステータス取得の返却値を変更(処理結果:6/進捗:0)<br>
        /// </summary>
        [TestMethod]
        public void TestMethod5_2_3_6()
        {
            // Simulator起動
            startSimulator();
            // SimulatorのIPアドレス取得
            string[] ips = getIpAddressList();
            // VIN情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Vin", "1212000000000056494E303030303030303030303030303031");
            // リプロ前ソフト品番情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "SoftBefore", "13150000000000010000003030303030303030303030303030303031");

            // YardRepro起動
            startYardRepro();
            capture(1, "YardRepro起動");
            // 1台にチェックを入れる
            this.UIMap.dst1ItemSelect();
            capture(2, "1台選択し、次へボタン押下");
            // 次へボタン押下
            this.UIMap.nextBtnClick();
            capture(3, "進捗確認画面表示");
            // 進捗を0%→50%に変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Status", "1104000000000032000000");
            // 3秒待機
            System.Threading.Thread.Sleep(3000);
            // 進捗確認
            this.UIMap.AssertMethod5_2_3_6_Assert1();
            refreshMap();
            capture(4, "進捗を0%→50%に変更");
            // 進捗を50%→0x06 バッテリ電圧が11.8V未満エラーに変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Status", "1104000600000000000000");
            // 3秒待機
            System.Threading.Thread.Sleep(3000);
            // 進捗、リトライボタン確認
            this.UIMap.AssertMethod5_2_3_6_Assert2();
            capture(5, "進捗50%→0x06 バッテリ電圧が11.8V未満エラーに変更");
        }

        /// <summary>
        /// ５．進捗確認画面<br>
        /// ５．２．リスト更新処理<br>
        /// ５．２．３．ステータス取得中 50%→エラー ポーリング停止<br>
        /// ５．２．３．７．ステータス取得の返却値を変更(処理結果:7/進捗:0)<br>
        /// </summary>
        [TestMethod]
        public void TestMethod5_2_3_7()
        {
            // Simulator起動
            startSimulator();
            // SimulatorのIPアドレス取得
            string[] ips = getIpAddressList();
            // VIN情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Vin", "1212000000000056494E303030303030303030303030303031");
            // リプロ前ソフト品番情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "SoftBefore", "13150000000000010000003030303030303030303030303030303031");

            // YardRepro起動
            startYardRepro();
            capture(1, "YardRepro起動");
            // 1台にチェックを入れる
            this.UIMap.dst1ItemSelect();
            capture(2, "1台選択し、次へボタン押下");
            // 次へボタン押下
            this.UIMap.nextBtnClick();
            capture(3, "進捗確認画面表示");
            // 進捗を0%→50%に変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Status", "1104000000000032000000");
            // 3秒待機
            System.Threading.Thread.Sleep(3000);
            // 進捗確認
            this.UIMap.AssertMethod5_2_3_7_Assert1();
            refreshMap();
            capture(4, "進捗を0%→50%に変更");
            // 進捗を50%→0x07 定義されないエラーに変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Status", "1104000700000000000000");
            // 3秒待機
            System.Threading.Thread.Sleep(3000);
            // 進捗、リトライボタン確認
            this.UIMap.AssertMethod5_2_3_7_Assert2();
            capture(5, "進捗50%→0x07 定義されないエラーに変更");
        }

        /// <summary>
        /// ５．進捗確認画面<br>
        /// ５．２．リスト更新処理<br>
        /// ５．２．３．ステータス取得中 50%→エラー ポーリング停止<br>
        /// ５．２．３．８．ステータス取得の返却値を変更(処理結果:8/進捗:0)<br>
        /// </summary>
        [TestMethod]
        public void TestMethod5_2_3_8()
        {
            // Simulator起動
            startSimulator();
            // SimulatorのIPアドレス取得
            string[] ips = getIpAddressList();
            // VIN情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Vin", "1212000000000056494E303030303030303030303030303031");
            // リプロ前ソフト品番情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "SoftBefore", "13150000000000010000003030303030303030303030303030303031");

            // YardRepro起動
            startYardRepro();
            capture(1, "YardRepro起動");
            // 1台にチェックを入れる
            this.UIMap.dst1ItemSelect();
            capture(2, "1台選択し、次へボタン押下");
            // 次へボタン押下
            this.UIMap.nextBtnClick();
            capture(3, "進捗確認画面表示");
            // 進捗を0%→50%に変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Status", "1104000000000032000000");
            // 3秒待機
            System.Threading.Thread.Sleep(3000);
            // 進捗確認
            this.UIMap.AssertMethod5_2_3_8_Assert1();
            //this.UIMap.AssertMethod5_2_3_7_Assert1();
            refreshMap();
            capture(4, "進捗を0%→50%に変更");
            // 進捗を50%→0x08 読み出したソフト品番がリプロ後のソフト品番と同一に変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Status", "1104000800000000000000");
            // 3秒待機
            System.Threading.Thread.Sleep(3000);
            // 進捗、リトライボタン確認
            this.UIMap.AssertMethod5_2_3_8_Assert2();

            //this.UIMap.AssertMethod5_2_3_7_Assert2();
            capture(5, "進捗50%→0x07 定義されないエラーに変更");
        }

        /// <summary>
        /// ５．進捗確認画面<br>
        /// ５．２．リスト更新処理<br>
        /// ５．２．４．ステータス取得中 切断(ポーリング継続) ポーリング停止<br>
        /// ５．２．４．１．ステータス取得の返却値を変更(返却エラー)<br>
        /// ５．２．４．２．切断表示後、ステータス取得の返却値を変更(処理結果:0/進捗:50)<br>
        /// </summary>
        [TestMethod]
        public void TestMethod5_2_4_1()
        {
            // Simulator起動
            startSimulator();
            // SimulatorのIPアドレス取得
            string[] ips = getIpAddressList();
            // VIN情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Vin", "1212000000000056494E303030303030303030303030303031");
            // リプロ前ソフト品番情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "SoftBefore", "13150000000000010000003030303030303030303030303030303031");

            // YardRepro起動
            startYardRepro();
            capture(1, "YardRepro起動");
            // 1台にチェックを入れる
            this.UIMap.dst1ItemSelect();
            capture(2, "1台選択し、次へボタン押下");
            // 次へボタン押下
            this.UIMap.nextBtnClick();
            capture(3, "進捗確認画面表示");
            // 進捗を0%→50%に変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Status", "1104000000000032000000");
            // 3秒待機
            System.Threading.Thread.Sleep(3000);
            // 進捗確認
            this.UIMap.AssertMethod5_2_4_1_Assert1();
            refreshMap();
            capture(4, "進捗を0%→50%に変更");
            // 1台停止させる
            udpIniUpdateSend("localhost", byte.Parse("3"), ips[0], null, null);
            // 7秒待機
            System.Threading.Thread.Sleep(7000);
            // 進捗確認
            this.UIMap.AssertMethod5_2_4_1_Assert1();
            capture(5, "停止後、7秒経過");
            // 5秒待機
            System.Threading.Thread.Sleep(5000);
            // 進捗、リトライボタン確認
            this.UIMap.AssertMethod5_2_4_1_Assert2();
            refreshMap();
            capture(6, "停止後、12秒経過");
            // 1台開始させる
            udpIniUpdateSend("localhost", byte.Parse("2"), ips[0], null, null);
            // 3秒待機
            System.Threading.Thread.Sleep(3000);
            // 進捗、リトライボタン確認
            this.UIMap.AssertMethod5_2_4_1_Assert1();
            capture(7, "起動後、3秒経過");
        }

        /// <summary>
        /// ５．進捗確認画面<br>
        /// ５．２．リスト更新処理<br>
        /// ５．２．７．リプロ前<br>
        /// ５．２．７．１．ステータス取得の返却値を変更(処理結果:0/進捗:0) VIN取得情報処理結果:0 リプロ前ソフト品番処理結果:0<br>
        /// </summary>
        [TestMethod]
        public void TestMethod5_2_7_1()
        {
            // Simulator起動
            startSimulator();
            // SimulatorのIPアドレス取得
            string[] ips = getIpAddressList();
            // VIN情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Vin", "1212000000000056494E303030303030303030303030303031");
            // リプロ前ソフト品番情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "SoftBefore", "13150000000000010000003030303030303030303030303030303031");
            // YardRepro起動
            startYardRepro();
            capture(1, "YardRepro起動");
            // 1台にチェックを入れる
            this.UIMap.dst1ItemSelect();
            capture(2, "1台選択し、次へボタン押下");
            // 次へボタン押下
            this.UIMap.nextBtnClick();
            // 3秒待機
            System.Threading.Thread.Sleep(3000);
            // 進捗、リトライボタン、表示確認
            this.UIMap.AssertMethod5_2_7_1_Assert1();
            capture(3, "進捗確認画面表示");
        }

        /// <summary>
        /// ５．進捗確認画面<br>
        /// ５．２．リスト更新処理<br>
        /// ５．２．７．リプロ前<br>
        /// ５．２．７．２．ステータス取得の返却値を変更(処理結果:0/進捗:0) VIN取得情報処理結果:1 リプロ前ソフト品番処理結果:0<br>
        /// </summary>
        [TestMethod]
        public void TestMethod5_2_7_2()
        {
            // Simulator起動
            startSimulator();
            // SimulatorのIPアドレス取得
            string[] ips = getIpAddressList();
            // VIN情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Vin", "1212000100000056494E303030303030303030303030303031");
            // リプロ前ソフト品番情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "SoftBefore", "13150000000000010000003030303030303030303030303030303031");
            // YardRepro起動
            startYardRepro();
            capture(1, "YardRepro起動");
            // 1台にチェックを入れる
            this.UIMap.dst1ItemSelect();
            capture(2, "1台選択し、次へボタン押下");
            // 次へボタン押下
            this.UIMap.nextBtnClick();
            // 3秒待機
            System.Threading.Thread.Sleep(3000);
            // 進捗、リトライボタン、表示確認
            this.UIMap.AssertMethod5_2_7_2_Assert1();
            capture(3, "進捗確認画面表示");
        }

        /// <summary>
        /// ５．進捗確認画面<br>
        /// ５．２．リスト更新処理<br>
        /// ５．２．７．リプロ前<br>
        /// ５．２．７．３．ステータス取得の返却値を変更(処理結果:0/進捗:0) VIN取得情報処理結果:0 リプロ前ソフト品番処理結果:1<br>
        /// </summary>
        [TestMethod]
        public void TestMethod5_2_7_3()
        {
            // Simulator起動
            startSimulator();
            // SimulatorのIPアドレス取得
            string[] ips = getIpAddressList();
            // VIN情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Vin", "1212000000000056494E303030303030303030303030303031");
            // リプロ前ソフト品番情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "SoftBefore", "13150001000000010000003030303030303030303030303030303031");
            // YardRepro起動
            startYardRepro();
            capture(1, "YardRepro起動");
            // 1台にチェックを入れる
            this.UIMap.dst1ItemSelect();
            capture(2, "1台選択し、次へボタン押下");
            // 次へボタン押下
            this.UIMap.nextBtnClick();
            // 3秒待機
            System.Threading.Thread.Sleep(3000);
            // 進捗、リトライボタン、表示確認
            this.UIMap.AssertMethod5_2_7_3_Assert1();
            capture(3, "進捗確認画面表示");
        }

        /// <summary>
        /// ５．進捗確認画面<br>
        /// ５．２．リスト更新処理<br>
        /// ５．２．７．リプロ前<br>
        /// ５．２．７．４．ステータス取得の返却値を変更(処理結果:0/進捗:0) VIN取得情報処理結果:1 リプロ前ソフト品番処理結果:1<br>
        /// </summary>
        [TestMethod]
        public void TestMethod5_2_7_4()
        {
            // Simulator起動
            startSimulator();
            // SimulatorのIPアドレス取得
            string[] ips = getIpAddressList();
            // VIN情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Vin", "1212000100000056494E303030303030303030303030303031");
            // リプロ前ソフト品番情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "SoftBefore", "13150001000000010000003030303030303030303030303030303031");
            // YardRepro起動
            startYardRepro();
            capture(1, "YardRepro起動");
            // 1台にチェックを入れる
            this.UIMap.dst1ItemSelect();
            capture(2, "1台選択し、次へボタン押下");
            // 次へボタン押下
            this.UIMap.nextBtnClick();
            // 3秒待機
            System.Threading.Thread.Sleep(3000);
            // 進捗、リトライボタン、表示確認
            this.UIMap.AssertMethod5_2_7_4_Assert1();
            capture(3, "進捗確認画面表示");
        }

        /// <summary>
        /// ５．進捗確認画面<br>
        /// ５．２．リスト更新処理<br>
        /// ５．２．７．リプロ前<br>
        /// ５．２．７．５．ステータス取得の返却値を変更(処理結果:0/進捗:0) VIN取得情報処理結果:0 リプロ前ソフト品番処理結果:0が複数<br>
        /// </summary>
        [TestMethod]
        public void TestMethod5_2_7_5()
        {
            // Simulator起動
            startSimulator();
            // SimulatorのIPアドレス取得
            string[] ips = getIpAddressList();
            // VIN情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Vin", "1212000000000056494E303030303030303030303030303031");
            // リプロ前ソフト品番情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "SoftBefore", "13" + "2402" + "00000000" + "20000000" +
                "3030303030303030303030303030303031" +
                "3030303030303030303030303030303032" +
                "3030303030303030303030303030303033" +
                "3030303030303030303030303030303034" +
                "3030303030303030303030303030303035" +
                "3030303030303030303030303030303036" +
                "3030303030303030303030303030303037" +
                "3030303030303030303030303030303038" +
                "3030303030303030303030303030303039" +
                "3030303030303030303030303030303130" +
                "3030303030303030303030303030303131" +
                "3030303030303030303030303030303132" +
                "3030303030303030303030303030303133" +
                "3030303030303030303030303030303134" +
                "3030303030303030303030303030303135" +
                "3030303030303030303030303030303136" +
                "3030303030303030303030303030303137" +
                "3030303030303030303030303030303138" +
                "3030303030303030303030303030303139" +
                "3030303030303030303030303030303230" +
                "3030303030303030303030303030303231" +
                "3030303030303030303030303030303232" +
                "3030303030303030303030303030303233" +
                "3030303030303030303030303030303234" +
                "3030303030303030303030303030303235" +
                "3030303030303030303030303030303236" +
                "3030303030303030303030303030303237" +
                "3030303030303030303030303030303238" +
                "3030303030303030303030303030303239" +
                "3030303030303030303030303030303330" +
                "3030303030303030303030303030303331" +
                "3030303030303030303030303030303332");
            // YardRepro起動
            startYardRepro();
            capture(1, "YardRepro起動");
            // 1台にチェックを入れる
            this.UIMap.dst1ItemSelect();
            capture(2, "1台選択し、次へボタン押下");
            // 次へボタン押下
            this.UIMap.nextBtnClick();
            // 3秒待機
            System.Threading.Thread.Sleep(3000);
            // 進捗、リトライボタン、表示確認
            this.UIMap.AssertMethod5_2_7_5_Assert1();
            capture(3, "進捗確認画面表示");
        }

        /// <summary>
        /// ５．進捗確認画面<br>
        /// ５．２．リスト更新処理<br>
        /// ５．２．５．リプロ完了時<br>
        /// ５．２．５．１．ステータス取得の返却値を変更(処理結果:0/進捗:100) VIN取得情報処理結果:0 ソフト品番処理結果:0<br>
        /// </summary>
        [TestMethod]
        public void TestMethod5_2_5_1()
        {
            // Simulator起動
            startSimulator();
            // SimulatorのIPアドレス取得
            string[] ips = getIpAddressList();
            // VIN情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Vin", "1212000000000056494E303030303030303030303030303031");
            // リプロ前ソフト品番情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "SoftBefore", "13150000000000010000003030303030303030303030303030303031");
            // リプロ後ソフト品番情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "SoftAfter", "13150000000000010000003030303030303030303030303030303131");
            // YardRepro起動
            startYardRepro();
            capture(1, "YardRepro起動");
            // 1台にチェックを入れる
            this.UIMap.dst1ItemSelect();
            capture(2, "1台選択し、次へボタン押下");
            // 次へボタン押下
            this.UIMap.nextBtnClick();
            // 3秒待機
            System.Threading.Thread.Sleep(3000);
            capture(3, "進捗確認画面表示");
            // 進捗を0%→100%に変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Status", "1104000000000064000000");
            // 3秒待機
            System.Threading.Thread.Sleep(3000);
            // 進捗、リトライボタン、表示確認
            this.UIMap.AssertMethod5_2_5_1_Assert1();
            capture(4, "進捗を0%→100%に変更");
        }

        /// <summary>
        /// ５．進捗確認画面<br>
        /// ５．２．リスト更新処理<br>
        /// ５．２．５．リプロ完了時<br>
        /// ５．２．５．２．ステータス取得の返却値を変更(処理結果:0/進捗:100) VIN取得情報処理結果:1 ソフト品番処理結果:0<br>
        /// </summary>
        //[TestMethod]
        //public void TestMethod5_2_5_2()
        //{
        //    // Simulator起動
        //    startSimulator();
        //    // SimulatorのIPアドレス取得
        //    string[] ips = getIpAddressList();
        //    // VIN情報変更
        //    udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Vin", "1212000000000156494E303030303030303030303030303031");
        //    // YardRepro起動
        //    startYardRepro();
        //    capture(1, "YardRepro起動");
        //    // 1台にチェックを入れる
        //    this.UIMap.dst1ItemSelect();
        //    capture(2, "1台選択し、次へボタン押下");
        //    // 次へボタン押下
        //    this.UIMap.nextBtnClick();
        //    capture(3, "進捗確認画面表示");
        //    // 進捗を0%→100%に変更
        //    udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Status", "1104000000000064000000");
        //    // 3秒待機
        //    System.Threading.Thread.Sleep(3000);
        //    // 進捗、リトライボタン、表示確認
        //    this.UIMap.AssertMethod5_2_5_2_Assert1();
        //    capture(4, "VIN取得情報処理エラーで、進捗を0%→100%に変更");
        //}

        /// <summary>
        /// ５．進捗確認画面<br>
        /// ５．２．リスト更新処理<br>
        /// ５．２．５．リプロ完了時<br>
        /// ５．２．５．３．ステータス取得の返却値を変更(処理結果:0/進捗:100) VIN取得情報処理結果:0 ソフト品番処理結果:1<br>
        /// </summary>
        [TestMethod]
        public void TestMethod5_2_5_3()
        {
            // Simulator起動
            startSimulator();
            // SimulatorのIPアドレス取得
            string[] ips = getIpAddressList();
            // 進捗を0%に変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Status", "1104000000000000000000");
            // VIN情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Vin", "1212000000000056494E303030303030303030303030303031");
            // リプロ前ソフト品番情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "SoftBefore", "13150000000000010000003030303030303030303030303030303031");
            // リプロ後ソフト品番情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "SoftAfter", "13150001000000010000003030303030303030303030303030303131");
            // YardRepro起動
            startYardRepro();
            capture(1, "YardRepro起動");
            // 1台にチェックを入れる
            this.UIMap.dst1ItemSelect();
            capture(2, "1台選択し、次へボタン押下");
            // 次へボタン押下
            this.UIMap.nextBtnClick();
            // 3秒待機
            System.Threading.Thread.Sleep(3000);
            capture(3, "進捗確認画面表示");
            // 進捗を0%→100%に変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Status", "1104000000000064000000");
            // 3秒待機
            System.Threading.Thread.Sleep(3000);
            // 進捗、リトライボタン、表示確認
            this.UIMap.AssertMethod5_2_5_3_Assert1();
            capture(4, "リプロ後ソフト品番処理エラーで、進捗を0%→100%に変更");
        }

        /// <summary>
        /// ５．進捗確認画面<br>
        /// ５．２．リスト更新処理<br>
        /// ５．２．５．リプロ完了時<br>
        /// ５．２．５．４．ステータス取得の返却値を変更(処理結果:0/進捗:100) VIN取得情報処理結果:1 ソフト品番処理結果:1<br>
        /// </summary>
        //[TestMethod]
        //public void TestMethod5_2_5_4()
        //{
        //    // Simulator起動
        //    startSimulator();
        //    // SimulatorのIPアドレス取得
        //    string[] ips = getIpAddressList();
        //    // VIN情報変更
        //    udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Vin", "1212000000000156494E303030303030303030303030303031");
        //    // ソフト品番情報変更
        //    udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Soft", "13150000000001010000003030303030303030303030303030303031");
        //    // YardRepro起動
        //    startYardRepro();
        //    capture(1, "YardRepro起動");
        //    // 1台にチェックを入れる
        //    this.UIMap.dst1ItemSelect();
        //    capture(2, "1台選択し、次へボタン押下");
        //    // 次へボタン押下
        //    this.UIMap.nextBtnClick();
        //    capture(3, "進捗確認画面表示");
        //    // 進捗を0%→100%に変更
        //    udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Status", "1104000000000064000000");
        //    // 3秒待機
        //    System.Threading.Thread.Sleep(3000);
        //    // 進捗、リトライボタン、表示確認
        //    this.UIMap.AssertMethod5_2_5_4_Assert1();
        //    capture(4, "VIN取得情報処理エラー、ソフト品番処理エラーで、進捗を0%→100%に変更");
        //}

        /// <summary>
        /// ５．進捗確認画面<br>
        /// ５．２．リスト更新処理<br>
        /// ５．２．５．リプロ完了時<br>
        /// ５．２．５．５．ステータス取得の返却値を変更(処理結果:0/進捗:100) VIN取得情報処理結果:0 ソフト品番処理結果:0が複数<br>
        /// </summary>
        //[TestMethod]
        //public void TestMethod5_2_5_5()
        //{
        //    // Simulator起動
        //    startSimulator();
        //    // SimulatorのIPアドレス取得
        //    string[] ips = getIpAddressList();
        //    // ソフト品番情報変更
        //    udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Soft",
        //        "1315000000000020000000" +
        //        "3030303030303030303030303030303031" +
        //        "3030303030303030303030303030303032" +
        //        "3030303030303030303030303030303033" +
        //        "3030303030303030303030303030303034" +
        //        "3030303030303030303030303030303035" +
        //        "3030303030303030303030303030303036" +
        //        "3030303030303030303030303030303037" +
        //        "3030303030303030303030303030303038" +
        //        "3030303030303030303030303030303039" +
        //        "3030303030303030303030303030303130" +
        //        "3030303030303030303030303030303131" +
        //        "3030303030303030303030303030303132" +
        //        "3030303030303030303030303030303133" +
        //        "3030303030303030303030303030303134" +
        //        "3030303030303030303030303030303135" +
        //        "3030303030303030303030303030303136" +
        //        "3030303030303030303030303030303137" +
        //        "3030303030303030303030303030303138" +
        //        "3030303030303030303030303030303139" +
        //        "3030303030303030303030303030303230" +
        //        "3030303030303030303030303030303231" +
        //        "3030303030303030303030303030303232" +
        //        "3030303030303030303030303030303233" +
        //        "3030303030303030303030303030303234" +
        //        "3030303030303030303030303030303235" +
        //        "3030303030303030303030303030303236" +
        //        "3030303030303030303030303030303237" +
        //        "3030303030303030303030303030303238" +
        //        "3030303030303030303030303030303239" +
        //        "3030303030303030303030303030303330" +
        //        "3030303030303030303030303030303331" +
        //        "3030303030303030303030303030303332");
        //    // YardRepro起動
        //    startYardRepro();
        //    capture(1, "YardRepro起動");
        //    // 1台にチェックを入れる
        //    this.UIMap.dst1ItemSelect();
        //    capture(2, "1台選択し、次へボタン押下");
        //    // 次へボタン押下
        //    this.UIMap.nextBtnClick();
        //    capture(3, "進捗確認画面表示");
        //    // 進捗を0%→100%に変更
        //    udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Status", "1104000000000064000000");
        //    // 3秒待機
        //    System.Threading.Thread.Sleep(3000);
        //    // 進捗、リトライボタン、表示確認
        //    this.UIMap.AssertMethod5_2_5_5_Assert1();
        //    capture(4, "進捗を0%→100%に変更");
        //}

        /// <summary>
        /// ５．進捗確認画面<br>
        /// ５．２．リスト更新処理<br>
        /// ５．２．６．リトライボタン<br>
        /// ５．２．６．１．リトライ要求の返却値を変更(処理結果:0) ステータス取得の返却値を変更(処理結果:0/進捗:0→リトライボタン押下→50)<br>
        /// </summary>
        [TestMethod]
        public void TestMethod5_2_6_1()
        {
            // Simulator起動
            startSimulator();
            // SimulatorのIPアドレス取得
            string[] ips = getIpAddressList();
            // VIN情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Vin", "1212000000000056494E303030303030303030303030303031");
            // リプロ前ソフト品番情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "SoftBefore", "13150000000000010000003030303030303030303030303030303031");

            // YardRepro起動
            startYardRepro();
            capture(1, "YardRepro起動");
            // 1台にチェックを入れる
            this.UIMap.dst1ItemSelect();
            capture(2, "1台選択し、次へボタン押下");
            // 次へボタン押下
            this.UIMap.nextBtnClick();
            capture(3, "進捗確認画面表示");
            // 進捗を0%→0x05 リプロ後のベリファイ時のエラーに変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Status", "1104000500000000000000");
            // 3秒待機
            System.Threading.Thread.Sleep(3000);
            // 進捗、リトライボタン確認
            this.UIMap.AssertMethod5_2_6_1_Assert1();
            refreshMap();
            capture(4, "0x05 リプロ後のベリファイ時のエラーを発生させる");
            // 進捗を0x05 リプロ後のベリファイ時のエラー→0%に変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Status", "1104000000000000000000");
            // リトライボタン押下
            this.UIMap.retryBtnClick();
            capture(5, "リトライボタン押下後、メッセージを表示");
            System.Threading.Thread.Sleep(1000);
            this.UIMap.GiBtnClick();
            // 3秒待機
            System.Threading.Thread.Sleep(3000);
            // 進捗確認
            this.UIMap.AssertMethod5_2_6_1_Assert2();
            refreshMap();
            capture(6, "リトライボタン押下後、3秒経過");
            // 進捗を0%→50%に変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Status", "1104000000000032000000");
            // 3秒待機
            System.Threading.Thread.Sleep(3000);
            // 進捗、リトライボタン確認
            this.UIMap.AssertMethod5_2_6_1_Assert3();
            capture(7, "進捗を0%→50%に変更後、3秒経過");
        }

        /// <summary>
        /// ５．進捗確認画面<br>
        /// ５．２．リスト更新処理<br>
        /// ５．２．６．リトライボタン<br>
        /// ５．２．６．２．リトライ要求の返却値を変更(処理結果:1)<br>
        /// </summary>
        [TestMethod]
        public void TestMethod5_2_6_2()
        {
            // Simulator起動
            startSimulator();
            // SimulatorのIPアドレス取得
            string[] ips = getIpAddressList();
            // VIN情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Vin", "1212000000000056494E303030303030303030303030303031");
            // リプロ前ソフト品番情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "SoftBefore", "13150000000000010000003030303030303030303030303030303031");

            // YardRepro起動
            startYardRepro();
            capture(1, "YardRepro起動");
            // 1台にチェックを入れる
            this.UIMap.dst1ItemSelect();
            capture(2, "1台選択し、次へボタン押下");
            // 次へボタン押下
            this.UIMap.nextBtnClick();
            capture(3, "進捗確認画面表示");
            // 進捗を0%→0x05 リプロ後のベリファイ時のエラーに変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Status", "1104000500000000000000");
            // 3秒待機
            System.Threading.Thread.Sleep(3000);
            // 進捗、リトライボタン確認
            this.UIMap.AssertMethod5_2_6_2_Assert1();
            refreshMap();
            capture(4, "0x05 リプロ後のベリファイ時のエラーを発生させる");
            // リトライ要求を変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Retry", "14000000000001");
            // リトライボタン押下
            this.UIMap.retryBtnClick();
            capture(5, "リトライボタン押下後、メッセージを表示");
            System.Threading.Thread.Sleep(1000);
            this.UIMap.GiBtnClick();
            // 3秒待機
            System.Threading.Thread.Sleep(3000);
            // エラーメッセージ確認
            this.UIMap.AssertMethod5_2_6_2_Assert2();
            capture(6, "エラーダイアログ確認");
            // エラーダイアログ閉じる
            this.UIMap.retryErrorDialogOKBtnClick();
            // リトライボタン確認
            this.UIMap.AssertMethod5_2_6_2_Assert3();
            capture(7, "エラーダイアログを閉じる");
        }

        /// <summary>
        /// ５．進捗確認画面<br>
        /// ５．２．リスト更新処理<br>
        /// ５．２．８．P-DTC消去操作済みチェック<br>
        /// ５．２．８．１．ステータス取得の返却値を変更(処理結果:0/進捗:100) P-DTC消去操作済みチェックをチェック済にする<br>
        /// </summary>
        [TestMethod]
        public void TestMethod5_2_8_1()
        {
            // Simulator起動
            startSimulator();
            // SimulatorのIPアドレス取得
            string[] ips = getIpAddressList();
            // VIN情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Vin", "1212000000000056494E303030303030303030303030303031");
            // リプロ前ソフト品番情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "SoftBefore", "13150000000000010000003030303030303030303030303030303031");
            // リプロ後ソフト品番情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "SoftAfter", "13150000000000010000003030303030303030303030303030303131");
            // YardRepro起動
            startYardRepro();
            capture(1, "YardRepro起動");
            // 1台にチェックを入れる
            this.UIMap.dst1ItemSelect();
            capture(2, "1台選択し、次へボタン押下");
            // 次へボタン押下
            this.UIMap.nextBtnClick();
            // 3秒待機
            System.Threading.Thread.Sleep(3000);
            // 進捗を0%→100%に変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Status", "1104000000000064000000");
            // 3秒待機
            System.Threading.Thread.Sleep(3000);
            capture(3, "進捗確認画面表示");
            this.UIMap.P_DTC_Checked();
            // DTC消去ボタン確認
            this.UIMap.AssertMethod5_2_8_1_Assert1();
            capture(4, "DTC消去ボタン有効");
            // P-DTC消去操作済みチェックをはずす
            this.UIMap.P_DTC_UnChecked();
            // DTC消去ボタン確認
            this.UIMap.AssertMethod5_2_8_1_Assert2();
            capture(5, "DTC消去ボタン無効");
        }

        /// <summary>
        /// ５．進捗確認画面<br>
        /// ５．２．リスト更新処理<br>
        /// ５．２．８．DTC消去ボタン押下<br>
        /// ５．２．８．２．後処理開始要求処理結果:0 後処理結果要求の受信タイムアウト値:10秒 後処理応答フレームの遅延:9秒<br>
        ///                 ログファイル出力先:C:\Users\カレントユーザ\Yardrepro<br>
        ///                 ログファイル取得要求の返却値を変更(処理結果:0/データ長:505/残りデータサイズ:0)
        /// </summary>
        [TestMethod]
        public void TestMethod5_2_8_2()
        {
            // Simulator起動
            startSimulator();
            // SimulatorのIPアドレス取得
            string[] ips = getIpAddressList();
            // VIN情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Vin", "1212000000000056494E303030303030303030303030303031");
            // リプロ前ソフト品番情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "SoftBefore", "13150000000000010000003030303030303030303030303030303031");
            // リプロ後ソフト品番情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "SoftAfter", "13150000000000010000003030303030303030303030303030303131");
            // YardRepro起動
            startYardRepro();
            capture(1, "YardRepro起動");
            // 1台にチェックを入れる
            this.UIMap.dst1ItemSelect();
            capture(2, "1台選択し、次へボタン押下");
            // 次へボタン押下
            this.UIMap.nextBtnClick();
            // 3秒待機
            System.Threading.Thread.Sleep(3000);
            // 進捗を0%→100%に変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Status", "1104000000000064000000");
            // 3秒待機
            System.Threading.Thread.Sleep(3000);
            capture(3, "進捗確認画面表示");
            // ini表示
            string iniFilePath = WORK_DIRECTORY + @"\YardRepro.ini";
            System.Diagnostics.Process p = System.Diagnostics.Process.Start("notepad.exe", System.IO.Path.GetFullPath(iniFilePath));
            System.Threading.Thread.Sleep(2000);
            capture(4, "受信タイムアウト値/Log出力先確認");
            p.Kill();
            System.Threading.Thread.Sleep(1000);
            // 後処理実行結果変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "DtcExec", "15000000000000");
            // 後処理応答フレームの遅延
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "DtcExecSleep", "9000");
            // ログファイル取得結果変更（データ長F901→01F9:505byte、残り00000000:0byte）
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "DtcExecLog",
                            "16" + "F901" + "00000000" + "00000000" +
                            "3030303030303030303030303030303031" +
                            "3030303030303030303030303030303032" +
                            "3030303030303030303030303030303033" +
                            "3030303030303030303030303030303034" +
                            "3030303030303030303030303030303035" +
                            "3030303030303030303030303030303036" +
                            "3030303030303030303030303030303037" +
                            "3030303030303030303030303030303038" +
                            "3030303030303030303030303030303039" +
                            "3030303030303030303030303030303130" +
                            "3030303030303030303030303030303131" +
                            "3030303030303030303030303030303132" +
                            "3030303030303030303030303030303133" +
                            "3030303030303030303030303030303134" +
                            "3030303030303030303030303030303135" +
                            "3030303030303030303030303030303136" +
                            "3030303030303030303030303030303137" +
                            "3030303030303030303030303030303138" +
                            "3030303030303030303030303030303139" +
                            "3030303030303030303030303030303230" +
                            "3030303030303030303030303030303231" +
                            "3030303030303030303030303030303232" +
                            "3030303030303030303030303030303233" +
                            "3030303030303030303030303030303234" +
                            "3030303030303030303030303030303235" +
                            "3030303030303030303030303030303236" +
                            "3030303030303030303030303030303237" +
                            "3030303030303030303030303030303238" +
                            "3030303030303030303030303030303239" +
                            "3030303030303030");
            System.Threading.Thread.Sleep(1000);
            // DTC有効
            this.UIMap.P_DTC_Checked();
            this.UIMap.AssertMethod5_2_8_2_Assert1();
            refreshMap();
            capture(5, "DTC消去実施前");
            System.Threading.Thread.Sleep(1000);
            // 後処理実行
            this.UIMap.DtcExec();
            System.Threading.Thread.Sleep(1000);
            this.UIMap.AssertMethod5_2_8_2_Assert2();
            refreshMap();
            capture(6, "DTC消去実施中");
            // DTC完了11秒待機
            System.Threading.Thread.Sleep(11000);
            this.UIMap.AssertMethod5_2_8_2_Assert3();
            refreshMap();
            capture(7, "DTC消去完了");
            System.Threading.Thread.Sleep(1000);

            // [yardrepro.ini]を読込み設定値を取得する
            Ini ini = new Ini(iniFilePath);
            // logディレクトリ表示
            System.Diagnostics.Process.Start("EXPLORER.EXE", @"/select,""" + System.IO.Path.GetFullPath(ini["LOG_FILE", "SAVE_FOLDER"]));// + @"""");
            System.Threading.Thread.Sleep(2000);
            this.UIMap.enterDtcLog();
            capture(8, "Logフォルダ確認");
            System.Threading.Thread.Sleep(1000);
            //System.Diagnostics.Process log = System.Diagnostics.Process.Start(@"C:\Program Files (x86)\sakura\sakura.exe", ini["LOG_FILE", "SAVE_FOLDER"] + @"\YardRepro_DTC.log");
            //System.Threading.Thread.Sleep(2000);
            //capture(9, "Log内容確認");
            //log.Kill();
            //System.Threading.Thread.Sleep(1000);
            this.UIMap.explorerClose_MyDocuments_DTC_Log();
        }

        /// <summary>
        /// ５．進捗確認画面<br>
        /// ５．２．リスト更新処理<br>
        /// ５．２．８．DTC消去ボタン押下<br>
        /// ５．２．８．３．後処理開始要求処理結果:1 後処理結果要求の受信タイムアウト値:10秒 後処理応答フレームの遅延:9秒<br>
        /// </summary>
        [TestMethod]
        public void TestMethod5_2_8_3()
        {
            // Simulator起動
            startSimulator();
            // SimulatorのIPアドレス取得
            string[] ips = getIpAddressList();
            // VIN情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Vin", "1212000000000056494E303030303030303030303030303031");
            // リプロ前ソフト品番情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "SoftBefore", "13150000000000010000003030303030303030303030303030303031");
            // リプロ後ソフト品番情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "SoftAfter", "13150000000000010000003030303030303030303030303030303131");
            // YardRepro起動
            startYardRepro();
            capture(1, "YardRepro起動");
            // 1台にチェックを入れる
            this.UIMap.dst1ItemSelect();
            capture(2, "1台選択し、次へボタン押下");
            // 次へボタン押下
            this.UIMap.nextBtnClick();
            // 3秒待機
            System.Threading.Thread.Sleep(3000);
            // 進捗を0%→100%に変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Status", "1104000000000064000000");
            // 3秒待機
            System.Threading.Thread.Sleep(3000);
            capture(3, "進捗確認画面表示");
            // 後処理実行結果変更（失敗）
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "DtcExec", "15000001000000");
            // 後処理応答フレームの遅延
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "DtcExecSleep", "9000");
            System.Threading.Thread.Sleep(1000);
            // DTC有効
            this.UIMap.P_DTC_Checked();
            this.UIMap.AssertMethod5_2_8_2_Assert1();
            refreshMap();
            capture(4, "DTC消去実施前");
            System.Threading.Thread.Sleep(1000);
            // 後処理実行
            this.UIMap.DtcExec();
            this.UIMap.AssertMethod5_2_8_2_Assert2();
            refreshMap();
            capture(5, "DTC消去実施中");
            // DTC応答11秒待機
            System.Threading.Thread.Sleep(11000);
            capture(6, "DTC消去要求失敗ダイアログ");
            System.Threading.Thread.Sleep(1000);
            // DTC実行エラー
            this.UIMap.DtcExecError();
            this.UIMap.AssertMethod5_2_8_2_Assert4();
            refreshMap();
            capture(7, "DTC消去エラー");
            System.Threading.Thread.Sleep(1000);
        }

        /// <summary>
        /// ５．進捗確認画面<br>
        /// ５．２．リスト更新処理<br>
        /// ５．２．８．DTC消去ボタン押下<br>
        /// ５．２．８．４．後処理開始要求処理結果:0 後処理結果要求の受信タイムアウト値:10秒 後処理応答フレームの遅延:11秒<br>
        /// </summary>
        [TestMethod]
        public void TestMethod5_2_8_4()
        {
            // Simulator起動
            startSimulator();
            // SimulatorのIPアドレス取得
            string[] ips = getIpAddressList();
            // VIN情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Vin", "1212000000000056494E303030303030303030303030303031");
            // リプロ前ソフト品番情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "SoftBefore", "13150000000000010000003030303030303030303030303030303031");
            // リプロ後ソフト品番情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "SoftAfter", "13150000000000010000003030303030303030303030303030303131");
            // YardRepro起動
            startYardRepro();
            capture(1, "YardRepro起動");
            // 1台にチェックを入れる
            this.UIMap.dst1ItemSelect();
            capture(2, "1台選択し、次へボタン押下");
            // 次へボタン押下
            this.UIMap.nextBtnClick();
            // 3秒待機
            System.Threading.Thread.Sleep(3000);
            // 進捗を0%→100%に変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Status", "1104000000000064000000");
            // 3秒待機
            System.Threading.Thread.Sleep(3000);
            capture(3, "進捗確認画面表示");
            // ini表示
            string iniFilePath = WORK_DIRECTORY + @"\YardRepro.ini";
            System.Diagnostics.Process p = System.Diagnostics.Process.Start("notepad.exe", System.IO.Path.GetFullPath(iniFilePath));
            System.Threading.Thread.Sleep(2000);
            capture(4, "受信タイムアウト値確認");
            p.Kill();
            System.Threading.Thread.Sleep(1000);
            // 後処理実行結果変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "DtcExec", "15000000000000");
            // 後処理応答フレームの遅延（11秒）
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "DtcExecSleep", "11000");
            System.Threading.Thread.Sleep(1000);

            // DTC有効
            this.UIMap.P_DTC_Checked();
            this.UIMap.AssertMethod5_2_8_2_Assert1();
            refreshMap();
            capture(5, "DTC消去実施前");
            System.Threading.Thread.Sleep(1000);
            // 後処理実行
            this.UIMap.DtcExec();
            this.UIMap.AssertMethod5_2_8_2_Assert2();
            refreshMap();
            capture(6, "DTC消去実施中");
            // DTC応答11秒待機
            System.Threading.Thread.Sleep(11000);
            // DTC実行エラー
            this.UIMap.AssertMethod5_2_8_2_Assert4();
            refreshMap();
            capture(7, "DTC消去エラー");
            System.Threading.Thread.Sleep(1000);
        }

        /// <summary>
        /// ５．進捗確認画面<br>
        /// ５．２．リスト更新処理<br>
        /// ５．２．８．DTC消去ボタン押下<br>
        /// ５．２．８．５．後処理開始要求処理結果:0 後処理結果要求の受信タイムアウト値:10秒 後処理応答フレームの遅延:9秒<br>
        ///                 ログファイル出力先:C:\Users\カレントユーザ\Yardrepro<br>
        ///                 ログファイル取得要求の返却値を変更(処理結果:1/データ長:0/残りデータサイズ:0)
        /// </summary>
        [TestMethod]
        public void TestMethod5_2_8_5()
        {
            // Simulator起動
            startSimulator();
            // SimulatorのIPアドレス取得
            string[] ips = getIpAddressList();
            // VIN情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Vin", "1212000000000056494E303030303030303030303030303031");
            // リプロ前ソフト品番情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "SoftBefore", "13150000000000010000003030303030303030303030303030303031");
            // リプロ後ソフト品番情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "SoftAfter", "13150000000000010000003030303030303030303030303030303131");
            // YardRepro起動
            startYardRepro();
            capture(1, "YardRepro起動");
            // 1台にチェックを入れる
            this.UIMap.dst1ItemSelect();
            capture(2, "1台選択し、次へボタン押下");
            // 次へボタン押下
            this.UIMap.nextBtnClick();
            // 3秒待機
            System.Threading.Thread.Sleep(3000);
            // 進捗を0%→100%に変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Status", "1104000000000064000000");
            // 3秒待機
            System.Threading.Thread.Sleep(3000);
            capture(3, "進捗確認画面表示");
            // 後処理実行結果変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "DtcExec", "15000000000000");
            // 後処理応答フレームの遅延
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "DtcExecSleep", "9000");
            // ログファイル取得結果変更（取得結果失敗）
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "DtcExecLog",
                            "16" + "0000" + "01000000" + "00000000");
            System.Threading.Thread.Sleep(1000);
            // DTC有効
            this.UIMap.P_DTC_Checked();
            this.UIMap.AssertMethod5_2_8_2_Assert1();
            refreshMap();
            capture(4, "DTC消去実施前");
            System.Threading.Thread.Sleep(1000);
            // 後処理実行
            this.UIMap.DtcExec();
            this.UIMap.AssertMethod5_2_8_2_Assert2();
            refreshMap();
            capture(5, "DTC消去実施中");
            // DTC完了11秒待機
            System.Threading.Thread.Sleep(11000);
            this.UIMap.AssertMethod5_2_8_2_Assert5();
            refreshMap();
            capture(6, "ログ取得エラー");
            System.Threading.Thread.Sleep(1000);
        }

        /// <summary>
        /// ５．進捗確認画面<br>
        /// ５．２．リスト更新処理<br>
        /// ５．２．８．DTC消去ボタン押下<br>
        /// ５．２．８．６．後処理開始要求処理結果:0 後処理結果要求の受信タイムアウト値:10秒 後処理応答フレームの遅延:9秒<br>
        ///                 ログファイル出力先:C:\Users\カレントユーザ\Yardrepro<br>
        ///                 ログファイル取得要求の返却値を変更(１回目：処理結果:0/データ長:505/残りデータサイズ:1)<br>
        ///                 ログファイル取得要求の返却値を変更(２回目：処理結果:0/データ長:5/残りデータサイズ:0)
        /// </summary>
        [TestMethod]
        public void TestMethod5_2_8_6()
        {
            // Simulator起動
            startSimulator();
            // SimulatorのIPアドレス取得
            string[] ips = getIpAddressList();
            // VIN情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Vin", "1212000000000056494E303030303030303030303030303031");
            // リプロ前ソフト品番情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "SoftBefore", "13150000000000010000003030303030303030303030303030303031");
            // リプロ後ソフト品番情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "SoftAfter", "13150000000000010000003030303030303030303030303030303131");
            // YardRepro起動
            startYardRepro();
            capture(1, "YardRepro起動");
            // 1台にチェックを入れる
            this.UIMap.dst1ItemSelect();
            capture(2, "1台選択し、次へボタン押下");
            // 次へボタン押下
            this.UIMap.nextBtnClick();
            // 3秒待機
            System.Threading.Thread.Sleep(3000);
            // 進捗を0%→100%に変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Status", "1104000000000064000000");
            // 3秒待機
            System.Threading.Thread.Sleep(3000);
            capture(3, "進捗確認画面表示");
            // ini表示
            string iniFilePath = WORK_DIRECTORY + @"\YardRepro.ini";
            System.Diagnostics.Process p = System.Diagnostics.Process.Start("notepad.exe", System.IO.Path.GetFullPath(iniFilePath));
            System.Threading.Thread.Sleep(2000);
            capture(4, "Log出力先確認");
            p.Kill();
            System.Threading.Thread.Sleep(1000);
            // 後処理実行結果変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "DtcExec", "15000000000000");
            // 後処理応答フレームの遅延
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "DtcExecSleep", "9000");
            // ログファイル取得結果変更（データ長F901→01F9:505byte、残り01000000:1byte）
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "DtcExecLog",
                            "16" + "F901" + "00000000" + "01000000" +
                            "3030303030303030303030303030303031" +
                            "3030303030303030303030303030303032" +
                            "3030303030303030303030303030303033" +
                            "3030303030303030303030303030303034" +
                            "3030303030303030303030303030303035" +
                            "3030303030303030303030303030303036" +
                            "3030303030303030303030303030303037" +
                            "3030303030303030303030303030303038" +
                            "3030303030303030303030303030303039" +
                            "3030303030303030303030303030303130" +
                            "3030303030303030303030303030303131" +
                            "3030303030303030303030303030303132" +
                            "3030303030303030303030303030303133" +
                            "3030303030303030303030303030303134" +
                            "3030303030303030303030303030303135" +
                            "3030303030303030303030303030303136" +
                            "3030303030303030303030303030303137" +
                            "3030303030303030303030303030303138" +
                            "3030303030303030303030303030303139" +
                            "3030303030303030303030303030303230" +
                            "3030303030303030303030303030303231" +
                            "3030303030303030303030303030303232" +
                            "3030303030303030303030303030303233" +
                            "3030303030303030303030303030303234" +
                            "3030303030303030303030303030303235" +
                            "3030303030303030303030303030303236" +
                            "3030303030303030303030303030303237" +
                            "3030303030303030303030303030303238" +
                            "3030303030303030303030303030303239" +
                            "3030303030303030" +
                            //（データ長0100:1byte、残り00000000:0byte）
                            "16" + "0100" + "00000000" + "00000000" + "30");
            System.Threading.Thread.Sleep(1000);
            // DTC有効
            this.UIMap.P_DTC_Checked();
            this.UIMap.AssertMethod5_2_8_2_Assert1();
            refreshMap();
            capture(5, "DTC消去実施前");
            System.Threading.Thread.Sleep(1000);
            // 後処理実行
            this.UIMap.DtcExec();
            this.UIMap.AssertMethod5_2_8_2_Assert2();
            refreshMap();
            capture(6, "DTC消去実施中");
            // DTC完了11秒待機
            System.Threading.Thread.Sleep(11000);
            this.UIMap.AssertMethod5_2_8_2_Assert3();
            refreshMap();
            capture(7, "DTC消去完了");
            System.Threading.Thread.Sleep(1000);

            // [yardrepro.ini]を読込み設定値を取得する
            Ini ini = new Ini(iniFilePath);
            // logディレクトリ表示
            System.Diagnostics.Process.Start("EXPLORER.EXE", @"/select,""" + System.IO.Path.GetFullPath(ini["LOG_FILE", "SAVE_FOLDER"]) + @"""");
            System.Threading.Thread.Sleep(2000);
            this.UIMap.enterDtcLog();
            capture(8, "Logフォルダ確認");
            System.Threading.Thread.Sleep(1000);
            //System.Diagnostics.Process log = System.Diagnostics.Process.Start(@"C:\Program Files (x86)\sakura\sakura.exe", ini["LOG_FILE", "SAVE_FOLDER"] + @"\YardRepro_DTC.log");
            //System.Threading.Thread.Sleep(2000);
            //capture(9, "Log内容確認");
            //log.Kill();
            //System.Threading.Thread.Sleep(1000);
            this.UIMap.explorerClose_MyDocuments_DTC_Log();
        }

        /// <summary>
        /// ５．進捗確認画面<br>
        /// ５．２．リスト更新処理<br>
        /// ５．２．８．DTC消去ボタン押下<br>
        /// ５．２．８．７．後処理開始要求処理結果:0 後処理結果要求の受信タイムアウト値:10秒 後処理応答フレームの遅延:9秒<br>
        ///                 ログファイル出力先:C:\Users\カレントユーザ\Yardrepro<br>
        ///                 ログファイル取得要求の返却値を変更(１回目：処理結果:0/データ長:505/残りデータサイズ:501)<br>
        ///                 ログファイル取得要求の返却値を変更(２回目：処理結果:0/データ長:505/残りデータサイズ:0)
        /// </summary>
        [TestMethod]
        public void TestMethod5_2_8_7()
        {
            // Simulator起動
            startSimulator();
            // SimulatorのIPアドレス取得
            string[] ips = getIpAddressList();
            // VIN情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Vin", "1212000000000056494E303030303030303030303030303031");
            // リプロ前ソフト品番情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "SoftBefore", "13150000000000010000003030303030303030303030303030303031");
            // リプロ後ソフト品番情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "SoftAfter", "13150000000000010000003030303030303030303030303030303131");
            // YardRepro起動
            startYardRepro();
            capture(1, "YardRepro起動");
            // 1台にチェックを入れる
            this.UIMap.dst1ItemSelect();
            capture(2, "1台選択し、次へボタン押下");
            // 次へボタン押下
            this.UIMap.nextBtnClick();
            // 3秒待機
            System.Threading.Thread.Sleep(3000);
            // 進捗を0%→100%に変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Status", "1104000000000064000000");
            // 3秒待機
            System.Threading.Thread.Sleep(3000);
            capture(3, "進捗確認画面表示");
            // ini表示
            string iniFilePath = WORK_DIRECTORY + @"\YardRepro.ini";
            System.Diagnostics.Process p = System.Diagnostics.Process.Start("notepad.exe", System.IO.Path.GetFullPath(iniFilePath));
            System.Threading.Thread.Sleep(2000);
            capture(4, "受信タイムアウト値/Log出力先確認");
            p.Kill();
            System.Threading.Thread.Sleep(1000);
            // 後処理実行結果変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "DtcExec", "15000000000000");
            // 後処理応答フレームの遅延
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "DtcExecSleep", "9000");
            // ログファイル取得結果変更（データ長F901→01F9:505byte、残りF5010000→01F5:501byte）
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "DtcExecLog",
                            "16" + "F901" + "00000000" + "F5010000" +
                            "3030303030303030303030303030303031" +
                            "3030303030303030303030303030303032" +
                            "3030303030303030303030303030303033" +
                            "3030303030303030303030303030303034" +
                            "3030303030303030303030303030303035" +
                            "3030303030303030303030303030303036" +
                            "3030303030303030303030303030303037" +
                            "3030303030303030303030303030303038" +
                            "3030303030303030303030303030303039" +
                            "3030303030303030303030303030303130" +
                            "3030303030303030303030303030303131" +
                            "3030303030303030303030303030303132" +
                            "3030303030303030303030303030303133" +
                            "3030303030303030303030303030303134" +
                            "3030303030303030303030303030303135" +
                            "3030303030303030303030303030303136" +
                            "3030303030303030303030303030303137" +
                            "3030303030303030303030303030303138" +
                            "3030303030303030303030303030303139" +
                            "3030303030303030303030303030303230" +
                            "3030303030303030303030303030303231" +
                            "3030303030303030303030303030303232" +
                            "3030303030303030303030303030303233" +
                            "3030303030303030303030303030303234" +
                            "3030303030303030303030303030303235" +
                            "3030303030303030303030303030303236" +
                            "3030303030303030303030303030303237" +
                            "3030303030303030303030303030303238" +
                            "3030303030303030303030303030303239" +
                            "3030303030303030" +
                            //（データ長F901→01F9:505byte、残り00000000:0byte）
                            "16" + "F901" + "00000000" + "00000000" +
                            "3030303030303030303030303030303031" +
                            "3030303030303030303030303030303032" +
                            "3030303030303030303030303030303033" +
                            "3030303030303030303030303030303034" +
                            "3030303030303030303030303030303035" +
                            "3030303030303030303030303030303036" +
                            "3030303030303030303030303030303037" +
                            "3030303030303030303030303030303038" +
                            "3030303030303030303030303030303039" +
                            "3030303030303030303030303030303130" +
                            "3030303030303030303030303030303131" +
                            "3030303030303030303030303030303132" +
                            "3030303030303030303030303030303133" +
                            "3030303030303030303030303030303134" +
                            "3030303030303030303030303030303135" +
                            "3030303030303030303030303030303136" +
                            "3030303030303030303030303030303137" +
                            "3030303030303030303030303030303138" +
                            "3030303030303030303030303030303139" +
                            "3030303030303030303030303030303230" +
                            "3030303030303030303030303030303231" +
                            "3030303030303030303030303030303232" +
                            "3030303030303030303030303030303233" +
                            "3030303030303030303030303030303234" +
                            "3030303030303030303030303030303235" +
                            "3030303030303030303030303030303236" +
                            "3030303030303030303030303030303237" +
                            "3030303030303030303030303030303238" +
                            "3030303030303030303030303030303239" +
                            "3030303030303030");
            System.Threading.Thread.Sleep(1000);
            // DTC有効
            this.UIMap.P_DTC_Checked();
            this.UIMap.AssertMethod5_2_8_2_Assert1();
            refreshMap();
            capture(5, "DTC消去実施前");
            System.Threading.Thread.Sleep(1000);
            // 後処理実行
            this.UIMap.DtcExec();
            this.UIMap.AssertMethod5_2_8_2_Assert2();
            refreshMap();
            capture(6, "DTC消去実施中");
            // DTC完了11秒待機
            System.Threading.Thread.Sleep(11000);
            this.UIMap.AssertMethod5_2_8_2_Assert3();
            refreshMap();
            capture(7, "DTC消去完了");
            System.Threading.Thread.Sleep(1000);

            // [yardrepro.ini]を読込み設定値を取得する
            Ini ini = new Ini(iniFilePath);
            // logディレクトリ表示
            System.Diagnostics.Process.Start("EXPLORER.EXE", @"/select,""" + System.IO.Path.GetFullPath(ini["LOG_FILE", "SAVE_FOLDER"]) + @"""");
            System.Threading.Thread.Sleep(2000);
            this.UIMap.enterDtcLog();
            capture(8, "Logフォルダ確認");
            System.Threading.Thread.Sleep(1000);
            //System.Diagnostics.Process log = System.Diagnostics.Process.Start(@"C:\Program Files (x86)\sakura\sakura.exe", ini["LOG_FILE", "SAVE_FOLDER"] + @"\YardRepro_DTC.log");
            //System.Threading.Thread.Sleep(2000);
            //capture(9, "Log内容確認");
            //log.Kill();
            //System.Threading.Thread.Sleep(1000);
            this.UIMap.explorerClose_MyDocuments_DTC_Log();
        }

        /// <summary>
        /// ５．進捗確認画面<br>
        /// ５．２．リスト更新処理<br>
        /// ５．２．８．DTC消去ボタン押下<br>
        /// ５．２．８．８．後処理開始要求処理結果:0 後処理結果要求の受信タイムアウト値:10秒 後処理応答フレームの遅延:9秒<br>
        ///                 ログファイル出力先:C:\Users\カレントユーザ\Yardrepro<br>
        ///                 ログファイル取得要求の返却値を変更(１回目：処理結果:0/データ長:505/残りデータサイズ:501)<br>
        ///                 サーバ停止（通信切断）
        /// </summary>
        [TestMethod]
        public void TestMethod5_2_8_8()
        {
            // [yardrepro.ini]を読込み設定値を取得する
            string iniFilePath = WORK_DIRECTORY + @"\YardRepro.ini";
            Ini ini = new Ini(iniFilePath);

            // logディレクトリ削除
            if (System.IO.Directory.Exists(System.IO.Path.GetFullPath(ini["LOG_FILE", "SAVE_FOLDER"])))
            {
                System.IO.Directory.Delete(System.IO.Path.GetFullPath(ini["LOG_FILE", "SAVE_FOLDER"]), true);
            }

            // Simulator起動
            startSimulator();
            // SimulatorのIPアドレス取得
            string[] ips = getIpAddressList();
            // VIN情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Vin", "1212000000000056494E303030303030303030303030303031");
            // リプロ前ソフト品番情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "SoftBefore", "13150000000000010000003030303030303030303030303030303031");
            // リプロ後ソフト品番情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "SoftAfter", "13150000000000010000003030303030303030303030303030303131");
            // YardRepro起動
            startYardRepro();
            capture(1, "YardRepro起動");
            // 1台にチェックを入れる
            this.UIMap.dst1ItemSelect();
            capture(2, "1台選択し、次へボタン押下");
            // 次へボタン押下
            this.UIMap.nextBtnClick();
            // 3秒待機
            System.Threading.Thread.Sleep(3000);
            // 進捗を0%→100%に変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Status", "1104000000000064000000");
            // 3秒待機
            System.Threading.Thread.Sleep(3000);
            capture(3, "進捗確認画面表示");
            // ini表示
            System.Diagnostics.Process p = System.Diagnostics.Process.Start("notepad.exe", System.IO.Path.GetFullPath(iniFilePath));
            System.Threading.Thread.Sleep(2000);
            capture(4, "受信タイムアウト値/Log出力先確認");
            p.Kill();
            System.Threading.Thread.Sleep(1000);
            // 後処理実行結果変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "DtcExec", "15000000000000");
            // 後処理応答フレームの遅延
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "DtcExecSleep", "9000");
            // ログファイル取得結果変更（データ長F901→01F9:505byte、残りF5010000→01F5:501byte）
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "DtcExecLog",
                            "16" + "F901" + "00000000" + "F5010000" +
                            "3030303030303030303030303030303031" +
                            "3030303030303030303030303030303032" +
                            "3030303030303030303030303030303033" +
                            "3030303030303030303030303030303034" +
                            "3030303030303030303030303030303035" +
                            "3030303030303030303030303030303036" +
                            "3030303030303030303030303030303037" +
                            "3030303030303030303030303030303038" +
                            "3030303030303030303030303030303039" +
                            "3030303030303030303030303030303130" +
                            "3030303030303030303030303030303131" +
                            "3030303030303030303030303030303132" +
                            "3030303030303030303030303030303133" +
                            "3030303030303030303030303030303134" +
                            "3030303030303030303030303030303135" +
                            "3030303030303030303030303030303136" +
                            "3030303030303030303030303030303137" +
                            "3030303030303030303030303030303138" +
                            "3030303030303030303030303030303139" +
                            "3030303030303030303030303030303230" +
                            "3030303030303030303030303030303231" +
                            "3030303030303030303030303030303232" +
                            "3030303030303030303030303030303233" +
                            "3030303030303030303030303030303234" +
                            "3030303030303030303030303030303235" +
                            "3030303030303030303030303030303236" +
                            "3030303030303030303030303030303237" +
                            "3030303030303030303030303030303238" +
                            "3030303030303030303030303030303239" +
                            "3030303030303030" +
                            //（データ長F901→01F9:505byte、残り00000000:0byte）
                            "16" + "F901" + "00000000" + "00000000" +
                            "3030303030303030303030303030303031" +
                            "3030303030303030303030303030303032" +
                            "3030303030303030303030303030303033" +
                            "3030303030303030303030303030303034" +
                            "3030303030303030303030303030303035" +
                            "3030303030303030303030303030303036" +
                            "3030303030303030303030303030303037" +
                            "3030303030303030303030303030303038" +
                            "3030303030303030303030303030303039" +
                            "3030303030303030303030303030303130" +
                            "3030303030303030303030303030303131" +
                            "3030303030303030303030303030303132" +
                            "3030303030303030303030303030303133" +
                            "3030303030303030303030303030303134" +
                            "3030303030303030303030303030303135" +
                            "3030303030303030303030303030303136" +
                            "3030303030303030303030303030303137" +
                            "3030303030303030303030303030303138" +
                            "3030303030303030303030303030303139" +
                            "3030303030303030303030303030303230" +
                            "3030303030303030303030303030303231" +
                            "3030303030303030303030303030303232" +
                            "3030303030303030303030303030303233" +
                            "3030303030303030303030303030303234" +
                            "3030303030303030303030303030303235" +
                            "3030303030303030303030303030303236" +
                            "3030303030303030303030303030303237" +
                            "3030303030303030303030303030303238" +
                            "3030303030303030303030303030303239" +
                            "3030303030303030");
            System.Threading.Thread.Sleep(1000);
            // DTC有効
            this.UIMap.P_DTC_Checked();
            this.UIMap.AssertMethod5_2_8_2_Assert1();
            refreshMap();
            capture(5, "DTC消去実施前");
            System.Threading.Thread.Sleep(1000);
            // 後処理実行
            this.UIMap.DtcExec();
            this.UIMap.AssertMethod5_2_8_2_Assert2();
            refreshMap();
            capture(6, "DTC消去実施中");
            // DTC完了10秒待機
            System.Threading.Thread.Sleep(9100);

            // サービス切断
            udpIniUpdateSend("localhost", byte.Parse("3"), ips[0], null, null);
            System.Threading.Thread.Sleep(12000);
            this.UIMap.AssertMethod5_2_8_3_Assert1();
            refreshMap();
            capture(7, "DTCログ取得エラー");
            System.Threading.Thread.Sleep(1000);

            // logディレクトリ表示
            System.Diagnostics.Process.Start("EXPLORER.EXE", @"/select,""" + System.IO.Path.GetFullPath(ini["LOG_FILE", "SAVE_FOLDER"]) + @"""");
            System.Threading.Thread.Sleep(2000);
            this.UIMap.enterDtcLog();
            capture(8, "Logフォルダ確認 - エラーのため出力なし");
            System.Threading.Thread.Sleep(1000);
            this.UIMap.explorerClose_MyDocuments_DTC_Log();
        }

        /// <summary>
        /// ５．進捗確認画面<br>
        /// ５．２．リスト更新処理<br>
        /// ５．２．８．DTC消去ボタン押下<br>
        /// ５．２．８．９．後処理開始要求処理結果:0 後処理結果要求の受信タイムアウト値:10秒 後処理応答フレームの遅延:9秒<br>
        ///                 ログファイル出力先:C:\Users\カレントユーザ\Yardrepro<br>
        ///                 ログファイル取得要求の返却値を変更(１回目：処理結果:0/データ長:505/残りデータサイズ:501)<br>
        ///                 サーバ停止（通信切断）<br>
        ///                 ログファイル取得要求の返却値を変更(１回目：処理結果:0/データ長:505/残りデータサイズ:501)<br>
        ///                 ログファイル取得要求の返却値を変更(２回目：処理結果:0/データ長:505/残りデータサイズ:0)
        /// </summary>
        [TestMethod]
        public void TestMethod5_2_8_9()
        {
            // [yardrepro.ini]を読込み設定値を取得する
            string iniFilePath = WORK_DIRECTORY + @"\YardRepro.ini";
            Ini ini = new Ini(iniFilePath);

            // logディレクトリ削除
            if (System.IO.Directory.Exists(System.IO.Path.GetFullPath(ini["LOG_FILE", "SAVE_FOLDER"])))
            {
                System.IO.Directory.Delete(System.IO.Path.GetFullPath(ini["LOG_FILE", "SAVE_FOLDER"]), true);
            }

            // Simulator起動
            startSimulator();
            // SimulatorのIPアドレス取得
            string[] ips = getIpAddressList();
            // VIN情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Vin", "1212000000000056494E303030303030303030303030303031");
            // リプロ前ソフト品番情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "SoftBefore", "13150000000000010000003030303030303030303030303030303031");
            // リプロ後ソフト品番情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "SoftAfter", "13150000000000010000003030303030303030303030303030303131");
            // YardRepro起動
            startYardRepro();
            capture(1, "YardRepro起動");
            // 1台にチェックを入れる
            this.UIMap.dst1ItemSelect();
            capture(2, "1台選択し、次へボタン押下");
            // 次へボタン押下
            this.UIMap.nextBtnClick();
            // 3秒待機
            System.Threading.Thread.Sleep(3000);
            // 進捗を0%→100%に変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Status", "1104000000000064000000");
            // 3秒待機
            System.Threading.Thread.Sleep(3000);
            capture(3, "進捗確認画面表示");
            // ini表示
            System.Diagnostics.Process p = System.Diagnostics.Process.Start("notepad.exe", System.IO.Path.GetFullPath(iniFilePath));
            System.Threading.Thread.Sleep(2000);
            capture(4, "受信タイムアウト値/Log出力先確認");
            p.Kill();
            System.Threading.Thread.Sleep(1000);
            // 後処理実行結果変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "DtcExec", "15000000000000");
            // 後処理応答フレームの遅延
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "DtcExecSleep", "9000");
            // ログファイル取得結果変更（データ長F901→01F9:505byte、残りF5010000→01F5:501byte）
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "DtcExecLog",
                            "16" + "F901" + "00000000" + "F5010000" +
                            "3030303030303030303030303030303031" +
                            "3030303030303030303030303030303032" +
                            "3030303030303030303030303030303033" +
                            "3030303030303030303030303030303034" +
                            "3030303030303030303030303030303035" +
                            "3030303030303030303030303030303036" +
                            "3030303030303030303030303030303037" +
                            "3030303030303030303030303030303038" +
                            "3030303030303030303030303030303039" +
                            "3030303030303030303030303030303130" +
                            "3030303030303030303030303030303131" +
                            "3030303030303030303030303030303132" +
                            "3030303030303030303030303030303133" +
                            "3030303030303030303030303030303134" +
                            "3030303030303030303030303030303135" +
                            "3030303030303030303030303030303136" +
                            "3030303030303030303030303030303137" +
                            "3030303030303030303030303030303138" +
                            "3030303030303030303030303030303139" +
                            "3030303030303030303030303030303230" +
                            "3030303030303030303030303030303231" +
                            "3030303030303030303030303030303232" +
                            "3030303030303030303030303030303233" +
                            "3030303030303030303030303030303234" +
                            "3030303030303030303030303030303235" +
                            "3030303030303030303030303030303236" +
                            "3030303030303030303030303030303237" +
                            "3030303030303030303030303030303238" +
                            "3030303030303030303030303030303239" +
                            "3030303030303030" +
                            //（データ長F901→01F9:505byte、残り00000000:0byte）
                            "16" + "F901" + "00000000" + "00000000" +
                            "3030303030303030303030303030303031" +
                            "3030303030303030303030303030303032" +
                            "3030303030303030303030303030303033" +
                            "3030303030303030303030303030303034" +
                            "3030303030303030303030303030303035" +
                            "3030303030303030303030303030303036" +
                            "3030303030303030303030303030303037" +
                            "3030303030303030303030303030303038" +
                            "3030303030303030303030303030303039" +
                            "3030303030303030303030303030303130" +
                            "3030303030303030303030303030303131" +
                            "3030303030303030303030303030303132" +
                            "3030303030303030303030303030303133" +
                            "3030303030303030303030303030303134" +
                            "3030303030303030303030303030303135" +
                            "3030303030303030303030303030303136" +
                            "3030303030303030303030303030303137" +
                            "3030303030303030303030303030303138" +
                            "3030303030303030303030303030303139" +
                            "3030303030303030303030303030303230" +
                            "3030303030303030303030303030303231" +
                            "3030303030303030303030303030303232" +
                            "3030303030303030303030303030303233" +
                            "3030303030303030303030303030303234" +
                            "3030303030303030303030303030303235" +
                            "3030303030303030303030303030303236" +
                            "3030303030303030303030303030303237" +
                            "3030303030303030303030303030303238" +
                            "3030303030303030303030303030303239" +
                            "3030303030303030");
            System.Threading.Thread.Sleep(1000);
            // DTC有効
            this.UIMap.P_DTC_Checked();
            this.UIMap.AssertMethod5_2_8_2_Assert1();
            refreshMap();
            capture(5, "DTC消去実施前");
            System.Threading.Thread.Sleep(1000);
            // 後処理実行
            this.UIMap.DtcExec();
            this.UIMap.AssertMethod5_2_8_2_Assert2();
            refreshMap();
            capture(6, "DTC消去実施中");
            // DTC完了9.1秒待機
            System.Threading.Thread.Sleep(9100);

            // サービス切断
            udpIniUpdateSend("localhost", byte.Parse("3"), ips[0], null, null);
            System.Threading.Thread.Sleep(5000);
            // サービス開始
            udpIniUpdateSend("localhost", byte.Parse("2"), ips[0], null, null);
            System.Threading.Thread.Sleep(3000);

            this.UIMap.AssertMethod5_2_8_2_Assert3();
            refreshMap();
            capture(7, "DTC消去完了");
            System.Threading.Thread.Sleep(1000);

            // logディレクトリ表示
            System.Diagnostics.Process.Start("EXPLORER.EXE", @"/select,""" + System.IO.Path.GetFullPath(ini["LOG_FILE", "SAVE_FOLDER"]) + @"""");
            System.Threading.Thread.Sleep(2000);
            this.UIMap.enterDtcLog();
            capture(8, "Logフォルダ確認");
            System.Threading.Thread.Sleep(1000);
            //System.Diagnostics.Process log = System.Diagnostics.Process.Start(@"C:\Program Files (x86)\sakura\sakura.exe", ini["LOG_FILE", "SAVE_FOLDER"] + @"\YardRepro_DTC.log");
            //System.Threading.Thread.Sleep(2000);
            //capture(9, "Log内容確認");
            //log.Kill();
            //System.Threading.Thread.Sleep(1000);
            this.UIMap.explorerClose_MyDocuments_DTC_Log();
        }

        /// <summary>
        /// ５．進捗確認画面<br>
        /// ５．２．リスト更新処理<br>
        /// ５．２．９．リプロ差替え<br>
        /// ５．２．９．１．VIN変更無→リプロツール差替え中（接続エラー）→
        ///                 ステータス取得の返却値を変更(処理結果:0/進捗:0) VIN取得情報処理結果:0/VIN:VIN000000000000011→
        ///                 ステータス取得の返却値を変更(処理結果:0/進捗:50)
        /// </summary>
        [TestMethod]
        public void TestMethod5_2_9_1()
        {
            // Simulator起動
            startSimulator();
            // SimulatorのIPアドレス取得
            string[] ips = getIpAddressList();
            // VIN情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Vin", "1212000000000056494E303030303030303030303030303031");
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[1], "Vin", "1212000000000056494E303030303030303030303030303032");
            // リプロ前ソフト品番情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "SoftBefore", "13150000000000010000003030303030303030303030303030303031");
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[1], "SoftBefore", "13150000000000010000003030303030303030303030303030303032");
            // リプロ後ソフト品番情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "SoftAfter", "13150000000000010000003030303030303030303030303030303131");
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[1], "SoftAfter", "13150000000000010000003030303030303030303030303030303132");
            System.Threading.Thread.Sleep(1000);

            // YardRepro起動
            startYardRepro();
            capture(1, "YardRepro起動");
            // 2台にチェックを入れる
            this.UIMap.nextBtn2Click();
            // 3秒待機
            System.Threading.Thread.Sleep(3000);
            // 進捗を0%→100%に変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Status", "1104000000000064000000");
            // 3秒待機
            System.Threading.Thread.Sleep(3000);
            this.UIMap.AssertMethod5_2_9_1_Assert1();
            capture(2, "進捗確認画面表示");
            // 3秒待機
            System.Threading.Thread.Sleep(3000);
            this.UIMap.AssertMethod5_2_9_1_Assert1();
            capture(3, "進捗確認画面表示 - ３秒後");
            // サービス切断
            udpIniUpdateSend("localhost", byte.Parse("3"), ips[0], null, null);
            System.Threading.Thread.Sleep(12000);
            this.UIMap.AssertMethod5_2_9_1_Assert2();
            refreshMap();
            capture(4, "進捗確認画面表示 - 切断エラー");

            // VIN情報変更（VIN000000000000011）
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Vin", "1212000000000056494E303030303030303030303030303131");
            // 進捗を0%に変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Status", "1104000000000000000000");
            // サービス開始
            udpIniUpdateSend("localhost", byte.Parse("2"), ips[0], null, null);
            // 3秒待機
            System.Threading.Thread.Sleep(3000);

            this.UIMap.AssertMethod5_2_9_1_Assert3();
            this.UIMap.AssertMethod5_2_9_1_Assert4();
            refreshMap();
            capture(5, "進捗確認画面表示 - リプロツール差替え後");

            // 進捗を0%→50%に変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Status", "1104000000000032000000");
            // 3秒待機
            System.Threading.Thread.Sleep(3000);
            this.UIMap.AssertMethod5_2_9_1_Assert5();
            capture(6, "進捗確認画面表示 - リプロツール差替え後進捗５０％");
        }

        /// <summary>
        /// ５．進捗確認画面<br>
        /// ５．３．DST選択ボタン<br>
        /// ５．３．１．DST選択ボタンをクリック<br>
        /// ５．３．２．選択チェックを追加して次へをクリック<br>
        /// ５．３．３．選択チェックを外して次へをクリック<br>
        /// ５．３．４．表示順（リプロ開始日時の降順）<br>
        /// ５．３．５．リプロツール差替え済み情報の削除不可<br>
        /// </summary>
        [TestMethod]
        public void TestMethod5_3_3()
        {
            // Simulator起動
            startSimulator();
            // SimulatorのIPアドレス取得
            string[] ips = getIpAddressList();
            // VIN情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Vin", "1212000000000056494E303030303030303030303030303031");
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[1], "Vin", "1212000000000056494E303030303030303030303030303032");
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[5], "Vin", "1212000000000056494E303030303030303030303030303036");
            // リプロ前ソフト品番情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "SoftBefore", "13150000000000010000003030303030303030303030303030303031");
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[1], "SoftBefore", "13150000000000010000003030303030303030303030303030303032");
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[5], "SoftBefore", "13150000000000010000003030303030303030303030303030303036");
            // リプロ後ソフト品番情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "SoftAfter", "13150000000000010000003030303030303030303030303030303131");
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[1], "SoftAfter", "13150000000000010000003030303030303030303030303030303132");
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[5], "SoftAfter", "13150000000000010000003030303030303030303030303030303136");
            System.Threading.Thread.Sleep(1000);

            // YardRepro起動
            startYardRepro();
            capture(1, "YardRepro起動");
            // 1台にチェックを入れる
            this.UIMap.dst1ItemSelect();
            capture(2, "1台選択し、次へボタン押下");
            // 次へボタン押下
            this.UIMap.nextBtnClick();
            capture(3, "進捗確認画面表示");
            // DST選択ボタン押下
            this.UIMap.dstSelectBtnClick();
            // 画面確認
            this.UIMap.AssertMethod5_3_3_Assert1();
            capture(4, "DST選択ボタン押下");
            this.UIMap.dstNextItemSelect();
            // 一番下にチェックを入れる
            this.UIMap.dstLastItemSelect();
            capture(5, "追加で2台選択し、次へボタン押下");
            // 次へボタン押下
            this.UIMap.nextBtnClick();
            // 進捗確認画面確認
            this.UIMap.AssertMethod5_3_3_Assert2();
            this.UIMap.AssertMethod5_3_3_ListAssert1();
            capture(6, "進捗確認画面確認 - リプロ開始日時の降順表示");
            // DST選択ボタン押下
            this.UIMap.dstSelectBtnClick();
            // 一番下にチェックを外す
            this.UIMap.dstLastItemUnSelect();
            capture(7, "追加した1台のチェックを外し、次へボタン押下");
            // 次へボタン押下
            this.UIMap.nextBtnClick();
            // 進捗確認画面確認
            this.UIMap.AssertMethod5_3_3_Assert3();
            this.UIMap.AssertMethod5_3_3_ListAssert2();
            capture(8, "進捗確認画面確認 - 削除");

            // VIN情報変更（VIN000000000000011）
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Vin", "1212000000000056494E303030303030303030303030303131");
            // 3秒待機
            System.Threading.Thread.Sleep(6000);
            capture(9, "進捗確認画面確認 - リプロ差替え");
            // DST選択ボタン押下
            this.UIMap.dstSelectBtnClick();
            // 一番上のチェックを外す
            this.UIMap.dstTopItemUnSelect();
            capture(10, "リプロツール差替え対象のチェックを外し、次へボタン押下");
            // 次へボタン押下
            this.UIMap.nextBtnClick();
            // 進捗確認画面確認
            this.UIMap.AssertMethod5_3_3_Assert4();
            this.UIMap.AssertMethod5_3_3_ListAssert2();
            capture(11, "進捗確認画面確認 - リプロ差替え済み保持");

        }

        /// <summary>
        /// ５．進捗確認画面<br>
        /// ５．４．CSVボタン<br>
        /// ５．４．１．保存ダイアログ<br>
        /// ５．４．１．１．保存ダイアログ<br>
        /// ５．４．１．２．タイトル<br>
        /// ５．４．１．３．フィルタ<br>
        /// ５．４．１．４．ファイル種別<br>
        /// ５．４．１．５．デフォルトファイル名<br>
        /// ５．４．１．６．上書き確認<br>
        /// </summary>
        [TestMethod]
        public void TestMethod5_4_1_1()
        {
            string CsvFile = System.Environment.GetFolderPath(Environment.SpecialFolder.Personal) + @"\newfile.csv";
            // CSVファイル削除
            if (System.IO.File.Exists(CsvFile))
            {
                System.IO.File.Delete(CsvFile);
            }
            // CSVファイル作成
            using (System.IO.FileStream hStream = System.IO.File.Create(CsvFile))
            {
                if (hStream != null)
                {
                    hStream.Close();
                }
            }
            // Simulator起動
            startSimulator();
            // YardRepro起動
            startYardRepro();
            capture(1, "YardRepro起動");
            // 1台にチェックを入れる
            this.UIMap.dst1ItemSelect();
            capture(2, "1台選択し、次へボタン押下");
            // 次へボタン押下
            this.UIMap.nextBtnClick();
            capture(3, "進捗確認画面表示");
            // CSV出力ボタン押下
            this.UIMap.csvOutputBtnClick();
            // 保存ダイアログ確認
            this.UIMap.AssertMethod5_4_1_1_Assert1();
            this.UIMap.AssertMethod5_4_1_1_ListAssert();
            capture(4, "保存ダイアログ確認");
            // 保存ボタン押下
            this.UIMap.csvFileSaveBtnClick();
            // 上書き確認ダイアログ確認
            this.UIMap.AssertMethod5_4_1_1_Assert2();
            capture(5, "上書き確認ダイアログ確認");
            // CSVファイル削除
            System.IO.File.Delete(CsvFile);
        }

        /// <summary>
        /// ５．進捗確認画面<br>
        /// ５．４．CSVボタン<br>
        /// ５．４．２．CSVファイル<br>
        /// ５．４．２．１．保存先<br>
        /// ５．４．２．２．ヘッダ<br>
        /// ５．４．２．３．フォーマット<br>
        /// ５．４．２．４．内容<br>
        /// ５．４．２．５．エンコード<br>
        /// </summary>
        [TestMethod]
        public void TestMethod5_4_2_1()
        {
            // Simulator起動
            startSimulator();
            // SimulatorのIPアドレス取得
            string[] ips = getIpAddressList();
            // VIN情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Vin", "1212000000000056494E303030303030303030303030303031");
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[1], "Vin", "1212000000000056494E303030303030303030303030303032");
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[2], "Vin", "1212000000000056494E303030303030303030303030303033");
            // リプロ前ソフト品番情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "SoftBefore", "13150000000000010000003030303030303030303030303030303031");
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[1], "SoftBefore", "13150000000000010000003030303030303030303030303030303032");
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[2], "SoftBefore", "13150000000000010000003030303030303030303030303030303033");
            // リプロ後ソフト品番情報変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "SoftAfter", "13150000000000010000003030303030303030303030303030303131");

            // YardRepro起動
            startYardRepro();
            capture(1, "YardRepro起動");
            // 3台にチェックを入れる
            this.UIMap.dst3ItemSelect();
            capture(2, "3台選択し、次へボタン押下");
            // 次へボタン押下
            this.UIMap.nextBtnClick();
            // 1台目の進捗を0%→100%に変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[0], "Status", "1104000000000064000000");
            // 2台目の進捗を0%→50%に変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[1], "Status", "1104000000000032000000");
            // 3台目の進捗を0%→0x01 VIN読出し不可エラーに変更
            udpIniUpdateSend("localhost", byte.Parse("1"), ips[2], "Status", "1104000100000000000000");
            // 3秒待機
            System.Threading.Thread.Sleep(3000);
            capture(3, "ステータスを変更");
            // CSVファイル削除
            if (System.IO.File.Exists(System.Environment.GetFolderPath(Environment.SpecialFolder.Personal) + @"\newfile.csv"))
            {
                System.IO.File.Delete(System.Environment.GetFolderPath(Environment.SpecialFolder.Personal) + @"\newfile.csv");
            }
            // CSV出力ボタン押下
            this.UIMap.csvOutputBtnClick();
            // 保存ダイアログ表示まで待機
            System.Threading.Thread.Sleep(3000);
            capture(4, "CSVファイルを保存");
            // 保存ボタン押下
            this.UIMap.csvFileSaveBtnClick();
            // 2秒待機
            System.Threading.Thread.Sleep(2000);
            // CSVファイル内容確認
            List<string> lines = new List<string>();
            using (FileStream fs = new FileStream(System.Environment.GetFolderPath(Environment.SpecialFolder.Personal) + @"\newfile.csv", FileMode.Open, FileAccess.Read))
            {
                using (TextReader reader = new StreamReader(fs))
                { 
                    while (reader.Peek() >= 0)
                    {
                        lines.Add(reader.ReadLine());
                    }
                }
            }
            Assert.AreEqual("リプロツール情報,Vin,リプロ前ソフト品番,リプロ後ソフト品番,リプロ状況", lines[0]);
            Assert.AreEqual("DSTWiFiSim003,VIN000000000000003,00000000000000003,,VIN読出し不可", lines[1]);
            Assert.AreEqual("DSTWiFiSim002,VIN000000000000002,00000000000000002,,50%", lines[2]);
            Assert.AreEqual("DSTWiFiSim001,VIN000000000000001,00000000000000001,00000000000000011,100%", lines[3]);
            // BOM確認
            byte[] bs = System.IO.File.ReadAllBytes(System.Environment.GetFolderPath(Environment.SpecialFolder.Personal) + @"\newfile.csv");
            if ((bs[0] == 0xef) && (bs[1] == 0xbb) && (bs[2] == 0xbf))
            {
                Assert.Fail();
            }
            // CSVファイル削除
            System.IO.File.Delete(System.Environment.GetFolderPath(Environment.SpecialFolder.Personal) + @"\newfile.csv");
        }

        /// <summary>
        /// ５．進捗確認画面<br>
        /// ５．５．閉じるボタン<br>
        /// ５．５．１．閉じるボタンクリック<br>
        /// </summary>
        [TestMethod]
        public void TestMethod5_5_1()
        {
            // Simulator起動
            startSimulator();
            // YardRepro起動
            startYardRepro();
            capture(1, "YardRepro起動");
            // 1台にチェックを入れる
            this.UIMap.dst1ItemSelect();
            capture(2, "1台選択し、次へボタン押下");
            // 次へボタン押下
            this.UIMap.nextBtnClick();
            capture(3, "進捗確認画面遷移後、閉じるボタン押下");
            // 閉じるボタン押下
            this.UIMap.reproWindowClose();
            // 2秒待機
            System.Threading.Thread.Sleep(2000);
            // プロセスが存在しないことを確認
            System.Diagnostics.Process[] ps = System.Diagnostics.Process.GetProcessesByName("YardRepro");
            Assert.AreEqual(0, ps.Length);
        }

        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }
        private TestContext testContextInstance;

        public UIMap UIMap
        {
            get
            {
                if ((this.map == null))
                {
                    this.map = new UIMap();
                }

                return this.map;
            }
        }

        private UIMap map;
    }
}
