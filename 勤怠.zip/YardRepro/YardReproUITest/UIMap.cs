﻿namespace YardReproUITest
{
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    public partial class UIMap
    {
        public void AssertMethod4_1_1_ListAssert()
        {
            // リスト項目数確認
            UIListBox1List dstListItem = this.UIDST選択Window.UIElementHost1Window.UIElementHost1Client.UIElementHost1Pane.UIItemCustom.UIListBox1List;
            Assert.AreEqual(1, dstListItem.Items.Count);
        }

        public void AssertMethod4_1_2_ListAssert()
        {
            // リスト項目数確認
            UIListBox1List dstListItem = this.UIDST選択Window.UIElementHost1Window.UIElementHost1Client.UIElementHost1Pane.UIItemCustom.UIListBox1List;
            Assert.AreEqual(6, dstListItem.Items.Count);
        }

        public void AssertMethod4_1_3_ListAssert()
        {
            // リスト項目数確認
            UIListBox1List dstListItem = this.UIDST選択Window.UIElementHost1Window.UIElementHost1Client.UIElementHost1Pane.UIItemCustom.UIListBox1List;
            Assert.AreEqual(6, dstListItem.Items.Count);
        }

        public void AssertMethod4_1_4_ListAssert1()
        {
            // リスト項目数確認
            UIListBox1List dstListItem = this.UIDST選択Window.UIElementHost1Window.UIElementHost1Client.UIElementHost1Pane.UIItemCustom.UIListBox1List;
            Assert.AreEqual(6, dstListItem.Items.Count);
        }

        public void AssertMethod4_1_4_ListAssert2()
        {
            // リスト項目数確認
            UIListBox1List dstListItem = this.UIDST選択Window.UIElementHost1Window.UIElementHost1Client.UIElementHost1Pane.UIItemCustom.UIListBox1List;
            Assert.AreEqual(5, dstListItem.Items.Count);
        }

        public void AssertMethod4_3_1_DisplayAssert()
        {
            // DST選択画面非表示確認
            Assert.AreEqual(false, this.UIDST選択Window.Exists);
        }

        public void AssertMethod4_3_1_ListAssert()
        {
            // リスト項目数確認
            UIListBox1List1 dstListItem = this.UIヤードリプロWindow.UIElementHost1Window.UIElementHost1Client.UIElementHost1Pane.UIItemCustom.UIListBox1List;
            Assert.AreEqual(1, dstListItem.Items.Count);
        }

        public void AssertMethod4_3_2_DisplayAssert()
        {
            // DST選択画面非表示確認
            Assert.AreEqual(false, this.UIDST選択Window.Exists);
        }

        public void AssertMethod4_3_2_ListAssert()
        {
            // リスト項目数確認
            UIListBox1List1 dstListItem = this.UIヤードリプロWindow.UIElementHost1Window.UIElementHost1Client.UIElementHost1Pane.UIItemCustom.UIListBox1List;
            Assert.AreEqual(3, dstListItem.Items.Count);
        }

        public void AssertMethod4_5_1_ListAssert()
        {
            // リスト項目数確認
            UIListBox1List1 dstListItem = this.UIヤードリプロWindow.UIElementHost1Window.UIElementHost1Client.UIElementHost1Pane.UIItemCustom.UIListBox1List;
            Assert.AreEqual(1, dstListItem.Items.Count);
        }

        public void AssertMethod5_1_1_ListAssert()
        {
            // リスト項目数確認
            UIListBox1List1 dstListItem = this.UIヤードリプロWindow.UIElementHost1Window.UIElementHost1Client.UIElementHost1Pane.UIItemCustom.UIListBox1List;
            Assert.AreEqual(1, dstListItem.Items.Count);
        }

        public void AssertMethod5_1_1_DisplayAssert()
        {
            // DST選択画面メッセージ非表示確認
            Assert.AreEqual(false, this.UIヤードリプロWindow.UI選択されていませんWindow.Exists);
        }

        public void AssertMethod5_3_3_ListAssert1()
        {
            // リスト項目数確認
            UIListBox1List1 dstListItem = this.UIヤードリプロWindow.UIElementHost1Window.UIElementHost1Client.UIElementHost1Pane.UIItemCustom.UIListBox1List;
            Assert.AreEqual(3, dstListItem.Items.Count);
        }

        public void AssertMethod5_3_3_ListAssert2()
        {
            // リスト項目数確認
            UIListBox1List1 dstListItem = this.UIヤードリプロWindow.UIElementHost1Window.UIElementHost1Client.UIElementHost1Pane.UIItemCustom.UIListBox1List;
            Assert.AreEqual(2, dstListItem.Items.Count);            
        }

        public void AssertMethod5_4_1_1_ListAssert()
        {
            Assert.AreEqual("CSVファイル(*.csv)", this.UI保存先のファイルを選択してくださいWindow.UI詳細ウィンドウPane.UIファイルの種類ComboBox.Items[0].Name);
            Assert.AreEqual("すべてのファイル(*.*)", this.UI保存先のファイルを選択してくださいWindow.UI詳細ウィンドウPane.UIファイルの種類ComboBox.Items[1].Name);
        }
    }
}
