﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DWRemoteCommunication;
using Microsoft.VisualBasic.FileIO;

namespace DWRemoteViewClient
{

    public class CsvConnect
    {
        //  格納されるメンバ
        private List<CsvConnectInfo> ConnectInfo;
        private string filePath;
        private const string TAB = "\t";

        /// <summary>
        /// ファイル名を指定して初期化します。
        /// ファイルが存在しない場合は初回書き込み時に作成されます。
        /// </summary>
        /// <param name="filePath">設定ファイルのパス</param>
        public CsvConnect(string filePath)
        {
            this.filePath = filePath;
        }

        /// <summary>
        /// 接続情報ファイルを読み込みます
        /// </summary>
        public bool ReadCsvConnectInfoAll()
        {
            int colNoBhtId = -1;
            int colNoServer = -1;
            int colNoPort = -1;
            int colNoPassword = -1;
            int colNoRaito = -1;
            int colNoActionMode = -1;

            try
            {
                byte[] bs = System.IO.File.ReadAllBytes(this.filePath);
                Encoding enc = GetEncode(bs);
                //Console.WriteLine(enc.BodyName);

                ConnectInfo = new List<CsvConnectInfo>();
                var parser = new TextFieldParser(this.filePath, Encoding.GetEncoding(enc.CodePage));
                using (parser)
                {
                    // 区切りの指定
                    parser.TextFieldType = FieldType.Delimited;
                    parser.SetDelimiters(TAB);// tab区切り

                    // フィールドが引用符で囲まれているか
                    parser.HasFieldsEnclosedInQuotes = true;
                    // フィールドの空白トリム設定
                    parser.TrimWhiteSpace = false;

                    // ヘッダー行読込
                    string[] headerrow = parser.ReadFields();
                    // 空のファイルだった場合
                    if (headerrow == null) return false;

                    for (int i = 0; i < headerrow.Length; i++)
                    {
                        // ヘッダー行の項目と列番号の紐づけ
                        switch (headerrow[i])
                        {
                            case Constants.CONNECT_INFO_KEY_BHT_ID:
                                colNoBhtId = i;
                                break;
                            case Constants.CONNECT_INFO_KEY_SERVER:
                                colNoServer = i;
                                break;
                            case Constants.CONNECT_INFO_KEY_PORT:
                                colNoPort = i;
                                break;
                            case Constants.CONNECT_INFO_KEY_PASSWORD:
                                colNoPassword = i;
                                break;
                            case Constants.CONNECT_INFO_KEY_RATIO:
                                colNoRaito = i;
                                break;
                            case Constants.CONNECT_INFO_KEY_ACTIONMODE:
                                colNoActionMode = i;
                                break;
                            default:
                                // 指定外の項目は無視する
                                break;
                        }
                    }
                    // BHT IDのヘッダーが定義されていない場合
                    if (colNoBhtId == -1) return false;

                    // ファイルの終端までループ
                    while (!parser.EndOfData)
                    {
                        // フィールドを読込
                        string[] row = parser.ReadFields();
                        CsvConnectInfo info = new CsvConnectInfo();

                        int colNo = 0;
                        foreach (string field in row)
                        {
                            // BHT ID
                            if (colNo == colNoBhtId)
                            {
                                info.BhtId = field;
                            }
                            // Host
                            else if (colNo == colNoServer)
                            {
                                info.Host = field;
                            }
                            // Port
                            else if (colNo == colNoPort)
                            {
                                if (int.TryParse(field, out int port))
                                {
                                    info.Port = field;
                                }
                                else
                                {
                                    info.Port = "";
                                }
                            }
                            // Password
                            else if (colNo == colNoPassword)
                            {
                                info.Password = field;
                            }
                            // Raito
                            else if (colNo == colNoRaito)
                            {
                                if (int.TryParse(field, out int raito))
                                {
                                    if (raito >= 50 || raito <= 260)
                                    {
                                        info.Raito = field;
                                    }
                                    else
                                    {
                                        info.Raito = "100";
                                    }
                                }
                                else
                                {
                                    info.Raito = "100";
                                }
                            }
                            // Action Mode
                            else if (colNo == colNoActionMode)
                            {
                                info.ActionMode = field;
                            }
                            // Other
                            else
                            {
                                // 指定外の項目は無視する
                            }

                            // タブ区切りで出力
                            //Console.Write(field + TAB);
                            colNo++;
                        }

                        ConnectInfo.Add(info);
                    }
                }
            }
            catch(Exception)
            {
                return false;
            }

            return true;
        }

        /// <summary>
        /// BHT IDの一覧を返します．
        /// </summary>
        /// <returns>BHT IDの一覧</returns>
        public List<string> GetBhtIdItems()
        {
            List<string> BhtIdData = new List<string>();
            for (int i = 0; i < ConnectInfo.Count; i++)
            {
                BhtIdData.Add(ConnectInfo[i].BhtId);
            }

            return BhtIdData;
        }

        /// <summary>
        /// 指定Hostが同一かつ接続が最新のBHT IDを返します．
        /// </summary>
        /// <returns>BHT IDの一覧</returns>
        public string GetBhtIdItems(string Host)
        {
            string BhtIdData = "";

            // 降順
            for (int i = ConnectInfo.Count - 1; i >= 0; --i)
            {
                if (Host.Equals(ConnectInfo[i].Host))
                {
                    BhtIdData = ConnectInfo[i].BhtId;
                    break;
                }
            }

            return BhtIdData;
        }

        /// <summary>
        /// Hostの一覧を返します．
        /// </summary>
        /// <returns>Hostの一覧</returns>
        public List<string> GetHostItems()
        {
            List<string> HostData = new List<string>();
            for (int i = 0; i < ConnectInfo.Count; i++)
            {
                // 重複チェック
                if (!HostData.Contains(ConnectInfo[i].Host))
                {
                    HostData.Add(ConnectInfo[i].Host);
                }
            }

            return HostData;
        }

        /// <summary>
        /// 指定BHT IDの接続情報を返します．
        /// </summary>
        /// <returns>接続情報</returns>
        public CsvConnectInfo GetConnectInfoItems(string BhtId)
        {
            CsvConnectInfo conInfo = null;
            for (int i = 0; i < ConnectInfo.Count; i++)
            {
                if (BhtId.Equals(ConnectInfo[i].BhtId))
                {
                    conInfo = ConnectInfo[i];
                }
            }

            return conInfo;
        }

        /// <summary>
        /// 指定BHT IDの接続情報を保存します．
        /// </summary>
        /// <param name="BhtId">接続/保存対象のBHT ID</param>
        /// <param name="con">接続/保存フラグ（接続：true/保存:false）</param>
        /// <param name="conInfo">画面入力接続情報</param>
        /// <returns>保存可否</returns>
        public bool SaveConnectInfoItem(string BhtId, bool con, CsvConnectInfo conInfo)
        {
            StreamWriter OutputSW = null;
            string Backupfile = System.IO.Path.GetDirectoryName(this.filePath) + "\\" +
                                        Constants.CONNECT_INFO_FILE_NAME_NOT_Extension + "_" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".txt";

            FileInfo CurrentFile = new FileInfo(this.filePath);
            try
            {
                // 接続情報設定ファイル存在チェック
                if (CurrentFile.Exists)
                {
                    // バックアップファイルの作成
                    File.Copy(this.filePath, Backupfile);
                }

                using (OutputSW = new StreamWriter(this.filePath, false, Encoding.GetEncoding("UTF-8")))
                {
                    // ヘッダー行書き込み
                    string headerName = Constants.CONNECT_INFO_KEY_BHT_ID + TAB + Constants.CONNECT_INFO_KEY_SERVER + TAB +
                                        Constants.CONNECT_INFO_KEY_PORT + TAB + Constants.CONNECT_INFO_KEY_PASSWORD + TAB +
                                        Constants.CONNECT_INFO_KEY_RATIO + TAB + Constants.CONNECT_INFO_KEY_ACTIONMODE;
                    OutputSW.WriteLine(headerName);

                    // 保存内容がない場合ヘッダーのみ作成する
                    if (conInfo == null)
                    {
                        return true;
                    }

                    bool updFlg = false;    //true:更新、false:新規
                    // 接続情報
                    for (int i = 0; i < ConnectInfo.Count; i++)
                    {
                        // 接続時は接続対象の情報を最終行に移動する（最新接続情報となるため）
                        if (con && BhtId.Equals(ConnectInfo[i].BhtId))
                        {
                            updFlg = true;
                        }
                        // 保存時は保存対象のデータを上書きする
                        else if (!con && BhtId.Equals(ConnectInfo[i].BhtId))
                        {
                            updFlg = true;

                            OutputSW.WriteLine(conInfo.BhtId + TAB + conInfo.Host + TAB + conInfo.Port + TAB +
                                               conInfo.Password + TAB + conInfo.Raito + TAB + conInfo.ActionMode);

                        }
                        // 接続/保存の対象ではない場合
                        else
                        {
                            OutputSW.WriteLine(ConnectInfo[i].BhtId + TAB + ConnectInfo[i].Host + TAB + ConnectInfo[i].Port + TAB +
                                               ConnectInfo[i].Password + TAB + ConnectInfo[i].Raito + TAB + ConnectInfo[i].ActionMode);
                        }
                    }

                    // 接続時は最新接続情報を最終行へ移動
                    if (con && updFlg)
                    {
                        OutputSW.WriteLine(conInfo.BhtId + TAB + conInfo.Host + TAB + conInfo.Port + TAB +
                                           conInfo.Password + TAB + conInfo.Raito + TAB + conInfo.ActionMode);
                    }

                    // 新規追加
                    if (!updFlg)
                    {
                        OutputSW.WriteLine(conInfo.BhtId + TAB + conInfo.Host + TAB + conInfo.Port + TAB +
                                           conInfo.Password + TAB + conInfo.Raito + TAB + conInfo.ActionMode);
                    }
                }
            }
            catch (Exception)
            {
                // バックアップファイルが作成されている場合
                if (File.Exists(Backupfile))
                {
                    // 編集途中の接続情報ファイルの削除
                    if (File.Exists(this.filePath))
                    {
                        try
                        {
                            File.Delete(this.filePath);
                            // ロールバック
                            File.Copy(Backupfile, this.filePath);
                        }
                        catch (IOException)
                        {
                            // 「connect.txt」ファイルが開かれている
                        }
                    }
                }
                else
                {
                    // バックアップファイルが作成されていない場合はバックアップファイルの作成に失敗したことが理由で
                    // エラー処理を行うため何もしない
                }

                return false;
            }
            finally
            {
                // バックアップファイルの削除
                if (File.Exists(Backupfile))
                {
                    File.Delete(Backupfile);
                }
                // ストリームクローズ
                if (OutputSW != null)
                {
                    OutputSW.Close();
                }
                OutputSW = null;
            }
            //Console.WriteLine(DateTime.Now.Subtract(logOutput).TotalMilliseconds);

            return true;
        }

        /// <summary>
        /// 文字コードを判別する
        /// </summary>
        /// <param name="bs">接続情報ファイルの文字列配列</param>
        /// <returns>適当と思われるEncodingオブジェクト。 判断できなかった時はnull。</returns>
        public static Encoding GetEncode(byte[] bs)
        {
            const byte bEscape = 0x1B;
            const byte bAt = 0x40;
            const byte bDollar = 0x24;
            const byte bAnd = 0x26;
            const byte bOpen = 0x28;    //'('
            const byte bB = 0x42;
            const byte bD = 0x44;
            const byte bJ = 0x4A;
            const byte bI = 0x49;

            int len = bs.Length;
            byte b1, b2, b3, b4;

            bool isBinary = false;
            for (int i = 0; i < len; i++)
            {
                b1 = bs[i];
                if (b1 <= 0x06 || b1 == 0x7F || b1 == 0xFF)
                {
                    //'binary'
                    isBinary = true;
                    if (b1 == 0x00 && i < len - 1 && bs[i + 1] <= 0x7F)
                    {
                        //unicode
                        return Encoding.Unicode;
                    }
                }
            }
            if (isBinary)
            {
                return null;
            }

            //not Japanese
            bool notJapanese = true;
            for (int i = 0; i < len; i++)
            {
                b1 = bs[i];
                if (b1 == bEscape || 0x80 <= b1)
                {
                    notJapanese = false;
                    break;
                }
            }
            if (notJapanese)
            {
                return Encoding.ASCII;
            }

            // JIS
            for (int i = 0; i < len - 2; i++)
            {
                b1 = bs[i];
                b2 = bs[i + 1];
                b3 = bs[i + 2];

                if (b1 == bEscape)
                {
                    if (b2 == bDollar && b3 == bAt)
                    {
                        //JIS_0208 1978
                        //JIS
                        return Encoding.GetEncoding(50220);
                    }
                    else if (b2 == bDollar && b3 == bB)
                    {
                        //JIS_0208 1983
                        //JIS
                        return Encoding.GetEncoding(50220);
                    }
                    else if (b2 == bOpen && (b3 == bB || b3 == bJ))
                    {
                        //JIS_ASC
                        //JIS
                        return Encoding.GetEncoding(50220);
                    }
                    else if (b2 == bOpen && b3 == bI)
                    {
                        //JIS_KANA
                        //JIS
                        return Encoding.GetEncoding(50220);
                    }
                    if (i < len - 3)
                    {
                        b4 = bs[i + 3];
                        if (b2 == bDollar && b3 == bOpen && b4 == bD)
                        {
                            //JIS_0212
                            //JIS
                            return Encoding.GetEncoding(50220);
                        }
                        if (i < len - 5 &&
                            b2 == bAnd && b3 == bAt && b4 == bEscape &&
                            bs[i + 4] == bDollar && bs[i + 5] == bB)
                        {
                            //JIS_0208 1990
                            //JIS
                            return Encoding.GetEncoding(50220);
                        }
                    }
                }
            }

            //should be euc|sjis|utf8
            //use of (?:) by Hiroki Ohzaki <ohzaki@iod.ricoh.co.jp>
            int sjis = 0;
            int euc = 0;
            int utf8 = 0;
            for (int i = 0; i < len - 1; i++)
            {
                b1 = bs[i];
                b2 = bs[i + 1];
                if (((0x81 <= b1 && b1 <= 0x9F) || (0xE0 <= b1 && b1 <= 0xFC)) &&
                    ((0x40 <= b2 && b2 <= 0x7E) || (0x80 <= b2 && b2 <= 0xFC)))
                {
                    //SJIS_C
                    sjis += 2;
                    i++;
                }
            }
            for (int i = 0; i < len - 1; i++)
            {
                b1 = bs[i];
                b2 = bs[i + 1];
                if (((0xA1 <= b1 && b1 <= 0xFE) && (0xA1 <= b2 && b2 <= 0xFE)) ||
                    (b1 == 0x8E && (0xA1 <= b2 && b2 <= 0xDF)))
                {
                    //EUC_C
                    //EUC_KANA
                    euc += 2;
                    i++;
                }
                else if (i < len - 2)
                {
                    b3 = bs[i + 2];
                    if (b1 == 0x8F && (0xA1 <= b2 && b2 <= 0xFE) &&
                        (0xA1 <= b3 && b3 <= 0xFE))
                    {
                        //EUC_0212
                        euc += 3;
                        i += 2;
                    }
                }
            }
            for (int i = 0; i < len - 1; i++)
            {
                b1 = bs[i];
                b2 = bs[i + 1];
                if ((0xC0 <= b1 && b1 <= 0xDF) && (0x80 <= b2 && b2 <= 0xBF))
                {
                    //UTF8
                    utf8 += 2;
                    i++;
                }
                else if (i < len - 2)
                {
                    b3 = bs[i + 2];
                    if ((0xE0 <= b1 && b1 <= 0xEF) && (0x80 <= b2 && b2 <= 0xBF) &&
                        (0x80 <= b3 && b3 <= 0xBF))
                    {
                        //UTF8
                        utf8 += 3;
                        i += 2;
                    }
                }
            }

            //System.Diagnostics.Debug.WriteLine(string.Format("sjis = {0}, euc = {1}, utf8 = {2}", sjis, euc, utf8));
            if (euc > sjis && euc > utf8)
            {
                //EUC
                return Encoding.GetEncoding(51932);
            }
            else if (sjis > euc && sjis > utf8)
            {
                //SJIS
                return Encoding.GetEncoding(932);
            }
            else if (utf8 > euc && utf8 > sjis)
            {
                //UTF8
                return Encoding.UTF8;
            }

            return null;
        }

        public class CsvConnectInfo
        {
            /// <summary>コンストラクタ</summary>
            public CsvConnectInfo()
            {
            }

            public string BhtId { get; set; }
            public string Host { get; set; }
            public string Port { get; set; }
            public string Password { get; set; }
            public string Raito { get; set; }
            public string ActionMode { get; set; }

        }
    }
}
