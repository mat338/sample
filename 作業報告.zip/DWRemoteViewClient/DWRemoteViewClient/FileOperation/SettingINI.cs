﻿using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;

namespace DWRemoteViewClient
{
    public class SettingINI
    {
        internal static class NativeMethods
        {
            [DllImport("kernel32.dll", SetLastError = true, BestFitMapping = false, ThrowOnUnmappableChar = true)]
            internal static extern int GetPrivateProfileString(
            [MarshalAs(UnmanagedType.LPStr)] string lpApplicationName,
            [MarshalAs(UnmanagedType.LPStr)] string lpKeyName,
            [MarshalAs(UnmanagedType.LPStr)] string lpDefault,
            StringBuilder lpReturnedstring,
            int nSize,
            [MarshalAs(UnmanagedType.LPStr)] string lpFileName);

            [DllImport("kernel32.dll", SetLastError = true, BestFitMapping = false, ThrowOnUnmappableChar = true)]
            internal static extern int WritePrivateProfileString(
                [MarshalAs(UnmanagedType.LPStr)] string lpApplicationName,
                [MarshalAs(UnmanagedType.LPStr)] string lpKeyName,
                [MarshalAs(UnmanagedType.LPStr)] string lpstring,
                [MarshalAs(UnmanagedType.LPStr)] string lpFileName);

            [DllImport("kernel32.dll", BestFitMapping = false, ThrowOnUnmappableChar = true)]
            internal static extern int GetPrivateProfileSectionNames(
                IntPtr lpszReturnBuffer,
                uint nSize,
                [MarshalAs(UnmanagedType.LPStr)] string lpFileName);

            [DllImport("KERNEL32.DLL", EntryPoint = "GetPrivateProfileStringA", BestFitMapping = false, ThrowOnUnmappableChar = true)]
            internal static extern uint GetPrivateProfileStringByByteArray(
                [MarshalAs(UnmanagedType.LPStr)] string lpApplicationName,
                [MarshalAs(UnmanagedType.LPStr)] string lpKeyName,
                [MarshalAs(UnmanagedType.LPStr)] string lpDefault,
                byte[] lpReturnedString,
                uint nSize,
                [MarshalAs(UnmanagedType.LPStr)] string lpFileName);
        }

        private string filePath;

        /// <summary>
        /// ファイル名を指定して初期化します。
        /// ファイルが存在しない場合は初回書き込み時に作成されます。
        /// </summary>
        /// <param name="filePath">設定ファイルのパス</param>
        public SettingINI(string filePath)
        {
            this.filePath = filePath;
        }

        /// <summary>
        /// sectionとkeyからiniファイルの設定値を設定、取得します。 
        /// 
        /// [設定]
        /// 追加：「section」で指定したセクションが定義ファイルに未定義だった場合、セクションを追加します。
        /// 　　　「key」で指定したキーが定義ファイルに未定義だった場合、キーを追加します。
        /// 更新：「section」、「key」で指定したセクションとキーの値を更新します。
        /// 削除：「value」値をnullに設定した場合、指定セクションのキーを削除します。
        /// 　　　「key」、「value」値をnullに設定した場合、指定セクションを削除します。
        /// 　　　
        /// [取得]
        /// 「section」、「key」で指定したセクションとキーの値を取得します。
        /// </summary>
        /// <param name="section">設定ファイルのセクション</param>
        /// <param name="key">設定ファイルのキー</param>
        /// <returns>指定したsectionとkeyの組合せが無い場合は""が返ります。</returns>
        public string this[string section, string key]
        {
            set
            {
                int ret = NativeMethods.WritePrivateProfileString(section, key, value, filePath);
                if (ret == 0) throw new IOException();
            }
            get
            {
                StringBuilder sb = new StringBuilder(256);
                NativeMethods.GetPrivateProfileString(section, key, string.Empty, sb, sb.Capacity, filePath);
                return sb.ToString();
            }
        }

        /// <summary>
        /// sectionとkeyからiniファイルの設定値を取得します。
        /// 指定したsectionとkeyの組合せが無い場合はdefaultvalueで指定した値が返ります。
        /// </summary>
        /// <returns>
        /// 指定したsectionとkeyの組合せが無い場合はdefaultvalueで指定した値が返ります。
        /// </returns>
        public string GetValue(string section, string key, string defaultvalue)
        {
            StringBuilder sb = new StringBuilder(256);
            NativeMethods.GetPrivateProfileString(section, key, defaultvalue, sb, sb.Capacity, filePath);
            return sb.ToString();
        }

        /// <summary>
        /// セクション名の一覧を返します．
        /// </summary>
        /// <returns>セクション名の一覧を返します。</returns>
        public string[] GetSectionNames()
        {
            IntPtr ptr = Marshal.StringToHGlobalAnsi(new String('\0', 1024));
            int length = NativeMethods.GetPrivateProfileSectionNames(ptr, 1024, filePath);

            String result;
            String[] sectionData;
            if (0 < length)
            {
                result = Marshal.PtrToStringAnsi(ptr, length);
                sectionData = result.Substring(0, result.Length - 1).Split('\0');
            }
            else
            {
                sectionData = new String[0];// 空を返す
            }

            return sectionData;
        }

        /// <summary>
        /// セクションに属するキー名の一覧を返します．
        /// </summary>
        /// <param name="sectionName"></param>
        /// <returns></returns>
        public string[] GetKeyNames(string sectionName)
        {
            byte[] data = new byte[1024];
            uint length = NativeMethods.GetPrivateProfileStringByByteArray(sectionName, null, string.Empty, data, (uint)data.Length, filePath);

            string[] keys;
            if (0 < length)
            {
                keys = System.Text.Encoding.Default.GetString(data, 0, (int)length - 1).Split('\0');
            }
            else
            {
                keys = new String[0];// 空を返す
            }

            return keys;
        }
    }
}
