﻿#define logging

using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;

namespace DWRemoteViewClient
{
    public class AccessLog
    {
        /// <summary>排他ロックに使用する object。</summary>
        private static readonly object _syncLock = new object();

        private const int MAX_FILE_SIZE = 1024 * 1024;//10MB
        private const int MAX_FFILES = 4;//履歴4ファイル保持数

        /* アクセス履歴ログ定義 */
        private const string LOGIN_HISTORY_FILE_EXTENSION = "log";
        private const string LOGIN_HISTORY_FILE_NAME = "BHTRemote_access";

        private string filePath;
        private string fileName;
        private string filePathName;

        private Queue<string> LogQueue = new Queue<string>();

        /// <summary>コンストラクタ</summary>
        /// <param name="filePath">アクセス履歴出力先（setting.iniから取得）</param>
        public AccessLog(string filePath)
        {
            this.filePath = filePath;
            this.fileName = LOGIN_HISTORY_FILE_NAME;

            this.filePathName = filePath;
            if (this.filePathName.Substring(this.filePathName.Length - 1) != "\\")
            {
                this.filePathName += "\\";
            }
            this.filePathName += fileName + "." + LOGIN_HISTORY_FILE_EXTENSION;
        }

#if logging

        /// <summary>
        /// Logging Output Setting
        /// </summary>
        /// <param name="lt">ログ出力タイプ</param>
        /// <param name="lm">ログ出力メッセージ</param>
        public void InputLog(string lt, string lm)
        {
            lock (_syncLock)
            {
                if (LogQueue.Count < Int32.MaxValue)
                {
                    lock (((ICollection)LogQueue).SyncRoot)
                    {
                        LogQueue.Enqueue("[" + DateTime.Now.ToString() + "." + DateTime.Now.Millisecond.ToString() + "]" + "\t" + lt + "\t" + lm);
                    }
                }
            }
        }

        /// <summary>
        /// Logging Output Events
        /// </summary>
        public bool OutputLog()
        {
            lock (_syncLock)
            {
                FileStream stream = null;
                StreamWriter sW = null;
                TextWriter writerSync = null;

                try
                {
                    // ディレクトリ存在チェック
                    if (!Directory.Exists(this.filePath))
                    {
                        // ディレクトリがない場合は作成する
                        Directory.CreateDirectory(this.filePath);
                    }

                    // ファイルを排他ロックする
                    using (stream = new FileStream(this.filePathName, FileMode.Append, FileAccess.Write, FileShare.None))
                    using (sW = new StreamWriter(stream))
                    using (writerSync = TextWriter.Synchronized(sW))
                    {
                        while (LogQueue.Count > 0)
                        {
                            writerSync.WriteLine(LogQueue.Dequeue());
                            writerSync.Flush();
                        }

                        return true;
                    }
                }
                catch (IOException)
                {
                    return false;
                }
                finally
                {
                    if (writerSync != null)
                    {
                        writerSync.Close();
                        sW.Close();
                        stream.Close();
                    }

                    writerSync = null;
                    sW = null;
                    stream = null;
                }

            }
        }

        /// <summary>
        /// Create Zip Log File
        /// </summary>
        public void FileBackup()
        {
            // ファイルサイズのチェックを行う
            FileInfo CurrentFile = new FileInfo(this.filePathName);
            // ログファイル存在チェック
            if (CurrentFile.Exists == false)
            {
                CurrentFile = null;
                return;
            }

            if (CurrentFile.Length > MAX_FILE_SIZE)
            {
                // バックアップフォルダ
                string backup = this.filePath + "backup\\";
                // バックアップ日時
                string backupDate = DateTime.Now.ToString("yyyyMMddHHmmss");
                // バックアップファイル名
                string backupFileName = this.fileName + "_" + backupDate;
                // ログファイルのリネーム名
                string copyFileName = backupFileName + "." + LOGIN_HISTORY_FILE_EXTENSION;

                try
                {
                    // バックアップフォルダの作成
                    if (!Directory.Exists(backup))
                    {
                        Directory.CreateDirectory(backup);
                    }
                    // ログファイルをリネームして圧縮作業用ディレクトリに移動する
                    CurrentFile.MoveTo(backup + copyFileName);

                    // バックアップフォルダ直下にあるすべてのログファイルを取得する
                    string[] files = Directory.GetFiles(backup, "*." + LOGIN_HISTORY_FILE_EXTENSION);

                    if (files.Length > MAX_FFILES)
                    {
                        // 取得したすべてのファイルをファイル名でソートする
                        Array.Sort(files);
                        // ソートした結果を表示
                        int count = 0;
                        int delFile = files.Length - MAX_FFILES;
                        foreach (string file in files)
                        {
                            // ファイル名と最終書き込み日時を表示
                            //Console.WriteLine("{0} {1}", File.GetLastWriteTime(file), file);
                            File.Delete(file);

                            count++;
                            if (delFile <= count)
                            {
                                break;
                            }
                        }
                    }

                }
                catch (IOException)
                {
                    // 他プロセスがログ出力中は何もしない
                    // 他プロセスが先にファイル移動を行った場合は何もしない
                    // Console.WriteLine(ioe.ToString());
                }
                finally
                {
                    CurrentFile = null;
                }
            }
        }

#else
        private void Log(Logtype lt, string lm) { return; }
#endif

    }
}