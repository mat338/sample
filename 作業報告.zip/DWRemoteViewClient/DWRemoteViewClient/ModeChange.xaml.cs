﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DWRemoteViewClient
{
    /// <summary>
    /// ModeChange.xaml の相互作用ロジック
    /// </summary>
    public partial class ModeChange : Window
    {
        // 親画面
        private MainWindow main;

        public ModeChange()
        {
            InitializeComponent();
            this.WindowStyle = WindowStyle.ToolWindow;
        }

        /// <summary>画面描画終了イベント(ウィンドウのコンテンツが描画された後に発生)</summary>
        protected override void OnContentRendered(EventArgs e)
        {
            base.OnContentRendered(e);
            Keyboard.Focus(menu);
        }

        /// <summary>キーダウンイベント</summary>
        void SpecialKeys_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Escape)
            {
                this.Close();
            }
        }

        #region SpecialKey Event
        /// <summary>F6キーイベント</summary>
        private void miF6_Click(object sender, RoutedEventArgs e)
        {
            SpecialKey(DWRemoteCommunication.BHTKey.F6);
        }
        /// <summary>F7キーイベント</summary>
        private void miF7_Click(object sender, RoutedEventArgs e)
        {
            SpecialKey(DWRemoteCommunication.BHTKey.F7);
        }
        /// <summary>F8キーイベント</summary>
        private void miF8_Click(object sender, RoutedEventArgs e)
        {
            SpecialKey(DWRemoteCommunication.BHTKey.F8);
        }
        #endregion

        #region Private Methods
        /// <summary>
        /// 特殊キーを親画面にセットする 
        /// </summary>
        /// <param name="i">特殊キー番号</param>
        private void SpecialKey(DWRemoteCommunication.BHTKey i)
        {
            main.SpecialKeys(i);
            this.Close();
        }
        #endregion

        #region Public Methods
        /// <summary>
        /// 親画面の情報をセットする 
        /// </summary>
	    /// <param name="main">親ウィンドウ</param>
        public void SetParent(MainWindow main)
        {
            this.main = main;
        }
        #endregion
    }
}
