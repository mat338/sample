﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Net.Sockets;
using System.IO;
using System.Security.Cryptography;
using System.Windows.Threading;
using System.Windows.Interop;
using System.Text.RegularExpressions;
using System.Runtime.InteropServices;
using System.Threading;
using System.Diagnostics;
using System.Globalization;
using DWRemoteCommunication;
using static DWRemoteViewClient.CsvConnect;

namespace DWRemoteViewClient
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window, IDisposable
    {
        // コマンドライン引数有無
        private bool cmdLine = false;
        // 再接続有無フラグ
        private bool reConnect = false;
        // 再接続中フラグ
        private bool ReConnecting = false;
        // 接続中フラグ
        private bool connectFlg = false;
        // リサイズフラグ
        private bool resizeFlg = false;
        // dispose
        bool disposed = false;

        // BHT ID 選択Index
        private int bhtSelectedIndex = 0;
        // HOST 選択Index
        private int hostSelectedIndex = 0;

        // ウィンドウサイズ
        private int InitRaito = 0;
        private int InitImageHeight = 0;
        private int InitImageWidth = 0;
        private int MinImageHeight = 0;
        private int MinImageWidth = 0;
        private double sabunHeight = 0;
        private double sabunWidth = 0;
        
        private int _BhtStandardHeight = 0; // BHT1700の100%時の高さ（400）を基準とする（BHT1800_100% 640 → 400 = 62.5%）
        private int _ReconnectTimeout = 0;  // 再接続タイムアウト
        private int _ReceiveTimeout = 0;    // 受信タイムアウト
        // ログ定義
        private string _LogFilePath = Constants.LOGIN_HISTORY_FILE_PATH;
        private string _SystemFilePath = Constants.SYSTEM_LOG_FILE_PATH;
        private Logtype _SystemLogOutLevel = Logtype.Information;// システムログ出力レベル
        // Csvファイル
        private string _ConnectCsvPath = ".\\" + Constants.CONNECT_INFO_FILE_NAME;
        private CsvConnect _Csv;            // connection csv

        // 各言語版Dictionary
        public Dictionary<string, string> _ScreenDictionary; //画面項目
        public Dictionary<string, string> _MessageDictionary;//ディクショナリー
        public Dictionary<string, string> _TooltipDictionary;//ツールチップ

        private DispatcherTimer tmrScreen;

        // メッセージダイアログ中央表示
        private IntPtr HHook;
        private static MessageCenter.HOOKPROC proc;

        // ウィンドウサイズの比率維持
        [StructLayout(LayoutKind.Sequential)]
        public struct RECT
        {
            public int left;
            public int top;
            public int right;
            public int bottom;
        }

        // 最大化ボタン無効
        private WindowInteropHelper helper;
        private static class NativeMethods
        {
            [DllImport("user32", CharSet = CharSet.Auto)]
            public static extern int GetWindowLong(HandleRef window, int index);
            [DllImport("user32", CharSet = CharSet.Auto)]
            public static extern int SetWindowLong(HandleRef window, int index, int value);
        }

        // モード切替選択画面
        private ModeChange ModeChangeWindow;
        // 特殊キー選択画面
        private SpecialKeys SpecialKeyWindow;

        /// <summary>コンストラクタ</summary>
        public MainWindow()
        {
            InitializeComponent();

            // アプリケーション設定情報処理
            GetSettingInfo();

            // 言語設定
            LanguageRead Language = new LanguageRead();
            _ScreenDictionary = Language.GetScreen();
            _MessageDictionary = Language.GetMessage();
            _TooltipDictionary = Language.GetToolTip();

            // 接続情報設定ファイル
            _Csv = new CsvConnect(_ConnectCsvPath);
            if (!File.Exists(_ConnectCsvPath))
            {
                // 接続情報のファイルがない場合はヘッダーのみのファイルを作成する
                _Csv.SaveConnectInfoItem(null, false, null);
            }
            _Csv.ReadCsvConnectInfoAll();

            // 画面項目初期化
            this.cmbRaito.SelectedIndex = 6;// 100%既定値
			this.cmbAction.SelectedIndex = 0;// ASSISTANT既定値
            SettingMenu.Visibility = Visibility.Visible;//接続設定画面-ツールバー
            ConnectionItems.Visibility = Visibility.Visible;//接続設定画面
            ConnectingMenu.Visibility = Visibility.Collapsed;//BHT端末画面-ツールバー
            AccessView.Visibility = Visibility.Collapsed;//BHT端末画面-接続先
            BhtImage.Visibility = Visibility.Collapsed;//BHT端末画面
            FootMenu.Visibility = Visibility.Collapsed;//BHT端末画面-下部キー
            ConnectingFrame.Visibility = Visibility.Hidden;//接続画面
            pasPassword.Visibility = Visibility.Visible;
            txtPassword.Visibility = Visibility.Collapsed;

            AccessView.ToolTip = _TooltipDictionary[LanguageConstantsNumber.TOOLTIP_CONNECT_INFO_DISCONNECT];
            AccessPoint.Background = Brushes.Red;
            AccessPoint.Foreground = Brushes.Black;

            this.ResizeMode = ResizeMode.CanMinimize;

            // BHT ID
            this.Loaded += (sender, e) =>
            {
                var tb = cmbTerminal.Template.FindName("PART_EditableTextBox", cmbTerminal) as TextBox;
                if (tb != null)
                {
                    InputMethod.SetIsInputMethodSuspended(tb, true);
                    // 最大入力桁数設定
                    tb.MaxLength = 100;
                }
            };
            // Host
            this.Loaded += (sender, e) =>
            {
                var th = cmbHost.Template.FindName("PART_EditableTextBox", cmbHost) as TextBox;
                if (th != null)
                {
                    InputMethod.SetIsInputMethodSuspended(th, true);
                    // 最大入力桁数設定
                    th.MaxLength = 50;
                }
            };
            // 拡大縮小率 IME無効化
            this.Loaded += (sender, e) =>
            {
                var tr = cmbRaito.Template.FindName("PART_EditableTextBox", cmbRaito) as TextBox;
                if (tr != null)
                {
                    InputMethod.SetIsInputMethodSuspended(tr, true);
                    // 最大入力桁数設定
                    tr.MaxLength = 3;
                }
            };

            // BHT ID 初期値の設定
            ReadConnectInfo(false);
            this.cmbTerminal.SelectedIndex = bhtSelectedIndex;

            //コマンドライン引数を配列で取得する
            string[] cmds = System.Environment.GetCommandLineArgs();
            // 引数がある場合
            if (cmds.Length > 1)
            {
                // 必須項目の初期化
                cmbHost.Text = "";
                txtPort.Text = "";
                pasPassword.Password = "";
                txtPassword.Text = "";
                this.cmbAction.Text = "";

                // 任意項目の初期化
                Top = 0;
                Left = 0;
                cmbTerminal.Text = "";
                this.cmbRaito.SelectedIndex = 6;// 100%既定値

                //コマンドライン引数を列挙する
                int i = 0;
                foreach (string cmd in cmds)
                {
                    int pos = 0;
                    switch (cmd)
                    {
                        // 必須
                        case "-s":// IPアドレス
                            if ((i + 1) < cmds.Length && cmds[i + 1].Substring(0, 1) != "-")
                            {
                                cmbHost.Text = cmds[i + 1];
                                //Console.WriteLine(cmd + ":" + cmds[i + 1]);
                            }
                            i++;
                            break;
                        case "-p":// Port
                            if ((i + 1) < cmds.Length && cmds[i + 1].Substring(0, 1) != "-")
                            {
                                txtPort.Text = cmds[i + 1];
                                //Debug.WriteLine(cmd + ":" + cmds[i + 1]);
                            }
                            i++;
                            break;
                        case "-w":// パスワード
                            if ((i + 1) < cmds.Length && cmds[i + 1].Substring(0, 1) != "-")
                            {
                                pasPassword.Password = cmds[i + 1];
                                txtPassword.Text = cmds[i + 1];
                                //Debug.WriteLine(cmd + ":" + cmds[i + 1]);
                            }
                            i++;
                            break;
                        case "-m":// モード
                            if ((i + 1) < cmds.Length && cmds[i + 1].Substring(0, 1) != "-")
                            {
                                cmbAction.Text = cmds[i + 1];
                                //Debug.WriteLine(cmd + ":" + cmds[i + 1]);
                            }
                            i++;
                            break;
                        // 任意
                        case "-t":// Top座標
                            if ((i + 1) < cmds.Length && cmds[i + 1].Substring(0, 1) != "-")
                            {
                                if (int.TryParse(cmds[i + 1], out pos)) Top = pos;
                                //Debug.WriteLine(cmd + ":" + cmds[i + 1]);
                            }
                            i++;
                            break;
                        case "-l":// Left座標
                            if ((i + 1) < cmds.Length && cmds[i + 1].Substring(0, 1) != "-")
                            {
                                if (int.TryParse(cmds[i + 1], out pos)) Left = pos;
                                //Debug.WriteLine(cmd + ":" + cmds[i + 1]);
                            }
                            i++;
                            break;
                        case "-i":// BHT ID
                            if ((i + 1) < cmds.Length && cmds[i + 1].Substring(0, 1) != "-")
                            {
                                cmbTerminal.Text = cmds[i + 1];
                                //Debug.WriteLine(cmd + ":" + cmds[i + 1]);
                            }
                            i++;
                            break;
                        case "-r":// Raito
                            if ((i + 1) < cmds.Length && cmds[i + 1].Substring(0, 1) != "-")
                            {
                                cmbRaito.Text = cmds[i + 1];
                                //Debug.WriteLine(cmd + ":" + cmds[i + 1]);
                            }
                            i++;
                            break;
                        default:// 値
                            //Debug.WriteLine(cmd);
                            i++;
                            break;
                    }
                }

                // コマンド起動のエラーログの場合（起動ごとに削除）
                File.Delete(_SystemFilePath + Constants.COMMAND_LOG_FILE_NAME + "." + Constants.SYSTEM_LOG_FILE_EXTENSION);

                if (!CmdLineExec())
                {
                    // エラー時はアプリ終了
                    this.Close();
                }
                cmdLine = true;

            }

            tmrScreen = new DispatcherTimer();
            tmrScreen.Interval = new TimeSpan(0, 0, 0, 0, 25);
            tmrScreen.Tick += TmrScreen_Tick;
            tmrScreen.Start();

        }

        // 再接続開始日時
        DateTime firstConnect = DateTime.MinValue;
        // 最終再接続日時
        DateTime lastConnect = DateTime.MinValue;
        /// <summary>
        /// 定期実行関数
        /// ・エラー検知 
        /// ・コマンドライン引数起動処理（初回のみ）
        /// ・BHT端末画面の初回表示処理（初回のみ）
        /// ・状態変化表示処理
        /// </summary>
        /// <param name="sender">センダー(DispatcherTimer)</param>
        /// <param name="e">EventArgs</param>
        void TmrScreen_Tick(object sender, EventArgs e)
        {
            bool ret = true;

            try
            {
                // BHT端末に接続していない場合（再接続除く）又はリサイズ中は、以降の処理を行わない
                if ((!connectFlg && !reConnect) || resizeFlg)
                {
                    return;
                }

                // BHT端末画面の初回表示時
                if (BhtView.FirstView)
                {
                    BhtScreenSwitching();
                    //BHT端末画面表示後、接続/再接続ボタン押下以外は切断→再接続となる
                    reConnect = true;
                }

                // ERROR CHECK
                BhtView.GetError();

                // エラー発生時
                if (BhtView.Error)
                {
                    AccessView.ToolTip = _TooltipDictionary[LanguageConstantsNumber.TOOLTIP_CONNECT_INFO_DISCONNECT];
                    AccessPoint.Background = Brushes.Red;
                    AccessPoint.Foreground = Brushes.Black;

                    // 再接続を行う場合（切断エラー発生時は再接続処理を行う）
                    if (reConnect)
                    {
                        // 再接続中
                        ReConnecting = true;

                        // 再接続開始の時刻保持
                        if (firstConnect == DateTime.MinValue)
                        {
                            firstConnect = DateTime.Now;
                        }

                        // 再接続タイムアウト設定値を経過後はエラーメッセージを表示。
                        if (DateTime.Now.Subtract(firstConnect).TotalMilliseconds >= _ReconnectTimeout * 1000)
                        {
                            BhtImage.Visibility = Visibility.Hidden;
                            FootMenu.Visibility = Visibility.Hidden;

                            ConnectingFrame.Width = BhtImage.ActualWidth;
                            ConnectingFrame.Height = BhtImage.ActualHeight + FootMenu.ActualHeight;

                            ConnectingStr.Content = "Connected fail";
                            ConnectingMsg.Text = BhtView.ErrorMessage;
                            ConnectingMsg.TextWrapping = TextWrapping.Wrap;
                            Connecting.Visibility = Visibility.Collapsed;
                            ConnectingFrame.Visibility = Visibility.Visible;

                            this.ResizeMode = ResizeMode.CanMinimize;
                            DoEvents();

                            // リセット
                            BhtView.Error = false;
                            BhtView.ErrorMessage = "";
                            BhtView.ErrorType = Constants.ERROR_TYPE_NOTHING;

                            firstConnect = DateTime.MinValue;
                            lastConnect = DateTime.MinValue;
                            reConnect = false;
                            ReConnecting = false;
                            // BHT端末と接続できなかった場合はタイマーを無効化する
                            connectFlg = false;

                            return;
                        }

                        // １秒間隔で再接続する。
                        if (DateTime.Now.Subtract(lastConnect).TotalMilliseconds > 1000)
                        {
                            // 現在の拡大縮小率/動作モードを保持
                            BhtScreenSetting();

                            BhtImage.Visibility = Visibility.Hidden;
                            FootMenu.Visibility = Visibility.Hidden;
                            ConnectingFrame.Width = BhtImage.ActualWidth;
                            ConnectingFrame.Height = BhtImage.ActualHeight + FootMenu.ActualHeight;

                            // 接続
                            ret = ConnectProcess(3);

                            // 最終再接続の時刻
                            lastConnect = DateTime.Now;

                            // 再接続成功
                            if (ret)
                            {
                                // 画面切り替え
                                SettingMenu.Visibility = Visibility.Collapsed;//接続設定画面-ツールバー
                                ConnectionItems.Visibility = Visibility.Collapsed;//接続設定画面
                                ConnectingMenu.Visibility = Visibility.Visible;  //BHT端末画面-ツールバー
                                AccessView.Visibility = Visibility.Visible;//BHT端末画面-接続先
                                BhtImage.Visibility = Visibility.Visible;  //BHT端末画面
                                FootMenu.Visibility = Visibility.Visible;  //BHT端末画面-下部キー
                                ConnectingFrame.Visibility = Visibility.Collapsed;//接続中画面
                                Connecting.Visibility = Visibility.Collapsed;//グルグル

                                AccessView.ToolTip = _TooltipDictionary[LanguageConstantsNumber.TOOLTIP_CONNECT_INFO_CONNECT];
                                AccessPoint.Background = Brushes.Blue;
                                AccessPoint.Foreground = Brushes.White;

                                // リセット
                                BhtView.Error = false;
                                BhtView.ErrorMessage = "";
                                BhtView.ErrorType = Constants.ERROR_TYPE_NOTHING;
                                firstConnect = DateTime.MinValue;
                                lastConnect = DateTime.MinValue;
                                reConnect = true;
                                ReConnecting = false;

                                return;
                            }
                            // 再接続失敗
                            else
                            {
                                // 再接続失敗ログを出力
                                // 接続直後（ConnectProcessメソッド内）で出力しているが、接続成功→ログ出力失敗＆接続クローズのケースがあるため、
                                // 接続失敗のログを出力し直す
                                OutputAccessLog(1, false);

                                return;
                            }
                        }

                    }
                    // 再接続を行わない場合
                    // BHT端末表示画面：ReConnectボタン押下
                    else
                    {
                        // 何もしない（切断状態であるため、connectFlg=falseであり、このロジックに到達しない）
                    }
                }
                // サーバによる強制切断/セッションタイムアウトの場合
                else
                {
                    // 強制切断/セッションタイムアウトの場合はError=false、ErrorType=4で処理される
                    if (BhtView.ErrorType == Constants.ERROR_TYPE_FORCE_DISCONNECT)
                    {
                        BhtView.DisConnect();
                        connectFlg = false;

                        ConnectingFrame.Width = BhtImage.ActualWidth;
                        ConnectingFrame.Height = BhtImage.ActualHeight + FootMenu.ActualHeight;

                        ConnectingStr.Content = "Connected fail";
                        ConnectingMsg.Text = BhtView.ErrorMessage;
                        ConnectingMsg.TextWrapping = TextWrapping.Wrap;
                        BhtImage.Visibility = Visibility.Hidden;
                        FootMenu.Visibility = Visibility.Hidden;
                        ConnectingFrame.Visibility = Visibility.Visible;

                        this.ResizeMode = ResizeMode.CanMinimize;

                        // 切断ログを出力
                        OutputAccessLog(2, true);

                        // リセット
                        BhtView.ErrorType = Constants.ERROR_TYPE_NOTHING;
                    }
                }

                // 接続状態アイコン
                if (BhtView.IsConncted())
                {
                    AccessView.ToolTip = _TooltipDictionary[LanguageConstantsNumber.TOOLTIP_CONNECT_INFO_CONNECT];
                    AccessPoint.Background = Brushes.Blue;
                    AccessPoint.Foreground = Brushes.White;
                }
                else
                {
                    AccessView.ToolTip = _TooltipDictionary[LanguageConstantsNumber.TOOLTIP_CONNECT_INFO_DISCONNECT];
                    AccessPoint.Background = Brushes.Red;
                    AccessPoint.Foreground = Brushes.Black;
                }

                // 動作モードアイコン
                switch (BhtView.ActionMode)
                {
                    case Constants.ACTION_MODE_ASSISTANT:
                        ActionMode.Source = new BitmapImage(new Uri("/logo/ic_assist.png", UriKind.Relative));
                        ActionMode.ToolTip = _TooltipDictionary[LanguageConstantsNumber.TOOLTIP_ASSISTANT];
                        break;
                    case Constants.ACTION_MODE_DESKTOP:
                        ActionMode.Source = new BitmapImage(new Uri("/logo/ic_desktop.png", UriKind.Relative));
                        ActionMode.ToolTip = _TooltipDictionary[LanguageConstantsNumber.TOOLTIP_DESKTOP];
                        break;
                    case Constants.ACTION_MODE_VIEW:
                        ActionMode.Source = new BitmapImage(new Uri("/logo/ic_view.png", UriKind.Relative));
                        ActionMode.ToolTip = _TooltipDictionary[LanguageConstantsNumber.TOOLTIP_VIEW];
                        break;
                    default:
                        // 変更しない
                        break;
                }

            }
            catch (Exception)
            {
                // 処理中にアプリ終了が行われた場合
            }
    }

        #region Event

        /// <summary>画面描画終了イベント(ウィンドウのコンテンツが描画された後に発生)</summary>
        protected override void OnContentRendered(EventArgs e)
        {
            base.OnContentRendered(e);

            SetScreen();
            SetToolTip(true);
            this.Focus();
        }

        /// <summary>画面終了イベント</summary>
        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            // コマンド起動の場合は確認しない（50個起動したアプリを一括で閉じる場合があるため）
            if (!cmdLine)
            {
                SetHook(this);
                var result = MessageBox.Show(this,
                                            _MessageDictionary[LanguageConstantsNumber.MESSAGE_APPLICATION_EXIT],
                                            "Confirm",
                                            MessageBoxButton.OKCancel,
                                            MessageBoxImage.Question);
                if (result == MessageBoxResult.Cancel)
                {
                    e.Cancel = true;
                }
            }

            // 切断ログを出力
            if (connectFlg)
            {
                bool ret = OutputAccessLog(2, true);
                // コマンド起動ではない場合保存
                if (!cmdLine)
                {
                    BhtScreenSetting();
                    ret = SaveCsvFile(cmbTerminal.Text, chkSavedPass.IsChecked.Value, false);
                }
            }
        }

        private void btnModeChangeKeys_Click(object sender, RoutedEventArgs e)
        {
            // 再接続中
            if (ReConnecting)
            {
                return;
            }

            // 多重起動防止
            if (ModeChangeWindow != null)
            {
                // 表示中
                if (ModeChangeWindow.IsVisible)
                {
                    return;
                }
            }

            // 特殊キー選択画面を開く
            ModeChangeWindow = new ModeChange();
            ModeChangeWindow.WindowStartupLocation = WindowStartupLocation.Manual;
            ModeChangeWindow.Title = _TooltipDictionary[LanguageConstantsNumber.TOOLTIP_CONNECT_SWITCH_MODE_SCREEN];
            ModeChangeWindow.assi.ToolTip = _TooltipDictionary[LanguageConstantsNumber.TOOLTIP_CONNECT_SWITCH_KEY_SCREEN_ASSISTANT];
            ModeChangeWindow.desk.ToolTip = _TooltipDictionary[LanguageConstantsNumber.TOOLTIP_CONNECT_SWITCH_KEY_SCREEN_DESKTOP];
            ModeChangeWindow.view.ToolTip = _TooltipDictionary[LanguageConstantsNumber.TOOLTIP_CONNECT_SWITCH_KEY_SCREEN_VIEW];

            // 表示位置の設定
            ModeChangeWindow.Width = 140;
            ModeChangeWindow.Height = 72;
            ModeChangeWindow.Top = this.Top + 30 + AccessView.Height + ConnectingMenu.Height;//30:ツールバーの高さ
            ModeChangeWindow.Left = this.Left + (this.ActualWidth - ModeChangeWindow.Width) / 2;
            // 表示領域の設定
            ModeChangeWindow.Owner = GetWindow(this);
            ModeChangeWindow.SetParent(this);
            ModeChangeWindow.menu.Focusable = true;
            Keyboard.Focus(ModeChangeWindow.menu);
            ModeChangeWindow.Show();
        }

        private void btnSpecialKeys_Click(object sender, RoutedEventArgs e)
        {
            // 再接続中
            if (ReConnecting)
            {
                return;
            }

            // 多重起動防止
            if (SpecialKeyWindow != null)
            {
                // 表示中
                if (SpecialKeyWindow.IsVisible)
                {
                    return;
                }
            }

            // 特殊キー選択画面を開く
            SpecialKeyWindow = new SpecialKeys();
            SpecialKeyWindow.WindowStartupLocation = WindowStartupLocation.Manual;
            SpecialKeyWindow.Title = _TooltipDictionary[LanguageConstantsNumber.TOOLTIP_CONNECT_SWITCH_KEY_SCREEN];
            SpecialKeyWindow.pgup.ToolTip = _TooltipDictionary[LanguageConstantsNumber.TOOLTIP_CONNECT_SWITCH_KEY_SCREEN_PGUP];
            SpecialKeyWindow.pgdn.ToolTip = _TooltipDictionary[LanguageConstantsNumber.TOOLTIP_CONNECT_SWITCH_KEY_SCREEN_PGDN];
            SpecialKeyWindow.scan.ToolTip = _TooltipDictionary[LanguageConstantsNumber.TOOLTIP_CONNECT_SWITCH_KEY_SCREEN_SCAN];
            SpecialKeyWindow.app_reboot.ToolTip = _TooltipDictionary[LanguageConstantsNumber.TOOLTIP_CONNECT_SWITCH_KEY_SCREEN_APP_REBOOT];
            SpecialKeyWindow.bht_reboot.ToolTip = _TooltipDictionary[LanguageConstantsNumber.TOOLTIP_CONNECT_SWITCH_KEY_SCREEN_BHT_REBOOT];



            // 表示位置の設定
            SpecialKeyWindow.Width = 180;
            SpecialKeyWindow.Height = 72;
            SpecialKeyWindow.Top = this.Top + 30 + AccessView.Height + ConnectingMenu.Height;//30:ツールバーの高さ
            SpecialKeyWindow.Left = this.Left + (this.ActualWidth - SpecialKeyWindow.Width) / 2;
            // 表示領域の設定
            SpecialKeyWindow.Owner = GetWindow(this);
            SpecialKeyWindow.SetParent(this);
            SpecialKeyWindow.menu.Focusable = true;
            Keyboard.Focus(SpecialKeyWindow.menu);
            SpecialKeyWindow.Show();
        }

        /// <summary>キーダウンイベント</summary>
        void MainWindow_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Escape)
            {
                this.Close();
            }
        }

        /// <summary>Endキーイベント</summary>
        private void miEnd_Click(object sender, RoutedEventArgs e)
        {
            // 再接続中
            if (ReConnecting)
            {
                return;
            }

            SpecialKeys(BHTKey.End);
        }
        /// <summary>Homeキーイベント</summary>
        private void miHome_Click(object sender, RoutedEventArgs e)
        {
            // 再接続中
            if (ReConnecting)
            {
                return;
            }

            SpecialKeys(BHTKey.Home);
        }
        /// <summary>Insertキーイベント</summary>
        private void miInsert_Click(object sender, RoutedEventArgs e)
        {
            // 再接続中
            if (ReConnecting)
            {
                return;
            }

            SpecialKeys(BHTKey.Insert);
        }

        /// <summary>接続ボタン押下イベント</summary>
        public void btnConnect_Click(object sender, RoutedEventArgs e)
        {
            btnConnect.IsEnabled = false;

            // 接続ボタン押下時は接続失敗でも再接続処理をしない
            reConnect = false;

            SettingMenu.Visibility = Visibility.Hidden;
            ConnectionItems.Visibility = Visibility.Hidden;
            ConnectingFrame.Width = ConnectionItems.ActualWidth;
            ConnectingFrame.Height = ConnectionItems.ActualHeight;

            // 接続
            bool ret = ConnectProcess(0);
            if (!ret)
            {
                SettingMenu.Visibility = Visibility.Visible;
                ConnectionItems.Visibility = Visibility.Visible;

                ConnectingFrame.Visibility = Visibility.Hidden;
                Connecting.Visibility = Visibility.Collapsed;
                Thread.Sleep(100);
                DoEvents();

                if (BhtView != null)
                {
                    ConnectionItems.Width = ConnectionItems.ActualWidth;
                    ErrorMsg.Text = "";
                    ErrorTitle.Foreground = Brushes.Red;
                    ErrorTitle.Text = _ScreenDictionary[LanguageConstantsNumber.SCREEN_ITEM_ERROR_TITLE];
                    ErrorMsg.Text = BhtView.ErrorMessage;

                    // リセット
                    BhtView.Error = false;
                    BhtView.ErrorMessage = "";
                    BhtView.ErrorType = Constants.ERROR_TYPE_NOTHING;
                }
            }

            btnConnect.IsEnabled = true;
        }

        /// <summary>再接続ボタン押下イベント</summary>
        public void btnReConnect_Click(object sender, RoutedEventArgs e)
        {
            // 再接続中
            if (ReConnecting)
            {
                return;
            }

            // 接続済
            if (BhtView.IsConncted())
            {
                return;
            }

            // 切断処理中
            if (!miDisConnect.IsEnabled)
            {
                return;
            }

            miReConnect.IsEnabled = false;

            // 接続ボタン押下時は接続失敗でも再接続処理をしない
            reConnect = false;

            // 現在の拡大縮小率/動作モードを保持
            BhtScreenSetting();

            BhtImage.Visibility = Visibility.Hidden;
            FootMenu.Visibility = Visibility.Hidden;
            ConnectingFrame.Width = BhtImage.ActualWidth;
            ConnectingFrame.Height = BhtImage.ActualHeight + FootMenu.ActualHeight;

            // 接続
            bool ret =  ConnectProcess(2);
            if (!ret)
            {
                // エラーメッセージを出力
                ConnectingStr.Content = "Connected fail";
                ConnectingMsg.Text = BhtView.ErrorMessage;
                ConnectingMsg.TextWrapping = TextWrapping.Wrap;
                Connecting.Visibility = Visibility.Collapsed;

                AccessView.ToolTip = _TooltipDictionary[LanguageConstantsNumber.TOOLTIP_CONNECT_INFO_DISCONNECT];
                AccessPoint.Background = Brushes.Red;
                AccessPoint.Foreground = Brushes.Black;

                if (BhtView != null)
                {
                    // リセット
                    BhtView.Error = false;
                    BhtView.ErrorMessage = "";
                    BhtView.ErrorType = Constants.ERROR_TYPE_NOTHING;
                }

                miReConnect.IsEnabled = true;
                return;
            }

            AccessView.ToolTip = _TooltipDictionary[LanguageConstantsNumber.TOOLTIP_CONNECT_INFO_CONNECT];
            AccessPoint.Background = Brushes.Blue;
            AccessPoint.Foreground = Brushes.White;

            miReConnect.IsEnabled = true;
        }

        /// <summary>切断ボタン押下イベント</summary>
        private void btnDisConnect_Click(object sender, RoutedEventArgs e)
        {
            // 再接続処理中は処理しない
            if (!miReConnect.IsEnabled)
            {
                return;
            }

            miDisConnect.IsEnabled = false;

            // 意図した切断時は再接続処理をしない
            reConnect = false;

            if (connectFlg || ReConnecting)
            {
                // 切断ログを出力
                bool ret = OutputAccessLog(2, true);
                // 切断
                DisConnectProcess();

                AccessView.ToolTip = _TooltipDictionary[LanguageConstantsNumber.TOOLTIP_CONNECT_INFO_DISCONNECT];
                AccessPoint.Background = Brushes.Red;
                AccessPoint.Foreground = Brushes.Black;
            }

            // 切断中にウィンドウが閉じられた場合
            if (BhtView != null)
            {
                ReConnecting = false;
            }
            miDisConnect.IsEnabled = true;
        }

        /// <summary>
        /// [BHT ID]同一項目選択イベント
        /// 
        /// 特定の[BHT ID]を選択後、入力項目の編集を行う。
        /// その後、[BHT ID]のドロップダウンから編集中（同一）の[BHT ID]を選択する。
        /// この場合、選択されたドロップダウンのインデックスが同一であるため「SelectionChanged」イベントが発生しない。
        /// そのため編集内容がリセットされず「connect.txt」に登録された内容に置き換わらないため、リセット処理が行われるよう実装。
        /// 
        /// 現在選択中の[BHT ID]以外をドロップダウンから選択した場合は「cmbTerminal_SelectionChanged」イベントが発生するが、
        /// 同一の[BHT ID]を選択した場合はイベントが発生しないため、「DropDownOpened」イベントと「DropDownClosed」イベント、
        /// 「PreviewMouseUp」イベントの組合せで、[BHT ID]同一項目選択イベントを実装。
        /// 
        /// 「DropDownOpened」イベント発生時の選択項目のIndexと「DropDownClosed」イベント発生時の選択項目のIndexが同じであった場合は
        /// 同一項目が選択されたとみなす。ただし、[BHT ID]のドロップダウンの項目以外をクリックした場合も「DropDownClosed」イベントが発生し
        /// リセット処理が行われてしまうため、「PreviewMouseUp」イベントでドロップダウンの項目が選択されて「DropDownClosed」イベントが
        /// 発生したかを判定する。
        /// </summary>
        private int TerminalDropDownOpenIndex = -1;
        private int TerminalDropDownSelect = -1;
        private void cmbTerminal_DropDownOpened(object sender, EventArgs e)
        {
            // ドロップダウン表示時のIndexを保持する
            TerminalDropDownOpenIndex = cmbTerminal.SelectedIndex;
            //Console.WriteLine("cmbTerminal_DropDownOpened:");
        }
        private void cmbTerminal_DropDownClosed(object sender, EventArgs e)
        {
            // ドロップダウンクローズ時のIndexとドロップダウン表示時のIndexが一致した場合
            // （つまり選択項目の変更がなかった場合。変更があった場合は「cmbTerminal_SelectionChanged」イベントで処理）
            if (cmbTerminal.SelectedIndex == TerminalDropDownOpenIndex && TerminalDropDownSelect == 1)
            {
                //Console.WriteLine("cmbTerminal_DropDownClosed:");
                // 編集中の情報を破棄してリロードする
                ReadConnectInfo(true);
                this.cmbTerminal.SelectedIndex = bhtSelectedIndex;
                //this.cmbHost.SelectedIndex = hostSelectedIndex;
            }

            // 初期化
            TerminalDropDownOpenIndex = -1;
            TerminalDropDownSelect = -1;
        }
        private void cmbTerminal_PreviewMouseUp(object sender, MouseButtonEventArgs e)
        {
            // BHT IDのドロップダウン表示があった場合のみ処理対象とする
            if (TerminalDropDownOpenIndex != -1)
            {
                //ドロップダウン表示:-1 → 0、ドロップダウン項目選択クローズ：0 → 1、ドロップダウン項目未選択クローズ：0 → 0
                TerminalDropDownSelect++;
                //Console.WriteLine("cmbTerminal_PreviewMouseUp:" + TerminalDropDownSelect);
            }
        }
        /// <summary>
        /// [ホスト]同一項目選択イベント
        /// 
        /// [BHT ID]同一項目選択イベントと同じ内容
        /// </summary>
        private int HostDropDownOpenIndex = -1;
        private int HostDropDownSelect = -1;
        private void cmbHost_DropDownOpened(object sender, EventArgs e)
        {
            // ドロップダウン表示時のIndexを保持する
            HostDropDownOpenIndex = cmbHost.SelectedIndex;
            //Console.WriteLine("cmbTerminal_DropDownOpened:");
        }
        private void cmbHost_DropDownClosed(object sender, EventArgs e)
        {
            // ドロップダウンクローズ時のIndexとドロップダウン表示時のIndexが一致した場合
            // （つまり選択項目の変更がなかった場合。変更があった場合は「cmbTerminal_SelectionChanged」イベントで処理）
            if (cmbHost.SelectedIndex == HostDropDownOpenIndex && HostDropDownSelect == 1)
            {
                //Console.WriteLine("cmbTerminal_DropDownClosed:");
                // 編集中の情報を破棄してリロードする
                ReadConnectInfo(true);
                this.cmbHost.SelectedIndex = hostSelectedIndex;
                //this.cmbHost.SelectedIndex = hostSelectedIndex;
            }

            // 初期化
            HostDropDownOpenIndex = -1;
            HostDropDownSelect = -1;
        }
        private void cmbHost_PreviewMouseUp(object sender, MouseButtonEventArgs e)
        {
            // BHT IDのドロップダウン表示があった場合のみ処理対象とする
            if (HostDropDownOpenIndex != -1)
            {
                //ドロップダウン表示:-1 → 0、ドロップダウン項目選択クローズ：0 → 1、ドロップダウン項目未選択クローズ：0 → 0
                HostDropDownSelect++;
                //Console.WriteLine("cmbTerminal_PreviewMouseUp:" + TerminalDropDownSelect);
            }
        }

        private bool bhtChangeHost = false;
        /// <summary>端末ID選択イベント</summary>
        private void cmbTerminal_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // BHT ID 一覧クリア時ななにもしない
            if (cmbTerminal.Items.Count == 0)
            {
                return;
            }

            bhtSelectedIndex = cmbTerminal.SelectedIndex;

            // BHT ID変更
            string section = (string)cmbTerminal.SelectedValue;
            if (section == null)
            {
                section = "";
            }

            // 接続情報定義を読み込み取得項目の値をセットする
            ReadSettingFile(section);
            // Host
            if (hostSelectedIndex != -1)
            {
                int i = 0;
                foreach (string str in cmbHost.Items)
                {
                    if (str.Equals(BhtView.Host))
                    {
                        hostSelectedIndex = i;
                        break;
                    }
                    i++;
                }

                bhtChangeHost = true;
                this.cmbHost.SelectedIndex = hostSelectedIndex;
            }
            // Port
            if (BhtView.ServerPort == -1)
            {
                txtPort.Text = "";
            }
            else
            {
                txtPort.Text = BhtView.ServerPort.ToString();
            }
            // Password
            if (BhtView.ServerPassword != "")
            {
                pasPassword.Password = BhtView.ServerPassword;
                txtPassword.Text = BhtView.ServerPassword;
                chkSavedPass.IsChecked = true;
            }
            else
            {
                pasPassword.Password = "";
                txtPassword.Text = "";
                chkSavedPass.IsChecked = false;
            }
            // 拡大縮小率
            cmbRaito.Text = BhtView.WindowRatio;
            // 動作モード
            switch (BhtView.ActionMode)
            {
                case Constants.ACTION_MODE_DESKTOP:
                    cmbAction.Text = Constants.ACTION_MODE_DESKTOP_NAME;
                    break;
                case Constants.ACTION_MODE_ASSISTANT:
                    cmbAction.Text = Constants.ACTION_MODE_ASSISTANT_NAME;
                    break;
                case Constants.ACTION_MODE_VIEW:
                    cmbAction.Text = Constants.ACTION_MODE_VIEW_NAME;
                    break;
            }
        }

        /// <summary>IPアドレス変更イベント</summary>
        private void cmbHost_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // Host 一覧クリア時ななにもしない
            if (cmbHost.Items.Count == 0)
            {
                return;
            }
            if (cmbTerminal.Items.Count == 0)
            {
                return;
            }

            hostSelectedIndex = cmbHost.SelectedIndex;

            if (!bhtChangeHost)
            {
                int i = 0;
                string host = (string)cmbHost.SelectedValue;
                if (host == null)
                {
                    host = "";
                }
                // 接続情報定義を読み込み取得項目の値をセットする
                string section = _Csv.GetBhtIdItems(host);
                foreach (string str in cmbTerminal.Items)
                {
                    if (str.Equals(section))
                    {
                        bhtSelectedIndex = i;
                        break;
                    }

                    i++;
                }
                this.cmbTerminal.SelectedIndex = bhtSelectedIndex;

            }

            bhtChangeHost = false;
        }

        /// <summary>パスワード参照チェックイベント</summary>
        private void btnShowPassword_Checked(object sender, RoutedEventArgs e)
        {
            if(pasPassword.Visibility == Visibility.Collapsed)
            {
                pasPassword.Password = txtPassword.Text;
                pasPassword.Visibility = Visibility.Visible;
                txtPassword.Visibility = Visibility.Collapsed;
                passShow.Source = new BitmapImage(new Uri("/logo/ic_password_not_show.png", UriKind.Relative));
                passShow.ToolTip = _TooltipDictionary[LanguageConstantsNumber.TOOLTIP_HIDE_PASSWORD];
            }
            else
            {
                txtPassword.Text = pasPassword.Password;
                pasPassword.Visibility = Visibility.Collapsed;
                txtPassword.Visibility = Visibility.Visible;
                passShow.Source = new BitmapImage(new Uri("/logo/ic_password_show.png", UriKind.Relative));
                passShow.ToolTip = _TooltipDictionary[LanguageConstantsNumber.TOOLTIP_SHOW_PASSWORD];
            }
        }

        /// <summary>動作モード選択イベント</summary>
        private void cmbAction_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (cmbAction.Items.Count == 0)
            {
                return;
            }

            switch (cmbAction.SelectedIndex)
            {
                case 0:// ASSISTANT
                    ActionImg.ToolTip = _TooltipDictionary[LanguageConstantsNumber.TOOLTIP_ASSISTANT_DESCRIPTION];
                    ActionImg.Source = new BitmapImage(new Uri("/logo/ic_assist.png", UriKind.Relative));
                    break;
                case 1:// DESKTOP
                    ActionImg.ToolTip = _TooltipDictionary[LanguageConstantsNumber.TOOLTIP_DESKTOP_DESCRIPTION];
                    ActionImg.Source = new BitmapImage(new Uri("/logo/ic_desktop.png", UriKind.Relative));
                    break;
                case 2:// VIEW
                    ActionImg.ToolTip = _TooltipDictionary[LanguageConstantsNumber.TOOLTIP_VIEW_DESCRIPTION];
                    ActionImg.Source = new BitmapImage(new Uri("/logo/ic_view.png", UriKind.Relative));
                    break;
                default:// 
                    cmbAction.ToolTip = "";
                    break;
            }
        }

        /// <summary>接続情報保存イベント</summary>
        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            ConnectionItems.Width = ConnectionItems.ActualWidth;
            DoEvents();

            // 入力項目のチェック
            if (!InputCheck(false))
            {
                ErrorMsg.Text = "";
                ErrorTitle.Foreground = Brushes.Red;
                ErrorTitle.Text = _ScreenDictionary[LanguageConstantsNumber.SCREEN_ITEM_ERROR_TITLE];
                ErrorMsg.Text = BhtView.ErrorMessage;
                return;
            }

            miSave.IsEnabled = false;
            DoEvents();

            // CSVファイルに書込み
            bool ret = SaveCsvFile(cmbTerminal.Text, chkSavedPass.IsChecked.Value, false);
            if(!ret)
            {
                ErrorMsg.Text = "";
                ErrorTitle.Foreground = Brushes.Red;
                ErrorTitle.Text = _ScreenDictionary[LanguageConstantsNumber.SCREEN_ITEM_ERROR_TITLE];
                ErrorMsg.Text = LanguageConstantsNumber.MESSAGE_SETTING_FILE_NOT_SAVE + Environment.NewLine + 
                                _MessageDictionary[LanguageConstantsNumber.MESSAGE_SETTING_FILE_NOT_SAVE];

                miSave.IsEnabled = true;
                return;
            }
            ReadConnectInfo(true);
            this.cmbTerminal.SelectedIndex = bhtSelectedIndex;
            this.cmbHost.SelectedIndex = hostSelectedIndex;

            ErrorMsg.Text = "";
            ErrorTitle.Text = "";
            ErrorTitle.Foreground = Brushes.Black;
            ErrorMsg.Text = LanguageConstantsNumber.MESSAGE_SETTING_FILE_SAVE + Environment.NewLine +
                            _MessageDictionary[LanguageConstantsNumber.MESSAGE_SETTING_FILE_SAVE];

            miSave.IsEnabled = true;
        }

        /// <summary>エディター起動イベント</summary>
        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
            // ファイルのチェックを行う
            FileInfo CurrentFile = new FileInfo(_ConnectCsvPath);
            // 接続情報設定ファイル存在チェック
            if (!CurrentFile.Exists)
            {
                // 接続情報のファイルがない場合はヘッダーのみのファイルを作成する
                _Csv.SaveConnectInfoItem(null, false, null);
            }

            // ファイルに関連付けられたアプリケーションで起動
            Process p = Process.Start(_ConnectCsvPath);

            CurrentFile = null;
        }

        /// <summary>ヘルプ起動イベント</summary>
        private void btnHelp_Click(object sender, RoutedEventArgs e)
        {
            FileInfo CurrentFile = null;
            string FilePath = ".\\" + Constants.README_FILE_NAME;

            // 言語の判定
            try
            {
                switch (CultureInfo.CurrentCulture.Name)
                {
                    // 日本語
                    case LanguageRead.OS_LANGUEGE_JPN:
                        FilePath += "jp.txt";
                        break;
                    // 英語
                    case LanguageRead.OS_LANGUEGE_US_ENG:
                    case LanguageRead.OS_LANGUEGE_UK_ENG:
                        FilePath += "en.txt";
                        break;
                    // その他（英語）
                    default:
                        FilePath += "en.txt";
                        break;
                }

                // ファイルのチェックを行う
                CurrentFile = new FileInfo(FilePath);
                // 接続情報設定ファイル存在チェック
                if (CurrentFile.Exists)
                {
                    // ファイルに関連付けられたアプリケーションで起動
                    Process p = Process.Start(FilePath);
                    CurrentFile = null;
                }
                else
                {
                    ConnectionItems.Width = ConnectionItems.ActualWidth;
                    ErrorMsg.Text = "";
                    ErrorTitle.Foreground = Brushes.Red;
                    ErrorTitle.Text = _ScreenDictionary[LanguageConstantsNumber.SCREEN_ITEM_ERROR_TITLE];
                    ErrorMsg.Text = LanguageConstantsNumber.ERROR_MESSAGE_NOT_README_FILE + Environment.NewLine +
                                    _MessageDictionary[LanguageConstantsNumber.ERROR_MESSAGE_NOT_README_FILE];
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }

        /// <summary>Port番号/拡大縮小率キー入力イベント</summary>
        private void cmbRaito_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            // 0-9のみ（英字禁止）
            e.Handled = !new Regex("[0-9]").IsMatch(e.Text);
        }
        /// <summary>Port番号/拡大縮小率コピーペースト入力イベント</summary>
        private void cmbRaito_PreviewExecuted(object sender, ExecutedRoutedEventArgs e)
        {
            // 貼り付けを許可しない
            if (e.Command == ApplicationCommands.Paste)
            {
                e.Handled = true;
            }
        }
        #endregion

        #region Private Methods

        /// <summary>
        /// 接続処理
        /// </summary>
        /// <param name="ConnectTimming">接続のタイミング（0:接続設定画面の接続ボタン押下時、1:コマンドライン起動時、2:BHT表示画面の再接続時、3:切断エラー再接続時）</param>
        private bool ConnectProcess(int ConnectTimming)
        {
            // 接続処理中はタイマーを無効化する
            connectFlg = false;

            // 入力チェック
            if (!InputCheck(true))
            {
                return false;
            }

            // 接続設定ファイルに書き込み(接続設定画面で接続ボタン押下時のみ)
            if (ConnectTimming == 0)
            {
                bool ret = SaveCsvFile(cmbTerminal.Text, chkSavedPass.IsChecked.Value, true);
                if (!ret)
                {
                    BhtView.ErrorMessage = LanguageConstantsNumber.MESSAGE_SETTING_FILE_NOT_SAVE + Environment.NewLine + 
                                             _MessageDictionary[LanguageConstantsNumber.MESSAGE_SETTING_FILE_NOT_SAVE];

                    return false;
                }
            }

            // 接続中画面切替え
            this.SizeToContent = SizeToContent.WidthAndHeight;
            this.SizeToContent = SizeToContent.Manual;

            ConnectingStr.Content = "connecting...";
            ConnectingMsg.Text = "";
            ConnectingFrame.Visibility = Visibility.Visible;
            Connecting.Visibility = Visibility.Visible;

            // 接続
            bool isConnect = false;
            try
            {
                BhtView.Connect(_ReceiveTimeout, _SystemFilePath, _SystemLogOutLevel, _MessageDictionary);//バックグランド処理
                DateTime ConnectCheck = DateTime.Now;
                // 接続確認できるまでループ
                while (true)
                {
                    // ２１秒間（WindowsのTCPタイムアウト）＋１秒のみ処理
                    // WindowsのTCPタイムアウトより短い秒数でタイムアウトをしたい場合はここで定義する
                    if (DateTime.Now.Subtract(ConnectCheck).TotalMilliseconds <= 22000)
                    {
                        // 接続を確認
                        if (BhtView.IsConncted())
                        {
                            // 接続OKの場合は処理を抜ける
                            isConnect = true;
                            break;
                        }

                        // エラー確認
                        BhtView.GetError();
                        // 接続失敗
                        if (BhtView.Error)
                        {
                            BhtView.DisConnect();
                            break;
                        }

                        // 画面の反応を確保
                        DoEvents();
                    }
                    // タイムアウトエラー
                    else
                    {
                        BhtView.Error = true;
                        BhtView.ErrorMessage = LanguageConstantsNumber.ERROR_MESSAGE_SERVER_NOT_FOUND + Environment.NewLine +
                                                    _MessageDictionary[LanguageConstantsNumber.ERROR_MESSAGE_SERVER_NOT_FOUND];
                        BhtView.ErrorType = Constants.ERROR_TYPE_CONNECT;
                        BhtView.DisConnect();
                        break;
                    }
                }

                int conType = 0;
                //3:切断エラー再接続時
                if (ConnectTimming == 3)
                {
                    conType = 1;
                }
                //0:接続設定画面の接続ボタン押下時、1:コマンドライン起動時、2:BHT表示画面の再接続時
                else
                {
                    conType = 0;
                }
                bool retLog = OutputAccessLog(conType, isConnect);
                // アクセスログの出力失敗
                if (!retLog)
                {
                    // アクセスログの出力失敗時は接続させないため
                    // 接続成功かつログ出力失敗時は切断する
                    if (isConnect)
                    {
                        BhtView.DisConnect();
                    }

                    isConnect = false;
                }

                if (!isConnect)
                {
                    return false;
                }

                // BHT端末と接続できた場合はタイマーを有効化する
                connectFlg = true;
                return true;
            }

            // 接続に時間がかかる場合があり、処理中にユーザがアプリを終了する可能性があるため
            // 終了してしまったコントロールにアクセスして不正終了となるのを防ぐためcatchする
            catch (Exception)
            {
                return false;
            }
        }

        /// <summary>切断処理</summary>
        private void DisConnectProcess()
        {
            // 切断中にウィンドウが閉じられた場合
            if (BhtView != null)
            {
                // 切断
                BhtView.DisConnect();
            }

            // BHT端末と切断する場合はタイマーを無効化する
            connectFlg = false;

            BhtImage.Visibility = Visibility.Visible;
            FootMenu.Visibility = Visibility.Visible;

            ConnectingFrame.Width = BhtImage.ActualWidth;
            ConnectingFrame.Height = this.Height - ConnectingMenu.Height - FootMenu.Height;
            ConnectingFrame.Visibility = Visibility.Collapsed;
            Connecting.Visibility = Visibility.Collapsed;

            // 接続アイコン表示
            AccessView.ToolTip = _TooltipDictionary[LanguageConstantsNumber.TOOLTIP_CONNECT_INFO_DISCONNECT];
            AccessPoint.Background = Brushes.Red;
            AccessPoint.Foreground = Brushes.Black;

        }

        /// <summary>接続情報読込</summary>
        private void ReadConnectInfo(bool save)
        {
            // BHT ID一覧クリア
            this.cmbTerminal.Items.Clear();

            // BHT ID一覧を取得する
            List<string> BhtIdList = null;
            BhtIdList = _Csv.GetBhtIdItems();
            for (int i = BhtIdList.Count - 1; i >= 0; --i)
            {
                this.cmbTerminal.Items.Add(BhtIdList[i]);
            }

            // Host(IP)一覧を取得する
            List<string> list = null;
            list = _Csv.GetHostItems();
            if (list.Count > 0)
            {
                // Host一覧クリア
                this.cmbHost.Items.Clear();
                foreach (string str in list)
                {
                    this.cmbHost.Items.Add(str);
                }

                // Hostの初期選択
                if (!save)
                {
                    int i = 0;
                    string sectionName = (string)cmbTerminal.SelectedValue;
                    if (sectionName == null)
                    {
                        sectionName = "";
                    }

                    // 接続情報定義を読み込み取得項目の値をセットする
                    ReadSettingFile(sectionName);
                    foreach (string str in cmbHost.Items)
                    {
                        if (str.Equals(BhtView.Host))
                        {
                            hostSelectedIndex = i;
                            break;
                        }

                        i++;
                    }
                }
            }
            // 接続情報定義ファイルがない場合
            else
            {
                // 何もしない
            }

        }

        /// <summary>入力チェック</summary>
        /// <param name="ConnectCheck">接続用チェックフラグ</param>
        /// <returns>チェックOK/NG</returns>
        private bool InputCheck(bool ConnectCheck)
        {
            bool checkResult = true;
            string errorNum = "";
            string errorMsg = "";
            string Item = "";

            // BHT ID
            if (!cmdLine)
            {
                // 必須入力チェック
                if ("".Equals(cmbTerminal.Text))
                {
                    Item = "[" + _ScreenDictionary[LanguageConstantsNumber.SCREEN_ITEM_BHT_ID] + "]";
                    errorNum = LanguageConstantsNumber.ERROR_MESSAGE_INPUT_REQUIRED;
                    checkResult = false;
                }
                else
                {
                    BhtView.BhtID = cmbTerminal.Text;
                }
            }

            // ホスト
            // 必須入力チェック
            if ("".Equals(cmbHost.Text))
            {
                if (!"".Equals(Item))
                {
                    Item += ", " + "[" + _ScreenDictionary[LanguageConstantsNumber.SCREEN_ITEM_HOST] + "]";
                }
                else
                {
                    Item = "[" + _ScreenDictionary[LanguageConstantsNumber.SCREEN_ITEM_HOST] + "]";
                    errorNum = LanguageConstantsNumber.ERROR_MESSAGE_INPUT_REQUIRED;
                }

                checkResult = false;
            }
            else
            {
                BhtView.Host = cmbHost.Text;

            }

            // ポート
            int relPort = 0;
            // 必須入力チェック
            if ("".Equals(txtPort.Text))
            {
                if (!"".Equals(errorNum))
                {
                    errorNum += ", ";
                }
                errorNum += LanguageConstantsNumber.ERROR_MESSAGE_INPUT_PORT;

                errorMsg += _MessageDictionary[LanguageConstantsNumber.ERROR_MESSAGE_INPUT_PORT];
                checkResult = false;
            }
            // 数値チェック
            else if (!int.TryParse(txtPort.Text, out relPort))
            {
                if (!"".Equals(errorNum))
                {
                    errorNum += ", ";
                }
                errorNum += LanguageConstantsNumber.ERROR_MESSAGE_INPUT_PORT;

                errorMsg += _MessageDictionary[LanguageConstantsNumber.ERROR_MESSAGE_INPUT_PORT];
                checkResult = false;
            }
            else
            {
                // 範囲チェック
                if (relPort > 0 && relPort < 65536)
                {
                    BhtView.ServerPort = relPort;
                }
                else
                {
                    if (!errorNum.Equals(""))
                    {
                        errorNum += ", ";
                    }
                    errorNum += LanguageConstantsNumber.ERROR_MESSAGE_INPUT_PORT;
                    errorMsg += _MessageDictionary[LanguageConstantsNumber.ERROR_MESSAGE_INPUT_PORT];

                    checkResult = false;
                }
            }

            // パスワード
            string password;
            if (pasPassword.Visibility == Visibility.Visible)
            {
                password = pasPassword.Password;
            }
            else
            {
                password = txtPassword.Text;
            }
           
            if (ConnectCheck || chkSavedPass.IsChecked.Value)
            {
                // 必須入力チェック
                if ("".Equals(password))
                {
                    if (!"".Equals(Item))
                    {
                        Item += ", " + "[" + _ScreenDictionary[LanguageConstantsNumber.SCREEN_ITEM_PASSWORD] + "]";
                    }
                    else
                    {
                        Item = "[" + _ScreenDictionary[LanguageConstantsNumber.SCREEN_ITEM_PASSWORD] + "]";
                        errorNum = LanguageConstantsNumber.ERROR_MESSAGE_INPUT_REQUIRED;
                    }

                    checkResult = false;
                }
                else
                {
                    BhtView.ServerPassword = password;
                }
            }

            // 拡大・縮小
            int relRaito = 100;
            // 必須入力チェック
            if ("".Equals(cmbRaito.Text))
            {
                if (!"".Equals(errorNum))
                {
                    errorNum += ", ";
                }
                errorNum += LanguageConstantsNumber.ERROR_MESSAGE_INPUT_RAITO;

                if (!errorMsg.Equals(""))
                {
                    errorMsg += Environment.NewLine;
                }
                errorMsg += _MessageDictionary[LanguageConstantsNumber.ERROR_MESSAGE_INPUT_RAITO];
                checkResult = false;
            }
            // 数値チェック
            else if (!int.TryParse(cmbRaito.Text, out relRaito))
            {
                if (!errorNum.Equals(""))
                {
                    errorNum += ", ";
                }
                errorNum += LanguageConstantsNumber.ERROR_MESSAGE_INPUT_RAITO;

                if (!errorMsg.Equals(""))
                {
                    errorMsg += Environment.NewLine;
                }
                errorMsg += _MessageDictionary[LanguageConstantsNumber.ERROR_MESSAGE_INPUT_RAITO];
                checkResult = false;
            }
            // 範囲チェック
            else if (relRaito < 50 || relRaito > 260)
            {
                if (!errorNum.Equals(""))
                {
                    errorNum += ", ";
                }
                errorNum += LanguageConstantsNumber.ERROR_MESSAGE_INPUT_RAITO;

                if (!errorMsg.Equals(""))
                {
                    errorMsg += Environment.NewLine;
                }
                errorMsg += _MessageDictionary[LanguageConstantsNumber.ERROR_MESSAGE_INPUT_RAITO];
                checkResult = false;
            }
            else
            {
                // 50%～250%まで指定可能
                if (relRaito < 50)
                {
                    relRaito = 50;
                }
                if (relRaito > 250)
                {
                    relRaito = 250;
                }
                BhtView.WindowRatio = relRaito.ToString();
            }

            // 動作モード
            switch (cmbAction.Text)
            {
                case Constants.ACTION_MODE_DESKTOP_NAME:
                    BhtView.ActionMode = Constants.ACTION_MODE_DESKTOP;
                    break;
                case Constants.ACTION_MODE_ASSISTANT_NAME:
                    BhtView.ActionMode = Constants.ACTION_MODE_ASSISTANT;
                    break;
                case Constants.ACTION_MODE_VIEW_NAME:
                    BhtView.ActionMode = Constants.ACTION_MODE_VIEW;
                    break;
                default:
                    // 初期値
                    BhtView.ActionMode = Constants.ACTION_MODE_ASSISTANT;
                    break;
            }

            if (!checkResult)
            {//NG

                if (!"".Equals(Item))
                {
                    errorNum += ":" + Environment.NewLine + //Environment.NewLine + Environment.NewLine + Environment.NewLine + Environment.NewLine +
                                Item + _MessageDictionary[LanguageConstantsNumber.ERROR_MESSAGE_INPUT_REQUIRED] + Environment.NewLine +
                                errorMsg;
                }
                else
                {
                    errorNum += ":" + Environment.NewLine + errorMsg;
                }
                if (!cmdLine)
                {
                    BhtView.ErrorMessage = errorNum;
                }
                else
                {
                    // コマンドライン起動
                    DateTime logOutput = DateTime.Now;
                    // システムログに出力
                    SystemLog cmdLineError = new SystemLog(cmbHost.Text, relPort, _SystemFilePath,
                                Constants.COMMAND_LOG_FILE_NAME, Logtype.Warning);
                    cmdLineError.Log(Logtype.Warning, Environment.NewLine + errorNum + Environment.NewLine);
                    while (true)
                    {
                        // ５秒間のみリトライ
                        if (DateTime.Now.Subtract(logOutput).TotalMilliseconds <= 5000)
                        {
                            try
                            {
                                cmdLineError.tmrLog_Tick();
                                break;
                            }
                            catch (IOException)
                            {
                                // logファイルを閉じたら書き込まれる。
                            }
                        }
                        else
                        {
                            cmdLineError = null;
                            return checkResult;
                        }
                    }
                    cmdLineError = null;
                }
            }
            else
            {
                // 何もしない 
            }

            return checkResult;
        }


        /// <summary>
        /// ウインドウをフックする
        /// </summary>
        /// <param name="owner">ウィンドウハンドラ</param>
        private void SetHook(Window owner)
        {
            // コマンドライン引数による起動の際はオーナー画面非表示であるため
            // オーナー画面の中央表示はできない
            if (cmdLine)
            {
                return;
            }

            proc = new MessageCenter.HOOKPROC(CBTProc);

            // フック設定
            IntPtr hInstance = (IntPtr)GetWindowStyle((int)MessageCenter.WindowLongParam.GWLP_HINSTANCE);

            uint threadId = MessageCenter.NativeMethods.GetCurrentThreadId();
            HHook = MessageCenter.NativeMethods.SetWindowsHookEx((int)MessageCenter.HookType.WH_CBT, proc, hInstance, threadId);
        }

        /// <summary>
        /// ウインドウスタイルを設定する
        /// </summary>
        /// <param name="nCode"></param>
        /// <param name="wParam"></param>
        /// <param name="lParam"></param>
        private IntPtr CBTProc(int nCode, IntPtr wParam, IntPtr lParam)
        {
            if (nCode == (int)MessageCenter.HCBT.HCBT_ACTIVATE)
            {
                MessageCenter.RECT rectOwner;
                MessageCenter.RECT rectMsgBox;
                int x, y;

                // オーナーウィンドウの位置と大きさを取得
                MessageCenter.NativeMethods.GetWindowRect(this.helper.Handle, out rectOwner);
                // MessageBoxの位置と大きさを取得
                MessageCenter.NativeMethods.GetWindowRect(wParam, out rectMsgBox);

                // MessageBoxの表示位置を計算
                x = rectOwner.Left + (rectOwner.Width - rectMsgBox.Width) / 2;
                y = rectOwner.Top + (rectOwner.Height - rectMsgBox.Height) / 2;

                //MessageBoxの位置を設定
                MessageCenter.NativeMethods.SetWindowPos(wParam, 0, x, y, 0, 0,
                  (uint)(MessageCenter.SetWindowPosFlags.SWP_NOSIZE | MessageCenter.SetWindowPosFlags.SWP_NOZORDER | MessageCenter.SetWindowPosFlags.SWP_NOACTIVATE));

                // フック解除
                MessageCenter.NativeMethods.UnhookWindowsHookEx(HHook);
            }
            // 次のプロシージャへのポインタ
            return MessageCenter.NativeMethods.CallNextHookEx(HHook, nCode, wParam, lParam);
        }

        /// <summary>
        /// ウインドウスタイルを初期化する
        /// </summary>
        /// <param name="e"></param>
        protected override void OnSourceInitialized(EventArgs e)
        {
            base.OnSourceInitialized(e);
            // 現在のウインドウスタイルを取得
            this.helper = (new WindowInteropHelper(this));
            HwndSource hwndSource = (HwndSource)HwndSource.FromVisual(this);

            // ユーザーがサイズ変更中のウィンドウに送信されます。このメッセージを処理することによって、
            // アプリケーションはドラッグ矩形のサイズと位置を監視し、必要に応じてそのサイズや位置を変更することができます。
            hwndSource.AddHook(WndHookProc);
        }

        /// <summary>等倍でウィンドウサイズを変更する</summary>
        /// <param name="hwnd">ウィンドウハンドル</param>
        /// <param name="msg">WM_SIZINGメッセージ</param>
        /// <param name="wParam">サイズ変更箇所</param>
        /// <param name="lParam">変更結果</param>
        /// <param name="handled">未使用</param>
        private IntPtr WndHookProc(IntPtr hwnd, int msg, IntPtr wParam, IntPtr lParam, ref bool handled)
        {
            // WM_SIZINGメッセージ
            const int WM_SIZING = 0x214;
            //const int WM_ENTERSIZEMOVE = 0x0231;
            const int WM_EXITSIZEMOVE = 0x0232;
            const int WMSZ_LEFT = 1;
            const int WMSZ_RIGHT = 2;
            const int WMSZ_TOP = 3;
            const int WMSZ_TOPLEFT = 4;
            const int WMSZ_TOPRIGHT = 5;
            const int WMSZ_BOTTOM = 6;
            const int WMSZ_BOTTOMLEFT = 7;
            const int WMSZ_BOTTOMRIGHT = 8;

            // BHT端末画面表示中のみ
            if (BhtImage.Visibility == Visibility.Visible)
            {
                // リサイズ
                if (msg == WM_SIZING)
                {
                    resizeFlg = true;
                    RECT r = (RECT)Marshal.PtrToStructure(lParam, typeof(RECT));
                    RECT recCopy = r;
                    int w = r.right - r.left;
                    int h = r.bottom - r.top;
                    int dw;
                    int dh;

                    double Rate = (BhtView.Width + sabunWidth) / (BhtView.Height + sabunHeight);
                    dw = (int)(h * Rate + 0.5) - w;
                    dh = (int)(w / Rate + 0.5) - h;

                    switch (wParam.ToInt32())
                    {
                        case WMSZ_TOP:
                        case WMSZ_BOTTOM:
                            r.right += dw;
                            break;
                        case WMSZ_LEFT:
                        case WMSZ_RIGHT:
                            r.bottom += dh;
                            break;
                        case WMSZ_TOPLEFT:
                            if (dw > 0) r.left -= dw;
                            else r.top -= dh;
                            break;
                        case WMSZ_TOPRIGHT:
                            if (dw > 0) r.right += dw;
                            else r.top -= dh;
                            break;
                        case WMSZ_BOTTOMLEFT:
                            if (dw > 0) r.left -= dw;
                            else r.bottom += dh;
                            break;
                        case WMSZ_BOTTOMRIGHT:
                            if (dw > 0) r.right += dw;
                            else r.bottom += dh;
                            break;
                    }

                    // リサイズ後のイメージサイズ
                    int NowHeight = r.bottom - r.top - (int)sabunHeight;
                    int NowWidth = r.right - r.left - (int)sabunWidth;
                    // 最少の比率（50%）未満の時は50%でリサイズ
                    if (MinImageWidth > NowWidth || MinImageHeight > NowHeight)
                    {
                        NowHeight = MinImageHeight;
                        NowWidth = MinImageWidth;
                    }

                    // メニュー等アイコンの調整
                    MenuSizeAdjustment(NowWidth, NowHeight);

                    // 画像をリサイズする
                    BhtView.ResizeImage(InitImageHeight, InitImageWidth, NowHeight);
                    AccessView.Margin = new Thickness(0, 0, 0, 0);
                    ConnectingMenu.Margin = new Thickness(0, AccessView.Height - 1, 0, 0);
                    BhtImage.Margin = new Thickness(0, AccessView.Height + ConnectingMenu.Height - 1, 0, 0);
                    FootMenu.Margin = new Thickness(0, BhtView.Height + AccessView.Height + ConnectingMenu.Height - 1, 0, 0);

                    Marshal.StructureToPtr(r, lParam, false);
                    resizeFlg = false;
                }

                // リサイズ終了
                if (msg == WM_EXITSIZEMOVE)
                {
                    this.SizeToContent = SizeToContent.WidthAndHeight;
                    this.SizeToContent = SizeToContent.Manual;

                    //Console.WriteLine("ConnectingMenu:" + ConnectingMenu.Height);
                    //Console.WriteLine("BhtImage:" + BhtView.Height);
                    //Console.WriteLine("FootMenu:" + FootMenu.Height);

                    //Console.WriteLine("H:" + ActualHeight);
                    //Console.WriteLine("W:" + ActualWidth);
                }
            }

            return IntPtr.Zero;
        }

        /// <summary>メニューアイコンのサイズ調整</summary>
        private void MenuSizeAdjustment(int NowWidth, int NowHeight)
        {
            // 下部キーの幅を調整する（160ピクセル未満の場合）
            if (Width - sabunWidth < 160)
            {
                back.Width = (double)(NowWidth - sabunWidth) / 3;
                home.Width = (double)(NowWidth - sabunWidth) / 3;
                multi.Width = (double)(NowWidth - sabunWidth) / 3;
            }
            else
            {
                back.Width = 50;
                home.Width = 50;
                multi.Width = 50;
            }

            const int TOP_MENU_SMALL_SIZE = 14;
            const int TOP_MENU_MIDDLE_SIZE = 20;
            const int TOP_MENU_LARGE_SIZE = 25;
            const int ACCESS_MENU_SMALL_SIZE = 12;
            const int ACCESS_MENU_MIDDLE_SIZE = 13;
            const int ACCESS_MENU_LARGE_SIZE = 15;
            const int BOTTOM_MENU_SMALL_SIZE = 20;
            const int BOTTOM_MENU_MIDDLE_SIZE = 25;
            const int BOTTOM_MENU_LARGE_SIZE = 30;

            // アイコンの調整（300ピクセル未満の表示の場合）
            if (260 > NowHeight)
            {
                AccessView.Height = ACCESS_MENU_SMALL_SIZE;
                AccessPoint.FontSize = 8;

                ConnectingMenu.Height = TOP_MENU_SMALL_SIZE;
                miReConnect.Height = TOP_MENU_SMALL_SIZE - 2;
                miDisConnect.Height = TOP_MENU_SMALL_SIZE - 2;
                miSpecialKeys.Height = TOP_MENU_SMALL_SIZE - 2;
                ActionMode.Height = TOP_MENU_SMALL_SIZE - 2;

                miReConnect.Width = TOP_MENU_SMALL_SIZE - 2;
                miDisConnect.Width = TOP_MENU_SMALL_SIZE - 2;
                miSpecialKeys.Width = TOP_MENU_SMALL_SIZE - 2;
                ActionMode.Width = TOP_MENU_SMALL_SIZE - 2;

                FootMenu.Height = BOTTOM_MENU_SMALL_SIZE;
                back.Height = BOTTOM_MENU_SMALL_SIZE;
                home.Height = BOTTOM_MENU_SMALL_SIZE;
                multi.Height = BOTTOM_MENU_SMALL_SIZE;
            }
            else if (330 > NowHeight)
            {
                AccessView.Height = ACCESS_MENU_MIDDLE_SIZE;
                AccessPoint.FontSize = 9;

                ConnectingMenu.Height = TOP_MENU_MIDDLE_SIZE;
                miReConnect.Height = TOP_MENU_MIDDLE_SIZE - 2;
                miDisConnect.Height = TOP_MENU_MIDDLE_SIZE - 2;
                miSpecialKeys.Height = TOP_MENU_MIDDLE_SIZE - 2;
                ActionMode.Height = TOP_MENU_MIDDLE_SIZE - 2;

                miReConnect.Width = TOP_MENU_MIDDLE_SIZE - 2;
                miDisConnect.Width = TOP_MENU_MIDDLE_SIZE - 2;
                miSpecialKeys.Width = TOP_MENU_MIDDLE_SIZE - 2;
                ActionMode.Width = TOP_MENU_MIDDLE_SIZE - 2;

                FootMenu.Height = BOTTOM_MENU_MIDDLE_SIZE;
                back.Height = BOTTOM_MENU_MIDDLE_SIZE;
                home.Height = BOTTOM_MENU_MIDDLE_SIZE;
                multi.Height = BOTTOM_MENU_MIDDLE_SIZE;
            }
            else
            {
                AccessView.Height = ACCESS_MENU_LARGE_SIZE;
                AccessPoint.FontSize = 10;

                ConnectingMenu.Height = TOP_MENU_LARGE_SIZE;
                miReConnect.Height = TOP_MENU_LARGE_SIZE;
                miDisConnect.Height = TOP_MENU_LARGE_SIZE;
                miSpecialKeys.Height = TOP_MENU_LARGE_SIZE;
                ActionMode.Height = TOP_MENU_LARGE_SIZE - 5;

                miReConnect.Width = TOP_MENU_LARGE_SIZE;
                miDisConnect.Width = TOP_MENU_LARGE_SIZE;
                miSpecialKeys.Width = TOP_MENU_LARGE_SIZE;
                ActionMode.Width = TOP_MENU_LARGE_SIZE - 5;

                FootMenu.Height = BOTTOM_MENU_LARGE_SIZE;
                back.Height = BOTTOM_MENU_LARGE_SIZE;
                home.Height = BOTTOM_MENU_LARGE_SIZE;
                multi.Height = BOTTOM_MENU_LARGE_SIZE;
            }

            sabunHeight = AccessView.Height + ConnectingMenu.Height + FootMenu.Height + 38;//38:タイトルバーと枠の高さ
        }

        /// <summary>最大化ボタン無効</summary>
        private void InvalidateMinimizeButtonOnly()
        {
            // 最大化無効
            const int GWL_STYLE = -16;
            const int WS_MAXIMIZEBOX = 0x10000;
            //const int WS_MINIMIZEBOX = 0x20000;//未使用

            var style = this.GetWindowStyle(GWL_STYLE);
            this.SetWindowStyle(style & ~(WS_MAXIMIZEBOX), GWL_STYLE);
        }

        /// <summary>ウィンドウに関する情報を取得</summary>
        /// <param name="GWL_Style">ウィンドウスタイル</param>
        private int GetWindowStyle(int GWL_Style)
        {
            var handle = new HandleRef(this, this.helper.Handle);
            return NativeMethods.GetWindowLong(handle, GWL_Style);
        }

        /// <summary>ウィンドウの属性を変更</summary>
        /// <param name="hwnd">変更ウィンドウハンドル</param>
        /// <param name="GWL_Style">ウィンドウスタイル</param>
        private void SetWindowStyle(int style, int GWL_Style)
        {
            var handle = new HandleRef(this, this.helper.Handle);
            NativeMethods.SetWindowLong(handle, GWL_Style, style);
        }

        /// <summary>
        /// 特殊キー送信処理
        /// </summary>
        /// <param name="keyComb">押下キー</param>
        public void SpecialKeys(BHTKey keyComb)
        {
            // 切断時
            if (!BhtView.IsConncted())
            {
                return;
            }

            // 動作モード
            switch (keyComb)
            {
                case BHTKey.F6:
                    ActionMode.Source = new BitmapImage(new Uri("/logo/ic_assist.png", UriKind.Relative));
                    ActionMode.ToolTip = _TooltipDictionary[LanguageConstantsNumber.TOOLTIP_ASSISTANT];
                    BhtView.ActionMode = Constants.ACTION_MODE_ASSISTANT;
                    break;
                case BHTKey.F7:
                    ActionMode.Source = new BitmapImage(new Uri("/logo/ic_desktop.png", UriKind.Relative));
                    ActionMode.ToolTip = _TooltipDictionary[LanguageConstantsNumber.TOOLTIP_DESKTOP];
                    BhtView.ActionMode = Constants.ACTION_MODE_DESKTOP;
                    break;
                case BHTKey.F8:
                    ActionMode.Source = new BitmapImage(new Uri("/logo/ic_view.png", UriKind.Relative));
                    ActionMode.ToolTip = _TooltipDictionary[LanguageConstantsNumber.TOOLTIP_VIEW];
                    BhtView.ActionMode = Constants.ACTION_MODE_VIEW;
                    break;
                default:
                    // 何もしない
                    break;
            }

            // 特殊キー送信
            BhtView.SendKeyBHT(keyComb);
        }

        /// <summary>
        /// コマンド起動処理
        /// </summary>
        private bool CmdLineExec()
        {
            // 画面切り替え
            SettingMenu.Visibility = Visibility.Collapsed;//接続設定画面-ツールバー
            ConnectionItems.Visibility = Visibility.Collapsed;//接続設定画面
            ConnectingMenu.Visibility = Visibility.Collapsed;//BHT端末画面-ツールバー
            AccessView.Visibility = Visibility.Collapsed;//BHT端末画面-接続先
            BhtImage.Visibility = Visibility.Collapsed;//BHT端末画面
            FootMenu.Visibility = Visibility.Collapsed;//BHT端末画面-下部キー
            ConnectingFrame.Visibility = Visibility.Visible;//接続中画面
            Connecting.Visibility = Visibility.Visible;//グルグル

            ConnectingFrame.Width = ConnectionItems.ActualWidth;
            ConnectingFrame.Height = ConnectionItems.ActualHeight;

            DoEvents();
            
            // コマンドライン起動時のエラーログ出力
            int retPort = 0;
            if (int.TryParse(txtPort.Text, out int relPort))
            {
                retPort = relPort;
            }
            else
            {
                retPort = 0;
            }

            SystemLog cmdLineError = new SystemLog(cmbHost.Text, retPort, _SystemFilePath, 
                    Constants.COMMAND_LOG_FILE_NAME, Logtype.Warning);

            try
            {
                // 接続
                bool ret = ConnectProcess(1);
                // 接続失敗
                if (!ret)
                {
                    BhtView.GetError();
                    if (BhtView.Error)
                    {
                        cmdLineError.Log(Logtype.Warning, BhtView.ErrorMessage);
                        DateTime logOutput = DateTime.Now;
                        while (true)
                        {
                            // １０秒間のみリトライ
                            if (DateTime.Now.Subtract(logOutput).TotalMilliseconds <= 10000)
                            {
                                try
                                {
                                    cmdLineError.tmrLog_Tick();
                                    break;
                                }
                                catch (IOException)
                                {
                                    // logファイルを閉じたら書き込まれる。
                                }
                            }
                            else
                            {
                                break;
                            }
                        }
                    }
                    cmdLineError = null;
                    return false;
                }

                cmdLineError = null;

                return true;
            }

            // 接続に時間がかかる場合があり、処理中にユーザがアプリを終了する可能性があるため
            // 終了してしまったコントロールにアクセスして不正終了となるのを防ぐためcatchする
            catch (Exception)
            {
                return false;
            }
        }

        /// <summary>
        /// 接続設定画面→BHT画面切替処理
        /// </summary>
        private void BhtScreenSwitching()
        {
            BhtView.FirstView = false;
            Console.WriteLine("BHT端末画面の初回表示時:" + DateTime.Now.ToString() + "." + DateTime.Now.Millisecond.ToString());

            SettingMenu.Visibility = Visibility.Collapsed;//接続設定画面-ツールバー
            ConnectionItems.Visibility = Visibility.Collapsed;//接続設定画面
            ConnectingMenu.Visibility = Visibility.Visible;//BHT端末画面-ツールバー
            AccessView.Visibility = Visibility.Visible;//BHT端末画面-接続先
            BhtImage.Visibility = Visibility.Visible;//BHT端末画面
            FootMenu.Visibility = Visibility.Visible;//BHT端末画面-下部キー
            ConnectingFrame.Visibility = Visibility.Collapsed;//接続中画面
            Connecting.Visibility = Visibility.Collapsed;//ぐるぐる

            // BHT IDが空の場合（コマンド起動の場合）
            AccessPoint.TextTrimming = TextTrimming.CharacterEllipsis;
            if ("".Equals(this.cmbTerminal.Text))
            {
                AccessPoint.Text = cmbHost.Text;// IPアドレスを表示
            }
            else
            {
                AccessPoint.Text = this.cmbTerminal.Text + ":" + cmbHost.Text;// BHT IDを表示
            }

            this.ResizeMode = ResizeMode.CanResize;//リサイズ可能
            InvalidateMinimizeButtonOnly();
            DoEvents();

            // メニュー等アイコンの調整
            MenuSizeAdjustment((int)BhtView.Width, (int)BhtView.Height);

            // BHT端末表示画面のサイズを初期化
            this.Height = AccessView.Height + ConnectingMenu.Height + BhtView.Height + FootMenu.Height;
            this.Width = BhtView.Width + 16;//16:左右のウィンドウ枠の幅
            AccessView.Margin = new Thickness(0, 0, 0, 0);
            ConnectingMenu.Margin = new Thickness(0, AccessView.Height - 1, 0, 0);
            BhtImage.Margin = new Thickness(0, AccessView.Height + ConnectingMenu.Height - 1, 0, 0);
            FootMenu.Margin = new Thickness(0, BhtView.Height + AccessView.Height + ConnectingMenu.Height - 1, 0, 0);

            this.SizeToContent = SizeToContent.WidthAndHeight;
            this.SizeToContent = SizeToContent.Manual;

            // サイズの取得
            InitImageHeight = (int)BhtView.Height;
            InitImageWidth = (int)BhtView.Width;
            if (int.TryParse(cmbRaito.Text, out int relRaito))
            {
                InitRaito = relRaito;
            }
            sabunHeight = ActualHeight - BhtView.Height;
            sabunWidth = ActualWidth - BhtView.Width;

            // 接続したBHT端末（1700/1800）からイメージの最小サイズ（50%）を設定
            MinImageHeight = (int)(_BhtStandardHeight * 0.5);
            MinImageWidth = (int)((double)_BhtStandardHeight / (double)BhtView.Bht100PerHeight * (double)BhtView.Bht100PerWidth * 0.5 + 0.5);
            DoEvents();
        }

        /// <summary>
        /// BHT画面表示中の設定内容変更を保持
        /// </summary>
        private void BhtScreenSetting()
        {
            // 現在の拡大縮小率を保持
            int NowRaito = 0;
            if (BhtView.Bht100PerHeight != 0)
            {
                NowRaito = (int)(BhtView.Height / InitImageHeight * InitRaito + 0.5);
            }
            else
            {
                NowRaito = 100;
            }

            cmbRaito.Text = NowRaito.ToString();
            BhtView.WindowRatio = NowRaito.ToString();

            // 現在の動作モードを保持
            switch (BhtView.ActionMode)
            {
                case Constants.ACTION_MODE_DESKTOP:
                    cmbAction.Text = Constants.ACTION_MODE_DESKTOP_NAME;
                    BhtView.ActionMode = Constants.ACTION_MODE_DESKTOP;
                    break;
                case Constants.ACTION_MODE_ASSISTANT:
                    cmbAction.Text = Constants.ACTION_MODE_ASSISTANT_NAME;
                    BhtView.ActionMode = Constants.ACTION_MODE_ASSISTANT;
                    break;
                case Constants.ACTION_MODE_VIEW:
                    cmbAction.Text = Constants.ACTION_MODE_VIEW_NAME;
                    BhtView.ActionMode = Constants.ACTION_MODE_VIEW;
                    break;
                default:
                    // 変更しない
                    break;
            }
        }

        /// <summary>
        /// ToolTip設定
        /// </summary>
        /// <param name="setFlg">true:設定、false:初期化</param>
        private void SetScreen()
        {
            ConnectInfomation.Text = _ScreenDictionary[LanguageConstantsNumber.SCREEN_ITEM_CONNECT_INFO];
            bhtID.Content = _ScreenDictionary[LanguageConstantsNumber.SCREEN_ITEM_BHT_ID] + ":";
            host.Content = _ScreenDictionary[LanguageConstantsNumber.SCREEN_ITEM_HOST] + ":";
            port.Content = _ScreenDictionary[LanguageConstantsNumber.SCREEN_ITEM_PORT] + ":";
            pass.Content = _ScreenDictionary[LanguageConstantsNumber.SCREEN_ITEM_PASSWORD] + ":";
            OptionItem.Text = _ScreenDictionary[LanguageConstantsNumber.SCREEN_ITEM_OPTION];
            scale.Content = _ScreenDictionary[LanguageConstantsNumber.SCREEN_ITEM_SCALE] + ":";
            actMode.Content = _ScreenDictionary[LanguageConstantsNumber.SCREEN_ITEM_MODE] + ":";
            btnConnect.Content = _ScreenDictionary[LanguageConstantsNumber.SCREEN_ITEM_CONNECT];
        }

        /// <summary>
        /// ToolTip設定
        /// </summary>
        /// <param name="setFlg">true:設定、false:初期化</param>
        private void SetToolTip(bool setFlg)
        {
            if (setFlg)
            {
                // 接続設定画面
                miSave.ToolTip = _TooltipDictionary[LanguageConstantsNumber.TOOLTIP_SAVE];
                miEdit.ToolTip = _TooltipDictionary[LanguageConstantsNumber.TOOLTIP_EDIT];
                miHelp.ToolTip = _TooltipDictionary[LanguageConstantsNumber.TOOLTIP_HELP];
                cmbTerminal.ToolTip = _TooltipDictionary[LanguageConstantsNumber.TOOLTIP_BHT_TERMINAL];
                btnShowPassword.ToolTip = _TooltipDictionary[LanguageConstantsNumber.TOOLTIP_HIDE_PASSWORD];
                chkSavedPass.ToolTip = _TooltipDictionary[LanguageConstantsNumber.TOOLTIP_SAVE_PASSWORD];
                cmbRaito.ToolTip = _TooltipDictionary[LanguageConstantsNumber.TOOLTIP_SCALING];
                btnConnect.ToolTip = _TooltipDictionary[LanguageConstantsNumber.TOOLTIP_CONNECT];
                switch (cmbAction.SelectedIndex)
                {
                    case 0:// ASSISTANT
                        ActionImg.ToolTip = _TooltipDictionary[LanguageConstantsNumber.TOOLTIP_ASSISTANT_DESCRIPTION];
                        break;
                    case 1:// DESKTOP
                        ActionImg.ToolTip = _TooltipDictionary[LanguageConstantsNumber.TOOLTIP_DESKTOP_DESCRIPTION];
                        break;
                    case 2:// VIEW
                        ActionImg.ToolTip = _TooltipDictionary[LanguageConstantsNumber.TOOLTIP_VIEW_DESCRIPTION];
                        break;
                    default:// 
                        cmbAction.ToolTip = "";
                        break;
                }
                // BHT表示画面
                miReConnect.ToolTip = _TooltipDictionary[LanguageConstantsNumber.TOOLTIP_RECONNECT];
                miDisConnect.ToolTip = _TooltipDictionary[LanguageConstantsNumber.TOOLTIP_DISCONNECT];
                miSpecialKeys.ToolTip = _TooltipDictionary[LanguageConstantsNumber.TOOLTIP_TERMINAL_KEY_AND_MODE_SWITCH_KEY];
                back.ToolTip = _TooltipDictionary[LanguageConstantsNumber.TOOLTIP_BACK];
                home.ToolTip = _TooltipDictionary[LanguageConstantsNumber.TOOLTIP_HOMEPAGE];
                multi.ToolTip = _TooltipDictionary[LanguageConstantsNumber.TOOLTIP_MULTI_TASK];
            }
            else
            {
                // 接続設定画面
                miSave.ToolTip = null;
                miEdit.ToolTip = null;
                miHelp.ToolTip = null;
                cmbTerminal.ToolTip = null;
                btnShowPassword.ToolTip = null;
                chkSavedPass.ToolTip = null;
                cmbRaito.ToolTip = null;
                btnConnect.ToolTip = null;
                ActionImg.ToolTip = null;

                // BHT表示画面
                miReConnect.ToolTip = null;
                miDisConnect.ToolTip = null;
                miSpecialKeys.ToolTip = null;
                back.ToolTip = null;
                home.ToolTip = null;
                multi.ToolTip = null;
            }
        }

        /// <summary>
        /// アプリ設定情報初期化処理
        /// </summary>
        private void GetSettingInfo()
        {
            // 設定ファイルの読み込み
            SettingINI SettingIni = new SettingINI(".\\setting.ini");
            string[] SettingSections = SettingIni.GetSectionNames();
            int logLevel = -1;
            // 設定ファイルがない場合
            if (SettingSections.Length == 0)
            {
                // 初期値でアプリ設定定義ファイルを作成する
                SettingIni[Constants.SETTING_INI_SECTION, Constants.SETTING_INI_KEY_CONNECT] = ".\\";//CONNECT
                SettingIni[Constants.SETTING_INI_SECTION, Constants.SETTING_INI_KEY_ACCESS_LOG] = Constants.LOGIN_HISTORY_FILE_PATH;//ACCESS_LOG
                SettingIni[Constants.SETTING_INI_SECTION, Constants.SETTING_INI_KEY_SYSTEM_LOG] = Constants.SYSTEM_LOG_FILE_PATH;//SYSTEM_LOG
                SettingIni[Constants.SETTING_INI_SECTION, Constants.SETTING_INI_KEY_STANDART] = Constants.HEIGHT_100_PERCENT.ToString();//BHT_STANDART_HEIGHT
                logLevel = (int)Logtype.Information;
                SettingIni[Constants.SETTING_INI_SECTION, Constants.SETTING_INI_KEY_SYSLOG_LEVEL] = logLevel.ToString();//SYS_LOG_LEVEL
                SettingIni[Constants.SETTING_INI_SECTION, Constants.SETTING_INI_KEY_RECONNECT_TIMEOUT] = Constants.TIMEOUT_RECONNECT_SEC.ToString();//RECONNECT_TIMEOUT
                SettingIni[Constants.SETTING_INI_SECTION, Constants.SETTING_INI_KEY_RECEIVE_TIMEOUT] = Constants.TIMEOUT_RECEIVE_SEC.ToString();//RECEIVE_TIMEOUT
                // 初期値で設定
                _ConnectCsvPath = ".\\" + Constants.CONNECT_INFO_FILE_NAME;
                _LogFilePath = Constants.LOGIN_HISTORY_FILE_PATH;
                _SystemFilePath = Constants.SYSTEM_LOG_FILE_PATH;
                _BhtStandardHeight = Constants.HEIGHT_100_PERCENT;
                _SystemLogOutLevel = Logtype.Information;
                _ReconnectTimeout = Constants.TIMEOUT_RECONNECT_SEC;
                _ReceiveTimeout = Constants.TIMEOUT_RECEIVE_SEC;
            }
            else
            {
                // 接続設定情報の読み込み
                _ConnectCsvPath = SettingIni[Constants.SETTING_INI_SECTION, Constants.SETTING_INI_KEY_CONNECT] + Constants.CONNECT_INFO_FILE_NAME;//接続情報設定ファイルパス
                // 無効なパスが設定されていた場合は初期値で定義ファイルに設定する
                if (!File.Exists(_ConnectCsvPath))
                {
                    SettingIni[Constants.SETTING_INI_SECTION, Constants.SETTING_INI_KEY_CONNECT] = ".\\";
                    _ConnectCsvPath = ".\\" + Constants.CONNECT_INFO_FILE_NAME;
                }

                // アクセスログファイルパス
                _LogFilePath = SettingIni[Constants.SETTING_INI_SECTION, Constants.SETTING_INI_KEY_ACCESS_LOG];
                // ディレクトリ有無チェック
                if (!Directory.Exists(_LogFilePath))
                {
                    try
                    {
                        // ディレクトリがない場合は作成する
                        Directory.CreateDirectory(_LogFilePath);
                    }
                    catch (Exception)
                    {
                        // 未設定/無効なパスの場合は初期値で設定ファイルに書き込む
                        SettingIni[Constants.SETTING_INI_SECTION, Constants.SETTING_INI_KEY_ACCESS_LOG] = Constants.LOGIN_HISTORY_FILE_PATH;
                        _LogFilePath = Constants.LOGIN_HISTORY_FILE_PATH;
                    }
                }
                if (_LogFilePath.Substring(_LogFilePath.Length - 1) != "\\")
                {
                    _LogFilePath += "\\";
                }

                // システムログファイルパス
                _SystemFilePath = SettingIni[Constants.SETTING_INI_SECTION, Constants.SETTING_INI_KEY_SYSTEM_LOG];
                // ディレクトリ有無チェック
                if (!Directory.Exists(_SystemFilePath))
                {
                    try
                    {
                        // ディレクトリがない場合は作成する
                        Directory.CreateDirectory(_SystemFilePath);
                    }
                    catch (Exception)
                    {
                        // 未設定/無効なパスの場合は初期値で設定ファイルに書き込む
                        SettingIni[Constants.SETTING_INI_SECTION, Constants.SETTING_INI_KEY_SYSTEM_LOG] = Constants.SYSTEM_LOG_FILE_PATH;
                        _SystemFilePath = Constants.SYSTEM_LOG_FILE_PATH;
                    }
                }
                if (_SystemFilePath.Substring(_SystemFilePath.Length - 1) != "\\")
                {
                    _SystemFilePath += "\\";
                }

                // BHT端末の基準高さ
                _BhtStandardHeight = Constants.HEIGHT_100_PERCENT;
                if (int.TryParse(SettingIni[Constants.SETTING_INI_SECTION, Constants.SETTING_INI_KEY_STANDART], out int rel))
                {
                    // 400ピクセルより小さい場合は400（初期値）ピクセルに設定
                    if (Constants.HEIGHT_100_PERCENT > rel)
                    {
                        _BhtStandardHeight = Constants.HEIGHT_100_PERCENT;
                    }
                    else
                    {
                        _BhtStandardHeight = rel;
                    }
                }

                // システムログ出力レベル
                if (int.TryParse(SettingIni[Constants.SETTING_INI_SECTION, Constants.SETTING_INI_KEY_SYSLOG_LEVEL], out int relLevel))
                {
                    logLevel = relLevel;
                }
                // 定義済みのレベルの場合
                if (Enum.IsDefined(typeof(Logtype), logLevel))
                {
                    _SystemLogOutLevel = (Logtype)relLevel;
                }
                else
                {   // 無効な値の場合は初期値3：Informationを設定する
                    _SystemLogOutLevel = Logtype.Information;
                }

                // 再接続タイムアウト
                _ReconnectTimeout = Constants.TIMEOUT_RECONNECT_SEC;// 規定値
                if (int.TryParse(SettingIni[Constants.SETTING_INI_SECTION, Constants.SETTING_INI_KEY_RECONNECT_TIMEOUT], out int to))
                {
                    // 正の値の場合
                    if (to >= 0)
                    {
                        _ReconnectTimeout = to;
                    }
                }

                // 受信タイムアウト
                _ReceiveTimeout = Constants.TIMEOUT_RECEIVE_SEC;// 規定値
                if (int.TryParse(SettingIni[Constants.SETTING_INI_SECTION, Constants.SETTING_INI_KEY_RECEIVE_TIMEOUT], out to))
                {
                    // 設定値が5秒以上かつ999999999未満の場合
                    if (to >= 5 && to <= 999999999)
                    {
                        _ReceiveTimeout = to;
                    }
                }
            }

            BhtView.BhtStandardHeight = _BhtStandardHeight;
            //BhtView.ReceiveTimeout = _ReceiveTimeout;
        }

        /// <summary>
        /// BHT IDからcsvファイルの設定値を取得します。 
        /// </summary>
        /// <param name="section">section</param>
        /// <returns></returns>
        private void ReadSettingFile(string BhtId)
        {
            CsvConnectInfo ConInfo = _Csv.GetConnectInfoItems(BhtId);
            if (ConInfo != null)
            {
                BhtView.Host = ConInfo.Host;
                string ServerPort = ConInfo.Port;
                BhtView.ServerPort = -1;
                if (int.TryParse(ServerPort, out int rel))
                {
                    BhtView.ServerPort = rel;
                }
                BhtView.ServerPassword = ConInfo.Password;
                BhtView.WindowRatio = ConInfo.Raito;
                BhtView.ActionMode = ConInfo.ActionMode;
            }
        }

        /// <summary>
        /// 画面入力接続情報の内容を保存します
        /// </summary>
        /// <param name="section">BHT ID名</param>
        /// <param name="pass">パスワードの保存有無</param>
        /// <param name="con">接続時の保存（接続情報をcsvファイルの最後に移動する）</param>
        /// <returns></returns>
        private bool SaveCsvFile(string bhtId, bool pass, bool con)
        {
            CsvConnectInfo conInfo = new CsvConnectInfo();
            conInfo.BhtId = BhtView.BhtID;
            conInfo.Host = BhtView.Host;
            conInfo.Port = BhtView.ServerPort.ToString();
            // パスワード保存オプションがない場合（パスワード保存オプションがある場合はそのまま保存）
            if (pass)
            {
                conInfo.Password = BhtView.ServerPassword;
            }
            else conInfo.Password = "";
            conInfo.Raito = BhtView.WindowRatio;
            conInfo.ActionMode = BhtView.ActionMode;

            // 接続時は接続情報をcsvファイルの最後に移動する
            if (_Csv.SaveConnectInfoItem(bhtId, con, conInfo))
            {
                return _Csv.ReadCsvConnectInfoAll();
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// ログイン履歴をログに出力します。 
        /// </summary>
        /// <param name="con">0:接続/1:再接続/2:切断</param>
        /// <param name="success">接続成否フラグ/切断時は無視</param>
        private bool OutputAccessLog(int con, bool success)
        {
            DateTime logOutput = DateTime.Now;
            AccessLog accessLog = new AccessLog(_LogFilePath);

            // 出力タイプ
            string Logtype;
            // 接続/再接続ボタン押下時
            if (con == 0)
            {
                if (success)
                {
                    Logtype = "[Connected:Success]";
                }
                else
                {
                    Logtype = "[Connected:Failure]";
                }
            }
            // エラー再接続時
            else if (con == 1)
            {
                if (success)
                {
                    Logtype = "[Reconnected:Success]";
                }
                else
                {
                    Logtype = "[Reconnected:Failure]";
                }
            }
            // 切断時
            else if (con == 2)
            {
                Logtype = "[Disconnected]";
            }
            else
            {
                Logtype = "[Unknown]";
            }

            // 動作モード
            string action;
            switch (cmbAction.Text)
            {
                case Constants.ACTION_MODE_DESKTOP_NAME:
                    action = Constants.ACTION_MODE_DESKTOP;
                    break;
                case Constants.ACTION_MODE_ASSISTANT_NAME:
                    action = Constants.ACTION_MODE_ASSISTANT;
                    break;
                case Constants.ACTION_MODE_VIEW_NAME:
                    action = Constants.ACTION_MODE_VIEW;
                    break;
                default:
                    // 初期値
                    action = Constants.ACTION_MODE_ASSISTANT;
                    break;
            }

            // 出力メッセージ
            string LogMesseage = cmbTerminal.Text + "\t" + cmbHost.Text + "\t" + cmbRaito.Text + "\t" + action;
            accessLog.InputLog(Logtype, LogMesseage);

            // ログイン履歴のログ出力
            while (true)
            {
                // ５秒間のみリトライ
                if (DateTime.Now.Subtract(logOutput).TotalMilliseconds <= 5000)
                {
                    // ログイン履歴に出力
                    if (accessLog.OutputLog())
                    {
                        break;
                    }
                }
                // ５秒経過（ログファイルがテキストエディター等で開かれている？）
                else
                {
                    // 接続の場合のみ
                    if (con == 0)
                    {
                        // ログイン履歴へログ出力が出来なかったため、サーバへ接続させない
                        // エラーメッセージ
                        BhtView.Error = true;
                        BhtView.ErrorType = Constants.ERROR_TYPE_CONNECT;
                        BhtView.ErrorMessage = LanguageConstantsNumber.ERROR_MESSAGE_LOG_OUTPUT_FAIL + Environment.NewLine +
                                        _MessageDictionary[LanguageConstantsNumber.ERROR_MESSAGE_LOG_OUTPUT_FAIL];
                    }

                    return false;
                }
            }

            // サイズローテ（バックアップ）
            accessLog.FileBackup();

            return true;
        }

        /// <summary>
        /// DoEvents
        /// </summary>
        private void DoEvents()
        {
            try
            {
                DispatcherFrame frame = new DispatcherFrame();
                var callback = new DispatcherOperationCallback(obj =>
                {
                    ((DispatcherFrame)obj).Continue = false;
                    return null;
                });
                Dispatcher.CurrentDispatcher.BeginInvoke(DispatcherPriority.Background, callback, frame);
                Dispatcher.PushFrame(frame);
            }
            catch (Exception)
            {
                // 何もしない
            }
        }
        #endregion

        #region Dispose
        public void Dispose()
    {
        Dispose(true);
        GC.SuppressFinalize(this);
    }

    protected virtual void Dispose(bool disposing)
    {
        if (!disposed)
        {
            if (disposing)
            {
                if (BhtView != null)
                {
                    BhtView.Dispose();
                    BhtView = null;
                }
            }

            // Free the unmanaged resource ...

            disposed = true;
        }
    }

    ~MainWindow()
    {
        Dispose(false);
    }
    #endregion
    }
}
