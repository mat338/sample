﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Windows;

namespace DWRemoteViewClient
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        private static class NativeMethods
        {
            [System.Runtime.InteropServices.DllImport("Kernel32.dll")]
            public static extern bool AttachConsole(int processId);
        }

        static App()
        {
            NativeMethods.AttachConsole(-1);
        }
    }
}
