﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace DWRemoteViewClient
{
    /// <summary>
    /// SpecialKeys.xaml の相互作用ロジック
    /// </summary>
    public partial class SpecialKeys : Window
    {
        // 親画面
        private MainWindow main;

        /// <summary>コンストラクタ</summary>
        public SpecialKeys()
        {
            InitializeComponent();
            this.WindowStyle = WindowStyle.ToolWindow;
        }

        /// <summary>画面描画終了イベント(ウィンドウのコンテンツが描画された後に発生)</summary>
        protected override void OnContentRendered(EventArgs e)
        {
            base.OnContentRendered(e);
            Keyboard.Focus(menu);
        }

        /// <summary>キーダウンイベント</summary>
        void SpecialKeys_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Escape)
            {
                this.Close();
            }
        }

        #region SpecialKey Event
        /// <summary>PgUpキーイベント</summary>
        private void miPgUp_Click(object sender, RoutedEventArgs e)
        {
            SpecialKey(DWRemoteCommunication.BHTKey.PgUp);
        }
        /// <summary>PgDnキーイベント</summary>
        private void miPgDn_Click(object sender, RoutedEventArgs e)
        {
            SpecialKey(DWRemoteCommunication.BHTKey.PgDn);
        }
        /// <summary>F2キーイベント</summary>
        private void miF2_Click(object sender, RoutedEventArgs e)
        {
            SpecialKey(DWRemoteCommunication.BHTKey.F2);
        }
        /// <summary>F11キーイベント</summary>
        private void miF11_Click(object sender, RoutedEventArgs e)
        {
            SpecialKey(DWRemoteCommunication.BHTKey.F11);
        }
        /// <summary>F12キーイベント</summary>
        private void miF12_Click(object sender, RoutedEventArgs e)
        {
            SpecialKey(DWRemoteCommunication.BHTKey.F12);
        }
        #endregion

        #region Private Methods
        /// <summary>
        /// 特殊キーを親画面にセットする 
        /// </summary>
        /// <param name="i">特殊キー番号</param>
        private void SpecialKey(DWRemoteCommunication.BHTKey i)
        {
            main.SpecialKeys(i);
            this.Close();
        }
        #endregion

        #region Public Methods
        /// <summary>
        /// 親画面の情報をセットする 
        /// </summary>
	    /// <param name="main">親ウィンドウ</param>
        public void SetParent(MainWindow main)
        {
            this.main = main;
        }
        #endregion

    }
}
