#include "stdafx.h"
#include "BaseStream.h"
#include "ReadStream.h"

using namespace DWReadStream;


int BaseStream::ReadByteData(void* data, int length) {
	BYTE* Pos = (BYTE*)data;
	BYTE* End = Pos + length;

	int n = 0;
	while (Pos < End) {
		n = DataSizeCheck(End - Pos);
		if (n <= 0) return n;

		memcpy(Pos, nowPosition, n);
		nowPosition += n;
		Pos += n;
	}

	return n;
}

int BaseStream::DataSizeCheck(int nItems)
{
	if (nowPosition + nItems > endPosition) {
		if (nowPosition + 1 > endPosition)
		return overrun(nItems);

		nItems = endPosition - nowPosition;
	}
	return nItems;
}
