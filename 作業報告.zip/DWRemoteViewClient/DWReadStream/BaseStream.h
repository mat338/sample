#ifndef __DWReadStream_INSTREAM_H__
#define __DWReadStream_INSTREAM_H__

#pragma once 

#include <string.h> 
namespace DWReadStream {

	class BaseStream {

		public:

		virtual ~BaseStream() {}

		//virtual int DataSizeCheck(int itemSize, int nItems = 1);
		virtual int DataSizeCheck(int nItems = 1);
		virtual int ReadByteData(void* data, int length);

		private:

		//virtual int overrun(int itemSize, int nItems) = 0;
		virtual int overrun(int nItems) = 0;

		protected:

		BaseStream() {
			nowPosition = NULL;
			endPosition = NULL;
		}
		const BYTE* nowPosition;
		const BYTE* endPosition;
	};
}
#endif
