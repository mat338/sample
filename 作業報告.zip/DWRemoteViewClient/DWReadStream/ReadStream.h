
#ifndef __DWReadStream_FDINSTREAM_H__
#define __DWReadStream_FDINSTREAM_H__

#pragma once

#include "BaseStream.h"

namespace DWReadStream {

	class ReadStream : public BaseStream {

	public:

		ReadStream(int fd, int bufSize=0);
		virtual ~ReadStream();

		int readBytes(void* data, int length);

	protected:
		int overrun(int nItems);

	private:
		int SelectTimeout(int fd);
		int ReceiveData(void* buf, int len);

		int fd;
		void (*blockCallback)(void*);
		void* blockCallbackArg;

		int bufSize;
		int offset;
		BYTE* startPosition;
	};

}

#endif
