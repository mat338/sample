
#include "stdafx.h"
#include <stdio.h>
#include <string.h>
#include <errno.h>

#ifdef _WIN32
#include <winsock2.h>
#include <sys/timeb.h>
#define read(s,b,l) recv(s,(char*)b,l,0)
#undef errno
#define errno WSAGetLastError()

#else
#include <unistd.h>
#include <sys/time.h>
#endif

#ifdef _AIX
#include <sys/select.h>
#endif

#include "ReadStream.h"

using namespace DWReadStream;

enum {
	DEFAULT_BUF_SIZE = 8192,
	MIN_BULK_SIZE = 1024
};

ReadStream::ReadStream(int fd_, int bufSize_) : fd(fd_), blockCallback(0), blockCallbackArg(0), bufSize(bufSize_ ? bufSize_ : DEFAULT_BUF_SIZE), offset(0)
{
	nowPosition = endPosition = startPosition = new BYTE[bufSize];
}

ReadStream::~ReadStream()
{
	delete[] startPosition;
}


int ReadStream::readBytes(void* data, int length)
{
	if (length < MIN_BULK_SIZE)
	{
		int ret = BaseStream::ReadByteData(data, length);
		return ret;
	}

	BYTE* Pos = (BYTE*)data;

	int	n = endPosition - nowPosition;
	if (n > length) n = length;

	// select��������e���㏑�����Ă��܂��̂ŁA���񏉊������܂�
	memcpy(Pos, nowPosition, n);
	Pos += n;
	length -= n;
	nowPosition += n;

	while (length > 0) {
		n = ReceiveData(Pos, length);
		if (n <= 0) return n;
		Pos += n;
		length -= n;
		offset += n;
	}

	return n;
}


int ReadStream::overrun(int nItems)
{
	if (1 > bufSize) return -1;

	if (endPosition - nowPosition != 0)
		memmove(startPosition, nowPosition, endPosition - nowPosition);

	offset += nowPosition - startPosition;
	endPosition -= nowPosition - startPosition;
	nowPosition = startPosition;

	while (endPosition < startPosition + 1) {
		int n = ReceiveData((BYTE*)endPosition, startPosition + bufSize - endPosition);
		if (n <= 0) return n;
		endPosition += n;
	}

	if (nItems > endPosition - nowPosition)
		nItems = endPosition - nowPosition;

	return nItems;
}


int ReadStream::ReceiveData(void* buf, int len)
{
	if (fd == INVALID_SOCKET) return -1;

	int n = SelectTimeout(fd);
	if (n < 0)  return n; 
	if (n == 0)
	{
		if (blockCallback) (*blockCallback)(blockCallbackArg);
	}

	if (fd == INVALID_SOCKET) return -1;
	while (true)
	{
		if (fd == INVALID_SOCKET) return -1;

		n = ::read(fd, buf, len);
		if (n != -1 || errno != EINTR) break;
	}

	if (n <= 0)
	{
		int errorNo = WSAGetLastError();
		return -1 * errorNo;
	}
	return n;
}


int ReadStream::SelectTimeout(int fd)
{
	while (true) {
		struct timeval tv;
		fd_set fd_s;

		tv.tv_sec = 0;//(sec)�iSocket��Option�Ŏw�肵���^�C���A�E�g���Ԃɉ��Z����j
		tv.tv_usec = 0;//(timeout % 1000) * 1000;

		memset(&fd_s, 0, sizeof(fd_s));

		FD_ZERO(&fd_s);
		FD_SET(fd, &fd_s);

		// fd_s�ɐݒ肳�ꂽ�\�P�b�g���ǂݍ��݉\�ɂȂ�܂ő҂��܂�
		int n = select(fd + 1, &fd_s, NULL, NULL, &tv);
		if (n != -1 || errno != EINTR) 
			return n;
	}
}
