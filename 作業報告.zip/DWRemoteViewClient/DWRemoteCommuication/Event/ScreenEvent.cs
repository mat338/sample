﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Controls;
using System.Windows.Media.Imaging;
using System.ComponentModel;

namespace DWRemoteCommunication
{
    /*
     * イベント定義
     */
    /// <summary>Receive Screen</summary>
	public class ScreenUpdateEventArgs : EventArgs
	{
        /// <summary>コンストラクタ</summary>
        public ScreenUpdateEventArgs() { }

        /// <summary>Rects Data</summary>
		public List<Rectangle> Rects { get; set; }

	}
}
