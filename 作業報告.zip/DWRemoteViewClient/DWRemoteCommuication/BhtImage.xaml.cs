﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Threading;
using System.Windows.Threading;
using System.Runtime.InteropServices;

using System.Drawing;
using System.IO;
using System.Reflection;
using System.Diagnostics;
using System.Net;

namespace DWRemoteCommunication
{
	/// <summary>
	/// Interaction logic for BhtImg1.xaml
	/// </summary>
	public partial class BhtImage : IDisposable
    {
		private CommunicateClient _Connection;  // socketのコネクション
		private DateTime _LastMouseMove = DateTime.Now;
        private int _LastMouseClick = 0;
		private WriteableBitmap Bitmap;         // サーバから取得した画像データのbitmap作成

        // 接続設定画面入力項目
        private string _BhtID = "";         // The RemoteserverName
        private string _Host = "";          // The RemoteHost
        private int _ServerPort = 0;        // The Remoteserverport
		private string _ServerPassword = "";// The Remoteserverpassword
        private string _WindowRatio = "";   // The Window Resize Ratio
		private string _ActionMode = "";    // The Action Mode
        // ウィンドウサイズ
        private int _BhtStandardHeight = 0; // BHT1700の100%時の高さ（400）を基準とする（BHT1800_100% 640 → 400 = 62.5%）
        private int _Bht100PerHeight = 0;   // BHT100%時の高さ（BHT1700:400、BHT1800:640）
        private int _Bht100PerWidth = 0;    // BHT100%時の幅（BHT1700:240、BHT1800:360）

        private bool _FirstView = false;    // 初回表示有フラグ
        private bool ReSizeFlg = false;     // ウィンドウ枠リサイズ中フラグ
        private bool isIncr = true;         // isIncremental

        // 画像データUpdataイベント
        public delegate void UpdateScreenCallback(ScreenUpdateEventArgs newScreen);

		public DispatcherTimer tmrScreen;
        // ロック用オブジェクト
        private readonly object LockObjNewScreen = new object();

        // エラー
        private bool _Error = false;        // エラー
        private string _ErrorMessage = "";  // エラーメッセージ
        private int _ErrorType = Constants.ERROR_TYPE_NOTHING; // エラータイプ（0:エラーなし、1:入力エラー、2:接続エラー、3:切断エラー、4:強制切断）

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public BhtImage()
		{
            InitializeComponent();
        }

        /// <summary>
        /// 画面更新要求 定期実行
        /// </summary>
        /// <param name="sender">センダー(DispatcherTimer)</param>
        /// <param name="e">EventArgs</param>
        void TmrScreen_Tick(object sender, EventArgs e)
	{
            if (_Connection != null)
            {
                _Connection.refreshScreen(isIncr);
            }
    }

        #region Screen Update
        /// <summary>
        /// 画面更新イベント
        /// </summary>
        /// <param name="sender">センダー(DispatcherTimer)</param>
        /// <param name="e">EventArgs</param>
        private void _Connection_ScreenUpdate(object sender, ScreenUpdateEventArgs e)
		{
            // 接続がある場合
			if (_Connection != null && _Connection.IsConnected)
			{
                image1.Dispatcher.Invoke(new UpdateScreenCallback(UpdateImage), new object[] { e });
            }
        }

        /// <summary>
        /// Update the RemoteImage
        /// </summary>
        /// <param name="newScreen"></param>
        private void UpdateImage(ScreenUpdateEventArgs newScreens)
		{
            // 更新データがない場合
            if (newScreens.Rects.Count == 0)
            {
                return;
            }

            // 画像更新中はサーバーから送信された画像データの反映を行わない（差分データの破棄）
            if (ReSizeFlg)
            {
                // 差分データ破棄による全画面データ再取得（FramebufferUpdateRequest）
                isIncr = false;
                //Console.WriteLine("isIncr = false");
                return;
            }

            // Scale raito %
            int raito = 100;    // init 100%
            int.TryParse(_WindowRatio, out raito);

            // Init
            double resize_Width = this.Width;
            double resize_Height = this.Height;

            DateTime startTime = DateTime.Now;

            try
            {
                // 初回画像データ取得時
                if (Bitmap == null)
                {
                    _Bht100PerHeight = newScreens.Rects.First().Height;
                    _Bht100PerWidth = newScreens.Rects.First().Width;

                    double bhtRaito = 100.0;
                    // 基準の高さではない場合
                    if ((int)newScreens.Rects.First().Height != _BhtStandardHeight)
                    {
                        // BHT1800は100%の指定で62.5%に縮小する
                        bhtRaito = (double)_BhtStandardHeight / newScreens.Rects.First().Height * 100;
                    }
                    resize_Width = (int)(newScreens.Rects.First().Width * ((double)raito / 100) * (bhtRaito / 100) + 0.5);
                    resize_Height = (int)(newScreens.Rects.First().Height * ((double)raito / 100) * (bhtRaito / 100) + 0.5);

                    // Bitmapの初期化
                    Bitmap = new WriteableBitmap(
                        newScreens.Rects.First().Width, 
                        newScreens.Rects.First().Height, 
                        96, 
                        96, 
                        PixelFormats.Bgr32, 
                        null);

                    this.Width = resize_Width;
                    this.Height = resize_Height;

                    // 接続後、初回表示有フラグを設定
                    _FirstView = true;
                }

                // write pixel data
                foreach (var newScreen in newScreens.Rects)
                {
                    Bitmap.WritePixels(
                        new Int32Rect(0, 0, newScreen.Width, newScreen.Height),
                        newScreen.PixelData,
                        newScreen.Width * 4,    // 一行あたりのバイトサイズ
                        newScreen.PosX,
                        newScreen.PosY);
                }

                // WriteableBitmap To BitmapImage
                BitmapImage bi = ConvertWriteableBitmapToBitmapImage(Bitmap, resize_Width, resize_Height);
                if (bi != null)
                {
                    image1.Source = bi;
                    image1.InvalidateVisual();

                    isIncr = true;//受信成功（次回は差分データの取得）
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// Bitmap画像形式変換
        /// To BitmapImage From WriteableBitmap
        /// </summary>
        /// <param name="wbm">変換元WriteableBitmap</param>
        /// <param name="wsize">変換後の幅</param>
        /// <param name="hsize">変換後の高さ</param>
        /// <returns>変換後 BitmapImage</returns>
        private BitmapImage ConvertWriteableBitmapToBitmapImage(WriteableBitmap wbm, double wsize, double hsize)
        {
            BitmapImage image = new BitmapImage();
            try
            {
                using (MemoryStream stream = new MemoryStream())
                {
                    // PNG形式にエンコードする
                    PngBitmapEncoder encoder = new PngBitmapEncoder();
                    encoder.Frames.Add(BitmapFrame.Create(wbm));
                    encoder.Save(stream);

                    image.BeginInit();
                    image.CacheOption = BitmapCacheOption.OnLoad;
                    image.StreamSource = stream;
                    image.DecodePixelWidth = (int)wsize;
                    image.DecodePixelHeight = (int)hsize;
                    image.EndInit();
                    image.Freeze();
                }
            }
            catch (Exception)
            {
                return null;
            }
            return image;
        }
        #endregion

        #region Keyboard/Mouse handling

        /// <summary>
        /// sendData Special Keys
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BhtImg_PreviewKeyDown(object sender, KeyEventArgs e)
		{
            if (_Connection == null)
            {
                return;
            }
            // 動作モード
            switch (e.Key)
            {
                case Key.F6:
                    _ActionMode = Constants.ACTION_MODE_ASSISTANT;
                    break;
                case Key.F7:
                    _ActionMode = Constants.ACTION_MODE_DESKTOP;
                    break;
                case Key.F8:
                    _ActionMode = Constants.ACTION_MODE_VIEW;
                    break;
                default:
                    if (Constants.ACTION_MODE_VIEW.Equals(_ActionMode))
                        return;
                    break;
            }

            KeyCodeDictionary keyCodeDic = new KeyCodeDictionary();
            if (!keyCodeDic.loadNonSpecialKeyDictionary().Contains(e.Key))
			{
                _Connection.sendKey(e);
			}

        }

        /// <summary>
        /// sendData Special Keys
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BhtImg_PreviewKeyUp(object sender, KeyEventArgs e)
		{
            if (_Connection == null)
            {
                return;
            }
            if (Constants.ACTION_MODE_VIEW.Equals(_ActionMode))
            {
                return;
            }

            KeyCodeDictionary keyCodeDic = new KeyCodeDictionary();
            if (!keyCodeDic.loadNonSpecialKeyDictionary().Contains(e.Key))
			{
                _Connection.sendKey(e);
			}
		}

        /// <summary>
        /// sendData all typed Signes
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tbInsert_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (_Connection == null)
            {
                return;
            }
            if (Constants.ACTION_MODE_VIEW.Equals(_ActionMode))
            {
                return;
            }

            if (tbInput.Text.Length > 0)
            {
                string sign = tbInput.Text;
                tbInput.Clear();

                _Connection.sendSign(sign.ToCharArray()[0]);
            }
            else
            {
                // 入力値がない場合は何もしない
            }
        }

        /// <summary>
        /// Captures the Mouseclicks
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BhtImg_PreviewMouseDown(object sender, MouseButtonEventArgs e)
		{
            if (_Connection == null)
            {
                return;
            }
            if (Constants.ACTION_MODE_VIEW.Equals(_ActionMode))
            {
                return;
            }

            this.tbInput.Focus();
            handleMouseState(e);
		}

		/// <summary>
		/// Captures the Mouseclicks
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void BhtImg_PreviewMouseUp(object sender, MouseButtonEventArgs e)
		{
            if (_Connection == null)
            {
                return;
            }
            if (Constants.ACTION_MODE_VIEW.Equals(_ActionMode))
            {
                return;
            }

            handleMouseState(e);
		}

		/// <summary>
		/// sendData Mouse Movements to the Server
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void BhtImg_PreviewMouseMove(object sender, MouseEventArgs e)
		{
            if (_Connection == null)
            {
                return;
            }
            if (Constants.ACTION_MODE_VIEW.Equals(_ActionMode))
            {
                return;
            }

            handleMouseState(e);
		}

		/// <summary>
		/// Thats what to do, when a Mousebutton was clicked
		/// </summary>
		/// <param name="e"></param>
		private void handleMouseState(MouseEventArgs e)
		{
            if (_Connection == null)
            {
                return;
            }
            if (Constants.ACTION_MODE_VIEW.Equals(_ActionMode))
            {
                return;
            }

			byte buttonValue = 0;
            if (e.LeftButton == MouseButtonState.Pressed)
            {
                buttonValue = 1;
            }
            if (e.RightButton == MouseButtonState.Pressed)
            {
                buttonValue += 4;
            }
            if (e.MiddleButton == MouseButtonState.Pressed)
            {
                buttonValue += 2;
            }

            //Don't sendData, if there is no MouseClick and a Event was triggered less then 1/5 second before.
            if (_LastMouseClick == 0 && buttonValue == 0 && DateTime.Now.Subtract(_LastMouseMove).TotalMilliseconds < 200)
            {
                return;
            }

			_Connection.sendMouseClick(
					(UInt16)(e.GetPosition(tbInput).X / image1.ActualWidth * _Connection.Properties.FramebufferWidth + 1),
					(UInt16)(e.GetPosition(tbInput).Y / image1.ActualHeight * _Connection.Properties.FramebufferHeight + 1)
					, buttonValue);

			_LastMouseMove = DateTime.Now;
            _LastMouseClick = buttonValue;
        }
        #endregion

        #region Public Properties
        /// <summary>
        /// The BHT ID to join the Remoteserver
        /// </summary>
        public string BhtID
        {
            get { return (_BhtID); }
            set { _BhtID = value; }
        }

        /// <summary>
        /// The IP or Hostname of the Remoteserver
        /// </summary>
        public string Host
		{
            get { return (_Host); }
            set { _Host = value; }
		}

		/// <summary>
		/// The Port of the Remoteserver (Default: 5900)
		/// </summary>
		public int ServerPort
		{
            get { return (_ServerPort); }
            set
            {
				//Validate of port is valid
				if (value > 0 && value < 65536)
				{
					_ServerPort = value;
				}
			}
		}

		/// <summary>
		/// The Password to join the Server
		/// </summary>
		public string ServerPassword
		{
            get { return (_ServerPassword); }
            set { _ServerPassword = value; }
		}

        /// <summary>
        /// The Raito to Resize the Window
        /// </summary>
        public string WindowRatio
        {
            get { return (_WindowRatio); }
            set { _WindowRatio = value; }
        }

		/// <summary>
		/// The Mode to Action
		/// </summary>
		public string ActionMode
		{
            get { return (_ActionMode); }
            set { _ActionMode = value; }
		}

        /// <summary>
        /// 初回表示有フラグ
        /// </summary>
		public bool FirstView
        {
            get { return (_FirstView); }
            set { _FirstView = value; }
        }

        /// <summary>
        /// BHT端末を100%表示した際の基準
        /// </summary>
		public int BhtStandardHeight
        {
            get { return (_BhtStandardHeight); }
            set { _BhtStandardHeight = value; }
        }

        /// <summary>
        /// BHT端末を100%表示した際の高さ
        /// </summary>
		public int Bht100PerHeight
        {
            get { return (_Bht100PerHeight); }
        }

        /// <summary>
        /// BHT端末を100%表示した際の幅
        /// </summary>
        public int Bht100PerWidth
        {
            get { return (_Bht100PerWidth); }
        }

        /// <summary>
        /// Error
        /// </summary>
		public bool Error
        {
            get { return (_Error); }
            set { _Error = value; }
        }

        /// <summary>
        /// Error Message
        /// </summary>
		public string ErrorMessage
        {
            get { return (_ErrorMessage); }
            set { _ErrorMessage = value; }
        }

        /// <summary>
        /// Error Type
        /// </summary>
		public int ErrorType
        {
            get { return (_ErrorType); }
            set { _ErrorType = value; }
        }
#if logging
		/// <summary>
		/// How much logging should be done? None=Disable
		/// </summary>
		public Logtype LoggingLevel
		{
			get { return _LoggingLevel; }
			set { _LoggingLevel = value; }
		}

		/// <summary>
		/// Where should the log be saved?
		/// </summary>
		public string LoggingPath
		{
			get { return _LoggingPath; }
			set { _LoggingPath = value; }
		}
#endif
        #endregion

        #region Public Methods

        /// <summary>
        /// サーバ端末へ接続
        /// </summary>
        /// <returns>接続成功/失敗</returns>
        public void Connect(int Timeout, string SystemLogFilePath, Logtype SystemLogOutLebel, Dictionary<string, string> MessageDictionary)
		{
            // 接続中は再接続を行わない
            if (_Connection != null)
            {
                return;
            }

            // Create a connection
            _Connection = new CommunicateClient(_Host, _ServerPort, _ServerPassword, Timeout, SystemLogFilePath, SystemLogOutLebel, MessageDictionary);
            _Connection.ActionMode = _ActionMode;
            _Connection.Error = false;
            _Connection.ErrorMessage = "";
            _Connection.ErrorType = Constants.ERROR_TYPE_NOTHING;
            _Error = false;
            _ErrorMessage = "";
            _ErrorType = Constants.ERROR_TYPE_NOTHING;

            // Is Triggered when the Screen is beeing updated
            Bitmap = null;
            _Connection.ScreenUpdate += new CommunicateClient.ScreenUpdateEventHandler(_Connection_ScreenUpdate);

            // BHT接続
            _Connection.StartConnection();

            tmrScreen = new DispatcherTimer();
            // ToDo SendFramebufferUpdateRequest 処理間隔 50msec
            tmrScreen.Interval = new TimeSpan(0, 0, 0, 0, 50);
            tmrScreen.Tick += TmrScreen_Tick;
            tmrScreen.Start();
        }

        /// <summary>
        /// サーバ端末の切断接続
        /// </summary>
        public void DisConnect()
        {
            if (_Connection == null)
            {
                return;
            }

            if (_Connection.IsConnected)
            {
                _Connection.sendClose();
                _Connection.Disconnect();
            }
            _Connection = null;
        }

        /// <summary>
        /// The BHT ID to join the Remoteserver
        /// </summary>
        public bool IsConncted()
        {
            if (_Connection != null)
            {
                return _Connection.IsConnected;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// 特殊キー処理
        /// </summary>
        /// <param name="keyComb">特殊キー（PgUp、Home等）</param>
		public void SendKeyBHT(BHTKey keyComb)
		{
            // 切断されていた場合
            if (_Connection == null || !_Connection.IsConnected)
            {
                return;
            }

            // 動作モードの切替
            switch (keyComb)
            {
                case BHTKey.F6:
                    _ActionMode = Constants.ACTION_MODE_ASSISTANT;
                    break;
                case BHTKey.F7:
                    _ActionMode = Constants.ACTION_MODE_DESKTOP;
                    break;
                case BHTKey.F8:
                    _ActionMode = Constants.ACTION_MODE_VIEW;
                    break;
                default:
                    // 動作モードがViewモードの場合、モード切替以外ははじく
                    if (Constants.ACTION_MODE_VIEW.Equals(_ActionMode))
                    {
                        return;
                    }
                    break;
            }

            _Connection.sendKeyCombination(keyComb);
		}

        /// <summary>
        /// ウィンドウ枠リサイズに合わせた表示画像のリサイズ処理
        /// </summary>
        /// <param name="InitHeight">初期画像サイズ（高さ）</param>
        /// <param name="InitWidth">初期画像サイズ（幅）</param>
        /// <param name="NowPic">変更予定のの画像サイズ（高さ）</param>
        public void ResizeImage(double InitHeight, double InitWidth, double NowHeight)
        {
            // ウィンドウリサイズ中はサーバーから送信された画像データの反映を行わないようにする
            ReSizeFlg = true;
            try
            {
                this.Height = NowHeight;
                this.Width = InitWidth * NowHeight / InitHeight;

                // リサイズ画像の再生成
                BitmapImage bi = ConvertWriteableBitmapToBitmapImage(Bitmap, (int)this.Width, (int)NowHeight);
                if (bi != null)
                {
                    image1.Source = bi;
                    image1.InvalidateVisual();
                }
            }
            catch (Exception e)
            {
                System.Diagnostics.Debug.WriteLine("Exception:" + e.ToString());
            }
            finally
            {
                ReSizeFlg = false;
            }
        }
        
        /// <summary>
        /// エラー情報を取得 
        /// </summary>
        public void GetError()
        {
            if (_Connection != null)
            {
                if (!_Error && _Connection.Error)
                {
                    _Error = _Connection.Error;
                    _ErrorMessage = _Connection.ErrorMessage;
                    _ErrorType = _Connection.ErrorType;
                }

                // リセット
                if (_Connection.Error)
                {
                    DisConnect();
                }
                else
                {
                    // 強制切断の場合
                    if (_Connection.ErrorType == Constants.ERROR_TYPE_FORCE_DISCONNECT)
                    {
                        _ErrorMessage = _Connection.ErrorMessage;
                        _ErrorType = _Connection.ErrorType;
                    }
                }
            }
        }

        #endregion

        #region IDisposable Support
        private bool disposedValue = false; // 重複する呼び出しを検出するには

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    // TODO: マネージド状態を破棄します (マネージド オブジェクト)。
                    if (_Connection != null)
                    {
                        _Connection.Dispose();
                    }
                }

                // TODO: アンマネージド リソース (アンマネージド オブジェクト) を解放し、下のファイナライザーをオーバーライドします。
                // TODO: 大きなフィールドを null に設定します。

                disposedValue = true;
            }
        }

        // TODO: 上の Dispose(bool disposing) にアンマネージド リソースを解放するコードが含まれる場合にのみ、ファイナライザーをオーバーライドします。
        ~BhtImage()
        {
            // このコードを変更しないでください。クリーンアップ コードを上の Dispose(bool disposing) に記述します。
            Dispose(false);
        }

        // このコードは、破棄可能なパターンを正しく実装できるように追加されました。
        public void Dispose()
        {
            // このコードを変更しないでください。クリーンアップ コードを上の Dispose(bool disposing) に記述します。
            Dispose(true);
            // TODO: 上のファイナライザーがオーバーライドされる場合は、次の行のコメントを解除してください。
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}
