﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Threading;
using System.Windows.Input;
using System.Text.RegularExpressions;

namespace DWRemoteCommunication
{
    /*
     * 送信処理
     */
    internal class Send
    {
        private DWClientLibraryImpl _DataStream; //The Stream to read/write Data
        private ConnectionProperties _Properties;
        private SystemLog _sysLog;
        private bool _cryptFlag;
        private readonly object LockObjRequest = new object();
        private readonly object LockObjKeyEvent = new object();
        private readonly object LockObjSignEvent = new object();
        private readonly object LockObjPointerEvent = new object();
        private readonly object LockObjCloseEvent = new object();

        /// <summary>コンストラクタ</summary>
        /// <param name="DataStream">ソケット接続クラス</param>
        /// <param name="Properties">接続情報クラス</param>
        /// <param name="sysLog">システムログクラス</param>
        public Send(DWClientLibraryImpl DataStream, ConnectionProperties Properties, SystemLog sysLog, bool cryptFlag)
        {
            this._DataStream = DataStream;
            this._Properties = Properties;
            this._sysLog = sysLog;
            this._cryptFlag = cryptFlag;
        }

        /// <summary>
        /// SetPixelFormat
        /// </summary>
        /// <param name="pxFormat">ピクセルフォーマット</param>
        /// <param name="data">送信データ</param>
        /// <returns>送信結果</returns>
        public int SendPixelFormat(PixelFormat pxFormat, ref Byte[] data)
        {
            _sysLog.Log(Logtype.Information, "PixelFormat");

            data[0] = 0; //SetPixel
            pxFormat.getPixelFormat(_Properties.PxFormat.BigEndianFlag).CopyTo(data, 4);

            _sysLog.Log(Logtype.Debug, "Send:PixelFormat Write START:20byte");
            var ret = data.Take(1).Encrypt(_cryptFlag).Concat(data.Skip(1).Encrypt(_cryptFlag)).Write(0);
            _sysLog.Log(Logtype.Debug, "Send:PixelFormat Write END:");

            return ret;
        }

        /// <summary>
        /// SetEncodings
        /// </summary>
        /// <param name="data">送信データ</param>
        /// <returns>送信結果</returns>
        public int SendSetEncodings(ref Byte[] data)
        {
            //Contains the Details for the Encodings
            Dictionary<REncoding, EncodingDetails> EncodingDetails = new Dictionary<REncoding, EncodingDetails>();
            //Unsupported Encodings are in Comment
            EncodingDetails.Add(REncoding.Hextile_ENCODING, new EncodingDetails(5, "Hextile", 2));
            EncodingDetails.Add(REncoding.Raw_ENCODING, new EncodingDetails(0, "RAW", 255));
            _sysLog.Log(Logtype.Information, "Encoding (" + EncodingDetails.Count + ")");

            data[0] = 2;

            //sendData Count of Supported Encodings by this client
            Helper.ToByteArray((UInt16)EncodingDetails.Count, _Properties.PxFormat.BigEndianFlag).CopyTo(data, 2);

            _sysLog.Log(Logtype.Debug, "Send:Encodings Write START:[" + data[0] + data[1] + data[2] + data[3] + "]");
            int ret = data.Take(1).Encrypt(_cryptFlag).Concat(data.Skip(1).Encrypt(_cryptFlag)).Write(0);
            if (ret <= 0) return ret;

            //sendData Encoding Details for each supported Encoding
            foreach (KeyValuePair<REncoding, EncodingDetails> kvp in EncodingDetails)
            {
                Byte[] sendByte = Helper.ToByteArray(kvp.Value.Id, _Properties.PxFormat.BigEndianFlag);
                _sysLog.Log(Logtype.Debug, "Send:encoding-type Write START:[" + sendByte[0] + sendByte[1] + sendByte[2] + sendByte[3] + "]");
                ret = new Byte[4] { sendByte[0], sendByte[1], sendByte[2], sendByte[3] }
                            .Encrypt(_cryptFlag).Write(0);
                if (ret <= 0) return ret;
                _sysLog.Log(Logtype.Debug, "Send:encoding-type Write END:");
            }

            return ret;
        }

        /// <summary>
        /// SendFramebufferUpdateRequest
        /// </summary>
        /// <param name="isIncremental">画像データ領域フラグ</param>
        /// <param name="posX">Xポジション</param>
        /// <param name="posY">Yポジション</param>
        /// <param name="width">幅</param>
        /// <param name="height">高さ</param>
        /// <param name="data">送信データ</param>
        /// <returns>送信結果</returns>
        public int SendFramebufferUpdateRequest(bool isIncremental, UInt16 posX, UInt16 posY, UInt16 width, UInt16 height, ref Byte[] data)
        {
            lock (LockObjRequest)
            {
                _sysLog.Log(Logtype.Debug, "UpdRequest: I:" + isIncremental);

                data[0] = 3;
                data[1] = (Byte)(isIncremental ? 1 : 0);
                Helper.ToByteArray(posX, _Properties.PxFormat.BigEndianFlag).CopyTo(data, 2);
                Helper.ToByteArray(posY, _Properties.PxFormat.BigEndianFlag).CopyTo(data, 4);
                Helper.ToByteArray(width, _Properties.PxFormat.BigEndianFlag).CopyTo(data, 6);
                Helper.ToByteArray(height, _Properties.PxFormat.BigEndianFlag).CopyTo(data, 8);

                var ret = 1;
                try
                {
                    _sysLog.Log(Logtype.Debug, "Send:FramebufferUpdateRequest Write START:10byte[" + data[0] + data[1] + data[2] + data[3] + data[4] + data[5] + data[6] + data[7] + data[8] + data[9] + "]");
                    //var ret = _DataStream.WriteBeforeEncryptConcat(data.Take(1), data.Skip(1), 0, data.Length, cryptFlag);
                    ret = data.Take(1).Encrypt(_cryptFlag).Concat(data.Skip(1).Encrypt(_cryptFlag)).Write(0);
                    if (ret <= 0)
                    {
                        return ret;
                    }
                }
                catch (Exception e)
                {
                    _sysLog.Log(Logtype.Error, "Error on sendData a SendFramebufferUpdateRequest: " + e.ToString());
                }
                _sysLog.Log(Logtype.Debug, "Send:FramebufferUpdateRequest Write END:");

                return ret;
            }
        }

        /// <summary>
        /// SendKeyEvent
        /// </summary>
        /// <param name="e">押下キー</param>
        /// <param name="isDown">押下フラグ</param>
        /// <param name="data">送信データ</param>
        /// <returns>送信結果</returns>
        public int SendKeyEvent(Key e, bool isDown, ref Byte[] data)
        {
            lock (LockObjKeyEvent)
            {
                _sysLog.Log(Logtype.Information, "Key:" + e.ToString());

                UInt32 keyCode = 0;

                KeyCodeDictionary keyCodeDic = new KeyCodeDictionary();
                Dictionary<Key, UInt32> SpecialKeyDic = keyCodeDic.loadSpecialKeyDictionary();

                if (SpecialKeyDic.ContainsKey(e)) keyCode = SpecialKeyDic[e];
                if (keyCode == 0) //Was not a Special Sign
                {
                    //Get the Keycode
                    int key = KeyInterop.VirtualKeyFromKey(e);

                    //Get the related Char
                    char enteredChar = System.Text.Encoding.ASCII.GetChars(Helper.ToByteArray(key, true))[0];

                    //Offset for Keycode of pressed Sign
                    UInt32 offset = 0;

                    Regex rgExAZ = new Regex("[A-Z]"); //for A-Z and a-z
                    Regex rgEx09 = new Regex("[0-9]"); //For 0-9

                    #region Shift-Modifiers A-Z
                    if (rgExAZ.IsMatch(enteredChar.ToString())) //If it should be a small letter
                    {
                        if (Keyboard.Modifiers != ModifierKeys.Shift)
                        {
                            key += 32;
                            enteredChar = System.Text.Encoding.ASCII.GetChars(Helper.ToByteArray(key, true))[0];
                        }
                    }
                    #endregion

                    #region Shift-Modifiers 0-9
                    else if (rgEx09.IsMatch(enteredChar.ToString()) && Keyboard.Modifiers != ModifierKeys.Shift) //It is a number
                    {
                        //Do nothing
                    }
                    #endregion

                    #region Offset for unknown characters
                    else
                    {
                        offset = 0xFF00; //65280
                    }
                    #endregion
                    keyCode = (UInt32)key + offset;
                }

                data[0] = 4;

                //Press or Release the Key
                if (isDown == true)
                    data[1] = 1;
                else
                    data[1] = 0;

                Helper.ToByteArray(keyCode, _Properties.PxFormat.BigEndianFlag).CopyTo(data, 4);

                _sysLog.Log(Logtype.Debug, "Send:KeyEvent Write START:8byte[" + data[0] + data[1] + data[2] + data[3] + data[4] + data[5] + data[6] + data[7] + "]");
                var ret = data.Take(1).Encrypt(_cryptFlag).Concat(data.Skip(1).Encrypt(_cryptFlag)).Write(0);
                if (ret <= 0)
                {
                    return ret;
                }
                _sysLog.Log(Logtype.Debug, "Send:KeyEvent Write END:");

                return ret;
            }
        }

        /// <summary>
        /// SendSignEvent
        /// </summary>
        /// <param name="sign">送信文字列</param>
        /// <param name="_KeyCodes">送信対応キー定義</param>
        /// <param name="data">送信データ</param>
        /// <returns>送信結果</returns>
        public int SendSignEvent(char sign, Dictionary<char, UInt32> KeyCodes, ref Byte[] data)
        {
            lock (LockObjSignEvent)
            {

                _sysLog.Log(Logtype.Information, "Key:" + sign);

                data[0] = 4;
                //Press or Release the Key (currently defiend as released)
                data[1] = 1;

                var ret = 1;
                // Not「_KeyCodes」do nothing
                if (KeyCodes.ContainsKey(sign))
                {
                    Helper.ToByteArray(KeyCodes[sign], _Properties.PxFormat.BigEndianFlag).CopyTo(data, 4);

                    _sysLog.Log(Logtype.Debug, "Send:SignEvent Write START:8byte[" + data[0] + data[1] + data[2] + data[3] + data[4] + data[5] + data[6] + data[7] + "]");
                    ret = data.Take(1).Encrypt(_cryptFlag).Concat(data.Skip(1).Encrypt(_cryptFlag)).Write(0);
                    if (ret <= 0)
                    {
                        return ret;
                    }
                    _sysLog.Log(Logtype.Debug, "Send:SignEvent Write END:");
                }
                else
                {
                    // Do Nothing
                }

                return ret;
            }
        }

        /// <summary>
        /// SendPointerEvent
        /// </summary>
        /// <param name="posX">Xポジション</param>
        /// <param name="posY">Yポジション</param>
        /// <param name="ButtonMask">左右中ボタン識別</param>
        /// <param name="data">送信データ</param>
        /// <returns>送信結果</returns>
        public int SendPointerEvent(UInt16 posX, UInt16 posY, Byte ButtonMask, ref Byte[] data)
        {
            lock (LockObjPointerEvent)
            {
                _sysLog.Log(Logtype.Information, "Pointer: B:" + ButtonMask + ", X:" + posX + ", Y:" + posY);

                data[0] = 5;
                data[1] = ButtonMask;
                Helper.ToByteArray(posX, _Properties.PxFormat.BigEndianFlag).CopyTo(data, 2);
                Helper.ToByteArray(posY, _Properties.PxFormat.BigEndianFlag).CopyTo(data, 4);

                _sysLog.Log(Logtype.Debug, "Send:PointerEvent Write START:" + data[0] + data[0] + data[1] + data[2] + data[3] + data[4] + data[5]);
                var ret = data.Take(1).Encrypt(_cryptFlag).Concat(data.Skip(1).Encrypt(_cryptFlag)).Write(0);
                _sysLog.Log(Logtype.Debug, "Send:PointerEvent Write END:");

                return ret;
            }
        }

        /// <summary>
        /// SendCloseEvent
        /// </summary>
        /// <returns>送信結果</returns>
        public int SendCloseEvent(ref Byte[] data)
        {
            lock (LockObjCloseEvent)
            {
                _sysLog.Log(Logtype.Information, "Close:");

                data[0] = 255;

                _sysLog.Log(Logtype.Debug, "Send:CloseEvent Write START:" + data[0]);
                var ret = data.Encrypt(_cryptFlag).Write(0);
                _sysLog.Log(Logtype.Debug, "Send:CloseEvent Write END:");

                return ret;
            }
        }

    }
}
