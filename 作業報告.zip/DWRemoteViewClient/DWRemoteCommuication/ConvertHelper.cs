﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.Windows.Media.Imaging;
using System.IO;

namespace DWRemoteCommunication
{
    /*
     * Byte変換系Util
     */
    public class Helper
    {
        // Byte→UInt32変換
        public static UInt32 ToUInt32(byte[] data, bool isBigEndian)
        {
            if (isBigEndian == false)
                data = ReverseBytes(data);

            return(BitConverter.ToUInt32(data,0));
        }

        // Byte→UInt16変換
        public static UInt16 ToUInt16(byte[] data, bool isBigEndian)
        {
            if (isBigEndian == false)
                data = ReverseBytes(data);

            return (BitConverter.ToUInt16(data, 0));
        }

        // Byte→Int32変換
        public static Int32 ToInt32(byte[] data, bool isBigEndian)
        {
            if (isBigEndian == false)
                data = ReverseBytes(data);

            return (BitConverter.ToInt32(data, 0));
        }

        // UInt16→Byte変換
        public static Byte[] ToByteArray(UInt16 data, bool isBigEndian)
        {
            Byte[] ret = BitConverter.GetBytes(data);

            if (isBigEndian == false)
                ret = ReverseBytes(ret);
            
            return (ret);
        }

        // UInt32→Byte変換
        public static Byte[] ToByteArray(UInt32 data, bool isBigEndian)
        {
            Byte[] ret = BitConverter.GetBytes(data);

            if (isBigEndian == false)
                ret = ReverseBytes(ret);

            return (ret);
        }

        // Int32→Byte変換
        public static Byte[] ToByteArray(Int32 dataSigned, bool isBigEndian)
        {
            Byte[] ret = BitConverter.GetBytes(dataSigned);

            if (isBigEndian == false)
                ret = ReverseBytes(ret);

            return (ret);
        }

        // bool→Byte変換
        public static Byte[] ToByteArray(bool data)
        {
            return (BitConverter.GetBytes(data));
        }


        // ByteReverse変換
        private static byte[] ReverseBytes(byte[] inArray)
        {
            byte temp;
            int highCtr = inArray.Length - 1;

            for (int ctr = 0; ctr < inArray.Length / 2; ctr++)
            {
                temp = inArray[ctr];
                inArray[ctr] = inArray[highCtr];
                inArray[highCtr] = temp;
                highCtr -= 1;
            }
            return inArray;
        }
    }
}
