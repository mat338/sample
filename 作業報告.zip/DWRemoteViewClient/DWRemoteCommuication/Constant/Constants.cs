﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DWRemoteCommunication
{
    /*
     * 定数
     */
    public static class Constants
    {

        /* アプリ設定定義（setting.ini）*/
        public const string SETTING_INI_SECTION = "APP_SETTING";
        public const string SETTING_INI_KEY_CONNECT = "CONNECT";
        public const string SETTING_INI_KEY_ACCESS_LOG = "ACCESS_LOG";
        public const string SETTING_INI_KEY_SYSTEM_LOG = "SYSTEM_LOG";
        public const string SETTING_INI_KEY_STANDART = "BHT_STANDART_HEIGHT";
        public const string SETTING_INI_KEY_SYSLOG_LEVEL = "SYS_LOG_LEVEL";
        public const string SETTING_INI_KEY_RECONNECT_TIMEOUT = "RECONNECT_TIMEOUT";
        public const string SETTING_INI_KEY_RECEIVE_TIMEOUT = "RECEIVE_TIMEOUT";
        // ウィンドウサイズ（初期値）
        public const int HEIGHT_100_PERCENT = 400;   // BHT1700の100%時の高さ（400）を基準とする（BHT1800_100% 640 → 400 = 62.5%）

        /* 接続情報定義（connect.txt）*/
        public const string CONNECT_INFO_FILE_NAME = "connect.txt";
        public const string CONNECT_INFO_FILE_NAME_NOT_Extension = "connect";
        public const string CONNECT_INFO_KEY_BHT_ID = "BHT ID";
        public const string CONNECT_INFO_KEY_SERVER = "Server";
        public const string CONNECT_INFO_KEY_PORT = "Port";
        public const string CONNECT_INFO_KEY_PASSWORD = "Password";
        public const string CONNECT_INFO_KEY_RATIO = "Scale";
        public const string CONNECT_INFO_KEY_ACTIONMODE = "ActionMode";

        /* Readme */
        public const string README_FILE_NAME = "BHTRemote_Readme_";

        /* アクセス履歴ログ定義 */
        public const string LOGIN_HISTORY_FILE_PATH = ".\\access_log\\";

        /* システム履歴ログ定義 */
        public const string SYSTEM_LOG_FILE_PATH = ".\\system_log\\";
        public const string COMMAND_LOG_FILE_NAME = "Command_Error";
        public const string SYSTEM_LOG_FILE_NAME = "BHTRemote";
        public const string SYSTEM_LOG_FILE_EXTENSION = "log";

        /* タイムアウト（初期値）*/
        public const int TIMEOUT_RECONNECT_SEC = 120;
        public const int TIMEOUT_RECEIVE_SEC = 30;

        /* DNWA認証 */
        //public const string DNWA_AUTH = "Product Auth";
        //public const string DNWA_PASS = "DNWA";

        /* 動作モード */
        public const String ACTION_MODE_ASSISTANT = "ASSI";         // アシスタントモード
        public const String ACTION_MODE_ASSISTANT_NAME = "ASSISTANT";// アシスタントモード_表示名
        public const String ACTION_MODE_DESKTOP = "DESK";           // デスクトップモード
        public const String ACTION_MODE_DESKTOP_NAME = "DESKTOP";   // デスクトップモード_表示名
        public const String ACTION_MODE_VIEW = "VIEW";              // 閲覧モード
        public const String ACTION_MODE_VIEW_NAME = "VIEW";         // 閲覧モード_表示名

        // ERROR identification
        public const string ERROR_STRING_END_OF_STREAM = "EndOfStream";
        public const string ERROR_STRING_NET_DOWN = "NetDown";
        public const string ERROR_STRING_NET_REACH = "NetReach";
        public const string ERROR_STRING_NET_RESET = "NetReset";
        public const string ERROR_STRING_CONN_ABORTED = "ConnAborted";
        public const string ERROR_STRING_NO_BUFS = "Nobufs";
        public const string ERROR_STRING_TIME_OUT_ERROR = "TimeOutError";
        public const string ERROR_STRING_INCORRECT_DATA = "IncorrectData";

        // Error Type
        public const int ERROR_TYPE_NOTHING = 0;            //エラーなし
        public const int ERROR_TYPE_INPUT = 1;              //入力エラー
        public const int ERROR_TYPE_CONNECT = 2;            //接続エラー
        public const int ERROR_TYPE_DISCONNECT = 3;         //切断エラー
        public const int ERROR_TYPE_FORCE_DISCONNECT = 4;   //強制切断
    }
}
