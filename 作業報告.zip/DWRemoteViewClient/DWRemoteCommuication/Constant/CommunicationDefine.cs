﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DWRemoteCommunication
{
    /*
     * 通信(RFB)用定義
     */
    /// <summary>Server Message Type</summary>
    internal enum ServerMessageType
    {
        Unknown,
        FramebufferUpdate,      //0
        KeyChangeRequest,       //100
        KeepAlive,              //101
        SessionTimeOut,         //102
        ExclusiveConnectClose   //255
    }

    /// <summary>Client Message Type</summary>
    internal enum ClientMessageType
    {
        Unknown,
        SetPixelFormat, //0
        SetEncodings,   //2
        FramebufferUpdateRequest, //3
        KeyEvent,       //4
        PointerEvent    //5
    }

    /// <summary>Encoding</summary>
    internal enum REncoding
    {
		Hextile_ENCODING,   //1
		Raw_ENCODING        //16
    }

    /// <summary>Logtype</summary>
    public enum Logtype
    {
        Error = 6,
        Critical = 5,
        Warning = 4,
        Information = 3,
        Debug = 2,
        None = 1
    }
    /// <summary>BHT Key</summary>
    public enum BHTKey
    {
        PgUp,
        PgDn,
        End,
        Home,
        Insert,
        F2,
        F5,
        F6,
        F7,
        F8,
        F11,
        F12
    }
}
