﻿using System;
using System.Collections.Generic;
using System.Windows.Input;

namespace DWRemoteCommunication
{
    /*
     * 入力キー定義
     */
    internal class KeyCodeDictionary
    {

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public KeyCodeDictionary()
        {
        }

        /// <summary>
        /// Send KeyCode Dictionary
        /// Dictionary化した文字がクライアントから送信可能な文字となる
        /// </summary>
        /// <returns>KeyCodesDic</returns>
        public Dictionary<char, UInt32> loadKeyDictionary()
        {
            Dictionary<char, UInt32>  KeyCodesDic = new Dictionary<char, uint>();

            try
            {
                if (!KeyCodesDic.ContainsKey(' ')) KeyCodesDic.Add(' ', 32);
                if (!KeyCodesDic.ContainsKey('!')) KeyCodesDic.Add('!', 33);
                if (!KeyCodesDic.ContainsKey('"')) KeyCodesDic.Add('"', 34);
                if (!KeyCodesDic.ContainsKey('#')) KeyCodesDic.Add('#', 35);
                if (!KeyCodesDic.ContainsKey('$')) KeyCodesDic.Add('$', 36);
                if (!KeyCodesDic.ContainsKey('%')) KeyCodesDic.Add('%', 37);
                if (!KeyCodesDic.ContainsKey('&')) KeyCodesDic.Add('&', 38);
                if (!KeyCodesDic.ContainsKey('\'')) KeyCodesDic.Add('\'', 39);
                if (!KeyCodesDic.ContainsKey('(')) KeyCodesDic.Add('(', 40);
                if (!KeyCodesDic.ContainsKey(')')) KeyCodesDic.Add(')', 41);
                if (!KeyCodesDic.ContainsKey('*')) KeyCodesDic.Add('*', 42);
                if (!KeyCodesDic.ContainsKey('+')) KeyCodesDic.Add('+', 43);
                if (!KeyCodesDic.ContainsKey(',')) KeyCodesDic.Add(',', 44);
                if (!KeyCodesDic.ContainsKey('-')) KeyCodesDic.Add('-', 45);
                if (!KeyCodesDic.ContainsKey('.')) KeyCodesDic.Add('.', 46);
                if (!KeyCodesDic.ContainsKey('.')) KeyCodesDic.Add('.', 46);
                if (!KeyCodesDic.ContainsKey('/')) KeyCodesDic.Add('/', 47);
                if (!KeyCodesDic.ContainsKey('0')) KeyCodesDic.Add('0', 48);
                if (!KeyCodesDic.ContainsKey('1')) KeyCodesDic.Add('1', 49);
                if (!KeyCodesDic.ContainsKey('2')) KeyCodesDic.Add('2', 50);
                if (!KeyCodesDic.ContainsKey('3')) KeyCodesDic.Add('3', 51);
                if (!KeyCodesDic.ContainsKey('4')) KeyCodesDic.Add('4', 52);
                if (!KeyCodesDic.ContainsKey('5')) KeyCodesDic.Add('5', 53);
                if (!KeyCodesDic.ContainsKey('6')) KeyCodesDic.Add('6', 54);
                if (!KeyCodesDic.ContainsKey('7')) KeyCodesDic.Add('7', 55);
                if (!KeyCodesDic.ContainsKey('8')) KeyCodesDic.Add('8', 56);
                if (!KeyCodesDic.ContainsKey('9')) KeyCodesDic.Add('9', 57);
                if (!KeyCodesDic.ContainsKey(':')) KeyCodesDic.Add(':', 58);
                if (!KeyCodesDic.ContainsKey(';')) KeyCodesDic.Add(';', 59);
                if (!KeyCodesDic.ContainsKey('<')) KeyCodesDic.Add('<', 60);
                if (!KeyCodesDic.ContainsKey('=')) KeyCodesDic.Add('=', 61);
                if (!KeyCodesDic.ContainsKey('>')) KeyCodesDic.Add('>', 62);
                if (!KeyCodesDic.ContainsKey('?')) KeyCodesDic.Add('?', 63);
                if (!KeyCodesDic.ContainsKey('@')) KeyCodesDic.Add('@', 64);
                if (!KeyCodesDic.ContainsKey('A')) KeyCodesDic.Add('A', 65);
                if (!KeyCodesDic.ContainsKey('B')) KeyCodesDic.Add('B', 66);
                if (!KeyCodesDic.ContainsKey('C')) KeyCodesDic.Add('C', 67);
                if (!KeyCodesDic.ContainsKey('D')) KeyCodesDic.Add('D', 68);
                if (!KeyCodesDic.ContainsKey('E')) KeyCodesDic.Add('E', 69);
                if (!KeyCodesDic.ContainsKey('F')) KeyCodesDic.Add('F', 70);
                if (!KeyCodesDic.ContainsKey('G')) KeyCodesDic.Add('G', 71);
                if (!KeyCodesDic.ContainsKey('H')) KeyCodesDic.Add('H', 72);
                if (!KeyCodesDic.ContainsKey('I')) KeyCodesDic.Add('I', 73);
                if (!KeyCodesDic.ContainsKey('J')) KeyCodesDic.Add('J', 74);
                if (!KeyCodesDic.ContainsKey('K')) KeyCodesDic.Add('K', 75);
                if (!KeyCodesDic.ContainsKey('L')) KeyCodesDic.Add('L', 76);
                if (!KeyCodesDic.ContainsKey('M')) KeyCodesDic.Add('M', 77);
                if (!KeyCodesDic.ContainsKey('N')) KeyCodesDic.Add('N', 78);
                if (!KeyCodesDic.ContainsKey('O')) KeyCodesDic.Add('O', 79);
                if (!KeyCodesDic.ContainsKey('P')) KeyCodesDic.Add('P', 80);
                if (!KeyCodesDic.ContainsKey('Q')) KeyCodesDic.Add('Q', 81);
                if (!KeyCodesDic.ContainsKey('R')) KeyCodesDic.Add('R', 82);
                if (!KeyCodesDic.ContainsKey('S')) KeyCodesDic.Add('S', 83);
                if (!KeyCodesDic.ContainsKey('T')) KeyCodesDic.Add('T', 84);
                if (!KeyCodesDic.ContainsKey('U')) KeyCodesDic.Add('U', 85);
                if (!KeyCodesDic.ContainsKey('V')) KeyCodesDic.Add('V', 86);
                if (!KeyCodesDic.ContainsKey('W')) KeyCodesDic.Add('W', 87);
                if (!KeyCodesDic.ContainsKey('X')) KeyCodesDic.Add('X', 88);
                if (!KeyCodesDic.ContainsKey('Y')) KeyCodesDic.Add('Y', 89);
                if (!KeyCodesDic.ContainsKey('Z')) KeyCodesDic.Add('Z', 90);
                if (!KeyCodesDic.ContainsKey('[')) KeyCodesDic.Add('[', 91);
                if (!KeyCodesDic.ContainsKey('\\')) KeyCodesDic.Add('\\', 92);
                if (!KeyCodesDic.ContainsKey(']')) KeyCodesDic.Add(']', 93);
                if (!KeyCodesDic.ContainsKey('^')) KeyCodesDic.Add('^', 94);
                if (!KeyCodesDic.ContainsKey('_')) KeyCodesDic.Add('_', 95);
                if (!KeyCodesDic.ContainsKey('_')) KeyCodesDic.Add('_', 95);
                if (!KeyCodesDic.ContainsKey('`')) KeyCodesDic.Add('`', 96);
                if (!KeyCodesDic.ContainsKey('a')) KeyCodesDic.Add('a', 97);
                if (!KeyCodesDic.ContainsKey('b')) KeyCodesDic.Add('b', 98);
                if (!KeyCodesDic.ContainsKey('c')) KeyCodesDic.Add('c', 99);
                if (!KeyCodesDic.ContainsKey('d')) KeyCodesDic.Add('d', 100);
                if (!KeyCodesDic.ContainsKey('e')) KeyCodesDic.Add('e', 101);
                if (!KeyCodesDic.ContainsKey('f')) KeyCodesDic.Add('f', 102);
                if (!KeyCodesDic.ContainsKey('g')) KeyCodesDic.Add('g', 103);
                if (!KeyCodesDic.ContainsKey('h')) KeyCodesDic.Add('h', 104);
                if (!KeyCodesDic.ContainsKey('i')) KeyCodesDic.Add('i', 105);
                if (!KeyCodesDic.ContainsKey('j')) KeyCodesDic.Add('j', 106);
                if (!KeyCodesDic.ContainsKey('k')) KeyCodesDic.Add('k', 107);
                if (!KeyCodesDic.ContainsKey('l')) KeyCodesDic.Add('l', 108);
                if (!KeyCodesDic.ContainsKey('m')) KeyCodesDic.Add('m', 109);
                if (!KeyCodesDic.ContainsKey('n')) KeyCodesDic.Add('n', 110);
                if (!KeyCodesDic.ContainsKey('o')) KeyCodesDic.Add('o', 111);
                if (!KeyCodesDic.ContainsKey('p')) KeyCodesDic.Add('p', 112);
                if (!KeyCodesDic.ContainsKey('q')) KeyCodesDic.Add('q', 113);
                if (!KeyCodesDic.ContainsKey('r')) KeyCodesDic.Add('r', 114);
                if (!KeyCodesDic.ContainsKey('s')) KeyCodesDic.Add('s', 115);
                if (!KeyCodesDic.ContainsKey('t')) KeyCodesDic.Add('t', 116);
                if (!KeyCodesDic.ContainsKey('u')) KeyCodesDic.Add('u', 117);
                if (!KeyCodesDic.ContainsKey('v')) KeyCodesDic.Add('v', 118);
                if (!KeyCodesDic.ContainsKey('w')) KeyCodesDic.Add('w', 119);
                if (!KeyCodesDic.ContainsKey('x')) KeyCodesDic.Add('x', 120);
                if (!KeyCodesDic.ContainsKey('y')) KeyCodesDic.Add('y', 121);
                if (!KeyCodesDic.ContainsKey('z')) KeyCodesDic.Add('z', 122);
                if (!KeyCodesDic.ContainsKey('{')) KeyCodesDic.Add('{', 123);
                if (!KeyCodesDic.ContainsKey('|')) KeyCodesDic.Add('|', 124);
                if (!KeyCodesDic.ContainsKey('}')) KeyCodesDic.Add('}', 125);
                if (!KeyCodesDic.ContainsKey('~')) KeyCodesDic.Add('~', 126);
            }
            catch (Exception e)
            {
                throw new Exception("Be sure it is availabe! Error is " + e.ToString());
            }

            return KeyCodesDic;
        }

        /// <summary>
        /// Send Specialsigns KeyCode Dictionary
        /// </summary>
        /// <returns>Special Key Codes</returns>
        public Dictionary<Key, UInt32> loadSpecialKeyDictionary()
        {
            Dictionary<Key, UInt32> KeyCodesDic = new Dictionary<Key, uint>();

            try
            {
                if (!KeyCodesDic.ContainsKey(Key.LeftShift)) KeyCodesDic.Add(Key.LeftShift, 0x0000ffe1);
                if (!KeyCodesDic.ContainsKey(Key.Space)) KeyCodesDic.Add(Key.Space, 0x00000020);
                if (!KeyCodesDic.ContainsKey(Key.Tab)) KeyCodesDic.Add(Key.Tab, 0x0000FF09);
                if (!KeyCodesDic.ContainsKey(Key.Enter)) KeyCodesDic.Add(Key.Enter, 0x0000FF0D);
                if (!KeyCodesDic.ContainsKey(Key.Escape)) KeyCodesDic.Add(Key.Escape, 0x0000FF1B);
                if (!KeyCodesDic.ContainsKey(Key.Home)) KeyCodesDic.Add(Key.Home, 0x0000FF50);
                if (!KeyCodesDic.ContainsKey(Key.Left)) KeyCodesDic.Add(Key.Left, 0x0000FF51);
                if (!KeyCodesDic.ContainsKey(Key.Up)) KeyCodesDic.Add(Key.Up, 0x0000FF52);
                if (!KeyCodesDic.ContainsKey(Key.Right)) KeyCodesDic.Add(Key.Right, 0x0000FF53);
                if (!KeyCodesDic.ContainsKey(Key.Down)) KeyCodesDic.Add(Key.Down, 0x0000FF54);
                if (!KeyCodesDic.ContainsKey(Key.PageUp)) KeyCodesDic.Add(Key.PageUp, 0x0000FF55);
                if (!KeyCodesDic.ContainsKey(Key.PageDown)) KeyCodesDic.Add(Key.PageDown, 0x0000FF56);
                if (!KeyCodesDic.ContainsKey(Key.End)) KeyCodesDic.Add(Key.End, 0x0000FF57);
                if (!KeyCodesDic.ContainsKey(Key.Insert)) KeyCodesDic.Add(Key.Insert, 0x0000FF63);
                if (!KeyCodesDic.ContainsKey(Key.Delete)) KeyCodesDic.Add(Key.Delete, 0x0000FFFF);

                if (!KeyCodesDic.ContainsKey(Key.CapsLock)) KeyCodesDic.Add(Key.CapsLock, 0x0000FFE5);
                if (!KeyCodesDic.ContainsKey(Key.LeftAlt)) KeyCodesDic.Add(Key.LeftAlt, 0x0000FFE9);
                if (!KeyCodesDic.ContainsKey(Key.RightAlt)) KeyCodesDic.Add(Key.RightAlt, 0x0000FFEA);
                if (!KeyCodesDic.ContainsKey(Key.LeftCtrl)) KeyCodesDic.Add(Key.LeftCtrl, 0x0000FFE3);
                if (!KeyCodesDic.ContainsKey(Key.RightCtrl)) KeyCodesDic.Add(Key.RightCtrl, 0x0000FFE4);
                if (!KeyCodesDic.ContainsKey(Key.LWin)) KeyCodesDic.Add(Key.LWin, 0x0000FFEB);
                if (!KeyCodesDic.ContainsKey(Key.RWin)) KeyCodesDic.Add(Key.RWin, 0x0000FFEC);
                if (!KeyCodesDic.ContainsKey(Key.Apps)) KeyCodesDic.Add(Key.Apps, 0x0000FFEE);

                if (!KeyCodesDic.ContainsKey(Key.F1)) KeyCodesDic.Add(Key.F1, 0x0000FFBE);
                if (!KeyCodesDic.ContainsKey(Key.F2)) KeyCodesDic.Add(Key.F2, 0x0000FFBF);
                if (!KeyCodesDic.ContainsKey(Key.F3)) KeyCodesDic.Add(Key.F3, 0x0000FFC0);
                if (!KeyCodesDic.ContainsKey(Key.F4)) KeyCodesDic.Add(Key.F4, 0x0000FFC1);
                if (!KeyCodesDic.ContainsKey(Key.F5)) KeyCodesDic.Add(Key.F5, 0x0000FFC2);
                if (!KeyCodesDic.ContainsKey(Key.F6)) KeyCodesDic.Add(Key.F6, 0x0000FFC3);
                if (!KeyCodesDic.ContainsKey(Key.F7)) KeyCodesDic.Add(Key.F7, 0x0000FFC4);
                if (!KeyCodesDic.ContainsKey(Key.F8)) KeyCodesDic.Add(Key.F8, 0x0000FFC5);
                if (!KeyCodesDic.ContainsKey(Key.F9)) KeyCodesDic.Add(Key.F9, 0x0000FFC6);
                if (!KeyCodesDic.ContainsKey(Key.F10)) KeyCodesDic.Add(Key.F10, 0x0000FFC7);
                if (!KeyCodesDic.ContainsKey(Key.F11)) KeyCodesDic.Add(Key.F11, 0x0000FFC8);
                if (!KeyCodesDic.ContainsKey(Key.F12)) KeyCodesDic.Add(Key.F12, 0x0000FFC9);

                if (!KeyCodesDic.ContainsKey(Key.NumLock)) KeyCodesDic.Add(Key.NumLock, 0x0000FF7F);
                if (!KeyCodesDic.ContainsKey(Key.NumPad0)) KeyCodesDic.Add(Key.NumPad0, 0x0000FFB0);
                if (!KeyCodesDic.ContainsKey(Key.NumPad1)) KeyCodesDic.Add(Key.NumPad1, 0x0000FFB1);
                if (!KeyCodesDic.ContainsKey(Key.NumPad2)) KeyCodesDic.Add(Key.NumPad2, 0x0000FFB2);
                if (!KeyCodesDic.ContainsKey(Key.NumPad3)) KeyCodesDic.Add(Key.NumPad3, 0x0000FFB3);
                if (!KeyCodesDic.ContainsKey(Key.NumPad4)) KeyCodesDic.Add(Key.NumPad4, 0x0000FFB4);
                if (!KeyCodesDic.ContainsKey(Key.NumPad5)) KeyCodesDic.Add(Key.NumPad5, 0x0000FFB5);
                if (!KeyCodesDic.ContainsKey(Key.NumPad6)) KeyCodesDic.Add(Key.NumPad6, 0x0000FFB6);
                if (!KeyCodesDic.ContainsKey(Key.NumPad7)) KeyCodesDic.Add(Key.NumPad7, 0x0000FFB7);
                if (!KeyCodesDic.ContainsKey(Key.NumPad8)) KeyCodesDic.Add(Key.NumPad8, 0x0000FFB8);
                if (!KeyCodesDic.ContainsKey(Key.NumPad9)) KeyCodesDic.Add(Key.NumPad9, 0x0000FFB9);

            }
            catch (Exception e)
            {
                throw new Exception("Be sure it is availabe! Error is " + e.ToString());
            }

            return KeyCodesDic;
        }

        /// <summary>
        /// Send Specialsigns KeyCode Dictionary
        /// </summary>
        /// <returns>Special Key Codes</returns>
        public List<Key> loadNonSpecialKeyDictionary()
        {
            List<Key> KeyCodesDic = new List<Key>();

            try
            {
                KeyCodesDic.Add(Key.A);
                KeyCodesDic.Add(Key.B);
                KeyCodesDic.Add(Key.C);
                KeyCodesDic.Add(Key.D);
                KeyCodesDic.Add(Key.E);
                KeyCodesDic.Add(Key.F);
                KeyCodesDic.Add(Key.G);
                KeyCodesDic.Add(Key.H);
                KeyCodesDic.Add(Key.I);
                KeyCodesDic.Add(Key.J);
                KeyCodesDic.Add(Key.K);
                KeyCodesDic.Add(Key.L);
                KeyCodesDic.Add(Key.M);
                KeyCodesDic.Add(Key.N);
                KeyCodesDic.Add(Key.O);
                KeyCodesDic.Add(Key.P);
                KeyCodesDic.Add(Key.Q);
                KeyCodesDic.Add(Key.R);
                KeyCodesDic.Add(Key.S);
                KeyCodesDic.Add(Key.T);
                KeyCodesDic.Add(Key.U);
                KeyCodesDic.Add(Key.V);
                KeyCodesDic.Add(Key.W);
                KeyCodesDic.Add(Key.X);
                KeyCodesDic.Add(Key.Y);
                KeyCodesDic.Add(Key.Z);

                KeyCodesDic.Add(Key.D0);
                KeyCodesDic.Add(Key.D1);
                KeyCodesDic.Add(Key.D2);
                KeyCodesDic.Add(Key.D3);
                KeyCodesDic.Add(Key.D4);
                KeyCodesDic.Add(Key.D5);
                KeyCodesDic.Add(Key.D6);
                KeyCodesDic.Add(Key.D7);
                KeyCodesDic.Add(Key.D8);
                KeyCodesDic.Add(Key.D9);

                KeyCodesDic.Add(Key.Add);
                KeyCodesDic.Add(Key.Decimal);
                KeyCodesDic.Add(Key.Divide);
                KeyCodesDic.Add(Key.Multiply);
                KeyCodesDic.Add(Key.OemBackslash);
                KeyCodesDic.Add(Key.OemCloseBrackets);
                KeyCodesDic.Add(Key.OemComma);
                KeyCodesDic.Add(Key.OemMinus);
                KeyCodesDic.Add(Key.OemOpenBrackets);
                KeyCodesDic.Add(Key.OemPeriod);
                KeyCodesDic.Add(Key.OemPipe);
                KeyCodesDic.Add(Key.OemPlus);
                KeyCodesDic.Add(Key.OemQuestion);
                KeyCodesDic.Add(Key.OemQuotes);
                KeyCodesDic.Add(Key.OemSemicolon);
                KeyCodesDic.Add(Key.OemTilde);

                KeyCodesDic.Add(Key.NumPad0);
                KeyCodesDic.Add(Key.NumPad1);
                KeyCodesDic.Add(Key.NumPad2);
                KeyCodesDic.Add(Key.NumPad3);
                KeyCodesDic.Add(Key.NumPad4);
                KeyCodesDic.Add(Key.NumPad5);
                KeyCodesDic.Add(Key.NumPad6);
                KeyCodesDic.Add(Key.NumPad7);
                KeyCodesDic.Add(Key.NumPad8);
                KeyCodesDic.Add(Key.NumPad9);

            }
            catch (Exception e)
            {
                throw new Exception("Be sure it is availabe! Error is " + e.ToString());
            }

            return KeyCodesDic;
        }
    }
}