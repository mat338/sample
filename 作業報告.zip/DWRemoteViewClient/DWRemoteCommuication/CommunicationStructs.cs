﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Media;

namespace DWRemoteCommunication
{
    /*
     * 通信系構造体定義
     */
	internal class ConnectionProperties
	{
		private UInt16 _FramebufferWidth = 0;
		private UInt16 _FramebufferHeight = 0;
		private PixelFormat _PxFormat = new PixelFormat();
		private string _ConnectionName = "";
		private REncoding _EncodingType;

		private string _Server = "";
		private int _Port = 5901;
		private string _Password = "";
		private bool _SharedFlag = true;
        private int _Timeout = 0;


        #region Constructor(ConnectionProperties)

        /// <summary>コンストラクタ</summary>
		public ConnectionProperties()
		{
		}

        /// <summary>コンストラクタ</summary>
        /// <param name="server">IPアドレス</param>
        /// <param name="password">パスワード</param>
        /// <param name="port">ポート番号</param>
        /// <param name="timeout">レシーブタイムアウト</param>
		public ConnectionProperties(string server, string password, int port, int timeout)
		{
			Server = server;
			Password = password;
			Port = port;
            Timeout = timeout;
        }

        #endregion

        #region Public Properties(ConnectionProperties)

        /// <summary>Framebuffer Width</summary>
		public UInt16 FramebufferWidth
		{
			get { return (_FramebufferWidth); }
			set { _FramebufferWidth = value; }
		}

        /// <summary>Framebuffer Height</summary>
		public UInt16 FramebufferHeight
		{
			get { return (_FramebufferHeight); }
			set { _FramebufferHeight = value; }
		}

        /// <summary>Pixel Format</summary>
		public PixelFormat PxFormat
		{
			get { return (_PxFormat); }
			set { _PxFormat = value; }
		}

        /// <summary>Connection Name</summary>
		public string ConnectionName
		{
			get { return (_ConnectionName); }
			set { _ConnectionName = value; }
		}

        /// <summary>Encoding Type</summary>
		public REncoding EncodingType
		{
			get { return (_EncodingType); }
			set { _EncodingType = value; }
		}

        /// <summary>IP Address</summary>
		public string Server
		{
			get { return (_Server); }
			set { _Server = value; }
		}

        /// <summary>Port</summary>
		public int Port
		{
			get { return (_Port); }
			set { _Port = value; }
		}

        /// <summary>Password</summary>
		public string Password
		{
			get { return (_Password); }
			set { _Password = value; }
		}

        /// <summary>SharedFlag</summary>
		public bool SharedFlag
		{
			get { return (_SharedFlag); }
			set { _SharedFlag = value; }
		}

        /// <summary>Timeout</summary>
		public int Timeout
        {
            get { return (_Timeout); }
            set { _Timeout = value; }
        }

        #endregion
    }

    public class PixelFormat
	{
		private Byte _BitsPerPixel = 0;
		private Byte _Depth = 0;
		private Boolean _BigEndianFlag = false;
		private Boolean _TrueColourFlag = false;
		private UInt16 _RedMax = 0;
		private UInt16 _GreenMax = 0;
		private UInt16 _BlueMax = 0;
		private Byte _RedShift = 0;
		private Byte _GreenShift = 0;
		private Byte _BlueShift = 0;
		private Byte[] _Padding = new Byte[3];

        #region Constructor(PixelFormat)

       /// <summary>コンストラクタ</summary>
        public PixelFormat()
		{
		}

        /// <summary>コンストラクタ</summary>
        /// <param name="bpp">BitsPerPixel</param>
        /// <param name="dp">Depth</param>
        /// <param name="bef">BigEndianFlag</param>
        /// <param name="tcf">TrueColourFlag</param>
        /// <param name="rm">RedMax</param>
        /// <param name="gm">GreenMax</param>
        /// <param name="bm">BlueMax</param>
        /// <param name="rs">RedShift</param>
        /// <param name="gs">GreenShift</param>
        /// <param name="bs">BlueShift</param>
		public PixelFormat(Byte bpp, Byte dp, Boolean bef, Boolean tcf, UInt16 rm, UInt16 gm, UInt16 bm, Byte rs, Byte gs, Byte bs)
		{
			BitsPerPixel = bpp;
			Depth = dp;
			BigEndianFlag = bef;
			TrueColourFlag = tcf;
			RedMax = rm;
			GreenMax = gm;
			BlueMax = bm;
			RedShift = rs;
			GreenShift = gs;
			BlueShift = bs;
		}

        #endregion

        /// <summary>
        /// Get PixelFormat
        /// </summary>
        /// <param name="bigEndianFlag">ビッグエンディアン</param>
        /// <returns>PixelFormat</returns>
        public byte[] getPixelFormat(bool bigEndianFlag)
		{
			Byte[] ret = new Byte[16];
			ret[0] = BitsPerPixel;
			ret[1] = Depth;
			ret[2] = Helper.ToByteArray(BigEndianFlag)[0];
			ret[3] = Helper.ToByteArray(TrueColourFlag)[0];
			ret[4] = Helper.ToByteArray(RedMax, bigEndianFlag)[0];
			ret[5] = Helper.ToByteArray(RedMax, bigEndianFlag)[1];
			ret[6] = Helper.ToByteArray(GreenMax, bigEndianFlag)[0];
			ret[7] = Helper.ToByteArray(GreenMax, bigEndianFlag)[1];
			ret[8] = Helper.ToByteArray(BlueMax, bigEndianFlag)[0];
			ret[9] = Helper.ToByteArray(BlueMax, bigEndianFlag)[1];
			ret[10] = RedShift;
			ret[11] = GreenShift;
			ret[12] = BlueShift;
			ret[13] = Padding[0];
			ret[14] = Padding[1];
			ret[15] = Padding[2];

			return (ret);
		}

        #region Public Properties(PixelFormat)

        /// <summary>Bits Per Pixel</summary>
        public Byte BitsPerPixel
		{
			get { return (_BitsPerPixel); }
			set { _BitsPerPixel = value; }
		}

        /// <summary>Depth</summary>
		public Byte Depth
		{
			get { return (_Depth); }
			set { _Depth = value; }
		}

        /// <summary>Big Endian Flag</summary>
		public Boolean BigEndianFlag
		{
			get { return (_BigEndianFlag); }
			set { _BigEndianFlag = value; }
		}

        /// <summary>True Colour Flag</summary>
		public Boolean TrueColourFlag
		{
			get { return (_TrueColourFlag); }
			set { _TrueColourFlag = value; }
		}

        /// <summary>Red Max</summary>
		public UInt16 RedMax
		{
			get { return (_RedMax); }
			set { _RedMax = value; }
		}

        /// <summary>Green Max</summary>
		public UInt16 GreenMax
		{
			get { return (_GreenMax); }
			set { _GreenMax = value; }
		}

        /// <summary>Blue Max</summary>
		public UInt16 BlueMax
		{
			get { return (_BlueMax); }
			set { _BlueMax = value; }
		}

        /// <summary>Red Shift</summary>
		public Byte RedShift
		{
			get { return (_RedShift); }
			set { _RedShift = value; }
		}

        /// <summary>Green Shift</summary>
		public Byte GreenShift
		{
			get { return (_GreenShift); }
			set { _GreenShift = value; }
		}

        /// <summary>Blue Shift</summary>
		public Byte BlueShift
		{
			get { return (_BlueShift); }
			set { _BlueShift = value; }
		}

        /// <summary>Padding</summary>
		public Byte[] Padding
		{
			get { return (_Padding); }
			set
			{
				if (value.Length == 3)
					_Padding = value;
			}
		}

        #endregion
    }

    public class Rectangle
    {

        #region Constructor(Rectangle)

        /// <summary>コンストラクタ</summary>
        /// <param name="posX">X座標</param>
        /// <param name="posY">Y座標</param>
        /// <param name="width">幅</param>
        /// <param name="height">高さ</param>
        /// <param name="encodingType">エンコードタイプ</param>
        public Rectangle(UInt16 posX, UInt16 posY, UInt16 width, UInt16 height, Byte[] encodingType)
        {
            PosX = posX;
            PosY = posY;
            Width = width;
            Height = height;
            EncodingType = encodingType;
        }

        #endregion

        #region Public Properties(Rectangle)

        /// <summary>The Rectangle PosX</summary>
        public UInt16 PosX { get; set; }

        /// <summary>The Rectangle PosY</summary>
        public UInt16 PosY { get; set; }

        /// <summary>The Rectangle Width</summary>
        public UInt16 Width { get; set; }

        /// <summary>The Rectangle Height</summary>
        public UInt16 Height { get; set; }

        /// <summary>The Rectangle EncodingType</summary>
        public Byte[] EncodingType { get; set; }

        /// <summary>The Rectangle PixelData</summary>
        public Byte[] PixelData { get; set; }

        #endregion
    }

    public class EncodingDetails
	{
		private Int32 _Id = 0;
        //↓値をセットしているだけで未使用
		private string _Name = "";
		private UInt16 _Priority = 0;

        #region Constructor(EncodingDetails)

        /// <summary>コンストラクタ</summary>
        /// <param name="id">ID</param>
        /// <param name="name">NAME</param>
        /// <param name="prio">優先度</param>
        public EncodingDetails(Int32 id, string name, UInt16 prio)
		{
			Id = id;        //Hextile:5,Raw:0
            Name = name;    //Hextile:Hextile,Raw:Raw
            Priority = prio;//Hextile:2,Raw:255
        }

        #endregion

        #region Public Properties(EncodingDetails)

        /// <summary>The Encoding ID</summary>
        public Int32 Id
		{
			get { return (_Id); }
			set { _Id = value; }
		}

        /// <summary>The Encoding Name</summary>
		public string Name
		{
			get { return (_Name); }
			set { _Name = value; }
		}

        /// <summary>The Encoding Priority</summary>
		public UInt16 Priority
		{
			get { return (_Priority); }
			set { _Priority = value; }
		}

        #endregion
    }
}
