﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Sockets;
using System.Security.Cryptography;
using System.Windows.Input;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Controls;
using System.ComponentModel;
using System.Windows.Threading;
using System.Threading;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.IO;

namespace DWRemoteCommunication
{
    /*
     * 通信基幹処理
     */
    internal class CommunicateClient : IDisposable
    {
        // システムログ出力
        private SystemLog _SysLog;
        private DispatcherTimer tmrLog = new DispatcherTimer();

        // メッセージ
        private Dictionary<string, string> _MessageDictionary;

        private DWClientLibraryImpl _DataStream; //The Stream to read/write Data

        //Contains Properties of the Client
        private ConnectionProperties _Properties = new ConnectionProperties();
        //Dictionary for Key-Endcodings (see keys.csv)
        private Dictionary<char, UInt32> _KeyCodes;

        //The BackgroundWorkerthread for receiving Data
        private BackgroundWorker _Connect;
        private BackgroundWorker _Receiver;
        private Send _Send;

        // 最終リクエスト日時
        private DateTime _lastRequest = DateTime.Now;

        private bool _IsConnected = false; //Is the Client connected?
        private bool _IsFramebufferUpdateRequest = true; // true：Request、false：UnRequest
        private string _ActionMode = ""; // Action Mode

        // エラー
        private bool _Error = false;        // エラー有無フラグ
        private string _ErrorMessage = "";  // エラーメッセージ
        private int _ErrorType = Constants.ERROR_TYPE_NOTHING;  // エラータイプ（0:エラーなし、1:入力エラー、2:接続エラー、3:切断エラー、4:強制切断/セッションタイムアウト）

        private bool cryptFlag;

        #region Events
        public delegate void ScreenUpdateEventHandler(object sender, ScreenUpdateEventArgs e);
        public event ScreenUpdateEventHandler ScreenUpdate;
        #endregion

        #region Constructor

        /// <summary>
        /// コンストラクタ
        /// Start a new connection
        /// </summary>
        /// <param name="server">IPアドレス</param>
        /// <param name="port">ポート番号</param>
        /// <param name="password">パスワード</param>
        /// <param name="timeout">受信タイムアウト</param>
        /// <param name="SystemLogFilePath">システムログ出力先</param>
        /// <param name="SystemLogOutLevel">システムログ出力レベル</param>
        /// <param name="MsgDic">エラーメッセージディクショナリー</param>
        public CommunicateClient(string server, int port, string password, int timeout, string SystemLogFilePath, Logtype SystemLogOutLevel, Dictionary<string, string> MsgDic)
        {
            this._MessageDictionary = MsgDic;
            _SysLog = new SystemLog(server, port, SystemLogFilePath, Constants.SYSTEM_LOG_FILE_NAME, SystemLogOutLevel);
            if (PrepareConnection(server, port, password, timeout) == false)
            {
                _SysLog.Log(Logtype.Debug, "Connection to the Server " + Properties.Server + " failed.");
            }
        }

        /// <summary>
        /// Preprocessing for Start a new connection
        /// </summary>
        /// <param name="server"></param>
        /// <param name="port"></param>
        /// <param name="password"></param>
        /// <returns>成功/失敗</returns>
        private bool PrepareConnection(string server, int port, string password, int timeout)
        {
            // サーバSendキーの定義
            KeyCodeDictionary keyCodeDic = new KeyCodeDictionary();
            _KeyCodes = keyCodeDic.loadKeyDictionary();

            // アプリのシステムログ収集
            tmrLog.Tick += new EventHandler(tmrLog_Tick);
            tmrLog.Interval = new TimeSpan(0, 0, 0, 0, 20);
            tmrLog.Start();

            //Set the Server, Port, Password and Timeout Properties
            Properties = new ConnectionProperties(server, password, port, timeout);

            _SysLog.Log(Logtype.Information, "+++ Initialize new connection +++");

            return true;
        }
        #endregion

        #region Connect
        /// <summary>
        /// Starts the Receiverthread to wait for new Data from the Server
        /// 
        /// サーバへの接続を非同期で処理する
        /// </summary>
        private void StartServerConnect()
        {
            _Connect = new BackgroundWorker();
            _Connect.DoWork += new DoWorkEventHandler(InitializeConnect);
            _Connect.RunWorkerCompleted += new RunWorkerCompletedEventHandler(_Connect_RunWorkerCompleted);
            _Connect.RunWorkerAsync();
        }

        /// <summary>
        /// Authentication（DNWA）
        /// </summary>
        /// <returns>接続成功/失敗</returns>
        private void InitializeConnect(object sender, DoWorkEventArgs eWork)
        {
            _SysLog.Log(Logtype.Information, "Connecting to " + Properties.Server + ":" + Properties.Port);

            //Start the Connection to the Server
            if (Connect(Properties.Server, Properties.Port, Properties.Timeout) == false)
            {
                throw new Exception(LanguageConstantsNumber.ERROR_MESSAGE_SERVER_NOT_FOUND);
            }

            //Check out the DNWA of the Server
            Byte[] cryptMode = new byte[1];
            Byte[] timeout = new byte[4];// タイムアウト
            timeout = Helper.ToByteArray(Properties.Timeout, false);
            int ret = _DataStream.Authentication(_ActionMode, cryptMode, Properties.Password, timeout);
            if (ret < 0)
            {
                _SysLog.Log(Logtype.Warning, "ErrorNo[" + ret + "]");
                switch (ret)
                {
                    case -1://RSA初期化エラー
                    case -2://RSA初期ベクトル暗号化エラー
                    case -3://RSA鍵生成文字列暗号化エラー
                    case -14://動作モード送信エラー
                    case -15://動作モード受信エラー
                    case -16://タイムアウト送信エラー
                    case -17://タイムアウト受信エラー
                        throw new Exception(LanguageConstantsNumber.ERROR_MESSAGE_PRODUCT_INIT_FAIL);
                    case -4://サーバーバージョン(BHTRC-01.00)受信エラー
                    case -5://サーバーバージョン(BHTRC-01.00)チェックエラー
                    case -6://クライアントバージョンの送信エラー
                    case -7://クライアントバージョンの判定エラー
                        throw new Exception(LanguageConstantsNumber.ERROR_MESSAGE_PRODUCT_CHECK_FAIL);
                    case -8://Challenge Code受信エラー
                    case -9://Challenge Code暗号化エラー
                    case -10://Challenge Code暗号化送信エラー
                    case -11://Challenge Code暗号化認証エラー
                    case -13://Challenge Code暗号化認証エラー内容受信エラー
                        throw new Exception(LanguageConstantsNumber.ERROR_MESSAGE_PASSWORD_CHECK);
                    case -20://不明
                    default:
                        throw new Exception(LanguageConstantsNumber.ERROR_MESSAGE_PRODUCT_INIT_FAIL);
                }
            }

            // Communication Encrypt Mode(DNWA only)
            if (49 == cryptMode[0])
            {
                cryptFlag = true;
            }
            else
            {
                cryptFlag = false;
            }
            //cryptFlag = false;

            //Do ClientInit
            //共有化することがないため未使用.
            if (!SendClientSharedFlag())
            {
                throw new Exception(LanguageConstantsNumber.ERROR_MESSAGE_PRODUCT_INIT_FAIL);
            }
            //Receive ServerInit
            if (!ReceiveServerInit())
            {
                throw new Exception(LanguageConstantsNumber.ERROR_MESSAGE_PRODUCT_INIT_FAIL);
            }

            _Send = new Send(_DataStream, Properties, _SysLog, cryptFlag);
            //Set the PixelFormat; Currently the only working Format
            if (!SendSetPixelFormat(new PixelFormat(32, 24, false, true, 255, 255, 255, 16, 8, 0)))
            //if (!SendSetPixelFormat(new PixelFormat(16, 16, false, true, 63, 31, 31, 0, 6, 11)))
            //if (!SendSetPixelFormat(new PixelFormat(8, 8, false, true, 7, 7, 3, 0, 3, 6)))
            {
                throw new Exception(LanguageConstantsNumber.ERROR_MESSAGE_PRODUCT_INIT_FAIL);
            }
            //Currently only RAW is supported
            if (!SendSetEncodings())
            {
                throw new Exception(LanguageConstantsNumber.ERROR_MESSAGE_PRODUCT_INIT_FAIL);
            }

            _IsConnected = true;
            _IsFramebufferUpdateRequest = false;

            SendFramebufferUpdateRequest(false, 0, 0, _Properties.FramebufferWidth, _Properties.FramebufferHeight);
        }

        /// <summary>
        /// Triggers the Thread for RunWorkerCompleted
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e">The Color/Pixel-Information</param>
        void _Connect_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            // エラー発生時
            if (e.Error != null)
            {
                string errorType = e.Error.Message;
                string errorMsg;
                // システムログ出力―メッセージ
                switch (errorType)
                {
                    case LanguageConstantsNumber.ERROR_MESSAGE_SERVER_NOT_FOUND:
                        errorMsg = "Connect failed:[" + Properties.Server + "::" + Properties.Port + "]";
                        break;
                    case LanguageConstantsNumber.ERROR_MESSAGE_PRODUCT_INIT_FAIL:
                        errorMsg = "DNWA Authentication Error: " + LanguageConstantsNumber.ERROR_MESSAGE_PRODUCT_INIT_FAIL;
                        break;
                    case LanguageConstantsNumber.ERROR_MESSAGE_PRODUCT_CHECK_FAIL:
                        errorMsg = "DNWA Authentication Error: " + LanguageConstantsNumber.ERROR_MESSAGE_PRODUCT_CHECK_FAIL;
                        break;
                    case LanguageConstantsNumber.ERROR_MESSAGE_PASSWORD_CHECK:
                        errorMsg = "DNWA Authentication Error: " + LanguageConstantsNumber.ERROR_MESSAGE_PASSWORD_CHECK;
                        break;
                    default:
                        errorMsg = "DNWA Authentication Error:";
                        break;
                }

                // エラー処理
                connectErrorLog(3, errorType, Logtype.Warning, errorMsg, true);

                if (_Connect != null)
                {
                    BackgroundWorker _Connect = sender as BackgroundWorker;
                    _Connect.DoWork -= new DoWorkEventHandler(InitializeConnect);
                    _Connect.Dispose();
                }
            }
            // 成功時
            else
            {
                // 受信処理を別スレッド化
                StartServerListener();
            }
        }

        /// <summary>
        /// Start the Connection to the Server
        /// </summary>
        /// <param name="server">The IP or Hostname of the Server</param>
        /// <param name="port">The Port of the Server</param>
        /// <param name="timeout">Recive Timeout</param>
        /// <returns></returns>
        private bool Connect(String server, int port, int timeout)
        {
            try
            {
                //Get a client stream for reading and writing.
                _DataStream = new DWClientLibraryImpl(server, port, "", timeout, _SysLog);
                return (_DataStream.Connect());
            }
            catch (SocketException se)
            {
                _SysLog.Log(Logtype.Warning, "SocketException:" + se.ToString());
            }
            catch (Exception e)
            {
                _SysLog.Log(Logtype.Error, "Exception:" + e.ToString());
            }

            _DataStream = null;
            return false;
        }
        #endregion

        #region Initialisation
        /// <summary>
        /// Sends the SharedFlag to the Server (sse. 6.3.1)
        /// 
        /// サーバーが他のクライアントを接続したままにすることでデスクトップの共有を試みるべき場合、shared-flag は非ゼロ(真)になる。
        /// 他のクライアントをすべて切断することでこのクライアントに排他的アクセスを与えるべき場合、ゼロ(偽)になる。
        /// 
        /// バイト数     | 型      [値] | 説明
        /// -------------+--------------+------------
        /// 1            | U8           | shared-flag
        /// </summary>
        //共有することがないため未使用.
        private bool SendClientSharedFlag()
        {
            _SysLog.Log(Logtype.Information, "SharedFlag(ClientInit)");

            try
            {
                //sendData the Shared-Flag (ClientInit)
                Byte[] sharedFlag = new Byte[1] { Properties.SharedFlag ? (byte)1 : (byte)0 };
                _SysLog.Log(Logtype.Debug, "Send:Shared-Flag (ClientInit) Write START:" + sharedFlag[0]);
                _DataStream.Write(sharedFlag, 0, sharedFlag.Length); //sendData the SharedFlag

                return true;
            }
            catch (Exception e)
            {
                connectErrorLog(2, LanguageConstantsNumber.ERROR_MESSAGE_PRODUCT_CHECK_FAIL, Logtype.Error, "SendClientSharedFlag failed: " + e.ToString(), true);
                return false;
            }
        }

        /// <summary>
        /// Receive the ServerInit (see 6.3.2)
        /// 
        /// サーバーは ClientInit メッセージを受信した後、ServerInit メッセージをSendする。
        /// これはクライアントに、サーバーのフレームバッファの幅と高さ、ピクセルフォーマット、デスクトップに関連付けられた名前を伝える
        /// 
        /// バイト数     | 型              [値] | 説明
        /// -------------+----------------------+------------
        /// 2            | U16                  | framebuffer-width
        /// 2            | U16                  | framebuffer-height
        /// 16           | PIXEL_FORMAT         | server-pixel-format
        /// 4            | U32                  | name-length
        /// name-length  | U8 array             | name-string
        /// 
        /// PIXEL_FORMAT
        /// バイト数     | 型      [値] | 説明
        /// -------------+--------------+------------
        /// 1            | U8           | bits-per-pixel
        /// 1            | U8           | depth
        /// 1            | U8           | big-endian-flag
        /// 1            | U8           | true-colour-flag
        /// 2            | U16          | red-max
        /// 2            | U16          | green-max
        /// 2            | U16          | blue-max
        /// 1            | U8           | red-shift
        /// 1            | U8           | green-shift
        /// 1            | U8           | blue-shift
        /// 3            |              | padding
        /// 
        /// Server-pixel-format はサーバーの持つ本来のピクセルフォーマットを表す。
        /// クライアントが SetPixelFormat メッセージ(セクション 6.4.1)によって別のフォーマットを要求しない限り、このピクセルフォーマットが使用されることになる。
        /// bits-per-pixel は各ピクセル値に使用されるビット数である。これは、ピクセル値のうちの有効なビット数である depth 以上でなければならない。
        /// 今のところ bits-per-pixel は 8 または 16 または 32 でなければならない(8 ビット未満のピクセル値はまだサポートされていない)。
        /// マルチバイトのピクセルがビッグエンティアンとして解釈される場合、big-endian-flag は非ゼロ(真)になる。当然ながら、bits-per-pixel が 8 の場合にはこのフラグは意味を持たない。
        /// 
        /// true-colour-flag が非ゼロ(真)の場合、続く 6 項目は、赤・緑・青の強さをピクセル値から抽出する方法を表す。red-max は赤の最大値(= 2n - 1 (n は赤に使用されるビット数))である。
        /// この値は常にビッグエンディアンであることに注意してほしい。
        /// red-shift は、ピクセル内の赤の値を最下位ビットに取得するのため必要なシフト数である。
        /// green-max ・ green-shift および blue-max ・ blue-shift は、緑・青のための同様の値である。
        /// </summary>
        private bool ReceiveServerInit()
        {
            try
            {
                _SysLog.Log(Logtype.Information, "Receive Server Initialisation Parameter");

                int[] sizebuff = new int[] { 2, 2, 1, 1, 1, 1, 2, 2, 2, 1, 1, 1, 3, 4 };
                byte[] data = new byte[24];
                int index = 0;
                _DataStream.ReadAfterDecrypt(data, 0, data.Length, cryptFlag);
                byte[][] databuff = new byte[sizebuff.Length][];

                for (int i = 0; i < sizebuff.Length; i++)
                {
                    databuff[i] = data.Skip(index).Take(sizebuff[i]).ToArray();
                    index += sizebuff[i];
                }

                //Receive the ServerInit
                //Framebuffer Width
                Properties.FramebufferWidth = Helper.ToUInt16(databuff[0],false);

                //Framebuffer Height
                Properties.FramebufferHeight = Helper.ToUInt16(databuff[1], false);

                //Set how many byte a Row have
                //_BackBuffer2RawStride = (Properties.FramebufferWidth * _BackBuffer2PixelFormat.BitsPerPixel + 7) / 8;

                //Initialize the Backend-Backbuffer with the correct size
                //_BackBuffer2PixelData = new byte[_BackBuffer2RawStride * Properties.FramebufferHeight];

                //Server Pixel Format
                _SysLog.Log(Logtype.Debug, "Read:PIXEL_FORMAT (ServerInit) Read START:");
                PixelFormat newPxf = new PixelFormat(databuff[2].First(),
                                                     databuff[3].First(),
                                                     true == Convert.ToBoolean(databuff[4].First()),
                                                     true == Convert.ToBoolean(databuff[5].First()),
                                                     Helper.ToUInt16(databuff[6], false),
                                                     Helper.ToUInt16(databuff[7].ToArray(), false),
                                                     Helper.ToUInt16(databuff[8], false),
                                                     databuff[9].First(),
                                                     databuff[10].First(),
                                                     databuff[11].First());

                Properties.PxFormat = newPxf;

                //Name Lenght
                UInt32 nameLenght = Helper.ToUInt32(databuff[13],false);

                //Name String
                Byte[] recData = new Byte[nameLenght];
                int bytes = _DataStream.ReadAfterDecrypt(recData, 0, recData.Length,cryptFlag);
                Properties.ConnectionName = System.Text.Encoding.ASCII.GetString(recData, 0, recData.Length);
                recData = null;

                _SysLog.Log(Logtype.Debug, "Read:Server Initialisationparameter Received. w:" + Properties.FramebufferWidth + " h:" + Properties.FramebufferHeight +
                                   " bbp:" + Properties.PxFormat.BitsPerPixel + " dep:" + Properties.PxFormat.Depth + " big:" + Properties.PxFormat.BigEndianFlag +
                                   " true:" + Properties.PxFormat.TrueColourFlag + " rmax:" + Properties.PxFormat.RedMax + " gmax:" + Properties.PxFormat.GreenMax +
                                   " bmax:" + Properties.PxFormat.BlueMax + " rsh:" + Properties.PxFormat.RedShift + " gsh:" + Properties.PxFormat.GreenShift +
                                   " bsh:" + Properties.PxFormat.BlueShift + " Remotename: " + Properties.ConnectionName);

                _DataStream.SetServerInitMsg(Properties);

                _SysLog.Log(Logtype.Information, "--- Server Initialisation END ---");
                return true;
            }
            catch (Exception e)
            {
                connectErrorLog(2, LanguageConstantsNumber.ERROR_MESSAGE_SERVER_DISCONNECTED, Logtype.Error, "Error during receiving ServerInit:" + e.ToString(), true);
                return false;
            }
        }
        #endregion

        #region Receive

        /// <summary>
        /// Starts the Receiverthread to wait for new Data from the Server
        /// 
        /// サーバからの受信を非同期で処理する
        /// </summary>
        private void StartServerListener()
        {
            _Receiver = new BackgroundWorker();
            _Receiver.WorkerReportsProgress = true;
            _Receiver.DoWork += new DoWorkEventHandler(Receiver);
            _Receiver.ProgressChanged += new ProgressChangedEventHandler(_Receiver_ProgressChanged);
            _Receiver.RunWorkerCompleted += new RunWorkerCompletedEventHandler(_Receiver_RunWorkerCompleted);
            _Receiver.RunWorkerAsync();
        }

        /// <summary>
        /// Triggers the Thread for RunWorkerCompleted
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e">The Color/Pixel-Information</param>
        void _Receiver_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Error != null)
            {
                string errorType = e.Error.Message;
                string errorMsg;
                Console.WriteLine("errorType:" + errorType);
                // エラーメッセージ
                switch (errorType)
                {
                    case Constants.ERROR_STRING_END_OF_STREAM:
                        errorMsg = LanguageConstantsNumber.ERROR_MESSAGE_SERVER_DISCONNECTED;
                        break;
                    case Constants.ERROR_STRING_NET_DOWN:
                        errorMsg = LanguageConstantsNumber.ERROR_MESSAGE_NET_DOWN;
                        break;
                    case Constants.ERROR_STRING_NET_RESET:
                        errorMsg = LanguageConstantsNumber.ERROR_MESSAGE_NET_RESET;
                        break;
                    case Constants.ERROR_STRING_CONN_ABORTED:
                        errorMsg = LanguageConstantsNumber.ERROR_MESSAGE_CON_ABORTED;
                        break;
                    case Constants.ERROR_STRING_NO_BUFS:
                        errorMsg = LanguageConstantsNumber.ERROR_MESSAGE_NO_BUFS;
                        break;
                    case Constants.ERROR_STRING_TIME_OUT_ERROR:
                        errorMsg = LanguageConstantsNumber.ERROR_MESSAGE_TIME_OUT_ERROR;
                        break;
                    case Constants.ERROR_STRING_INCORRECT_DATA:
                        errorMsg = LanguageConstantsNumber.ERROR_MESSAGE_CON_ABORTED;
                        break;
                    default:
                        errorMsg = LanguageConstantsNumber.ERROR_MESSAGE_SERVER_DISCONNECTED;
                        break;
                }

                if (_Receiver != null)
                {
	                BackgroundWorker _Receiver = sender as BackgroundWorker;
	                _Receiver.RunWorkerCompleted -= new RunWorkerCompletedEventHandler(_Receiver_RunWorkerCompleted);
	                _Receiver.DoWork -= new DoWorkEventHandler(Receiver);
	                _Receiver.Dispose();
                }

                connectErrorLog(3, errorMsg, Logtype.Warning, "Receive Error:" + errorType, true);
            }
        }

        /// <summary>
        /// Triggers the Thread for Backbufferchanges
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e">The Color/Pixel-Information</param>
        void _Receiver_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            //Create Thread for running Backbuffer-Update
            Thread th = new Thread(_Receiver_ProgressThread);
            th.Priority = ThreadPriority.BelowNormal;
            th.Start(e.UserState);
        }

        /// <summary>
        /// The Thread to update the Backbuffer
        /// </summary>
        /// <param name="objChangeData"></param>
        void _Receiver_ProgressThread(object objChangeData)
        {
            try
            {
                var changeDatas = (List<Rectangle>)objChangeData; //Parse Update-Data

                if (ScreenUpdate != null)
                {
                    ScreenUpdate(this, new ScreenUpdateEventArgs() { Rects = changeDatas, });
                }
            }
            catch (Exception e)
            {
                _SysLog.Log(Logtype.Error, e.ToString());
            }
        }

        /// <summary>
        /// Waits for Data from the Server
        /// </summary>
        private void Receiver(object sender, DoWorkEventArgs eWork)
		{
            if (_DataStream == null || !_IsConnected)
            {
                return;
            }

            Receiver receiver = new Receiver(_DataStream, _Properties, _SysLog, cryptFlag);

            DateTime rec;
            while (_IsConnected) //Wait for ServerMessages until the Client (or Server) wants to disconnect
            {
                // 受信処理開始と同時にサーバへリクエストを行う
                _IsFramebufferUpdateRequest = false;

                rec = DateTime.Now;
                _SysLog.Log(Logtype.Debug, "Read:Receiving Process Start:[" + rec + "]");
                ServerMessageType srvMsg = receiver.GetServerMessageType();
                _SysLog.Log(Logtype.Debug, "Read:GetServerMessageType Difference:[" + DateTime.Now.Subtract(rec) + "]");
                switch (srvMsg)
                {
                    // 未定義
                    default:
                        _SysLog.Log(Logtype.Error, "Receive unsupported Messagetype");
                        throw new Exception(Constants.ERROR_STRING_INCORRECT_DATA);
                    // Unknown
                    case ServerMessageType.Unknown:
                        _SysLog.Log(Logtype.Error, "Receive unknown Messagetype");
                        throw new Exception(Constants.ERROR_STRING_INCORRECT_DATA);
                    // 画像データ受信
                    case ServerMessageType.FramebufferUpdate:
                        _SysLog.Log(Logtype.Debug, "Receive buffUpdate");
                        var rects = receiver.ReceiveFramebufferUpdate();

                        UInt32 encrNr = Helper.ToUInt32(rects[0].EncodingType, _Properties.PxFormat.BigEndianFlag);
                        // Pseudo DesktopSize Request new Screen
                        if (encrNr == 4294967073)
                        {
                            SendFramebufferUpdateRequest(true, 0, 0, rects[0].Width, rects[0].Height);
                        }

                        // 画像データの受信完了（進捗を進める）
                        _Receiver.ReportProgress((int)srvMsg, rects);
                        _SysLog.Log(Logtype.Debug, "Read:FramebufferUpdate Difference:[" + DateTime.Now.Subtract(rec) + "]");
                        break;
                    // 切断要求受信.
                    case ServerMessageType.ExclusiveConnectClose:
                        _SysLog.Log(Logtype.Information, "Receive ConnectClose");
                        Disconnect();
                        _ErrorMessage = LanguageConstantsNumber.ERROR_MESSAGE_FORCED_DISCONNECTED + ":" + Environment.NewLine + 
                                        _MessageDictionary[LanguageConstantsNumber.ERROR_MESSAGE_FORCED_DISCONNECTED];
                        _ErrorType = Constants.ERROR_TYPE_FORCE_DISCONNECT;
                        break;
                    // 暗号変更要求受信.
                    case ServerMessageType.KeyChangeRequest:
                        _SysLog.Log(Logtype.Information, "Receive KeyChangeRequest");
                        _DataStream.makeAesKeyDatas();
                        break;
                    // キープアライブ
                    case ServerMessageType.KeepAlive:
                        _SysLog.Log(Logtype.Debug, "Receive KeepAlive");
                        break;
                    // セッションタイムアウト（BHTサーバのタイムアウト）
                    case ServerMessageType.SessionTimeOut:
                        _SysLog.Log(Logtype.Information, "Receive SessionTimeOut");
                        Disconnect();
                        _ErrorMessage = LanguageConstantsNumber.ERROR_MESSAGE_SESSION_DISCONNECTED + ":" + Environment.NewLine +
                                        _MessageDictionary[LanguageConstantsNumber.ERROR_MESSAGE_SESSION_DISCONNECTED];
                        _ErrorType = Constants.ERROR_TYPE_FORCE_DISCONNECT;
                        break;
                }

                _SysLog.Log(Logtype.Debug, "lastReceive:" + DateTime.Now);
            }
        }
        #endregion

        #region Send
		/// <summary>
		/// クライアントからサーバーへのメッセージ 
		/// 
		/// 値     | 名称
		/// -------+-------------------------
		/// 0      | SetPixelFormat
		/// 2      | SetEncodings
		/// 3      | FramebufferUpdateRequest
		/// 4      | KeyEvent
		/// 5      | PointerEvent
		/// 6      | ClientCutText
		/// 
		/// その他の登録済みメッセージタイプ
		/// 値       | 名称
		/// ---------+----------------
		/// 255      | Anthony Liguori
		/// 254, 127 | VMWare
		/// 253      | gii
		/// 252      | tight
		/// 251      | Pierre Ossman SetDesktopSize
		/// 250      | Colin Dean xvp
		/// </summary>
       
		/// <summary>
		/// FramebufferUpdate メッセージにおいてSendされるべきピクセル値のフォーマットを設定する。
		/// クライアントが SetPixelFormat メッセージをSendしない場合、サーバーは ServerInit メッセージ(セクション 6.3.2)で指定した本来のフォーマットでピクセル値をSendする。
		/// rue-colour-flag がゼロ(偽)の場合、"カラーマップ(colour map)" が使用されることを表す。
		/// サーバーは、SetColourMapEntries メッセージ(セクション 6.5.2)を使用してカラーマップ内の任意のエントリを設定できる。
		/// クライアントがこのメッセージをSendすると、それ以前にサーバーによってエントリが設定されていたとしても、カラーマップは空になる。
		/// 
		/// バイト数     | 型              [値] | 説明
		/// -------------+----------------------+------------
		/// 1            | U8                0  | message-type
		/// 3            |                      | padding
		/// 16           | PIXEL_FORMAT         | pixel-format
		/// 
		/// PIXEL_FORMAT
		/// バイト数     | 型      [値] | 説明
		/// -------------+--------------+-----------------
		/// 1            | U8           | bits-per-pixel
		/// 1            | U8           | depth
		/// 1            | U8           | big-endian-flag
		/// 1            | U8           | true-colour-flag
		/// 2            | U16          | red-max
		/// 2            | U16          | green-max
		/// 2            | U16          | blue-max
		/// 1            | U8           | red-shift
		/// 1            | U8           | green-shift
		/// 1            | U8           | blue-shift
		/// 3                           | padding
		/// </summary>
		private bool SendSetPixelFormat(PixelFormat pxFormat)
        {
            Byte[] data = new Byte[20];
            var ret = _Send.SendPixelFormat(pxFormat, ref data);
            if (!SendErrorLog(ret, data, 3, "PixelFormat"))
            {
                return false;
            }

            return true;
		}

		/// <summary>
		/// SetEncodings (see 6.4.2)
		/// 
		/// サーバーがSendしてもよいピクセルデータのエンコードタイプを設定する。
		/// このメッセージ内で与えられるエンコードタイプの順序は、クライアントによる優先順位のヒントである(先頭のエンコードがもっとも優先順位が高い)。
		/// サーバーはこのヒントを使用してもよいし、しなくてもよい。
		/// 明示的に指定されなかった場合、ピクセルデータは常に raw エンコードでSendされる。
		/// 本物のエンコードに加えて、クライアントはこのプロトコルに対する特定の拡張をサポートすることをサーバーに宣言するために、"擬似エンコード(pseudo-encoding)" を要求することができる。
		/// その拡張をサポートしないサーバーは、単純にその擬似エンコードを無視するだろう。
		/// これは、何らかの拡張固有の合意をサーバーから受け取らない限り、クライアントはそのサーバーがその拡張をサポートしないと仮定しなければならないことを意味していることに注意してほしい。 
		/// 
		/// バイト数     | 型      [値] | 説明
		/// -------------+--------------+--------------------
		/// 1            | U8        2  | message-type
		/// 1            |              | padding
		/// 2            | U16          | number-of-encodings
		/// 
		/// この後に number-of-encodings の数だけ以下の内容が繰り返される
		/// 
		/// バイト数     | 型      [値] | 説明
		/// -------------+--------------+--------------
		/// 4            | S32          | encoding-type
		/// </summary>
		private bool SendSetEncodings()
        {
            Byte[] data = new Byte[4];
            var ret = _Send.SendSetEncodings(ref data);
            if (!SendErrorLog(ret, data, 3, "Encodings"))
            {
                return false;
            }

            return true;
        }

        /// <summary>
        /// Sends a Request for Screenupdate (see 6.4.3)
        /// 
        /// クライアントがフレームバッファの x-position・y-position・width・height で指定される領域に関心があることをサーバーに伝える。
        /// 通常サーバーは FramebufferUpdate をSendすることで FramebufferUpdateRequest に応える。
        /// 複数の FramebufferUpdateRequest に対して単一の FramebufferUpdate がSendされてもよいことに注意してほしい。
        /// サーバーは、クライアントが関心を持つフレームバッファのすべてのコピーを保持すると仮定する。
        /// つまり通常サーバーは、クライアントに差分の更新のみを送る必要があることを意味する。
        /// しかしながら、何らかの理由でクライアントが特定の領域の内容を喪失した場合、クライアントは incremental にゼロ(偽)をセットした FramebufferUpdateRequest をSendする。
        /// これはサーバーに、指定のエリアを即座にSendするよう要求する。そのエリアが CopyRect エンコードを使用して更新されることはない。
        /// クライアントが関心を持つ領域の内容をすべて保持している場合、クライアントは incremental に非ゼロ(真)をセットした FramebufferUpdateRequest をSendする。
        /// フレームバッファの指定された領域に変更がある場合、サーバーは FramebufferUpdate をSendする。
        /// FramebufferUpdateRequest と FramebufferUpdate との間には不定の時間が掛かる可能性があることに注意してほしい。
        /// 高速なクライアントの場合、ネットワークの占有を避けるために、差分の FramebufferUpdateRequest をSendする速度を制限することを望んでもよい。 
        /// 
        /// バイト数     | 型      [値] | 説明
        /// -------------+--------------+--------------------
        /// 1            | U8        3  | message-type
        /// 1            | U8           | incremental
        /// 2            | U16          | x-position
        /// 2            | U16          | y-position
        /// 2            | U16          | width
        /// 2            | U16          | height
        /// </summary>
        /// <param name="isIncremental"></param>
        /// <param name="posX"></param>
        /// <param name="posY"></param>
        /// <param name="width"></param>
        /// <param name="height"></param>
        private void SendFramebufferUpdateRequest(bool isIncremental, UInt16 posX, UInt16 posY, UInt16 width, UInt16 height)
        {
            // 切断されていた場合
            if (_DataStream == null || !_IsConnected)
            {
                return;
            }
            // Requestの結果が返っていない場合は、再リクエストを行わない
            if (_IsFramebufferUpdateRequest)
            {
                return;
            }

            Byte[] data = new Byte[10];
            var ret = _Send.SendFramebufferUpdateRequest(isIncremental, posX, posY, width, height, ref data);
            _lastRequest = DateTime.Now;
            SendErrorLog(ret, data, 3, "FramebufferUpdateRequest");

            // RequestSend
            _IsFramebufferUpdateRequest = true;
        }

		/// <summary>
		/// キーの押下または解放。キーが押された場合 down-flag は非ゼロ(真)、解放された場合はゼロ(偽)となる。
		/// key 自体は、X Window System によって定義される "keysym" の値を表す。
		/// 
		/// バイト数     | 型[値] | 説明
		/// -------------+--------------+--------------------
		/// 1            | U8        4  | message-type
		/// 1            | U8           | down-flag
		/// 2            |              | padding
		/// 4            | U32          | key
		/// 
		/// 大部分の通常のキーの場合、"keysym" は対応する ASCII 値と同じである。
		/// 詳細に付いては O'Reilly & Associates から出版されている Xlib Reference Manual を参照するか、任意の X Window System のインストールが提供するヘッダファイル <X11/keysymdef.h> を参照してほしい。
		/// 他の一般的なキーの一部を以下に示す：
		/// 
		/// キー名          | Keysym 値       キー名          | Keysym 値
		/// ----------------+-------------    ----------------+-------------
		/// BackSpace       | 0xff08          F1              | 0xffbe
		///	Tab             | 0xff09          F2              | 0xffbf
		///	Return or Enter | 0xff0d          F3              | 0xffc0
		///	Escape          | 0xff1b          F4              | 0xffc1
		///	Insert          | 0xff63          ...             | ...
		///	Delete          | 0xffff          F12             | 0xffc9
		///	Home            | 0xff50          Shift(左)       | 0xffe1
		///	End             | 0xff57          Shift(右)       | 0xffe2
		///	Page Up         | 0xff55          Control(左)     | 0xffe3
		///	Page Down       | 0xff56          Control(右)     | 0xffe4
		///	Left            | 0xff51          Meta(左)        | 0xffe7
		///	Up              | 0xff52          Meta(右)        | 0xffe8
		/// Right           | 0xff53          Alt(左)         | 0xffe9
		/// Down            | 0xff54          Alt(右)         | 0xffea
		/// </summary>
		/// <param name="e"></param>
		/// <param name="isDown"></param>
		private void SendKeyEvent(Key e, bool isDown)
        {
            // 切断されていた場合
            if (_DataStream == null || !_IsConnected)
            {
                return;
            }

            Byte[] data = new Byte[8];
            var ret = _Send.SendKeyEvent(e, isDown, ref data);
            SendErrorLog(ret, data, 3, "KeyEvent");
        }

        /// <summary>
        /// sendData a KeyEvent to the Server based on a sign (see 6.4.4)
        /// </summary>
        /// <param name="sign">the Sign to sendData like typing a key on a keyboard</param>
        private void SendSignEvent(char sign)
        {
            // 切断されていた場合
            if (_DataStream == null || !_IsConnected)
            {
                return;
            }

            Byte[] data = new Byte[8];
            var ret = _Send.SendSignEvent(sign, _KeyCodes, ref data);
            SendErrorLog(ret, data, 3, "SignEvent");
        }

        /// <summary>
        /// ポインタの移動、またはポインタのボタンの押下または解放を表す。
        /// ポインタは現在 (x-position, y-position) にあり、ボタン 1 から 8 の現在の状態は、button-mask のビット 0 から 7 によって、
        /// 0 が上がっている状態、1 が下がっている(押されている)状態として表される。
        /// 
        /// 標準的なマウスの場合、ボタン 1・2・3 がマウスの左ボタン・中ボタン・右ボタンに対応する。
        /// ホイールマウスの場合、ホイールの上方向への各ステップがボタン 4 の押下と解放とで表され、下方向への各ステップがボタン 5 の押下と解放とで表される。
        /// 
        /// バイト数     | 型      [値] | 説明
        /// -------------+--------------+--------------------
        /// 1            | U8        5  | message-type
        /// 1            | U8           | button-mask
        /// 2            | U16          | x-position
        /// 2            | U16          | y-position
        /// </summary>
        /// <param name="ButtonMask">bit1=left; bit2=middle; bit3=right; bit4=wheelup; bit5=wheeldown</param>
        /// <param name="posX"></param>
        /// <param name="posY"></param>
        private void SendPointerEvent(UInt16 posX, UInt16 posY, Byte ButtonMask)
        {
            // 切断されていた場合
            if (_DataStream == null || !_IsConnected)
            {
                return;
            }

            _SysLog.Log(Logtype.Debug, "Send:sendData Pointer: Button:" + ButtonMask + ", PosX:" + posX + ", PosY:" + posY);

            Byte[] data = new Byte[6];
            var ret = _Send.SendPointerEvent(posX, posY, ButtonMask, ref data);
            SendErrorLog(ret, data, 3, "PointerEvent");
        }

        /// <summary>
        /// サーバーにアプリ終了通知を行う
        /// </summary>
        private void SendCloseEvent()
        {
            // 切断されていた場合
            if (_DataStream == null || !_IsConnected)
            {
                return;
            }

            _SysLog.Log(Logtype.Debug, "Send:sendData Close:");

            Byte[] data = new Byte[1];
            var ret = _Send.SendCloseEvent(ref data);
            SendErrorLog(ret, data, 3, "CloseEvent");
        }
        #endregion

        #region Logging
        /// <summary>
        /// Connect Error Log Output
        /// </summary>
        /// <param name="errorType">エラータイプ</param>
        /// <param name="errorMsg">エラーメッセージ</param>
        /// <param name="logtype">ログ出力タイプ</param>
        /// <param name="logMsg">ログ出力メッセージ</param>
        /// <param name="disConnect">切断有無</param>
        private void connectErrorLog(int errorType, string errorMsg, Logtype logtype,  string logMsg, bool disConnect)
        {
            _Error = true;
            _ErrorType = errorType;
            _ErrorMessage = errorMsg + ":" + Environment.NewLine + _MessageDictionary[errorMsg];
            if (logMsg != null)
            {
                _SysLog.Log(logtype, logMsg);
                _SysLog.tmrLog_Tick();
            }
            if (disConnect)
            {
                Disconnect();
            }
        }

        /// <summary>
        /// Send Error Log Output
        /// </summary>
        /// <param name="ret">エラー番号</param>
        /// <param name="data">Sendデータ</param>
        /// <param name="ErrorType">エラータイプ</param>
        /// <param name="msg">ログ出力メッセージ</param>
        /// <returns>出力成功/失敗</returns>
        private bool SendErrorLog(int ret, IEnumerable<byte> data, int ErrorType, String msg)
        {
            // エラーの場合
            if (ret <= 0)
            {
                string errorMsg;
                switch (-1 * ret)
                {
                    default:
                        errorMsg = LanguageConstantsNumber.ERROR_MESSAGE_SERVER_DISCONNECTED;
                        break;
                    case 10053:
                        errorMsg = LanguageConstantsNumber.ERROR_MESSAGE_CON_ABORTED;
                        break;
                }
                connectErrorLog(ErrorType, errorMsg, Logtype.Debug, "Send:" + msg + " Write END:failed[" + ret + "]", false);

                return false;
            }
            return true;
        }

        /// <summary>
        /// Logging Output Events
        /// </summary>
        private void tmrLog_Tick(object sender, EventArgs e)
        {
            try
            {
                _SysLog.tmrLog_Tick();
            }
            catch (IOException)
            {
                //Console.WriteLine(ex.ToString());
                return;// logファイルを閉じたら書き込まれる。
            }
        }

        #endregion

        #region Public Methods

        /// <summary>
        /// Authentication
        /// </summary>
        public void StartConnection()
        {
            StartServerConnect();
        }

        /// <summary>
        /// Close the Connection to the Server
        /// </summary>
        public void Disconnect()
        {
                _DataStream = null;
                _IsConnected = false;

                if (_Receiver != null)
                {
                    _Receiver.RunWorkerCompleted -= new RunWorkerCompletedEventHandler(_Receiver_RunWorkerCompleted);
                    _Receiver.DoWork -= new DoWorkEventHandler(Receiver);
                    _Receiver.Dispose();
                    _Receiver = null;
                }
        }

        /// <summary>
        /// 画面更新要求
        /// 
        /// Requestを行っていない場合のみ要求する。
        /// （受信待/受信中は要求しない）
        /// </summary>
        /// <param name="isIncremental"></param>
        public void refreshScreen(bool isIncremental)
        {
            try
            {
                // 全画面分の画像データを要求したい場合は再Requestする。
                if (!isIncremental)
                {
                    _IsFramebufferUpdateRequest = false;
                }

                // Requestを行っていない場合、Requestを行う
                if (!_IsFramebufferUpdateRequest)
                {
                    SendFramebufferUpdateRequest(isIncremental, 0, 0, _Properties.FramebufferWidth, _Properties.FramebufferHeight);
                }
            }
            catch (Exception ex)
            {
                _SysLog.Log(Logtype.Error, ex.ToString());
            }
        }

        /// <summary>
        /// sendData a pressed Key to the Server (i.e. Enter, Tab, Cntr, Alt etc.)
        /// </summary>
        /// <param name="e"></param>
        public void sendKey(System.Windows.Input.KeyEventArgs e)
        {
            try
            {
                SendKeyEvent(e.Key, e.IsDown);
            }
            catch (Exception ex)
            {
                _SysLog.Log(Logtype.Error, ex.ToString());
            }
        }

        /// <summary>
        /// sendData a Sign to the Server
        /// </summary>
        /// <param name="sign"></param>
        public void sendSign(char sign)
        {
            try
            {
                SendSignEvent(sign);
            }
            catch (Exception ex)
            {
                _SysLog.Log(Logtype.Error, ex.ToString());
            }
        }

        /// <summary>
        /// Sends a Click to the Server
        /// </summary>
        /// <param name="posX">X-Position of the Mouse</param>
        /// <param name="posY">Y-Position of the Mouse</param>
        /// <param name="button">1=left 4=right 2=middle 8=wheelup 16=wheeldown</param>
        public void sendMouseClick(UInt16 posX, UInt16 posY, byte button)
        {
            try
            {
                SendPointerEvent(posX, posY, button);
            }
            catch (Exception ex)
            {
                _SysLog.Log(Logtype.Error, ex.ToString());
            }
        }

        /// <summary>
        /// sendData a special Key Combination to the Server
        /// </summary>
        /// <param name="keyComb"></param>
        public void sendKeyCombination(BHTKey keyComb)
        {
            Key aKey1 = default(Key);
            Key aKey2 = default(Key);
            Key aKey3 = default(Key);

            switch (keyComb)
            {
                case BHTKey.PgUp:
                    aKey1 = Key.PageUp;
                    break;
                case BHTKey.PgDn:
                    aKey1 = Key.PageDown;
                    break;
                case BHTKey.End:
                    aKey1 = Key.End;
                    break;
                case BHTKey.Home:
                    aKey1 = Key.Home;
                    break;
                case BHTKey.Insert:
                    aKey1 = Key.Insert;
                    break;
                case BHTKey.F2:
                    aKey1 = Key.F2;
                    break;
                case BHTKey.F5:
                    aKey1 = Key.F5;
                    break;
                case BHTKey.F6:
                    aKey1 = Key.F6;
                    break;
                case BHTKey.F7:
                    aKey1 = Key.F7;
                    break;
                case BHTKey.F8:
                    aKey1 = Key.F8;
                    break;
                case BHTKey.F11:
                    aKey1 = Key.F11;
                    break;
                case BHTKey.F12:
                    aKey1 = Key.F12;
                    break;
                default:
                    // 未定義のキーは送信しない
                    return;
            }

            try
            {
                SendKeyEvent(aKey1, true);
                if (aKey2 != default(Key))
                {
                    SendKeyEvent(aKey2, true);
                }
                if (aKey3 != default(Key))
                {
                    SendKeyEvent(aKey3, true);
                }

                System.Threading.Thread.Sleep(100);

                if (aKey3 != default(Key))
                {
                    SendKeyEvent(aKey3, false);
                }
                if (aKey2 != default(Key))
                {
                    SendKeyEvent(aKey2, false);
                }
                SendKeyEvent(aKey1, false);
            }
            catch (Exception ex)
            {
                _SysLog.Log(Logtype.Error, ex.ToString());
            }
        }

        /// <summary>
        /// sends a disconnection notification to the server.
        /// </summary>
        public void sendClose()
        {
            try
            {
                SendCloseEvent();
            }
            catch (Exception ex)
            {
                _SysLog.Log(Logtype.Error, ex.ToString());
            }
        }
        #endregion

        #region Properties
        /// <summary>
        /// ConnectionProperties
        /// </summary>
        public ConnectionProperties Properties
        {
            get { return (_Properties); }
            set { _Properties = value; }
        }

        /// <summary>
        /// ActionMode(DESK:デスクトップモード、ASSI:アシスタントモード、VIEW:閲覧モード)
        /// </summary>
		public string ActionMode
		{
			get { return (_ActionMode); }
			set { _ActionMode = value; }
		}

        /// <summary>
        /// Error
        /// </summary>
		public bool Error
        {
            get { return (_Error); }
            set { _Error = value; }
        }

        /// <summary>
        /// Error Message
        /// </summary>
		public string ErrorMessage
        {
            get { return (_ErrorMessage); }
            set { _ErrorMessage = value; }
        }

        /// <summary>
        /// Error Type
        /// </summary>
		public int ErrorType
        {
            get { return (_ErrorType); }
            set { _ErrorType = value; }
        }

        /// <summary>
        /// Connected flag
        /// </summary>
        public bool IsConnected 
        { 
            get { return (_IsConnected); }
        }

        #endregion

        #region IDisposable Support
        private bool disposedValue = false; // 重複する呼び出しを検出するには

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    // TODO: マネージド状態を破棄します (マネージド オブジェクト)。
                    if (_Connect != null)
                    {
                        _Connect.RunWorkerCompleted -= new RunWorkerCompletedEventHandler(_Connect_RunWorkerCompleted);
                        _Connect.DoWork -= new DoWorkEventHandler(InitializeConnect);
                        _Connect.Dispose();
                        _Connect = null;
                    }
                    if (_Receiver != null)
                    {
                        _Receiver.RunWorkerCompleted -= new RunWorkerCompletedEventHandler(_Receiver_RunWorkerCompleted);
                        _Receiver.DoWork -= new DoWorkEventHandler(Receiver);
                        _Receiver.Dispose();
                        _Receiver = null;
                    }

                }

                // TODO: アンマネージド リソース (アンマネージド オブジェクト) を解放し、下のファイナライザーをオーバーライドします。
                // TODO: 大きなフィールドを null に設定します。

                disposedValue = true;
            }
        }

        // TODO: 上の Dispose(bool disposing) にアンマネージド リソースを解放するコードが含まれる場合にのみ、ファイナライザーをオーバーライドします。
        // ~CommunicateClient() {
        //   // このコードを変更しないでください。クリーンアップ コードを上の Dispose(bool disposing) に記述します。
        //   Dispose(false);
        // }

        // このコードは、破棄可能なパターンを正しく実装できるように追加されました。
        public void Dispose()
        {
            // このコードを変更しないでください。クリーンアップ コードを上の Dispose(bool disposing) に記述します。
            Dispose(true);
            // TODO: 上のファイナライザーがオーバーライドされる場合は、次の行のコメントを解除してください。
            // GC.SuppressFinalize(this);
        }
        #endregion
    }
}