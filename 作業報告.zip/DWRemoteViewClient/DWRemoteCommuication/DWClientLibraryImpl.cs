﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.ExceptionServices;
using System.Runtime.InteropServices;
using System.Text;

namespace DWRemoteCommunication
{
    /*
     * DWClientLibrary(C++).dllアクセス処理
     */
    unsafe class DWClientLibraryImpl
    {
        public const int MAX_NAME_LENGTH = 1000;

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
        public struct Properties
        {
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = MAX_NAME_LENGTH)]
            public string _ConnectionName;
            public Byte _BitsPerPixel;
            public Byte _Depth;
            public Byte _BigEndianFlag;
            public Byte _TrueColourFlag0;
            public UInt16 _RedMax;
            public UInt16 _GreenMax;
            public UInt16 _BlueMax;
            public Byte _RedShift;
            public Byte _GreenShift;
            public Byte _BlueShift;
            public UInt16 _FramebufferWidth;
            public UInt16 _FramebufferHeight;
        }

        // IP,Port,Proxy
        private string m_host;
        private int m_port;
        private string m_proxy;
        private int m_timeout;
        private SystemLog _SystemLog;

        internal static class NativeMethods
        {
            [DllImport("DWClientLibrary.dll", CallingConvention = CallingConvention.Cdecl, BestFitMapping = false, ThrowOnUnmappableChar = true)]
            public static extern bool doConnection(string host, int port, string proxy, int timeout);
            [DllImport("DWClientLibrary.dll", CallingConvention = CallingConvention.Cdecl)]
            public static extern void CloseConnection();

            [DllImport("DWClientLibrary.dll", CallingConvention = CallingConvention.Cdecl)]
            public static extern Int32 ReadBytes(byte* data, int offset, int size);
            [DllImport("DWClientLibrary.dll", CallingConvention = CallingConvention.Cdecl)]
            public static extern void readHextileRect(byte* pixelData, int posX, int posY, int width, int height, bool cryptMode);
            //[DllImport("DWClientLibrary.dll", CallingConvention = CallingConvention.Cdecl)]
            //public static extern void readHextileRectTest(byte* pixelData, int posX, int posY, int width, int height, bool cryptMode, ref byte* test, ref int* size);
            [DllImport("DWClientLibrary.dll", CallingConvention = CallingConvention.Cdecl)]
            public static extern Int32 writeExact(byte* data, int offset, int size);

            [DllImport("DWClientLibrary.dll", CallingConvention = CallingConvention.Cdecl)]
            public static extern void SetServerInit(IntPtr srvInit);

            [DllImport("DWClientLibrary.dll", CallingConvention = CallingConvention.Cdecl, BestFitMapping = false, ThrowOnUnmappableChar = true)]
            public static extern Int32 DoAuthentication(string action, byte* cryptMode, string password, byte* timeout);

            [DllImport("DWClientLibrary.dll", CallingConvention = CallingConvention.Cdecl, BestFitMapping = false, ThrowOnUnmappableChar = true)]
            public static extern void CryptorInit(string seed, uint seeSize, byte* IV, uint IVSize);

            [DllImport("DWClientLibrary.dll", CallingConvention = CallingConvention.Cdecl)]
            public static extern bool remakeAESKeyDatas();

            [DllImport("DWClientLibrary.dll", CallingConvention = CallingConvention.Cdecl)]
            public static extern bool CryptorEncrypt(byte* plainText, UInt32 plainTextSize, ref byte* encodedText, UInt32* encodedTextSize);

            [DllImport("DWClientLibrary.dll", CallingConvention = CallingConvention.Cdecl)]
            public static extern bool CryptorDecrypt(byte* encodedText, UInt32 encodedTextSize, ref byte* decodedText, UInt32* decodedTextSize);

            [DllImport("DWClientLibrary.dll", CallingConvention = CallingConvention.Cdecl)]
            public static extern void DWHeapFree(void* haep);
        }


        /// <summary>コンストラクタ</summary>
        /// <param name="host">IP Address</param>
        /// <param name="port">Port</param>
        /// <param name="proxy">Proxy(unused)</param>
        /// <param name="timeout">Recive Timeout</param>
        /// <param name="_SysLog">System Log</param>
        public DWClientLibraryImpl(string host, int port, string proxy, int timeout, SystemLog SysLog)
        {
            m_host = host;
            m_port = port;
            m_proxy = proxy;
            m_timeout = timeout;
            _SystemLog = SysLog;
            this.MakeInstance();
        }

        /// <summary>Connect</summary>
        public bool Connect()
        {
            return NativeMethods.doConnection(m_host, m_port, m_proxy, m_timeout);
        }

        /// <summary>Close</summary>
        public void Close()
        {
            NativeMethods.CloseConnection();
        }

        /// <summary>受信</summary>
        /// <param name="data">out 受信結果byteコレクション</param>
        /// <param name="offset">オフセット</param>
        /// <param name="size">読み込みサイズ</param>
        /// <returns>読み込み量,size以下の場合失敗</returns>
        public Int32 Read(byte[] data, int offset, int size)
        {
            // TODO: Readはoffsetを無視している（現状の実装では0しか入ってこない）
            fixed (byte* p = data)
                return NativeMethods.ReadBytes(p, offset, size);
        }

        /// <summary>読み込み.</summary>
        /// <param name="offset">オフセット</param>
        /// <param name="size">読み込みサイズ</param>
        /// <returns>読み込んだbyteコレクション.エラー時NULL</returns>
        public IEnumerable<byte> Read(int offset, int size)
        {
            byte[] result = new byte[size];
            Read(result, offset, size);
            return result;
        }

        /// <summary>読み込み（暗号時対応）.</summary>
        /// <param name="offset">オフセット</param>
        /// <param name="size">読み込みサイズ</param>
        /// <param name="isCrypt">暗号化モード化</param>
        /// <returns>読み込んだbyteコレクション.エラー時NULL</returns>
        public IEnumerable<byte> Read(int offset, int size, bool isCrypt)
        {
            if (isCrypt)
                size = (size / 16 + 1) * 16;
            return Read(offset, size);
        }
        /// <summary>読み込み後、復号化.</summary>
        /// <param name="data">out 複合結果byteコレクション</param>
        /// <param name="offset">オフセット</param>
        /// <param name="size">読み込みサイズ</param>
        /// <param name="isDecrypt">暗号化モードか</param>
        /// <returns>読み込み量,size以下の場合失敗</returns>
        public Int32 ReadAfterDecrypt(byte[] data, int offset, int size, bool isDecrypt)
        {
            var readBuff = new byte[size];
            var result = 0;
            if (!isDecrypt)
            {
                result = Read(data, offset, size);
            }
            else
            {
                //サーバから送信されてくる暗号文が16byte/1ブロックで送られてくる
                //（サーバ側で暗号化する際に端数はパディングされるため、必ず16byteの倍数値で受信する）
                size = ((size / 16) + 1) * 16;//端数は繰り上げて、16バイトで乗算する
                readBuff = new byte[size];
                result = Read(readBuff, offset, size);
                if (0 >= result)
                {
                    return result;
                }
                var decodeBuff = new byte[size];
                if (!CryptDecrypt(readBuff, (UInt32)size, ref decodeBuff))
                    return -1;
                Array.Copy(decodeBuff, data, data.Length);
            }
            return result;
        }

        /// <summary>送信</summary>
        /// <param name="data">out 送信結果byteコレクション</param>
        /// <param name="offset">オフセット</param>
        /// <param name="size">送信サイズ</param>
        /// <returns>送信量,size以下の場合失敗</returns>
        public Int32 Write(byte[] data, int offset, int size)
        {
            // TODO: Writeはoffsetを無視している（現状の実装では0しか入ってこない）
            fixed (byte* p = data)
                return NativeMethods.writeExact(p, offset, size);
        }

        /// <summary>暗号化後、書き込み.</summary>
        /// <param name="data">書き込みデータ</param>
        /// <param name="offset">オフセット</param>
        /// <param name="size">書き込みサイズ</param>
        /// <param name="isEncrypt">暗号化モードか</param>
        /// <returns>書き込み量、０以下の場合失敗</returns>
        public Int32 WriteBeforeEncrypt(IEnumerable<byte> data, int offset, int size, bool isEncrypt)
        {
            //データ固定化
            data = data.ToArray();
            if (isEncrypt)
            {
                byte[] writeData = new byte[size];
                if (!CryptEncrypt(data, (UInt32)size, ref writeData))
                    return -1;
                data = writeData.ToArray();
                size = data.Count();
            }
            var result = Write(data.ToArray(), offset, size);
            return result;
        }

        /// <summary>二つのデータを別々に暗号化後、合わせて送信.</summary>
        /// <param name="data">手前の書き込みbyteコレクション</param>
        /// <param name="dataAfter">後ろの書き込みbyteコレクション</param>
        /// <param name="offset">オフセット</param>
        /// <param name="size">サイズ</param>
        /// <param name="isEncrypt">暗号化モードか</param>
        /// <returns>書き込み量、０以下の場合失敗</returns>
        public Int32 WriteBeforeEncryptConcat(IEnumerable<byte> data, IEnumerable<byte> dataAfter, int offset, int size, bool isEncrypt)
        {
            var sizee = size;

            if (isEncrypt)
            {
                byte[] writeData = new byte[data.Count()];
                if (!CryptEncrypt(data, (UInt32)data.Count(), ref writeData))
                    return -1;
                data = writeData.ToArray();
                size = data.Count();

                writeData = new byte[dataAfter.Count()];
                if (!CryptEncrypt(dataAfter, (UInt32)dataAfter.Count(), ref writeData))
                    return -1;
                dataAfter = writeData.ToArray();
                size += dataAfter.Count();
            }
            data = data.Concat(dataAfter);
            var result = Write(data.ToArray(), offset, size);
            return result;
        }

        /// <summary>Flush</summary>
        public void Flush()
        {
            // TODO: Flushは何もしていない
            return;
        }

        //[HandleProcessCorruptedStateExceptions]
        /// <summary>Hextileデータ読み取り</summary>
        /// <param name="pixelData">out 読みこみpixcelデータ</param>
        /// <param name="srcData">複合化データ.暗号化モード時以外NULL</param>
        /// <param name="posX">開始位置x</param>
        /// <param name="posY">開始位置y</param>
        /// <param name="width">横幅</param>
        /// <param name="height">縦幅</param>
        public void ReadHextile(byte[] pixelData, int posX, int posY, int width, int height, Boolean cryptMode)
        {
            try
            {
                fixed (byte* p = pixelData)
                    NativeMethods.readHextileRect(p, posX, posY, width, height, cryptMode);
            }
            catch (Exception e)
            {
                _SystemLog.Log(Logtype.Error, "Exception:" + e.ToString());
                throw;
            }
            return;
        }
        //public void ReadHextileTest(byte[] pixelData, int posX, int posY, int width, int height, Boolean cryptMode, byte[] test)
        //{
        //    int buffi = 0;
        //    int *size = &buffi;
        //    byte[] buff= new byte[384000];
        //    byte* testt = (byte*)buff.First();

        //    try
        //    {
        //        fixed (byte* p = pixelData)
        //            NativeMethods.readHextileRectTest(p, posX, posY, width, height, cryptMode, ref testt, ref size);
        //        for (int i = 0; i < *size; i++)
        //        {
        //            test[i] = *(testt + i);
        //        }
        //        NativeMethods.DWHeapFree(testt);
        //    }
        //    catch (Exception e)
        //    {
        //        _SystemLog.Log(Logtype.Error, "Exception:" + e.ToString());
        //        throw;
        //    }
        //    return;
        //}

        /// <summary>Read ServerInit</summary>
        /// <param name="p">接続情報</param>
        public void SetServerInitMsg(ConnectionProperties p)
        {
            Properties prop;
            prop._BigEndianFlag = (byte)(p.PxFormat.BigEndianFlag == true ? 1 : 0);
            prop._BitsPerPixel = p.PxFormat.BitsPerPixel;
            prop._BlueMax = p.PxFormat.BlueMax;
            prop._BlueShift = p.PxFormat.BlueShift;
            prop._ConnectionName = p.ConnectionName;
            prop._Depth = p.PxFormat.Depth;
            prop._FramebufferHeight = p.FramebufferHeight;
            prop._FramebufferWidth = p.FramebufferWidth;
            prop._GreenMax = p.PxFormat.GreenMax;
            prop._GreenShift = p.PxFormat.GreenShift;
            prop._RedMax = p.PxFormat.RedMax;
            prop._RedShift = p.PxFormat.RedShift;
            prop._TrueColourFlag0 = (byte)(p.PxFormat.TrueColourFlag == true ? 1 : 0);

            IntPtr propPtr = (IntPtr)0;
            try
            {
                propPtr = Marshal.AllocCoTaskMem(Marshal.SizeOf(prop));
                Marshal.StructureToPtr(prop, propPtr, false);
                NativeMethods.SetServerInit(propPtr);
            }
            catch(Exception e)
            {
                _SystemLog.Log(Logtype.Error, "Exception:" + e.ToString());
            }
            finally
            {
                Marshal.FreeCoTaskMem(propPtr);
            }
        }

        /// <summary>DNWA認証.</summary>
        /// <param name="action">out アクション</param>
        /// <param name="data">out データ</param>
        /// <param name="iv">in イニシャライズベクター</param>
        /// <param name="challange">in チャレンジデータ</param>
        /// <param name="cryptMode">out 暗号化モードか</param>
        /// <param name="password">in パスワード</param>
        /// <param name="errorMsgSize">out メッセージサイズ</param>
        /// <returns>正の値なら成功</returns>
        public Int32 Authentication(string action, byte[] cryptMode, string password, byte[] timeout)
        {
            Int32 result = 0;
            try
            {
                fixed (byte*s = cryptMode, t = timeout)
                    result = NativeMethods.DoAuthentication(action, s, password, t);
            }
            catch (System.AccessViolationException ae)
            {
                _SystemLog.Log(Logtype.Error, "Exception:" + ae.ToString());
                throw;
            }
            return result;
        }

        /// <summary>キー作成.</summary>
        /// <param name="challenge">チャレンジデータ</param>
        /// <param name="seed">シード値</param>
        /// <param name="IV">イニシャライズベクター</param>
        //public void CryptInit(string seed, byte[] IV)
        //{
        //    try
        //    {
        //        seed += '\0';
        //        fixed (byte* q = IV)
        //            NativeMethods.CryptorInit(seed, (uint)seed.Length, q, (uint)IV.Length);
        //    }
        //    catch (System.Exception e)
        //    {
        //        _SystemLog.Log(Logtype.Error, "Exception:" + e.ToString());
        //        throw;
        //    }
        //    return;
        //}

        public bool makeAesKeyDatas()
        {
            return NativeMethods.remakeAESKeyDatas();
        }
        /// <summary>暗号化.</summary>
        /// <param name="plainText">平文のbyteコレクション</param>
        /// <param name="plainTextSize">平文のサイズ</param>
        /// <param name="encodedText">out 暗号化結果byteコレクション</param>
        /// <returns>成功したか</returns>
        public bool CryptEncrypt(IEnumerable<byte> plainText, UInt32 plainTextSize, ref byte[] encodedText)
        {
            bool result = false;
            byte* pencode = (byte*)encodedText.First();
            UInt32 encodedTextSize = 0;
            
            try
            {
                fixed (byte* p = plainText.ToArray())
                    result = NativeMethods.CryptorEncrypt(p, plainTextSize, ref pencode, &encodedTextSize);
                List<byte> bytebuff = new List<byte>();
                for (int i = 0; encodedTextSize > i; i++)
                {
                    bytebuff.Add(pencode[i]);
                }
                NativeMethods.DWHeapFree(pencode);
                encodedText = bytebuff.ToArray();
            }
            catch (System.Exception e)
            {
                _SystemLog.Log(Logtype.Error, "Exception:" + e.ToString());
                throw;
            }
            return result;
        }

        /// <summary>複合化.</summary>
        /// <param name="encodedText">暗号文byteコレクション</param>
        /// <param name="encodedTextSize">暗号文のサイズ</param>
        /// <param name="decodedText">out 複合化結果byteコレクション</param>
        /// <returns>成功したか</returns>
        public bool CryptDecrypt(IEnumerable<byte> encodedText, UInt32 encodedTextSize, ref byte[] decodedText)
        {
            bool result = false;
            byte* pdecode = (byte*)decodedText.First();
            UInt32 decodedTextSize = 0;
            try
            {
                fixed (byte* p = encodedText.ToArray())
                {
                    result = NativeMethods.CryptorDecrypt(p, encodedTextSize, ref pdecode, &decodedTextSize);
                }
                List<byte> bytebuff = new List<byte>();
                for (int i = 0; encodedTextSize > i; i++)
                {
                    bytebuff.Add(pdecode[i]);
                }
                NativeMethods.DWHeapFree(pdecode);
                decodedText = bytebuff.ToArray();
            }
            catch (System.Exception e)
            {
                _SystemLog.Log(Logtype.Error, "Exception:" + e.ToString());
                throw;
            }
            return result;
        }
    }

    //拡張メソッド.
    static class DWClientLibraryImplInstance
    {
        static private DWClientLibraryImpl instance;

        /// <summary>
        /// 拡張メソッド.dllクラス作成時にそのインスタンスを取得.
        /// 現状DWRemoteClientImplクラスがstaticでないため新たにインスタンスが.
        /// 作成された場合、問題が起きる.
        /// </summary>
        /// <param name="buf">クラスのインスタンス</param>
        /// <returns>クラスのインスタンス</returns>
        static public DWClientLibraryImpl MakeInstance(this DWClientLibraryImpl buf)
        {
            instance = buf;
            return instance;
        }


        /// <summary>拡張メソッド.書き込み(サイズ指定可).</summary>
        /// <param name="data">書き込みbyteコレクション</param>
        /// <param name="offset">オフセット</param>
        /// <param name="size">書き込みサイズ</param>
        /// <returns>書き込めた量.マイナス、０の時はエラー</returns>
        static public int Write(this IEnumerable<byte> data, int offset, int size)
        {
            var result = instance.Write(data.ToArray(), offset, size);
            return result;
        }

        /// <summary>拡張メソッド.書き込み.</summary>
        /// <param name="data">書き込みbyteコレクション</param>
        /// <param name="offset">オフセット</param>
        /// <returns>書き込めた量.マイナス、０の時はエラー</returns>
        static public int Write(this IEnumerable<byte> data, int offset)
        {
            var byteData = data.ToArray();
            var result = Write(byteData, offset, byteData.Length);
            return result;
        }

        /// <summary>拡張メソッド.暗号化.</summary>
        /// <param name="plainText">平文</param>
        /// <param name="isCrypt">暗号化モードか</param>
        /// <returns>暗号結果byteコレクション.エラー時NULL</returns>
        static public IEnumerable<byte> Encrypt(this IEnumerable<byte> plainText, bool isCrypt = true)
        {
            if (!isCrypt)
            {
                foreach (byte pl in plainText)
                    yield return pl;
                yield break;
            }
            var size = plainText.Count();
            var result = new byte[size];
            instance.CryptEncrypt(plainText, (uint)size,ref result);
            foreach(var re in result)
            {
                yield return re;
            }
        }

        /// <summary>拡張メソッド.複合化.</summary>
        /// <param name="cryptText">暗号文</param>
        /// <param name="isCrypt">暗号化モードか</param>
        /// <returns>複合結果byteコレクション.エラー時NULL</returns>
        static public IEnumerable<byte> Decript(this IEnumerable<byte> cryptText,bool isCrypt = true)
        {
            if (!isCrypt)
            {
                foreach (byte cr in cryptText)
                    yield return cr;
                yield break;
            }
            var size = cryptText.Count();
            var result = new byte[size];
            instance.CryptDecrypt(cryptText, (uint)size, ref result);
            foreach (var re in result)
            {
                yield return re;
            }
        }
    }
}


