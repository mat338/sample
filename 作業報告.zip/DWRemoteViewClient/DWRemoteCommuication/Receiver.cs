﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Threading;
using System.Security.Cryptography;

namespace DWRemoteCommunication
{
    /*
     * 受信処理
     */
    internal class Receiver
    {
        private DWClientLibraryImpl _DataStream; //The Stream to read/write Data
        private ConnectionProperties _Properties;
        private SystemLog _sysLog;
        private bool _cryptFlag;

        /// <summary>コンストラクタ</summary>
        /// <param name="DataStream">ソケット接続クラス</param>
        /// <param name="Properties">接続情報クラス</param>
        /// <param name="sysLog">システムログクラス</param>
        public Receiver(DWClientLibraryImpl DataStream, ConnectionProperties Properties, SystemLog sysLog, bool cryptFlag)
        {
            this._DataStream = DataStream;
            this._Properties = Properties;
            this._sysLog = sysLog;
            this._cryptFlag = cryptFlag;
        }

        /// <summary>
        /// Gets the ServerMessageType by the Next Byte
        /// 
        /// サーバーからクライアントへのメッセージタイプ
        /// 値     | 名称
        /// -------+--------------------
        /// 0      | FramebufferUpdate
        /// 1      | SetColourMapEntries
        /// 2      | Bell
        /// 3      | ServerCutText
        /// </summary>
        /// <param name="cryptFlag">複合化対象フラグ</param>
        /// <returns>ServerMessageType</returns>
        public ServerMessageType GetServerMessageType()
        {
            Byte[] recData = new Byte[1];
            _sysLog.Log(Logtype.Debug, "Read:GetServerMessageType Read START:1byte");

            int n = _DataStream.ReadAfterDecrypt(recData, 0, recData.Length, _cryptFlag);
            if (n <= 0)
            {
                _sysLog.Log(Logtype.Debug, "Read:GetServerMessageType Read END:failed[" + n + "]");
                switch (-1 * n)
                {
                    // Winsock エラー コード
                    default:
                        throw new Exception(Constants.ERROR_STRING_END_OF_STREAM);
                    case 0://END OF STREAM
                        throw new Exception(Constants.ERROR_STRING_END_OF_STREAM);
                    case 10050://WSAE NETDOWN
                        throw new Exception(Constants.ERROR_STRING_NET_DOWN);
                    case 10051://WSAE NETUNREACH
                        throw new Exception(Constants.ERROR_STRING_NET_REACH);
                    case 10052://WSAE NETRESET
                        throw new Exception(Constants.ERROR_STRING_NET_RESET);
                    case 10053://WSAE CONNABORTED
                        throw new Exception(Constants.ERROR_STRING_CONN_ABORTED);
                    case 10055://WSAE NOBUFS
                        throw new Exception(Constants.ERROR_STRING_NO_BUFS);
                    case 10060://WSAE TIMEDOUT
                        throw new Exception(Constants.ERROR_STRING_TIME_OUT_ERROR);
                }
            }

            _sysLog.Log(Logtype.Debug, "Read:GetServerMessageType Read END:[" + recData[0] + "]");

            return GetServerMessageType(recData[0]);
        }

        /// <summary>
        /// Gets the ServerMessageType by the Next Byte
        /// </summary>
        /// <returns>ServerMessageType</returns>
        private ServerMessageType GetServerMessageType(Byte ServerMessageId)
        {
            switch (ServerMessageId)
            {
                default:
                    return (ServerMessageType.Unknown);
                case 0:
                    return (ServerMessageType.FramebufferUpdate);
                case 100:
                    return (ServerMessageType.KeyChangeRequest);
                case 101:
                    return (ServerMessageType.KeepAlive);
                case 102:
                    return (ServerMessageType.SessionTimeOut);
                case 255:
                    return (ServerMessageType.ExclusiveConnectClose);
            }
        }

        /// <summary>
        /// Receives ne Frames after a Framebufferupdaterquest (see 6.5.1)
        /// 
        /// フレームバッファの更新は、クライアントがフレームバッファに入れるべき一連の矩形のピクセル情報から構成される。
        /// これはクライアントからの FramebufferUpdateRequest に応えて送信される。
        /// FramebufferUpdateRequest と FramebufferUpdate との間には不定の時間が掛かる可能性があることに注意してほしい。
        /// 
        /// バイト数     | 型      [値] | 説明
        /// -------------+--------------+---------------------
        /// 1            | U8        0  | message-type
        /// 1            |              | padding
        /// 2            | U16          | number-of-rectangles
        /// 
        /// この後に number-of-rectangles の数だけ矩形のピクセルデータが続く。各矩形は以下の内容から構成される
        /// バイト数     | 型      [値] | 説明
        /// -------------+--------------+--------------
        /// 2            | U16          | x-position
        /// 2            | U16          | y-position
        /// 2            | U16          | width
        /// 2            | U16          | height
        /// 4            | S32          | encoding-type
        /// 指定されたエンコードのピクセルデータがこの後に続く。
        /// 
        /// message-typeは受信済
        /// </summary>
        /// <param name="cryptFlag">複合化対象フラグ</param>
        /// <returns>画像データの情報</returns>
        public List<Rectangle> ReceiveFramebufferUpdate()
        {
            byte[] data = _DataStream.Read(0, 3, _cryptFlag).Decript(_cryptFlag).ToArray();
            UInt16 rectCount = Helper.ToUInt16(data.Skip(1).Take(2).ToArray(), false);
            _sysLog.Log(Logtype.Debug, "FramebufferUpdate received. Frames:[" + rectCount + "]");

            var rects = new List<Rectangle>(rectCount);
            try
            {
                for (int i = 0; i < rectCount; i++)
                {
                    data = new byte[12];
                    data = _DataStream.Read(0, data.Length, _cryptFlag).Decript(_cryptFlag).ToArray();

                    Rectangle rRec = new Rectangle(
                        Helper.ToUInt16(data.Take(2).ToArray(), false),
                        Helper.ToUInt16(data.Skip(2).Take(2).ToArray(), false),
                        Helper.ToUInt16(data.Skip(4).Take(2).ToArray(), false),
                        Helper.ToUInt16(data.Skip(6).Take(2).ToArray(), false),
                        data.Skip(8).Take(4).ToArray()
                        );
                    // 受信データのピクセル（幅/高さ）が端末から指定されたピクセルより大きい場合
                    if (_Properties.FramebufferWidth < rRec.Width || _Properties.FramebufferHeight < rRec.Height)
                    {
                        throw new Exception(Constants.ERROR_STRING_INCORRECT_DATA);
                    }

                    // 画像データ受信
                    rRec.PixelData = ReceiveRectangleData(rRec.EncodingType, rRec.PosX, rRec.PosY, rRec.Width, rRec.Height);

                    //Read the Pixelinformation, depending on EncryptionType and report it to the UI-Mainthread
                    if (rRec.PixelData != null)
                    {
                        rects.Add(rRec);
                    }
                }
            }
            catch (Exception e)
            {
                _sysLog.Log(Logtype.Error, "Error on FramebufferUpdate: " + e.ToString());
                throw;
            }


            return rects;
        }

        /* 画像崩れ対応 調査用 */
        private int screenNo = 1;
        /// <summary>
        /// Read Rectangle Data
        /// </summary>
        /// <param name="encryptionType">Rect Encodingtype</param>
        /// <param name="posX">Rect posision X</param>
        /// <param name="posY">Rect posision Y</param>
        /// <param name="width">Rect width</param>
        /// <param name="height">Rect height</param>
        /// <param name="cryptFlag">複合化対象フラグ</param>
        private Byte[] ReceiveRectangleData(Byte[] encryptionType, UInt16 posX, UInt16 posY, UInt16 width, UInt16 height)
        {
            DateTime start = DateTime.Now;

            try
            {
                byte[] myData = new byte[(UInt32)(width * height * 4)];

                _sysLog.Log(Logtype.Information, "Receive RectData enc:" + encryptionType[0] + ";size:" + width + "x" + height);

                UInt32 encrNr = Helper.ToUInt32(encryptionType, _Properties.PxFormat.BigEndianFlag);
                _sysLog.Log(Logtype.Debug, "ReceiveRectangleData encrNr:[" + encrNr + "]");
                switch (encrNr)
                {
                    #region X Not Supported

                    default:
                    case 1: //CopyRect
                    case 2: //RRE
                    case 16: //ZRLE
                        _sysLog.Log(Logtype.Information, "Encodingtype " + encrNr + " currently not supported");
                        break;

                    #endregion

                    #region 0 HEXTILE

                    case 5: //Hextile
                        {
                            _Properties.EncodingType = REncoding.Hextile_ENCODING;

                            // TODO: Hextile読み込み
                            _sysLog.Log(Logtype.Debug, "Read:ReadHextile Read START:[" + myData.Length + "]byte");
                            _sysLog.Log(Logtype.Debug, "Read:ReadHextile Read START:posX[" + posX + "]");
                            _sysLog.Log(Logtype.Debug, "Read:ReadHextile Read START:posY[" + posY + "]");
                            _sysLog.Log(Logtype.Debug, "Read:ReadHextile Read START:width[" + width + "]");
                            _sysLog.Log(Logtype.Debug, "Read:ReadHextile Read START:height[" + height + "]");

                            _DataStream.ReadHextile(myData, posX, posY, width, height, _cryptFlag);
                            /* 画像崩れ対応 調査用 */
                            //_sysLog.Log(Logtype.Critical, "screenNo:" + screenNo);
                            //Console.WriteLine(screenNo + ":");
                            //byte[] test = new byte[38400];
                            //_DataStream.ReadHextileTest(myData, posX, posY, width, height, _cryptFlag, test);

                            //string strRecData = null;
                            //for (int i = 0; i < myData.Length; i++)
                            //{
                            //    //Console.WriteLine(BitConverter.ToString(myData[i]));
                            //    //strRecData += myData[i];
                            //}

                            //SHA256 crypto256 = new SHA256CryptoServiceProvider();
                            //byte[] hash = crypto256.ComputeHash(myData);
                            //string str = "test";
                            //byte[] arr = System.Text.Encoding.GetEncoding("UTF-8").GetBytes(str);
                            //byte[] hash = crypto256.ComputeHash(arr);
                            //string hashStr = BitConverter.ToString(hash).Replace("-", string.Empty);

                            //Console.WriteLine(BitConverter.ToString(myData).Replace("-", string.Empty));
                            //Console.WriteLine(hashStr);

                            //_sysLog.Log(Logtype.Critical, "hash_moto:" + BitConverter.ToString(myData).Replace("-", string.Empty));
                            //_sysLog.Log(Logtype.Critical, "hash:" + hashStr);
                            screenNo++;

                            return myData;
                        }
                    #endregion

                    #region 0 RAW

                    case 0: //Raw
                        {
                            if (_cryptFlag)
                            {
                                byte[] sizedata = new byte[4];
                                _DataStream.ReadAfterDecrypt(sizedata, 0, sizedata.Length, _cryptFlag);
                                myData = new Byte[Helper.ToUInt32(sizedata.Take(4).ToArray(), true)];
                            }

                            _Properties.EncodingType = REncoding.Raw_ENCODING;
                            int readCount = 0;

                            while (readCount < myData.Length) //Get all Bytes
                            {
                                _sysLog.Log(Logtype.Debug, "Read:ReceiveRectangleData Read START:");
                                readCount += _DataStream.ReadAfterDecrypt(myData, readCount, myData.Length - readCount, _cryptFlag);

                            }
                            return myData;
                        }
                    #endregion

                    #region Pseudo DesktopSize
                    case 4294967073: //See 6.7.2
                                     //Set a new Backbuffersize
                                     //_BackBuffer2PixelData = new byte[width*height*4];

                        //Request new Screen
//                        SendFramebufferUpdateRequest(true, 0, 0, width, height);
                        break;
                        #endregion
                }

            }
            catch (Exception e)
            {
                _sysLog.Log(Logtype.Error, "Error on receiving a RawRectangle: " + e.ToString());
                throw;
            }

            _sysLog.Log(Logtype.Information, "Finished receive RectData.: " + DateTime.Now.Subtract(start).TotalMilliseconds + "ms");
            return null;
        }

    }
}