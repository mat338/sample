﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DWRemoteCommunication
{
    /*
     * 言語（ID）定義
     */
    public static class LanguageConstantsNumber
    {
        // 接続設定画面　項目名称
        public const string SCREEN_ITEM_CONNECT_INFO = "SC001T";
        public const string SCREEN_ITEM_BHT_ID = "SC002I";
        public const string SCREEN_ITEM_HOST = "SC003I";
        public const string SCREEN_ITEM_PORT = "SC004I";
        public const string SCREEN_ITEM_PASSWORD = "SC005I";
        public const string SCREEN_ITEM_OPTION = "SC006T";
        public const string SCREEN_ITEM_SCALE = "SC007I";
        public const string SCREEN_ITEM_MODE = "SC008I";
        public const string SCREEN_ITEM_ERROR_TITLE = "SC009T";
        public const string SCREEN_ITEM_CONNECT = "SC010B";

        // Error Message
        // 入力メッセージ
        public const string ERROR_MESSAGE_INPUT_REQUIRED = "CU001W";// 〇〇は必須入力です。
        public const string ERROR_MESSAGE_INPUT_PORT = "CU002W";// ポート番号は1から65535の範囲で入力してください。
        public const string ERROR_MESSAGE_INPUT_RAITO = "CU003W";// 50％以上250%以下の拡大縮小率を入力してください。(50% - 250%)
        public const string ERROR_MESSAGE_NOT_README_FILE = "CU004W";// ファイルが存在しないため起動に失敗しました。 BHTRemote_Readmeファイルが削除されていないか確認して下さい。
        public const string MESSAGE_SETTING_FILE_SAVE = "CU005C";// 接続設定ファイルへ保存することに成功しました。
        public const string MESSAGE_SETTING_FILE_NOT_SAVE = "CU006W";// 接続設定ファイルへの保存に失敗しました。接続設定ファイルを開いている場合は閉じてください。
        public const string MESSAGE_APPLICATION_EXIT = "CU007Q";// アプリケーションを終了します。よろしいですか？
        // 接続エラー
        public const string ERROR_MESSAGE_SERVER_NOT_FOUND = "CC001W";// サーバーに接続することができませんでした。IPアドレスやポート番号、サーバアプリの起動を確認してください。
        public const string ERROR_MESSAGE_PRODUCT_INIT_FAIL = "CC002E";// サーバーの初期化に失敗しました。[rsa-pubkey.dat]ファイルが削除されていないか確認して下さい。
        public const string ERROR_MESSAGE_PRODUCT_CHECK_FAIL = "CC003E";// 製品認証に失敗しました。サーバーアプリを再起動してください。
        public const string ERROR_MESSAGE_PASSWORD_CHECK = "CC004W";// パスワードの認証に失敗しました。正しいパスワードを入力してください。
        public const string ERROR_MESSAGE_LOG_OUTPUT_FAIL = "CC005W";// ログ出力に失敗したため、接続に失敗しました。 ログファイルが開いている場合は閉じてください。
        // 切断エラー
        public const string ERROR_MESSAGE_SERVER_DISCONNECTED = "CD001W";// End Of Stream サーバー停止、端末再起動などはEndOfStreamでエラーが返る
        public const string ERROR_MESSAGE_NET_DOWN = "CD002E";// ネットワークのダウンによる切断
        public const string ERROR_MESSAGE_NET_RESET = "CD003E";// ネットワークがリセットされたことによる切断
        public const string ERROR_MESSAGE_CON_ABORTED = "CD004E";// サーバーのソフトウェアによって切断
        public const string ERROR_MESSAGE_NO_BUFS = "CD005E";// システムのバッファ領域が不足しているか、キューがいっぱいであるため、ソケット操作の実行不能。			
        public const string ERROR_MESSAGE_TIME_OUT_ERROR = "CD006W";// タイムアウトによって切断
        public const string ERROR_MESSAGE_FORCED_DISCONNECTED = "CD007C";// サーバによる強制切断
        public const string ERROR_MESSAGE_SESSION_DISCONNECTED = "CD008C";// セッションタイムアウトによる強制切断


        // ToolTip
        // 接続設定画面
        public const string TOOLTIP_SAVE = "TC001B";//接続設定CSV保存ボタン
        public const string TOOLTIP_EDIT = "TC002B";//接続設定CSV編集ボタン
        public const string TOOLTIP_HELP = "TC003B";//ヘルプボタン
        public const string TOOLTIP_BHT_TERMINAL = "TC004C";//BHT IDコンボ
        public const string TOOLTIP_HIDE_PASSWORD = "TC005B";//パスワード（非表示）
        public const string TOOLTIP_SHOW_PASSWORD = "TC006B";//パスワード（表示）
        public const string TOOLTIP_SAVE_PASSWORD = "TC007C";//保存時のパスワード保存チェック
        public const string TOOLTIP_SCALING = "TC008C";//拡大縮小率
        public const string TOOLTIP_CONNECT = "TC009B";//接続ボタン
        public const string TOOLTIP_ASSISTANT_DESCRIPTION = "TC010C";//動作モード説明（ASSISTANT）
        public const string TOOLTIP_DESKTOP_DESCRIPTION = "TC011C";//動作モード説明（DESKTOP）
        public const string TOOLTIP_VIEW_DESCRIPTION = "TC012C";//動作モード説明（VIEW）
        // BHT表示画面
        public const string TOOLTIP_RECONNECT = "TB001B";//再接続ボタン
        public const string TOOLTIP_DISCONNECT = "TB002B";//切断ボタン
        public const string TOOLTIP_TERMINAL_KEY_AND_MODE_SWITCH_KEY = "TB003B";//端末/動作モード切替画面表示
        public const string TOOLTIP_BACK = "TB004B";//バックボタン
        public const string TOOLTIP_HOMEPAGE = "TB005B";//ホームボタン
        public const string TOOLTIP_MULTI_TASK = "TB006B";//マルチタスクボタン
        public const string TOOLTIP_ASSISTANT = "TB007I";//アシスタントモード
        public const string TOOLTIP_DESKTOP = "TB008I";//デスクトップモード
        public const string TOOLTIP_VIEW = "TB009I";//閲覧モード
        // 接続状態
        public const string TOOLTIP_CONNECT_INFO_CONNECT = "TB010I";//接続中
        public const string TOOLTIP_CONNECT_INFO_DISCONNECT = "TB011I";//切断中
        // 端末キーと動作モード変更キーの選択画面
        public const string TOOLTIP_CONNECT_SWITCH_KEY_SCREEN = "TS001S";//特殊キー選択画面タイトル
        public const string TOOLTIP_CONNECT_SWITCH_KEY_SCREEN_PGUP = "TS001B";//ウェイクアップボタン
        public const string TOOLTIP_CONNECT_SWITCH_KEY_SCREEN_PGDN = "TS002B";//スリープボタン
        public const string TOOLTIP_CONNECT_SWITCH_KEY_SCREEN_SCAN = "TS003B";//スキャンボタン
        public const string TOOLTIP_CONNECT_SWITCH_KEY_SCREEN_APP_REBOOT = "TS008B";//アプリ再起動ボタン
        public const string TOOLTIP_CONNECT_SWITCH_KEY_SCREEN_BHT_REBOOT = "TS009B";//BHT再起動ボタン

        public const string TOOLTIP_CONNECT_SWITCH_MODE_SCREEN = "TS007S";//モード切替選択画面タイトル
        public const string TOOLTIP_CONNECT_SWITCH_KEY_SCREEN_ASSISTANT = "TS004B";//アシスタントモードボタン
        public const string TOOLTIP_CONNECT_SWITCH_KEY_SCREEN_DESKTOP = "TS005B";//デスクトップモードボタン
        public const string TOOLTIP_CONNECT_SWITCH_KEY_SCREEN_VIEW = "TS006B";//閲覧モードボタン
    }

}
