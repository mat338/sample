﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DWRemoteCommunication
{
    /*
     * 言語（英語）定義
     */
    public class LanguageConstantsEng
    {
        // 接続設定画面　項目名称
        private const string SCREEN_ITEM_CONNECT_INFO = "Connection information items";
        private const string SCREEN_ITEM_BHT_ID = " BHT ID";
        private const string SCREEN_ITEM_HOST = " Host";
        private const string SCREEN_ITEM_PORT = " Port";
        private const string SCREEN_ITEM_PASSWORD = " Password";
        private const string SCREEN_ITEM_OPTION = "Setting items";
        private const string SCREEN_ITEM_SCALE = " Scale(%)";
        private const string SCREEN_ITEM_MODE = " Mode";
        private const string SCREEN_ITEM_ERROR_TITLE = " Error:";
        private const string SCREEN_ITEM_CONNECT = "Connect";


        // Error Message
        // 入力エラー
        private const string ERROR_MESSAGE_INPUT_REQUIRED = " is required input.";// 必須入力チェック
        private const string ERROR_MESSAGE_INPUT_PORT = "Please enter port number from 1024 to 65535.";// 未入力チェック、数値チェック、範囲（0～65536）チェック
        private const string ERROR_MESSAGE_INPUT_RAITO = "Scale must be in the range of 50 to 250.";// 拡大縮小率不正入力
        private const string ERROR_MESSAGE_NOT_README_FILE = "Failed to start because the file does not exist.  If installation files are insufficient please repair the application from the installer.";// ファイルが存在しないため起動に失敗しました。 インストールファイルが不足している場合はインストーラーからアプリの修復を行って下さい。
        private const string MESSAGE_SETTING_FILE_SAVE = "Successfully saved to the connection setting file.";// 接続設定ファイルへ保存することに成功しました。
        private const string MESSAGE_SETTING_FILE_NOT_SAVE = "Failed to save to connection setting file. Please close it if connection setting file is open.";// 接続設定ファイルへの保存に失敗しました。接続設定ファイルを開いている場合は閉じてください。
        private const string MESSAGE_APPLICATION_EXIT = "Exit the application. Is it OK?";// アプリケーションを終了します。よろしいですか？
        // 接続エラー
        private const string ERROR_MESSAGE_SERVER_NOT_FOUND = "Could not connect to the server. Please check IP address, port number, server application is running.";// サーバーへの接続に失敗（IP、Port不正）
        private const string ERROR_MESSAGE_PRODUCT_INIT_FAIL = "Communication initialization error. Please re-install the application if it occurs even after reconnecting.";//通信の初期化エラー。再接続後も発生する場合はアプリを再インストールして下さい。
        private const string ERROR_MESSAGE_PRODUCT_CHECK_FAIL = "Product authentication error. Please restart the server application.";// 製品認証エラー。サーバーアプリを再起動してください。
        private const string ERROR_MESSAGE_PASSWORD_CHECK = "Password authentication failed. Please enter the correct password.";// パスワードチェックエラー サーバ作成メッセージ
        private const string ERROR_MESSAGE_LOG_OUTPUT_FAIL = "Connection failed because log output failed. Please close it if the log file is open.";// ユーザがエディタ等でログファイルを開いている場合
        // 切断エラー
        private const string ERROR_MESSAGE_SERVER_DISCONNECTED = "The connection with the server has been disconnected. Please check if the server application is running.";// End Of Stream サーバー停止、端末再起動などはEndOfStreamでエラーが返る
        private const string ERROR_MESSAGE_NET_DOWN = "Network down error. Please connect after the network is restored.";// ネットワークダウンエラー。ネットワークが復旧してから接続して下さい。
        private const string ERROR_MESSAGE_NET_RESET = "Forced disconnect error. Please check whether the server application is running.";// 強制切断エラー。サーバアプリが起動しているか確認をして下さい。
        private const string ERROR_MESSAGE_CON_ABORTED = "Timeout or protocol error. Please check the status of the network.";// タイムアウトまたはプロトコルエラー。ネットワークの状態を確認して下さい。
        private const string ERROR_MESSAGE_NO_BUFS = "System memory error. Restart the application.";// システムのメモリエラー。アプリケーションを再起動して下さい。
        private const string ERROR_MESSAGE_TIME_OUT_ERROR = "The connection did not respond after a certain period of time. Check the network status and restart the server application.";// 接続が一定の時間を過ぎても応答しませんでした。ネットワークの状態を確認し、サーバアプリを再起動して下さい。
        private const string ERROR_MESSAGE_FORCED_DISCONNECTED = "Another user connected to the connected server, so it was disconnected.";//接続済みのサーバーに別ユーザーが接続したため切断されました。
        private const string ERROR_MESSAGE_SESSION_DISCONNECTED = "The server application timed out, so I disconnected it.";//サーバーアプリケーションがタイムアウトしたため切断しました。

        // ToolTip
        // 接続設定画面
        private const string TOOLTIP_SAVE = "Connect Settings File Save";
        private const string TOOLTIP_EDIT = "Connect Settings File Edit";
        private const string TOOLTIP_HELP = "Help";
        private const string TOOLTIP_BHT_TERMINAL = "Please enter a name to identify the BHT terminal";
        private const string TOOLTIP_HIDE_PASSWORD = "Hide Password";
        private const string TOOLTIP_SHOW_PASSWORD = "Show Password";
        private const string TOOLTIP_SAVE_PASSWORD = "Check to save password in connect setteings file";
        private const string TOOLTIP_SCALING = "The scaling factor is valid from 50 to 260%";
        private const string TOOLTIP_CONNECT = "Connect with the above setting contents";
        private const string TOOLTIP_ASSISTANT_DESCRIPTION = "Operable with both BHT and PC";
        private const string TOOLTIP_DESKTOP_DESCRIPTION = "BHT terminal inoperable";
        private const string TOOLTIP_VIEW_DESCRIPTION = "PC can only browse";
        // BHT表示画面
        private const string TOOLTIP_RECONNECT = "Reconnect";
        private const string TOOLTIP_DISCONNECT = "Disconnect";
        private const string TOOLTIP_TERMINAL_KEY_AND_MODE_SWITCH_KEY = "BHT terminal transmission key list";
        private const string TOOLTIP_BACK = "Back(End)";
        private const string TOOLTIP_HOMEPAGE = "Homepage (Home)";
        private const string TOOLTIP_MULTI_TASK = "Multi Task (Insert)";
        private const string TOOLTIP_ASSISTANT = "Assistant";
        private const string TOOLTIP_DESKTOP = "Desktop";
        private const string TOOLTIP_VIEW = "View";
        private const string TOOLTIP_CONNECT_INFO_CONNECT = "connecting";
        private const string TOOLTIP_CONNECT_INFO_DISCONNECT = "Cutting";
        // BHT端末送信キー画面
        private const string TOOLTIP_CONNECT_SWITCH_KEY_SCREEN = "BHT terminal transmit key";
        private const string TOOLTIP_CONNECT_SWITCH_KEY_SCREEN_PGUP = "Wake up(PgUp)";
        private const string TOOLTIP_CONNECT_SWITCH_KEY_SCREEN_PGDN = "Sleep(PgDn)";
        private const string TOOLTIP_CONNECT_SWITCH_KEY_SCREEN_SCAN = "Scan(F2)";
        private const string TOOLTIP_CONNECT_SWITCH_KEY_SCREEN_APP_REBOOT = "Restart the server(F11)";//アプリ再起動ボタン
        private const string TOOLTIP_CONNECT_SWITCH_KEY_SCREEN_BHT_REBOOT = "BHT terminal restart(F12)";//BHT再起動ボタン

        private const string TOOLTIP_CONNECT_SWITCH_MODE_SCREEN = "Mode switching selection";//モード切替選択画面タイトル
        private const string TOOLTIP_CONNECT_SWITCH_KEY_SCREEN_ASSISTANT = "Assistant(F6)";
        private const string TOOLTIP_CONNECT_SWITCH_KEY_SCREEN_DESKTOP = "Desktop(F7)";
        private const string TOOLTIP_CONNECT_SWITCH_KEY_SCREEN_VIEW = "View(F8)";

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public LanguageConstantsEng()
        {
        }

        /// <summary>
        /// OSの設定言語の画面項目名一覧を返す
        /// </summary>
        public Dictionary<string, string> getScreenItem()
        {
            Dictionary<string, string> ScreenDictionary = new Dictionary<string, string>();
            // 画面項目
            ScreenDictionary.Add(LanguageConstantsNumber.SCREEN_ITEM_CONNECT_INFO, SCREEN_ITEM_CONNECT_INFO);
            ScreenDictionary.Add(LanguageConstantsNumber.SCREEN_ITEM_BHT_ID, SCREEN_ITEM_BHT_ID);
            ScreenDictionary.Add(LanguageConstantsNumber.SCREEN_ITEM_HOST, SCREEN_ITEM_HOST);
            ScreenDictionary.Add(LanguageConstantsNumber.SCREEN_ITEM_PORT, SCREEN_ITEM_PORT);
            ScreenDictionary.Add(LanguageConstantsNumber.SCREEN_ITEM_PASSWORD, SCREEN_ITEM_PASSWORD);
            ScreenDictionary.Add(LanguageConstantsNumber.SCREEN_ITEM_OPTION, SCREEN_ITEM_OPTION);
            ScreenDictionary.Add(LanguageConstantsNumber.SCREEN_ITEM_SCALE, SCREEN_ITEM_SCALE);
            ScreenDictionary.Add(LanguageConstantsNumber.SCREEN_ITEM_MODE, SCREEN_ITEM_MODE);
            ScreenDictionary.Add(LanguageConstantsNumber.SCREEN_ITEM_ERROR_TITLE, SCREEN_ITEM_ERROR_TITLE);
            ScreenDictionary.Add(LanguageConstantsNumber.SCREEN_ITEM_CONNECT, SCREEN_ITEM_CONNECT);

            return ScreenDictionary;
        }

        /// <summary>
        /// OSの設定言語のメッセージ一覧を返す
        /// </summary>
        public Dictionary<string, string> getMessage()
        {
            Dictionary<string, string> MessageDictionary = new Dictionary<string, string>();
            // 入力エラー
            MessageDictionary.Add(LanguageConstantsNumber.ERROR_MESSAGE_INPUT_REQUIRED, ERROR_MESSAGE_INPUT_REQUIRED);
            MessageDictionary.Add(LanguageConstantsNumber.ERROR_MESSAGE_INPUT_PORT, ERROR_MESSAGE_INPUT_PORT);
            MessageDictionary.Add(LanguageConstantsNumber.ERROR_MESSAGE_INPUT_RAITO, ERROR_MESSAGE_INPUT_RAITO);
            MessageDictionary.Add(LanguageConstantsNumber.ERROR_MESSAGE_NOT_README_FILE, ERROR_MESSAGE_NOT_README_FILE);
            // 接続エラー
            MessageDictionary.Add(LanguageConstantsNumber.ERROR_MESSAGE_SERVER_NOT_FOUND, ERROR_MESSAGE_SERVER_NOT_FOUND);
            MessageDictionary.Add(LanguageConstantsNumber.ERROR_MESSAGE_PRODUCT_INIT_FAIL, ERROR_MESSAGE_PRODUCT_INIT_FAIL);
            MessageDictionary.Add(LanguageConstantsNumber.ERROR_MESSAGE_PRODUCT_CHECK_FAIL, ERROR_MESSAGE_PRODUCT_CHECK_FAIL);
            MessageDictionary.Add(LanguageConstantsNumber.ERROR_MESSAGE_PASSWORD_CHECK, ERROR_MESSAGE_PASSWORD_CHECK);
            MessageDictionary.Add(LanguageConstantsNumber.ERROR_MESSAGE_LOG_OUTPUT_FAIL, ERROR_MESSAGE_LOG_OUTPUT_FAIL);
            // 切断エラー
            MessageDictionary.Add(LanguageConstantsNumber.ERROR_MESSAGE_SERVER_DISCONNECTED, ERROR_MESSAGE_SERVER_DISCONNECTED);
            MessageDictionary.Add(LanguageConstantsNumber.ERROR_MESSAGE_NET_DOWN, ERROR_MESSAGE_NET_DOWN);
            MessageDictionary.Add(LanguageConstantsNumber.ERROR_MESSAGE_NET_RESET, ERROR_MESSAGE_NET_RESET);
            MessageDictionary.Add(LanguageConstantsNumber.ERROR_MESSAGE_CON_ABORTED, ERROR_MESSAGE_CON_ABORTED);
            MessageDictionary.Add(LanguageConstantsNumber.ERROR_MESSAGE_NO_BUFS, ERROR_MESSAGE_NO_BUFS);
            MessageDictionary.Add(LanguageConstantsNumber.ERROR_MESSAGE_TIME_OUT_ERROR, ERROR_MESSAGE_TIME_OUT_ERROR);
            MessageDictionary.Add(LanguageConstantsNumber.ERROR_MESSAGE_FORCED_DISCONNECTED, ERROR_MESSAGE_FORCED_DISCONNECTED);
            MessageDictionary.Add(LanguageConstantsNumber.ERROR_MESSAGE_SESSION_DISCONNECTED, ERROR_MESSAGE_SESSION_DISCONNECTED);
            // 接続情報設定ファイル
            MessageDictionary.Add(LanguageConstantsNumber.MESSAGE_SETTING_FILE_SAVE, MESSAGE_SETTING_FILE_SAVE);
            MessageDictionary.Add(LanguageConstantsNumber.MESSAGE_SETTING_FILE_NOT_SAVE, MESSAGE_SETTING_FILE_NOT_SAVE);
            MessageDictionary.Add(LanguageConstantsNumber.MESSAGE_APPLICATION_EXIT, MESSAGE_APPLICATION_EXIT);

            return MessageDictionary;
        }

        /// <summary>
        /// OSの設定言語のTooltip一覧を返す
        /// </summary>
        public Dictionary<string, string> getTooltip()
        {
            Dictionary<string, string> TooltipDictionary = new Dictionary<string, string>();
            // 接続設定画面
            TooltipDictionary.Add(LanguageConstantsNumber.TOOLTIP_SAVE, TOOLTIP_SAVE);
            TooltipDictionary.Add(LanguageConstantsNumber.TOOLTIP_EDIT, TOOLTIP_EDIT);
            TooltipDictionary.Add(LanguageConstantsNumber.TOOLTIP_HELP, TOOLTIP_HELP);
            TooltipDictionary.Add(LanguageConstantsNumber.TOOLTIP_BHT_TERMINAL, TOOLTIP_BHT_TERMINAL);
            TooltipDictionary.Add(LanguageConstantsNumber.TOOLTIP_HIDE_PASSWORD, TOOLTIP_HIDE_PASSWORD);
            TooltipDictionary.Add(LanguageConstantsNumber.TOOLTIP_SHOW_PASSWORD, TOOLTIP_SHOW_PASSWORD);
            TooltipDictionary.Add(LanguageConstantsNumber.TOOLTIP_SAVE_PASSWORD, TOOLTIP_SAVE_PASSWORD);
            TooltipDictionary.Add(LanguageConstantsNumber.TOOLTIP_SCALING, TOOLTIP_SCALING);
            TooltipDictionary.Add(LanguageConstantsNumber.TOOLTIP_CONNECT, TOOLTIP_CONNECT);
            TooltipDictionary.Add(LanguageConstantsNumber.TOOLTIP_ASSISTANT_DESCRIPTION, TOOLTIP_ASSISTANT_DESCRIPTION);
            TooltipDictionary.Add(LanguageConstantsNumber.TOOLTIP_DESKTOP_DESCRIPTION, TOOLTIP_DESKTOP_DESCRIPTION);
            TooltipDictionary.Add(LanguageConstantsNumber.TOOLTIP_VIEW_DESCRIPTION, TOOLTIP_VIEW_DESCRIPTION);
            // BHT表示画面
            TooltipDictionary.Add(LanguageConstantsNumber.TOOLTIP_RECONNECT, TOOLTIP_RECONNECT);
            TooltipDictionary.Add(LanguageConstantsNumber.TOOLTIP_DISCONNECT, TOOLTIP_DISCONNECT);
            TooltipDictionary.Add(LanguageConstantsNumber.TOOLTIP_TERMINAL_KEY_AND_MODE_SWITCH_KEY, TOOLTIP_TERMINAL_KEY_AND_MODE_SWITCH_KEY);
            TooltipDictionary.Add(LanguageConstantsNumber.TOOLTIP_BACK, TOOLTIP_BACK);
            TooltipDictionary.Add(LanguageConstantsNumber.TOOLTIP_HOMEPAGE, TOOLTIP_HOMEPAGE);
            TooltipDictionary.Add(LanguageConstantsNumber.TOOLTIP_MULTI_TASK, TOOLTIP_MULTI_TASK);
            TooltipDictionary.Add(LanguageConstantsNumber.TOOLTIP_ASSISTANT, TOOLTIP_ASSISTANT);
            TooltipDictionary.Add(LanguageConstantsNumber.TOOLTIP_DESKTOP, TOOLTIP_DESKTOP);
            TooltipDictionary.Add(LanguageConstantsNumber.TOOLTIP_VIEW, TOOLTIP_VIEW);
            TooltipDictionary.Add(LanguageConstantsNumber.TOOLTIP_CONNECT_INFO_CONNECT, TOOLTIP_CONNECT_INFO_CONNECT);
            TooltipDictionary.Add(LanguageConstantsNumber.TOOLTIP_CONNECT_INFO_DISCONNECT, TOOLTIP_CONNECT_INFO_DISCONNECT);
            // 端末キーと動作モード変更キーの選択画面
            TooltipDictionary.Add(LanguageConstantsNumber.TOOLTIP_CONNECT_SWITCH_KEY_SCREEN, TOOLTIP_CONNECT_SWITCH_KEY_SCREEN);
            TooltipDictionary.Add(LanguageConstantsNumber.TOOLTIP_CONNECT_SWITCH_KEY_SCREEN_PGUP, TOOLTIP_CONNECT_SWITCH_KEY_SCREEN_PGUP);
            TooltipDictionary.Add(LanguageConstantsNumber.TOOLTIP_CONNECT_SWITCH_KEY_SCREEN_PGDN, TOOLTIP_CONNECT_SWITCH_KEY_SCREEN_PGDN);
            TooltipDictionary.Add(LanguageConstantsNumber.TOOLTIP_CONNECT_SWITCH_KEY_SCREEN_SCAN, TOOLTIP_CONNECT_SWITCH_KEY_SCREEN_SCAN);
            TooltipDictionary.Add(LanguageConstantsNumber.TOOLTIP_CONNECT_SWITCH_KEY_SCREEN_APP_REBOOT, TOOLTIP_CONNECT_SWITCH_KEY_SCREEN_APP_REBOOT);
            TooltipDictionary.Add(LanguageConstantsNumber.TOOLTIP_CONNECT_SWITCH_KEY_SCREEN_BHT_REBOOT, TOOLTIP_CONNECT_SWITCH_KEY_SCREEN_BHT_REBOOT);

            TooltipDictionary.Add(LanguageConstantsNumber.TOOLTIP_CONNECT_SWITCH_MODE_SCREEN, TOOLTIP_CONNECT_SWITCH_MODE_SCREEN);
            TooltipDictionary.Add(LanguageConstantsNumber.TOOLTIP_CONNECT_SWITCH_KEY_SCREEN_ASSISTANT, TOOLTIP_CONNECT_SWITCH_KEY_SCREEN_ASSISTANT);
            TooltipDictionary.Add(LanguageConstantsNumber.TOOLTIP_CONNECT_SWITCH_KEY_SCREEN_DESKTOP, TOOLTIP_CONNECT_SWITCH_KEY_SCREEN_DESKTOP);
            TooltipDictionary.Add(LanguageConstantsNumber.TOOLTIP_CONNECT_SWITCH_KEY_SCREEN_VIEW, TOOLTIP_CONNECT_SWITCH_KEY_SCREEN_VIEW);

            return TooltipDictionary;
        }
    }
}
