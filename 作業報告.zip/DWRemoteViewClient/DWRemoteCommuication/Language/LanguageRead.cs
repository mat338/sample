﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;

namespace DWRemoteCommunication
{
    /*
     * 言語設定処理
     */
    public class LanguageRead
    {
        /* 各国言語 */
        public const string OS_LANGUEGE_JPN = "ja-JP";//日本語
        public const string OS_LANGUEGE_US_ENG = "en-US";//英語（アメリカ）
        public const string OS_LANGUEGE_UK_ENG = "en-GB";//英語（英国）

        private string nation;

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public LanguageRead()
        {
            this.nation = CultureInfo.CurrentCulture.Name;
        }

        /// <summary>
        /// 画面項目一覧を取得する
        /// </summary>
        public Dictionary<string, string> GetScreen()
        {
            Dictionary<string, string> ScreenDictionary = null;

            try
            {
                switch (this.nation)
                {
                    // 日本語
                    case OS_LANGUEGE_JPN:
                        LanguageConstantsJpn srnDicJpn = new LanguageConstantsJpn();
                        ScreenDictionary = srnDicJpn.getScreenItem();
                        break;
                    // 英語
                    case OS_LANGUEGE_US_ENG:
                    case OS_LANGUEGE_UK_ENG:
                        LanguageConstantsEng srnDicEng = new LanguageConstantsEng();
                        ScreenDictionary = srnDicEng.getScreenItem();
                        break;
                    // その他（英語）
                    default:
                        LanguageConstantsEng srnDicOth = new LanguageConstantsEng();
                        ScreenDictionary = srnDicOth.getScreenItem();
                        break;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }

            return ScreenDictionary;
        }

        /// <summary>
        /// メッセージ一覧を取得する
        /// </summary>
        public Dictionary<string, string> GetMessage()
        {
            Dictionary<string, string> MessageDictionary = null;

            try
            {
                switch (this.nation)
                {
                    // 日本語
                    case OS_LANGUEGE_JPN:
                        LanguageConstantsJpn msgDicJpn = new LanguageConstantsJpn();
                        MessageDictionary = msgDicJpn.getMessage();
                        break;
                    // 英語
                    case OS_LANGUEGE_US_ENG:
                    case OS_LANGUEGE_UK_ENG:
                        LanguageConstantsEng msgDicEng = new LanguageConstantsEng();
                        MessageDictionary = msgDicEng.getMessage();
                        break;
                    // その他（英語）
                    default:
                        LanguageConstantsEng msgDicOth = new LanguageConstantsEng();
                        MessageDictionary = msgDicOth.getMessage();
                        break;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }

            return MessageDictionary;
        }

        /// <summary>
        /// ToolTip一覧を取得する
        /// </summary>
        public Dictionary<string, string> GetToolTip()
        {
            Dictionary<string, string> TooltipDictionary = null;

            try
            {
                switch (this.nation)
                {
                    // 日本語
                    case OS_LANGUEGE_JPN:
                        LanguageConstantsJpn msgDicJpn = new LanguageConstantsJpn();
                        TooltipDictionary = msgDicJpn.getTooltip();
                        break;
                    // 英語
                    case OS_LANGUEGE_US_ENG:
                    case OS_LANGUEGE_UK_ENG:
                        LanguageConstantsEng msgDicEng = new LanguageConstantsEng();
                        TooltipDictionary = msgDicEng.getTooltip();
                        break;
                    // その他（英語）
                    default:
                        LanguageConstantsEng msgDicOth = new LanguageConstantsEng();
                        TooltipDictionary = msgDicOth.getTooltip();
                        break;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }

            return TooltipDictionary;
        }

    }
}
