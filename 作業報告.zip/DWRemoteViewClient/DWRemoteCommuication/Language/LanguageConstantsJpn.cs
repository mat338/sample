﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DWRemoteCommunication
{
    /*
     * 言語（日本語）定義
     */
    public class LanguageConstantsJpn
    {
        // 接続設定画面　項目名称
        private const string SCREEN_ITEM_CONNECT_INFO = "接続情報項目";
        private const string SCREEN_ITEM_BHT_ID = " BHT ID";
        private const string SCREEN_ITEM_HOST = " ホスト";
        private const string SCREEN_ITEM_PORT = " ポート";
        private const string SCREEN_ITEM_PASSWORD = " パスワード";
        private const string SCREEN_ITEM_OPTION = " 設定項目";
        private const string SCREEN_ITEM_SCALE = " スケール(%)";
        private const string SCREEN_ITEM_MODE = " モード";
        private const string SCREEN_ITEM_ERROR_TITLE = " エラー:";
        private const string SCREEN_ITEM_CONNECT = "接続";

        // Error Message
        // 入力エラー
        private const string ERROR_MESSAGE_INPUT_REQUIRED = "は必須入力です。";//CU001W
        private const string ERROR_MESSAGE_INPUT_PORT = "ポート番号は1024から65535の範囲で入力して下さい。";//CU002W
        private const string ERROR_MESSAGE_INPUT_RAITO = "スケールは50から250の範囲で入力して下さい。";//CU003W
        private const string ERROR_MESSAGE_NOT_README_FILE = "ファイルが存在しないため起動に失敗しました。 インストールファイルが不足している場合はインストーラーからアプリの修復を行って下さい。";//CU004W
        // 接続情報設定ファイル
        private const string MESSAGE_SETTING_FILE_SAVE = "接続設定ファイルへ保存することに成功しました。";//CU005C
        private const string MESSAGE_SETTING_FILE_NOT_SAVE = "接続設定ファイルへの保存に失敗しました。接続設定ファイルを開いている場合は閉じて下さい。";//CU006W
        private const string MESSAGE_APPLICATION_EXIT = "アプリケーションを終了します。よろしいですか？";// アプリケーションを終了します。よろしいですか？
        // 接続エラー
        private const string ERROR_MESSAGE_SERVER_NOT_FOUND = "サーバーに接続することができませんでした。IPアドレスやポート番号、サーバーアプリケーションが起動しているか確認をして下さい。";//CC001W
        private const string ERROR_MESSAGE_PRODUCT_INIT_FAIL = "通信の初期化エラー。再接続後も発生する場合はアプリを再インストールして下さい。";//CC002E
        private const string ERROR_MESSAGE_PRODUCT_CHECK_FAIL = "製品認証エラー。サーバーアプリを再起動してください。";//CC003E
        private const string ERROR_MESSAGE_PASSWORD_CHECK = "パスワードの認証に失敗しました。正しいパスワードを入力して下さい。";//CC004W
        private const string ERROR_MESSAGE_LOG_OUTPUT_FAIL = "ログ出力に失敗したため、接続に失敗しました。 ログファイルが開いている場合は閉じて下さい。";//CU005W
        // 切断エラー
        private const string ERROR_MESSAGE_SERVER_DISCONNECTED = "サーバーとの接続が切断されました。サーバーアプリケーションが起動しているか確認をして下さい。";//CD001W
        private const string ERROR_MESSAGE_NET_DOWN = "ネットワークダウンによるエラー。ネットワークが復旧してから接続して下さい。";//CD002E
        private const string ERROR_MESSAGE_NET_RESET = "強制切断エラー。サーバーアプリケーションが起動しているか確認をして下さい。";//CD003E
        private const string ERROR_MESSAGE_CON_ABORTED = "タイムアウトまたはプロトコルエラー。ネットワークの状態を確認して下さい。";//CD004E
        private const string ERROR_MESSAGE_NO_BUFS = "システムのメモリエラー。アプリケーションを再起動して下さい。";//CD005E
        private const string ERROR_MESSAGE_TIME_OUT_ERROR = "接続が一定の時間を過ぎても応答しませんでした。ネットワークの状態を確認し、サーバーアプリケーションを再起動して下さい。";//CD006W
        private const string ERROR_MESSAGE_FORCED_DISCONNECTED = "接続済みのサーバーに別ユーザーが接続したため切断しました。";//CD007C
        private const string ERROR_MESSAGE_SESSION_DISCONNECTED = "サーバーアプリケーションがタイムアウトしたため切断しました。";//CD008C

        // ToolTip
        // 接続設定画面
        private const string TOOLTIP_SAVE = "接続設定ファイルを保存";
        private const string TOOLTIP_EDIT = "接続設定ファイルを編集";
        private const string TOOLTIP_HELP = "ヘルプ";
        private const string TOOLTIP_BHT_TERMINAL = "BHT端末を識別する名称を入力して下さい";
        private const string TOOLTIP_HIDE_PASSWORD = "パスワードの非表示";
        private const string TOOLTIP_SHOW_PASSWORD = "パスワードの表示";
        private const string TOOLTIP_SAVE_PASSWORD = "接続設定ファイルにパスワードを保存する場合はチェックして下さい";
        private const string TOOLTIP_SCALING = "拡大縮小率は50%から260％まで入力できます";
        private const string TOOLTIP_CONNECT = "上記設定内容で接続する";
        private const string TOOLTIP_ASSISTANT_DESCRIPTION = "BHTとPCの両方の端末で操作可能";
        private const string TOOLTIP_DESKTOP_DESCRIPTION = "BHT端末は非表示になり操作不能";
        private const string TOOLTIP_VIEW_DESCRIPTION = "PC端末は閲覧のみ可能";
        // BHT表示画面
        private const string TOOLTIP_RECONNECT = "再接続";
        private const string TOOLTIP_DISCONNECT = "切断";
        private const string TOOLTIP_TERMINAL_KEY_AND_MODE_SWITCH_KEY = "BHT端末送信キーリスト";
        private const string TOOLTIP_BACK = "戻る(End)";
        private const string TOOLTIP_HOMEPAGE = "ホーム (Home)";
        private const string TOOLTIP_MULTI_TASK = "マルチタスク (Insert)";
        private const string TOOLTIP_ASSISTANT = "アシスタントモード";
        private const string TOOLTIP_DESKTOP = "デスクトップモード";
        private const string TOOLTIP_VIEW = "閲覧モード";
        private const string TOOLTIP_CONNECT_INFO_CONNECT = "接続中";
        private const string TOOLTIP_CONNECT_INFO_DISCONNECT = "切断中";
        // BHT端末送信キー画面
        private const string TOOLTIP_CONNECT_SWITCH_KEY_SCREEN = "BHT端末送信キー";
        private const string TOOLTIP_CONNECT_SWITCH_KEY_SCREEN_PGUP = "ウェイクアップ(PgUp)";
        private const string TOOLTIP_CONNECT_SWITCH_KEY_SCREEN_PGDN = "スリープ(PgDn)";
        private const string TOOLTIP_CONNECT_SWITCH_KEY_SCREEN_SCAN = "スキャン(F2)";
        private const string TOOLTIP_CONNECT_SWITCH_KEY_SCREEN_APP_REBOOT = "サーバー再起動(F11)";//アプリ再起動ボタン
        private const string TOOLTIP_CONNECT_SWITCH_KEY_SCREEN_BHT_REBOOT = "BHT端末再起動(F12)";//BHT再起動ボタン

        private const string TOOLTIP_CONNECT_SWITCH_MODE_SCREEN = "モード切替選択";//モード切替選択画面タイトル
        private const string TOOLTIP_CONNECT_SWITCH_KEY_SCREEN_ASSISTANT = "アシスタントモード(F6)";
        private const string TOOLTIP_CONNECT_SWITCH_KEY_SCREEN_DESKTOP = "デスクトップモード(F7)";
        private const string TOOLTIP_CONNECT_SWITCH_KEY_SCREEN_VIEW = "閲覧モード(F8)";

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public LanguageConstantsJpn()
        {
        }

        /// <summary>
        /// OSの設定言語の画面項目名一覧を返す
        /// </summary>
        public Dictionary<string, string> getScreenItem()
        {
            Dictionary<string, string> ScreenDictionary = new Dictionary<string, string>();
            // 画面項目
            ScreenDictionary.Add(LanguageConstantsNumber.SCREEN_ITEM_CONNECT_INFO, SCREEN_ITEM_CONNECT_INFO);
            ScreenDictionary.Add(LanguageConstantsNumber.SCREEN_ITEM_BHT_ID, SCREEN_ITEM_BHT_ID);
            ScreenDictionary.Add(LanguageConstantsNumber.SCREEN_ITEM_HOST, SCREEN_ITEM_HOST);
            ScreenDictionary.Add(LanguageConstantsNumber.SCREEN_ITEM_PORT, SCREEN_ITEM_PORT);
            ScreenDictionary.Add(LanguageConstantsNumber.SCREEN_ITEM_PASSWORD, SCREEN_ITEM_PASSWORD);
            ScreenDictionary.Add(LanguageConstantsNumber.SCREEN_ITEM_OPTION, SCREEN_ITEM_OPTION);
            ScreenDictionary.Add(LanguageConstantsNumber.SCREEN_ITEM_SCALE, SCREEN_ITEM_SCALE);
            ScreenDictionary.Add(LanguageConstantsNumber.SCREEN_ITEM_MODE, SCREEN_ITEM_MODE);
            ScreenDictionary.Add(LanguageConstantsNumber.SCREEN_ITEM_ERROR_TITLE, SCREEN_ITEM_ERROR_TITLE);
            ScreenDictionary.Add(LanguageConstantsNumber.SCREEN_ITEM_CONNECT, SCREEN_ITEM_CONNECT);

            return ScreenDictionary;
        }

        /// <summary>
        /// OSの設定言語のメッセージ一覧を返す
        /// </summary>
        public Dictionary<string, string> getMessage()
        {
            Dictionary<string, string> MessageDictionary = new Dictionary<string, string>();
            // 入力エラー
            MessageDictionary.Add(LanguageConstantsNumber.ERROR_MESSAGE_INPUT_REQUIRED, ERROR_MESSAGE_INPUT_REQUIRED);
            MessageDictionary.Add(LanguageConstantsNumber.ERROR_MESSAGE_INPUT_PORT, ERROR_MESSAGE_INPUT_PORT);
            MessageDictionary.Add(LanguageConstantsNumber.ERROR_MESSAGE_INPUT_RAITO, ERROR_MESSAGE_INPUT_RAITO);
            MessageDictionary.Add(LanguageConstantsNumber.ERROR_MESSAGE_NOT_README_FILE, ERROR_MESSAGE_NOT_README_FILE);
            // 接続エラー
            MessageDictionary.Add(LanguageConstantsNumber.ERROR_MESSAGE_SERVER_NOT_FOUND, ERROR_MESSAGE_SERVER_NOT_FOUND);
            MessageDictionary.Add(LanguageConstantsNumber.ERROR_MESSAGE_PRODUCT_INIT_FAIL, ERROR_MESSAGE_PRODUCT_INIT_FAIL);
            MessageDictionary.Add(LanguageConstantsNumber.ERROR_MESSAGE_PRODUCT_CHECK_FAIL, ERROR_MESSAGE_PRODUCT_CHECK_FAIL);
            MessageDictionary.Add(LanguageConstantsNumber.ERROR_MESSAGE_PASSWORD_CHECK, ERROR_MESSAGE_PASSWORD_CHECK);
            MessageDictionary.Add(LanguageConstantsNumber.ERROR_MESSAGE_LOG_OUTPUT_FAIL, ERROR_MESSAGE_LOG_OUTPUT_FAIL);
            // 切断エラー
            MessageDictionary.Add(LanguageConstantsNumber.ERROR_MESSAGE_SERVER_DISCONNECTED, ERROR_MESSAGE_SERVER_DISCONNECTED);
            MessageDictionary.Add(LanguageConstantsNumber.ERROR_MESSAGE_NET_DOWN, ERROR_MESSAGE_NET_DOWN);
            MessageDictionary.Add(LanguageConstantsNumber.ERROR_MESSAGE_NET_RESET, ERROR_MESSAGE_NET_RESET);
            MessageDictionary.Add(LanguageConstantsNumber.ERROR_MESSAGE_CON_ABORTED, ERROR_MESSAGE_CON_ABORTED);
            MessageDictionary.Add(LanguageConstantsNumber.ERROR_MESSAGE_NO_BUFS, ERROR_MESSAGE_NO_BUFS);
            MessageDictionary.Add(LanguageConstantsNumber.ERROR_MESSAGE_TIME_OUT_ERROR, ERROR_MESSAGE_TIME_OUT_ERROR);
            MessageDictionary.Add(LanguageConstantsNumber.ERROR_MESSAGE_FORCED_DISCONNECTED, ERROR_MESSAGE_FORCED_DISCONNECTED);
            MessageDictionary.Add(LanguageConstantsNumber.ERROR_MESSAGE_SESSION_DISCONNECTED, ERROR_MESSAGE_SESSION_DISCONNECTED);
            // 接続情報設定ファイル
            MessageDictionary.Add(LanguageConstantsNumber.MESSAGE_SETTING_FILE_SAVE, MESSAGE_SETTING_FILE_SAVE);
            MessageDictionary.Add(LanguageConstantsNumber.MESSAGE_SETTING_FILE_NOT_SAVE, MESSAGE_SETTING_FILE_NOT_SAVE);
            MessageDictionary.Add(LanguageConstantsNumber.MESSAGE_APPLICATION_EXIT, MESSAGE_APPLICATION_EXIT);

            return MessageDictionary;
        }

        /// <summary>
        /// OSの設定言語のTooltip一覧を返す
        /// </summary>
        public Dictionary<string, string> getTooltip()
        {
            Dictionary<string, string> TooltipDictionary = new Dictionary<string, string>();
            // 接続設定画面
            TooltipDictionary.Add(LanguageConstantsNumber.TOOLTIP_SAVE, TOOLTIP_SAVE);
            TooltipDictionary.Add(LanguageConstantsNumber.TOOLTIP_EDIT, TOOLTIP_EDIT);
            TooltipDictionary.Add(LanguageConstantsNumber.TOOLTIP_HELP, TOOLTIP_HELP);
            TooltipDictionary.Add(LanguageConstantsNumber.TOOLTIP_BHT_TERMINAL, TOOLTIP_BHT_TERMINAL);
            TooltipDictionary.Add(LanguageConstantsNumber.TOOLTIP_HIDE_PASSWORD, TOOLTIP_HIDE_PASSWORD);
            TooltipDictionary.Add(LanguageConstantsNumber.TOOLTIP_SHOW_PASSWORD, TOOLTIP_SHOW_PASSWORD);
            TooltipDictionary.Add(LanguageConstantsNumber.TOOLTIP_SAVE_PASSWORD, TOOLTIP_SAVE_PASSWORD);
            TooltipDictionary.Add(LanguageConstantsNumber.TOOLTIP_SCALING, TOOLTIP_SCALING);
            TooltipDictionary.Add(LanguageConstantsNumber.TOOLTIP_CONNECT, TOOLTIP_CONNECT);
            TooltipDictionary.Add(LanguageConstantsNumber.TOOLTIP_ASSISTANT_DESCRIPTION, TOOLTIP_ASSISTANT_DESCRIPTION);
            TooltipDictionary.Add(LanguageConstantsNumber.TOOLTIP_DESKTOP_DESCRIPTION, TOOLTIP_DESKTOP_DESCRIPTION);
            TooltipDictionary.Add(LanguageConstantsNumber.TOOLTIP_VIEW_DESCRIPTION, TOOLTIP_VIEW_DESCRIPTION);
            // BHT表示画面
            TooltipDictionary.Add(LanguageConstantsNumber.TOOLTIP_RECONNECT, TOOLTIP_RECONNECT);
            TooltipDictionary.Add(LanguageConstantsNumber.TOOLTIP_DISCONNECT, TOOLTIP_DISCONNECT);
            TooltipDictionary.Add(LanguageConstantsNumber.TOOLTIP_TERMINAL_KEY_AND_MODE_SWITCH_KEY, TOOLTIP_TERMINAL_KEY_AND_MODE_SWITCH_KEY);
            TooltipDictionary.Add(LanguageConstantsNumber.TOOLTIP_BACK, TOOLTIP_BACK);
            TooltipDictionary.Add(LanguageConstantsNumber.TOOLTIP_HOMEPAGE, TOOLTIP_HOMEPAGE);
            TooltipDictionary.Add(LanguageConstantsNumber.TOOLTIP_MULTI_TASK, TOOLTIP_MULTI_TASK);
            TooltipDictionary.Add(LanguageConstantsNumber.TOOLTIP_ASSISTANT, TOOLTIP_ASSISTANT);
            TooltipDictionary.Add(LanguageConstantsNumber.TOOLTIP_DESKTOP, TOOLTIP_DESKTOP);
            TooltipDictionary.Add(LanguageConstantsNumber.TOOLTIP_VIEW, TOOLTIP_VIEW);
            TooltipDictionary.Add(LanguageConstantsNumber.TOOLTIP_CONNECT_INFO_CONNECT, TOOLTIP_CONNECT_INFO_CONNECT);
            TooltipDictionary.Add(LanguageConstantsNumber.TOOLTIP_CONNECT_INFO_DISCONNECT, TOOLTIP_CONNECT_INFO_DISCONNECT);
            // 端末キーと動作モード変更キーの選択画面
            TooltipDictionary.Add(LanguageConstantsNumber.TOOLTIP_CONNECT_SWITCH_KEY_SCREEN, TOOLTIP_CONNECT_SWITCH_KEY_SCREEN);
            TooltipDictionary.Add(LanguageConstantsNumber.TOOLTIP_CONNECT_SWITCH_KEY_SCREEN_PGUP, TOOLTIP_CONNECT_SWITCH_KEY_SCREEN_PGUP);
            TooltipDictionary.Add(LanguageConstantsNumber.TOOLTIP_CONNECT_SWITCH_KEY_SCREEN_PGDN, TOOLTIP_CONNECT_SWITCH_KEY_SCREEN_PGDN);
            TooltipDictionary.Add(LanguageConstantsNumber.TOOLTIP_CONNECT_SWITCH_KEY_SCREEN_SCAN, TOOLTIP_CONNECT_SWITCH_KEY_SCREEN_SCAN);
            TooltipDictionary.Add(LanguageConstantsNumber.TOOLTIP_CONNECT_SWITCH_KEY_SCREEN_APP_REBOOT, TOOLTIP_CONNECT_SWITCH_KEY_SCREEN_APP_REBOOT);
            TooltipDictionary.Add(LanguageConstantsNumber.TOOLTIP_CONNECT_SWITCH_KEY_SCREEN_BHT_REBOOT, TOOLTIP_CONNECT_SWITCH_KEY_SCREEN_BHT_REBOOT);

            TooltipDictionary.Add(LanguageConstantsNumber.TOOLTIP_CONNECT_SWITCH_MODE_SCREEN, TOOLTIP_CONNECT_SWITCH_MODE_SCREEN);
            TooltipDictionary.Add(LanguageConstantsNumber.TOOLTIP_CONNECT_SWITCH_KEY_SCREEN_ASSISTANT, TOOLTIP_CONNECT_SWITCH_KEY_SCREEN_ASSISTANT);
            TooltipDictionary.Add(LanguageConstantsNumber.TOOLTIP_CONNECT_SWITCH_KEY_SCREEN_DESKTOP, TOOLTIP_CONNECT_SWITCH_KEY_SCREEN_DESKTOP);
            TooltipDictionary.Add(LanguageConstantsNumber.TOOLTIP_CONNECT_SWITCH_KEY_SCREEN_VIEW, TOOLTIP_CONNECT_SWITCH_KEY_SCREEN_VIEW);

            return TooltipDictionary;
        }
    }
}
