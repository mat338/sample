﻿#define logging

using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Threading;

namespace DWRemoteCommunication
{
    /*
     * システムログ出力処理
     */
    public class SystemLog
    {
        /// <summary>排他ロックに使用する object。</summary>
        private static readonly object _syncLock = new object();

        private Logtype _LoggingLevel = Logtype.Debug; //How much logging should be done
        private const int MAX_FILE_SIZE = 1024 * 1024 * 100;//104857600=100MB
        private const int MAX_FFILES = 10;//履歴10ファイル保持

        private string _server;
        private int _port = 0;
        private string filePath;
        private string fileName;
        private string filePathName;

        private Queue<string> LogQueue = new Queue<string>();

        /// <summary>コンストラクタ</summary>
        /// <param name="server">IPアドレス</param>
        /// <param name="port">ポート番号</param>
        public SystemLog(string server, int port, string filePath, string fileName, Logtype logLevel)
        {
            _server = server;
            _port = port;
            _LoggingLevel = logLevel;

            this.filePath = filePath;
            this.fileName = fileName;
            this.filePathName = filePath;

            if (this.filePathName.Substring(this.filePathName.Length - 1) != "\\") this.filePathName += "\\";
            this.filePathName += fileName + "." + Constants.SYSTEM_LOG_FILE_EXTENSION;
        }

#if logging

        /// <summary>
        /// Logging Output Setting
        /// </summary>
        /// <param name="lt">ログ出力タイプ</param>
        /// <param name="lm">ログ出力メッセージ</param>
        public void Log(Logtype lt, string lm)
        {
            if (_LoggingLevel == Logtype.None) return;

            if (LogQueue.Count < Int32.MaxValue)
            {
                if (_LoggingLevel <= lt)
                {
                    string message = null;
                    try
                    {
                        lock (_syncLock)
                        {
                            message = DateTime.Now.ToString() + "." + DateTime.Now.Millisecond.ToString() + "\t" + lt.ToString() + "\t" + _server + "::" + _port + "\t" + lm; ;
                            lock (((ICollection)LogQueue).SyncRoot)
                            {
                                LogQueue.Enqueue(message);
                            }
                        }
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine("message(" + message  + "):" + e.ToString());
                        Thread.Sleep(1000);
                    }
                }
            }
        }

        /// <summary>
        /// Logging Output Events
        /// </summary>
        public void tmrLog_Tick()
        {
            if (_LoggingLevel == Logtype.None) return;

            lock (_syncLock)
            {
                FileStream stream = null;
                StreamWriter sW = null;
                TextWriter writerSync = null;

                try
                {
                    // ディレクトリ存在チェック
                    if (!Directory.Exists(this.filePath))
                    {
                        // ディレクトリがない場合は作成する
                        Directory.CreateDirectory(this.filePath);
                    }

                    // ファイルを排他ロックする
                    using (stream = new FileStream(this.filePathName, FileMode.Append, FileAccess.Write, FileShare.None))
                    using (sW = new StreamWriter(stream))
                    using (writerSync = TextWriter.Synchronized(sW))
                    {
                        while (LogQueue.Count > 0)
                        {
                            writerSync.WriteLine(LogQueue.Dequeue());
                            writerSync.Flush();
                        }
                    }
                }
                catch (IOException)
                {
                    return;
                }
                finally
                {
                    if (writerSync != null)
                    {
                        writerSync.Close();
                        sW.Close();
                        stream.Close();
                    }

                    writerSync = null;
                    sW = null;
                    stream = null;
                }


                // ログファイル圧縮バックアップ
                ZipFileBackup();
            }
        }

        /// <summary>
        /// Create Zip Log File
        /// </summary>
        private void ZipFileBackup()
        {
            // ファイルサイズのチェックを行う
            FileInfo CurrentFile = new FileInfo(this.filePathName);
            // ログファイル存在チェック
            if (CurrentFile.Exists == false)
            {
                CurrentFile = null;
                return;
            }

            if (CurrentFile.Length > MAX_FILE_SIZE)
            {
                // バックアップフォルダ
                string backup = this.filePath + "backup\\";
                // 圧縮日時
                string zipDate = DateTime.Now.ToString("yyyyMMddHHmmss");
                // 圧縮ファイル名
                string zipFileName = this.fileName + "_" + zipDate;
                // 圧縮作業用ディレクトリ名
                string tmpDirectory = backup + "backup_" + zipDate;
                // ログファイルのリネーム名
                string copyFileName = zipFileName + "." + Constants.SYSTEM_LOG_FILE_EXTENSION;

                try
                {
                    // バックアップフォルダの作成
                    if (!Directory.Exists(backup))
                    {
                        Directory.CreateDirectory(backup);
                    }
                    // 圧縮作業用ディレクトリを作成する
                    Directory.CreateDirectory(tmpDirectory);
                    CurrentFile.Directory.Create();
                    // ログファイルをリネームして圧縮作業用ディレクトリに移動する
                    CurrentFile.MoveTo(tmpDirectory + "\\" + copyFileName);
                    // Zip圧縮を行う
                    ZipFile.CreateFromDirectory(tmpDirectory, backup + zipFileName + ".zip");


                    // バックアップフォルダ直下にあるすべてのZipファイルを取得する
                    string[] files = Directory.GetFiles(backup, "*.zip");

                    if (files.Length > MAX_FFILES)
                    {
                        // 取得したすべてのファイルをファイル名でソートする
                        Array.Sort(files);
                        // ソートした結果を表示
                        int count = 0;
                        int delFile = files.Length - MAX_FFILES;
                        foreach (string file in files)
                        {
                            // ファイル名と最終書き込み日時を表示
                            //Console.WriteLine("{0} {1}", File.GetLastWriteTime(file), file);
                            File.Delete(file);

                            count++;
                            if (delFile <= count)
                            {
                                break;
                            }
                        }
                    }

                }
                catch (IOException)
                {
                    // 他プロセスがログ出力中は何もしない
                    // 他プロセスが先にファイル移動を行った場合は何もしない
                    // Console.WriteLine(ioe.ToString());
                }
                finally
                {
                    // 圧縮作業用ディレクトリが作成済みの場合は削除する
                    if (Directory.Exists(tmpDirectory))
                    {
                        Directory.Delete(tmpDirectory, true);
                    }

                    CurrentFile = null;
                }
            }
        }
#else
        private void Log(Logtype lt, string lm) { return; }
#endif

        }
    }