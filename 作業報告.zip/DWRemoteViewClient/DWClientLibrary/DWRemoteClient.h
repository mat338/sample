#pragma once
//#include "stdafx.h"
#include "ClientConnect.h"

extern "C"
{
	__declspec(dllexport) BOOL doConnection(LPCTSTR host, int port, LPCTSTR proxy, int timeout);
	__declspec(dllexport) void CloseConnection();
	__declspec(dllexport) INT32 ReadBytes(BYTE *data, int offset, int size);
	__declspec(dllexport) INT32 writeExact(BYTE *data, int offset, int size);
	__declspec(dllexport) void readHextileRect(BYTE *pixelData, int posX, int posY, int width, int height, bool cryptMode);
//	__declspec(dllexport) void readHextileRectTest(BYTE *pixelData, int posX, int posY, int width, int height, bool cryptMode, BYTE *testbuff, int* size);
	__declspec(dllexport) void SetServerInit(Properties_t *srvInit);
	__declspec(dllexport) INT32 DoAuthentication(LPCTSTR action, BYTE *cryptMode, LPCTSTR password, BYTE *timeout);
	__declspec(dllexport) void CryptorInit(const char* seed, size_t seedSize, BYTE *IV, size_t IVSize);
	__declspec(dllexport) bool remakeAESKeyDatas();
	__declspec(dllexport) bool CryptorEncrypt(BYTE *plainText, DWORD plainTextSize, BYTE ** encodedText, DWORD *encodedTextSize);
	__declspec(dllexport) bool CryptorDecrypt(const BYTE *encodedText, DWORD encodedTextSize, BYTE ** decodedText, DWORD *decodedTextSize);
	__declspec(dllexport) void DWHeapFree(void* haep);

}