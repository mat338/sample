#pragma once

// �F�ؗp
#define DNWA_AUTH "Product Auth"
#define DNWA_AUTH_SERVER "BHTRC-01.00"
#define DNWA_AUTH_CLIENT "BHTRS-"
#define DNWA_PASS "DNWA"

#define IVSIZE 16
#define keyMsgTypeSize 1
#define keySeedSizeSize 1
#define challangeDataSize 16

#define keyCreateMSG 100

#define clientVersionSize 11
#define challangeCodeSize 16
#define keySeedSizeMax 246
#define keySeedSizeMin 32
#define keySeedSizeSurq (keySeedSizeMin+keySeedSizeMax)

#define AUTH_SUCCESS 0
#define AUTH_ERROR_RSA_INITIALIZE -1
#define AUTH_ERROR_STOP_SERVER -2
#define AUTH_ERROR_SENDKEY_MAKE -3

#define AUTH_ERROR_SERVER_VERSION_READ -4
#define AUTH_ERROR_SERVER_VERSION_CHECK -5

#define AUTH_ERROR_CLIENT_VERSION -6
#define AUTH_ERROR_CLIENT_VERSION_RESULT -7
#define AUTH_ERROR_CLIENT_VERSION_RESULT_REC -7

#define AUTH_ERROR_CHALLANG_REC -8
#define AUTH_ERROR_CHALLANGE_ENC -9
#define AUTH_ERROR_CHALLANGE_SEND -10
#define AUTH_ERROR_CHALLANGE_RESULT -11
#define AUTH_ERROR_CHALLANGE_RESULT_REC -11

#define AUTH_ERROR_MODE_SEND -14
#define AUTH_ERROR_MODE_RESULT -15
#define AUTH_ERROR_MODE_RESULT_REC -15
#define AUTH_ERROR_TIMEOUT_SEND -16
#define AUTH_ERROR_TIMEOUT_RESULT -17
#define AUTH_ERROR_TIMEOUT_RESULT_REC -17
#define AUTH_ERROR_ -2
#define AUTH_ERROR_ -2
#define AUTH_ERROR_ -2
