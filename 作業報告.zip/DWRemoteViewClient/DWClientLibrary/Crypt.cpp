
//#include "stdafx.h"

#include <stdio.h>
#include <stdlib.h>
#include <tchar.h>
#include <Windows.h>
#include <time.h>
#include "Crypt.h"

//�f�X�g���N�^.
Cryptor::~Cryptor()
{
	freeCryptData();
}
//16�o�C�g�p�f�B���O.
size_t Cryptor::padding(size_t size)
{
	return CryptMode? (size/ paddingSize +1)*paddingSize : size;
}
//ex�֐��̌����.
void Cryptor::freeCryptData()
{
	//NULL�`�F�b�N�̂���else�s�v.
	if (m_decryptData) {
		HeapFree(GetProcessHeap(), 0, m_decryptData);
		m_decryptData = NULL;
	}
	//NULL�`�F�b�N�̂���else�s�v.
	if (m_encryptData) {
		HeapFree(GetProcessHeap(), 0, m_encryptData);
		m_encryptData = NULL;
	}
}

//�Í����i��������Crypt���Ŋm�ۂ��邽�ߔ񐄏��AC#����g�p�j.
bool Cryptor::encript_ex(const BYTE *plainText, DWORD plainTextSize, BYTE **encodedText, DWORD *encodedTextSize)
{
	bool result;
	if (CryptMode)
	{
		std::vector<BYTE> vectorbuff;
		result = encode(plainText, plainTextSize, &vectorbuff);
		*encodedTextSize = vectorbuff.size();
		m_encryptData = (PBYTE)HeapAlloc(GetProcessHeap(), 0,*encodedTextSize);
		if (!m_encryptData)
			result = false;
		else
			memcpy(m_encryptData,vectorbuff.data(), *encodedTextSize);
	}
	else
	{
		*encodedTextSize = plainTextSize;
		m_encryptData = (PBYTE)HeapAlloc(GetProcessHeap(), 0, *encodedTextSize);
		if (!m_encryptData)
			result = false;
		else {
			memcpy(m_encryptData, plainText, plainTextSize);
			result = true;
		}
	}
	*encodedText = m_encryptData;
	return result;
}

//�������i��������Crypt���Ŋm�ۂ��邽�ߔ񐄏��A�������AC#����g�p�j.
bool Cryptor::decript_ex(const BYTE *encodedText, DWORD encodedTextSize, BYTE **decodedText, DWORD *decodedTextSize)
{
	bool result;
	if (CryptMode)
	{
		std::vector<BYTE> vectorbuff;
		result = decode(encodedText, encodedTextSize, &vectorbuff);
		*decodedTextSize = vectorbuff.size();
		m_decryptData = (PBYTE)HeapAlloc(GetProcessHeap(), 0, *decodedTextSize);
		if (!m_decryptData)
			result = false;
		else
			memcpy(m_decryptData, vectorbuff.data(), *decodedTextSize);
	}
	else
	{
		*decodedTextSize = encodedTextSize;
		m_decryptData = (PBYTE)HeapAlloc(GetProcessHeap(), 0, *decodedTextSize);
		if (!m_decryptData)
			result = false;
		else {
			memcpy(m_decryptData, encodedText, encodedTextSize);
			result = true;
		}
	}
	*decodedText = m_decryptData;
	return result;
}

//�o�C�g�f�[�^�Í���.
bool Cryptor::encript(const BYTE *plainText, DWORD plainTextSize, std::vector<BYTE>* encodedText)
{
	bool result = false;
	if (CryptMode)
	{
		result = encode(plainText, plainTextSize, encodedText);
	}
	else
	{
		encodedText->resize(plainTextSize);
		memcpy(encodedText->data(), plainText, plainTextSize);
		result = true;
	}
	return result;
}

//�o�C�g�f�[�^������.
bool Cryptor::decript(const BYTE *encodedText, DWORD encodedTextSize, std::vector<BYTE> *decodedText)
{
	bool result = false;
	if (CryptMode)
	{
		result = decode(encodedText, encodedTextSize, decodedText);
	}
	else
	{
		decodedText->resize(encodedTextSize);
		memcpy(decodedText->data(), encodedText, encodedTextSize);
		result = true;
	}
	return result;
}
//�x�N�^�[�f�[�^�Í���.
bool Cryptor::encript(std::vector<BYTE> plainText, std::vector<BYTE> *encodedText)
{
	BYTE* buff = plainText.data();
	bool result =encript(buff, plainText.size(), encodedText);
	return result;
}
//�x�N�^�[�f�[�^������.
bool Cryptor::decript(std::vector<BYTE> encodedText, std::vector<BYTE> *decodedText)
{
	BYTE* buff = encodedText.data();
	bool result =decript(buff, encodedText.size(), decodedText);
	return result;
}
