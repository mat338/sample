
#include "winsock2.h"
#include "ClientConnect.h"
#include "DWReadStream/ReadStream.h"

//�}�N���֐��N��.
void ClientConnect::readHextileRect(frameUpdateDatas *pfburh, bool cryptMode)
{
	switch (m_myFormat.bitsPerPixel) {
	case 8:
		handleHextileEncoding8(pfburh->r.w, pfburh->r.h, cryptMode);
		break;
	case 16:
		handleHextileEncoding16(pfburh->r.w, pfburh->r.h, cryptMode);
		break;
	case 32:
		handleHextileEncoding32(pfburh->r.w, pfburh->r.h, cryptMode);
		break;
	}

	//handleHextileEncoding32(pfburh->r.w, pfburh->r.h, cryptMode);
}

//�T�C�Y�`�F�b�N.
bool ClientConnect::checkBufferSize(int bufsize)
{
	bool result;
	char *newbuf = (char*)HeapAlloc(GetProcessHeap(), 0, bufsize + 256);
	if (NULL != newbuf)
	{
		//Null�`�F�b�N�̂���else�s�v.
		if (NULL != m_netbuf)
		{
			HeapFree(GetProcessHeap(), 0, m_netbuf);
			m_netbuf = NULL;
		}
		m_netbuf = newbuf;
		result = true;
	}
	else
	{
		result = false;
	}

	return result;
}

//�G���R�[�h�f�[�^����.
void ClientConnect::convertAllSub(int width, int height, int xx, int yy, int bytes_per_pixel, BYTE* source, BYTE* dest, int subRectWidth)
{
	int bytesPerOutputRow = subRectWidth * bytes_per_pixel;
	int bytesPerInputRow = width * bytes_per_pixel;
	if (bytesPerOutputRow % 4)
		bytesPerOutputRow += 4 - bytesPerOutputRow % 4;

	BYTE *sourcepos, *destpos;

	destpos = (BYTE *)dest + (bytesPerOutputRow * yy) + (xx * bytes_per_pixel);
	sourcepos = (BYTE*)source;

	width *= bytes_per_pixel;
	for (int y = 0; y < height; y++) {
		memcpy(destpos, sourcepos, width);
		sourcepos = (BYTE*)sourcepos + bytesPerInputRow;
		destpos = (BYTE*)destpos + bytesPerOutputRow;
	}
}

//�J���[�f�[�^����.
void ClientConnect::solidColorSub(int width, int height, int xx, int yy, int bytes_per_pixel, BYTE* source, BYTE* dest, int subRectWidth)
{
	int bytesPerOutputRow = subRectWidth * bytes_per_pixel;
	if (bytesPerOutputRow % 4)
		bytesPerOutputRow += 4 - bytesPerOutputRow % 4;
	BYTE* sourcepos = (BYTE*)source;
	BYTE* destpos = (BYTE *)dest + (bytesPerOutputRow * yy) + (xx * bytes_per_pixel);
	
	for (int y = 0; y < height; y++) {
		for (int x = 0; x < width;x++)
		{
			memcpy(destpos + x * bytes_per_pixel, sourcepos, bytes_per_pixel);
		}
		destpos = (BYTE*)destpos + bytesPerOutputRow; 
	}
}

//Hextile�f�R�[�h.
#define D_HEXTILES(BYTEFAR)                                                                                              \
void ClientConnect::handleHextileEncoding##BYTEFAR(int iRwide, int iRheigh, bool cryptMode)                              \
{                                                                                                                        \
    CARD##BYTEFAR zBg, zFg;                                                                                              \
	COLORREF zBgcolor, zFgcolor;											                                             \
    int iWide, iHeigh;                                                                                                   \
    int sx, sy, sw, sh;                                                                                                  \
    BYTE *pbyData;                                                                                                       \
    BYTE bySubencode;                                                                                                    \
    BYTE byNubrect;                                                                                                      \
																		                                                 \
    if(!checkBufferSize( HEXTIL_SIZE * HEXTIL_SIZE * BYTEFAR ))                                                          \
	{                                                                                                                    \
		return;                                                                                                          \
	}                                                                                                                    \
	SETUP_COLOR_SHORTCUTS;                                                                                               \
                                                                                                                         \
	byte* cryptPointBuff = NULL;                                                                                         \
	if (cryptMode)                                                                                                       \
	{                                                                                                                    \
		readEnc((byte*)&m_cryptDataSize, sizeof(m_cryptDataSize), aesCryptor);                                           \
		cryptPointBuff = (byte*)HeapAlloc(GetProcessHeap(), HEAP_GENERATE_EXCEPTIONS, m_cryptDataSize);                  \
		m_cryptData = cryptPointBuff;                                                                                    \
		readEnc(cryptPointBuff, m_cryptDataSize, aesCryptor);                                                            \
	}                                                                                                                    \
                                                                                                                         \
    for (int y = 0; y < iRheigh; y += HEXTIL_SIZE) {                                                                     \
		for (int x = 0; x < iRwide; x += HEXTIL_SIZE) {                                                                  \
            iWide = iHeigh = HEXTIL_SIZE;                                                                                \
            /*�ŏI�f�[�^�������ݗʌv�Z�̂���else�s�v.*/                                                                  \
            if (iRwide - x < HEXTIL_SIZE)                                                                                \
                iWide = iRwide - x;                                                                                      \
            /*�ŏI�f�[�^�������ݗʌv�Z�̂���else�s�v.*/                                                                  \
            if (iRheigh - y < HEXTIL_SIZE)                                                                               \
                iHeigh = iRheigh - y;                                                                                    \
                                                                                                                         \
            readExact((char *)&bySubencode, 1,cryptMode);                                                                \
                                                                                                                         \
            if (bySubencode & rHextileRaw) {                                                                             \
                readExact(m_netbuf, iWide * iHeigh * (BYTEFAR / 8),cryptMode);                                           \
                SETPIXELSSUB(m_netbuf,BYTEFAR, x,y,iWide,iHeigh,iRwide)                                                  \
                continue;                                                                                                \
            }                                                                                                            \
		    else if (bySubencode & rHextileBackgroundSpecified) {                                                        \
                readExact((char *)&zBg, (BYTEFAR/8),cryptMode);                                                          \
				zBgcolor = COLOR_FROM_PIXEL##BYTEFAR##_ADDRESS(&zBg);  			                                         \
			}																                                             \
            fillSolidRect_Sub(x,y,iWide,iHeigh, m_myFormat.bitsPerPixel,(BYTE*)&zBg, iRwide);                            \
                                                                                                                         \
            if (bySubencode & rHextileForegroundSpecified)  {                                                            \
                readExact((char *)&zFg, (BYTEFAR/8),cryptMode);                                                          \
				zFgcolor = COLOR_FROM_PIXEL##BYTEFAR##_ADDRESS(&zFg);			                                         \
			}                                                                                                            \
                                                                                                                         \
            if (!(bySubencode & rHextileAnySubrects)) {                                                                  \
                continue;                                                                                                \
            }                                                                                                            \
            else {                                                                                                       \
				readExact((char *)&byNubrect, 1,cryptMode) ;                                                             \
				pbyData = (BYTE *)m_netbuf;                                                                              \
            }                                                                                                            \
            if (bySubencode & rHextileSubrectsColoured) {                                                                \
				                                                                                                         \
                readExact(m_netbuf, byNubrect * (2 + (BYTEFAR / 8)),cryptMode);                                          \
                                                                                                                         \
                for (int i = 0; i < byNubrect; i++) {                                                                    \
                    zFgcolor = COLOR_FROM_PIXEL##BYTEFAR##_ADDRESS(pbyData);                                             \
					memcpy(&zFg,pbyData,BYTEFAR/8);								                                         \
					pbyData += (BYTEFAR/8);                                                                              \
                    sx = *pbyData >> 4;                                                                                  \
                    sy = *pbyData++ & 0x0f;                                                                              \
                    sw = (*pbyData >> 4) + 1;                                                                            \
                    sh = (*pbyData++ & 0x0f) + 1;                                                                        \
                    fillSolidRect_Sub(x+sx, y+sy, sw, sh, m_myFormat.bitsPerPixel,(BYTE*)&zFg,iRwide);                   \
                }                                                                                                        \
                                                                                                                         \
            } else {                                                                                                     \
                readExact(m_netbuf, byNubrect * 2,cryptMode);                                                            \
                                                                                                                         \
                for (int i = 0; i < byNubrect; i++) {                                                                    \
                    sx = *pbyData >> 4;                                                                                  \
                    sy = *pbyData++ & 0x0f;                                                                              \
                    sw = (*pbyData >> 4) + 1;                                                                            \
                    sh = (*pbyData++ & 0x0f) + 1;                                                                        \
                    fillSolidRect_Sub(x+sx, y+sy, sw, sh, m_myFormat.bitsPerPixel,(BYTE*)&zFg,iRwide);                   \
                }                                                                                                        \
            }															                                                 \
        }                                                                                                                \
    }                                                                                                                    \
	if (cryptPointBuff != NULL) {                                                                                        \
		HeapFree(GetProcessHeap(), 0, cryptPointBuff);                                                                   \
		cryptPointBuff = NULL;                                                                                           \
	}                                                                                                                    \
}

D_HEXTILES(8)
D_HEXTILES(16)
D_HEXTILES(32)
