#pragma once

#include <Windows.h>
#include"Crypt.h"
#include <ncrypt.h>


//#7�p�f�B���O(openssl�̊�b����).
#define keyPadding 0x0b
#define szPubKeyName "rsa-pubkey.dat"

class CryptRSA;

//���b�Z�[�W���Pbyte���Í�������Z�@.
//���݈Í����ɃI�v�V�����͂Ȃ�.
//��O��0�p�f�B���O.
class CryptRSA : public Cryptor
{
public:
	CryptRSA();

	bool startRsaKeyFile();

	bool encode(const BYTE *plainText, DWORD plainTextSize, std::vector<BYTE> *encodedText);
	bool decode(const BYTE *encodedText, DWORD encodedTextSize, std::vector<BYTE> *decodedText);

private:

	static constexpr const char* keyFilePath 
				= "C:/Users/dwuz028717/Desktop/myCrypt.txt";
	static const int streamLineSize = 2048;
	static const size_t mLength = 2048;

	static constexpr const char* publicKeyn_str  = "modulus\0";
	static constexpr const char* publicKeye_str  = "publicExponent\0";
	static constexpr const char* privateKey_str	 = "privateExponent\0";
	static constexpr const char* prime1_str		 = "prime1\0";
	static constexpr const char* prime2_str		 = "prime2\0";
	static constexpr const char* exponent1_str = "exponent1\0";
	static constexpr const char* exponent2_str = "exponent2\0";
	static constexpr const char* coefficient_str = "coefficient\0";
	
	enum keyType
	{
		modulus_e,			
		publicExponent_e,
		privateExponent_e,
		prime1_e,
		prime2_e,
		exponent1_e,
		exponent2_e,
		coefficient_e
	};



	//�Í��f�[�^.
	NCRYPT_PROV_HANDLE hProv = NULL;
	NCRYPT_KEY_HANDLE  hKey = NULL;


	void readOssKeyData();
	void getKeyDataX(const char* src, BYTE* dmp,size_t size);
	int getKeyData(const char* lineText);
	void removeUnneedStr(char* lineData);
	BOOL ImportKeyData(LPTSTR lpszFileName, LPCWSTR lpszType);
	BOOL ExportKeyData(LPTSTR lpszFileName, LPCWSTR lpszType);
	BOOL rewiteRSAKey(byte* publicn, size_t nsize, byte* publice, size_t eSize, LPTSTR lpszFileName, LPCWSTR lpszType);
	void rsaEndObject();
public:
	~CryptRSA()
	{
		rsaEndObject();
	}
};