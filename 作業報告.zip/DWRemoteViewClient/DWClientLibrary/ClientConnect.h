
#ifndef ClientConnect_H__
#define ClientConnect_H__

#pragma once

#include "winsock2.h"

#include <vector>
#include <algorithm>
#include"CryptAES.h"

extern const UINT FileTransferSendPacketMessage;

#define MAX_HOST_NAME_LEN 250
#define HEXTIL_SIZE 16

class ClientConnect;

namespace DWReadStream { class InStream; class ReadStream; }

#define rHextileRaw			(1 << 0)
#define rHextileBackgroundSpecified	(1 << 1)
#define rHextileForegroundSpecified	(1 << 2)
#define rHextileAnySubrects		(1 << 3)
#define rHextileSubrectsColoured	(1 << 4)

typedef unsigned long CARD32;
typedef unsigned short CARD16;
typedef unsigned char  CARD8;

typedef struct
{
	BYTE byPerPixel;
	BYTE byDepth;
	BYTE byBigEndianFlag;
	BYTE byTrueColourFlag;
	UINT16 _RedMax;
	UINT16 _GreenMax;
	UINT16 _BlueMax;
	BYTE _RedShift;
	BYTE _GreenShift;
	BYTE _BlueShift;
	UINT16 _FramebufferWidth;
	UINT16 _FramebufferHeight;
} Properties_t;

typedef struct {
	WORD x;
	WORD y;
	WORD w;
	WORD h;
} rRectangle;

typedef struct {
	BYTE bitsPerPixel;
	BYTE depth;
	BYTE bigEndian;
	BYTE trueColour;
	WORD redMax;
	WORD greenMax;
	WORD blueMax;
	BYTE redShift;
	BYTE greenShift;
	BYTE blueShift;
	BYTE pad1;
	WORD pad2;
} rPixelFormat;

typedef struct {
	WORD framebufferWidth;
	WORD framebufferHeight;
	rPixelFormat format;
	DWORD nameLength;
} rServerInitMsg;

typedef struct {
	rRectangle r;
	DWORD encoding;
} frameUpdateDatas;

class ClientConnect 
{
public:
	int		m_iPort;
    TCHAR	m_cHost[MAX_HOST_NAME_LEN];
	TCHAR	m_cProxyHost[MAX_HOST_NAME_LEN];

	ClientConnect(LPCTSTR host, int port, LPCTSTR proxy, int timeout);
	virtual ~ClientConnect();
	HANDLE KillEvent;
	rServerInitMsg m_si;
	int writeExact(char *buf, int bytes); 
	int writeEnc(const byte *buf, int bytes, Cryptor* pCryptType);
	int readEnc (byte *buf, int bytes, Cryptor* pCryptType);
	DWReadStream::ReadStream* GetStream();
	void setDIBbits(VOID *pixelData);
	void readHextileRect(frameUpdateDatas *pfburh,bool cryptMode);
	void setServerInit(Properties_t *srvInit);
	bool remakeAESKeyDatas();
	//byte*	m_cryptData;
	//size_t  m_cryptDataSize;
	//size_t  m_cryptDataSizeTest;

private:
	SOCKET	m_sock;
	struct timeval tv;

	bool Connect();
	bool connectProxy();
	bool setSocketOptions();
	void handleHextileEncoding8 ( int w, int h, bool cryptMode);
	void handleHextileEncoding16( int w, int h, bool cryptMode);
	void handleHextileEncoding32( int w, int h, bool cryptMode);

	int sendData(const char *buff, const unsigned int bufflen,int timeout);

	bool write(char *buf, int bytes, bool bTimeout = false, int timeout = 0);
	bool writeTransform(char *buf, int bytes);

	inline void fillSolidRect_Sub(int x, int y, int w, int h, int bpp, BYTE *color, int subRectWidth) {
		if (m_DIBbits) solidColorSub(w, h, x, y, bpp / 8, (BYTE*)color, (BYTE*)m_DIBbits, subRectWidth);
	};

	bool	checkBufferSize(int bufsize);
	rPixelFormat m_myFormat;
	char*	m_netbuf;
	VOID*	m_DIBbits;
	byte*	m_cryptData;
	size_t  m_cryptDataSize;

	DWReadStream::ReadStream* fis;
	
	void convertAllSub(int width, int height, int xx, int yy, int bytes_per_pixel, BYTE* source, BYTE* dest, int subRectWidth);
	void solidColorSub(int width, int height, int xx, int yy, int bytes_per_pixel, BYTE* source, BYTE* dest, int subRectWidth);

	HANDLE ThreadSocketTimeout;


public:
	CryptAES* aesCryptor;

	bool doConnection();
	int readExact(char *buf, int bytes,bool cryptMode);
	int readHasData(char *dst, int wanted);
	int rsaInit(BYTE* ivData, std::vector<byte> keyData);

	int handleInit(LPCTSTR action, BYTE *cryptMode, LPCSTR password, BYTE *timeout);
private:

	const rPixelFormat Colors32Format = { 32,24,0,1,255,255,255,16,8,0, 0, 0 }; // 32bit
	//const rPixelFormat Colors16Format = { 16,16,0,1,63,31,31,0,6,11, 0, 0 };// 16bit
	//const rPixelFormat Colors8Format = { 8,8,0,1,7,7,3,0,3,6, 0, 0 }; // 8bit
	int authDNWA(LPCTSTR action, BYTE *cryptMode, LPCSTR password, BYTE* timeout);
	int aesInitConect(BYTE* ivData, std::vector<byte> keyData);
	int dwrvAuthProcessClient(LPCSTR password, byte* ivData);
	int dwrvModeSend(LPCTSTR action);
	int dwrvTimeoutSend(BYTE *timeout);
	int dwrvClientVersion(BYTE* ivData);
};

#define SETUP_COLOR_SHORTCUTS \
	BYTE rs = m_myFormat.redShift;	\
	WORD rm = m_myFormat.redMax;	\
	BYTE gs = m_myFormat.greenShift;\
	WORD gm = m_myFormat.greenMax;	\
	BYTE bs = m_myFormat.blueShift;	\
	WORD bm = m_myFormat.blueMax;	\

#define COLOR_FROM_PIXEL8_ADDRESS(p) (PALETTERGB( \
                (int) (((*(BYTE *)(p) >> rs) & rm) * 255 / rm), \
                (int) (((*(BYTE *)(p) >> gs) & gm) * 255 / gm), \
                (int) (((*(BYTE *)(p) >> bs) & bm) * 255 / bm) ))

#define COLOR_FROM_PIXEL16_ADDRESS(p) (PALETTERGB( \
                (int) ((( *(WORD *)(p) >> rs) & rm) * 255 / rm), \
                (int) ((( *(WORD *)(p) >> gs) & gm) * 255 / gm), \
                (int) ((( *(WORD *)(p) >> bs) & bm) * 255 / bm) ))

#define COLOR_FROM_PIXEL32_ADDRESS(p) (PALETTERGB( \
                (int) ((( *(DWORD *)(p) >> rs) & rm) * 255 / rm), \
                (int) ((( *(DWORD *)(p) >> gs) & gm) * 255 / gm), \
                (int) ((( *(DWORD *)(p) >> bs) & bm) * 255 / bm) ))

#define SETPIXEL(b,x,y,c) SetPixelV((b),(x),(y),(c))

#define SETPIXELSSUB(buffer, bpp, x, y, w, h, rw)										\
	{																			\
			if (m_DIBbits) convertAllSub(w,h,x,y,bpp/8,(BYTE*)buffer,(BYTE*)m_DIBbits, rw);\
	}

#endif