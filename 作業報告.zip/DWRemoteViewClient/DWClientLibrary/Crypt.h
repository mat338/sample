#pragma once

#include <bcrypt.h>
#include <vector>

class  Cryptor;

//�Í����������.
class Cryptor
{
public:
	bool CryptMode;
	Cryptor():CryptMode(true),m_encryptData(NULL),m_decryptData(NULL){}
	virtual ~Cryptor();
	
	void freeCryptData();	//_ex���L�ڂ���Ă���񐄏��ȃ��\�b�h���Ăяo������K���ĂԂ���.(�ꉞ�f�X�g���N�^�ł��Ă�).

	bool encript_ex(const BYTE *plainText, DWORD plainTextSize, BYTE **encodedText, DWORD *encodedTextSize);
	bool decript_ex(const BYTE *encodedText, DWORD encodedTextSize, BYTE **decodedText, DWORD *decodedTextSize);

	bool encript(const BYTE *plainText, DWORD plainTextSize, std::vector<BYTE> *encodedText);
	bool decript(const BYTE *encodedText, DWORD encodedTextSize, std::vector<BYTE> *decodedText);

	bool encript(std::vector<BYTE> plainText, std::vector<BYTE> *encodedText);
	bool decript(std::vector<BYTE> encodedText, std::vector<BYTE> *decodedText);

	size_t padding(size_t size);

private:
	static const char paddingSize = 16;

	virtual bool encode(const BYTE *plainText, DWORD plainTextSize, std::vector<BYTE> *encodedText) = 0;
	virtual bool decode(const BYTE *encodedText, DWORD encodedTextSize, std::vector<BYTE> *decodedText) = 0;
	BYTE* m_encryptData;
	BYTE* m_decryptData;


	//template<class CT,class TT,class T>
	//bool beforeEncode(int(CT::*func)(TT, T),BYTE *plainText, DWORD plainTextSize, BYTE **encodedText, DWORD *encodedTextSize);
	//template<class CT, class TT,class T>
	//bool afterdecode(int(CT::*func)(TT, T), BYTE *encodedText, DWORD encodedTextSize, BYTE **decodedText, DWORD *decodedTextSize);


	//void makeRandByteData(BYTE* byteData,size_t size);
};