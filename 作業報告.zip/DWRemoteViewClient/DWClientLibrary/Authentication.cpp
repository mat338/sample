//#include "stdafx.h"
#include "ClientConnect.h"
#include "CryptAES.h"
#include "CryptRSA.h"
#include "DWReadStream/ReadStream.h"
#include <bcrypt.h>
#include <time.h>
#include "Authentication.h"

//Auth����.
int ClientConnect::handleInit(LPCTSTR action, BYTE *cryptMode, LPCSTR password, BYTE *timeout)
{
	return authDNWA(action, cryptMode,  password, timeout);
}

//DNWA�F��.
int ClientConnect::authDNWA(LPCTSTR action, BYTE *cryptMode, LPCSTR password, BYTE *timeout)
{
	int result = 0;
	std::vector<byte> challangeData;
	size_t challangeSize = 0;
	std::vector<byte> ivData;
	ivData.resize(IVSIZE);

	aesCryptor = new CryptAES();
	aesCryptor->makeRandData<size_t>(&challangeSize);
	challangeSize = challangeSize%(keySeedSizeMax-keySeedSizeMin)+ keySeedSizeMin;
	challangeData.resize(challangeSize);

	aesCryptor->makeRandByteData(challangeData.data(), challangeSize);
	aesCryptor->makeRandByteData(ivData.data(), IVSIZE);

	aesCryptor->remakeAESKey(challangeData,ivData);
	aesCryptor->CryptMode = true;
	memcpy(cryptMode,"1",1);

	do {
		result = aesInitConect(ivData.data(), challangeData);
		//���ʊm�F�����̂���else�s�v.
		if (0 > result)
		{
			break;
		}
		result = dwrvClientVersion(ivData.data());
		//���ʊm�F�����̂���else�s�v.
		if (0 > result)
		{
			break;
		}
		result = dwrvAuthProcessClient(password, ivData.data());
		//���ʊm�F�����̂���else�s�v.
		if (0 > result)
		{
			break;
		}
		result = dwrvModeSend(action);
		//���ʊm�F�����̂���else�s�v.
		if (0 > result)
		{
			break;
		}
		result = dwrvTimeoutSend(timeout);
		//���ʊm�F�����̂���else�s�v.
		if (0 > result)
		{
			break;
		}
		break;
	} while (false);

	return result;
}


//AES�L�[����RSA�ő��M.
int ClientConnect::rsaInit(BYTE* ivData, std::vector<byte> keyData)
{
	int result;

	CryptRSA* rsaCryptor = new CryptRSA();
	rsaCryptor->CryptMode = aesCryptor->CryptMode;
	// RSA ����������
	bool ret = rsaCryptor->startRsaKeyFile();
	if (ret)
	{
		BYTE keyCreateDatas[keyMsgTypeSize + IVSIZE + keySeedSizeSize];
		BYTE msgTypBuff = keyCreateMSG;
		memcpy(keyCreateDatas, &msgTypBuff, keyMsgTypeSize);
		memcpy(&(keyCreateDatas[keyMsgTypeSize]), ivData, IVSIZE);
		msgTypBuff = (BYTE)keyData.size();
		memcpy(&(keyCreateDatas[keyMsgTypeSize + IVSIZE]), &msgTypBuff, keySeedSizeSize);

		if (0 >= writeEnc(keyCreateDatas, sizeof(keyCreateDatas), rsaCryptor))
		{
			result = AUTH_ERROR_STOP_SERVER;
		}
		else if (0 >= writeEnc(keyData.data(), keyData.size(), rsaCryptor))
		{
			result = AUTH_ERROR_SENDKEY_MAKE;
		}
		else
		{
			result = AUTH_SUCCESS;
		}
	}
	else
	{
		result = AUTH_ERROR_RSA_INITIALIZE;
	}

	delete rsaCryptor;
	rsaCryptor = NULL;
	return result;
}

//�T�[�o�[�o�[�W��������M.
int ClientConnect::aesInitConect(BYTE* ivData, std::vector<byte> keyData)
{
	int ret;
	int resultreturn;

	std::vector<BYTE> cryptbuff;
	UINT32 result = 0;

	ret = rsaInit(ivData, keyData);
	if (ret < 0)
	{
		resultreturn = ret;
	}
	else
	{
		BYTE clientVersion[clientVersionSize];
		ret = readEnc(clientVersion, clientVersionSize, aesCryptor);
		if (ret <= 0) {
			resultreturn = AUTH_ERROR_SERVER_VERSION_READ;
		}
		else if (0 != memcmp(clientVersion, DNWA_AUTH_CLIENT, strlen(DNWA_AUTH_CLIENT)))
		{
			resultreturn = AUTH_ERROR_SERVER_VERSION_CHECK;
		}
		else
		{
			resultreturn = AUTH_SUCCESS;
		}
	}
	return resultreturn;
}

//�N���C�A���g�c�[���o�[�W�������M.
int ClientConnect::dwrvClientVersion(BYTE* ivData)
{
	int ret;
	int resultreturn;

	if (0 >= writeEnc((byte*)DNWA_AUTH_SERVER, strlen(DNWA_AUTH_SERVER), aesCryptor))
	{
		resultreturn = AUTH_ERROR_CLIENT_VERSION;
	}
	else
	{
		UINT32 result = 0;
		ret = readEnc((byte*)&result, sizeof(result), aesCryptor);
		if (ret <= 0)
		{
			resultreturn = AUTH_ERROR_CLIENT_VERSION_RESULT_REC;
		}
		else if (0 != result) {
			resultreturn = AUTH_ERROR_CLIENT_VERSION_RESULT;
		}
		else
		{
			resultreturn = AUTH_SUCCESS;
		}
	}
	return resultreturn;
}

//���[�U�[�F��(�`�������W�R�[�h)
int ClientConnect::dwrvAuthProcessClient(LPCSTR password, byte* ivData)
{
	int ret;
	int resultreturn;
	UINT32 result;
	std::vector<BYTE> encode;

	byte chgData[challangeCodeSize * 2];
	Cryptor* passCryptor = new CryptAES(password, strlen(password), ivData, IVSIZE);

	ret = readEnc(chgData, challangeCodeSize, aesCryptor);
	if (ret <= 0) {
		resultreturn = AUTH_ERROR_CHALLANG_REC;
	}
	else if (!passCryptor->encript(chgData, challangeCodeSize * 2, &encode)) {
		resultreturn = AUTH_ERROR_CHALLANGE_ENC;
	}
	else if (0 >= writeEnc(encode.data(), encode.size(), aesCryptor))
	{
		resultreturn = AUTH_ERROR_CHALLANGE_SEND;
	}

	else if (0 >= readEnc((byte*)&result, sizeof(result), aesCryptor))
	{
		resultreturn = AUTH_ERROR_CHALLANGE_RESULT;
	}
	else if (0 != result)
	{
		resultreturn = AUTH_ERROR_CHALLANGE_RESULT;
	}
	else
	{
		resultreturn = AUTH_SUCCESS;
	}

	delete passCryptor;
	return resultreturn;
}

//���샂�[�h���M.
int ClientConnect::dwrvModeSend(LPCTSTR action)
{
	int ret;
	int resultreturn;
	
	if(0 >= writeEnc((byte*)action,strlen(action),aesCryptor))
	{
		resultreturn = AUTH_ERROR_MODE_SEND;
	}
	else
	{
		UINT32 result;
		ret = readEnc((byte*)&result, sizeof(result), aesCryptor);
		if (ret <= 0)
		{
			resultreturn = AUTH_ERROR_MODE_RESULT_REC;
		}
		else if (0 != result)
		{
			resultreturn = AUTH_ERROR_MODE_RESULT;
		}
		else
		{
			resultreturn = AUTH_SUCCESS;
		}
	}
	return resultreturn;
}

//�^�C���A�E�g�l���M.
int ClientConnect::dwrvTimeoutSend(BYTE *timeout)
{
	int ret;
	int resultreturn;
	//printf(sizeof(timeout));
	if (0 >= writeEnc(timeout, sizeof(timeout), aesCryptor))
	{
		resultreturn = AUTH_ERROR_TIMEOUT_SEND;
	}
	else
	{
		UINT32 result;
		ret = readEnc((byte*)&result, sizeof(result), aesCryptor);
		if (ret <= 0)
		{
			resultreturn = AUTH_ERROR_TIMEOUT_RESULT_REC;
		}
		else if (0 != result)
		{
			resultreturn = AUTH_ERROR_TIMEOUT_RESULT;
		}
		else
		{
			resultreturn = AUTH_SUCCESS;
		}
	}
	return resultreturn;
}

//AES�L�[���ύX.
bool ClientConnect::remakeAESKeyDatas()
{
	bool result;
	std::vector<byte> keySeed;
	std::vector<byte> IV;
	size_t keySeedSize;

	if (!aesCryptor->makeRandData<size_t>(&keySeedSize))
		return false;
	keySeedSize = keySeedSize %32+32;

	keySeed.resize(keySeedSize);
	IV.resize(IVSIZE);


	byte msgTypeBuf = keyCreateMSG;

	aesCryptor->makeRandByteData(IV.data(), IV.size());
	BYTE keyCreateDatas[IVSIZE + keySeedSizeSize];
	BYTE msgTypBuff = keyCreateMSG;
	memcpy(keyCreateDatas, IV.data(), IVSIZE);
	msgTypBuff = (BYTE)keySeed.size();
	memcpy(&(keyCreateDatas[IVSIZE]), &msgTypBuff, keySeedSizeSize);

	if (0 >= writeEnc(&msgTypeBuf, sizeof(msgTypeBuf), aesCryptor))
	{
		result = false;
	}
	else if (0 >= writeEnc(keyCreateDatas, sizeof(keyCreateDatas), aesCryptor))
	{
		result = false;
	}
	else
	{
		aesCryptor->makeRandByteData(keySeed.data(), keySeed.size());
		if (0 >= writeEnc(keySeed.data(), keySeed.size(), aesCryptor))
		{
			result = false;
		}
		else
		{
			aesCryptor->remakeAESKey(keySeed, IV);
			result = true;
		}
	}
	return result;
}