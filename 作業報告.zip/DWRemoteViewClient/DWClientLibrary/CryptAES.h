#pragma once

#include <bcrypt.h>
#include "Crypt.h"

class  CryptAES;

class CryptAES :  public Cryptor
{
public:
	CryptAES(const char* seed, size_t seedSize, BYTE *IV, size_t IVSize);
	CryptAES();
	virtual ~CryptAES();
	bool encode(const BYTE *plainText, DWORD plainTextSize, std::vector<BYTE> *encodedText);
	bool decode(const BYTE *encodedText, DWORD encodedTextSize, std::vector<BYTE> *decodedText);
	bool remakeAESKeyDatas(std::vector<byte> *challenge, std::vector<byte> *IV);
	void remakeAESKey(const std::vector<byte> challenge, std::vector<byte> IV);
	void makeRandByteData(BYTE* byteData, size_t size);
	template<typename T>
	bool makeRandData(T *buffData)
	{
		BYTE* buff;
		buff = (BYTE*)HeapAlloc(GetProcessHeap(),0,sizeof(T));
		if (!buff) 
			return false;
		makeRandByteData(buff, sizeof(T));
		memcpy(buffData,buff,sizeof(T));
		HeapFree(GetProcessHeap(), 0, buff);
		return true;
	}
	void freeCryptBuffer();

private:
	bool privateCryptMode = false;
	bool srandActivateFlag = false;

	static const int KEYSIZE = 32;
	static const int decryptMinSize = 16;
	BCRYPT_ALG_HANDLE   hAlg = NULL;
	DWORD   cbKeyObj = 0;
	PBYTE   pbKeyObj = NULL;
	DWORD   Result = 0;
	BCRYPT_ALG_HANDLE   hAlgHash = NULL;
	BCRYPT_HASH_HANDLE hHash = NULL;
	DWORD   hashObjSize = 0;
	PBYTE   pHashObj = NULL;
	DWORD	hashLength = 0;
	PBYTE   pHashValue = NULL;
	DWORD   cbData = 0;
	DWORD   cbBlockLen = 0;
	BYTE*   pbIV =NULL;
	BYTE*	rgbIV =NULL;
	BCRYPT_KEY_HANDLE   hKey = NULL;

	void makeAES(const char* seed, size_t seedSize, BYTE *IV, size_t IVSize);
	void makeHashEncryptKey(const char* seed, size_t seedSize, BYTE *aesKey);


};