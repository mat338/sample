
#include "CryptRSA.h"
#include <ncrypt.h>

//�R���X�g���N�^.
CryptRSA::CryptRSA()
{
}
//RSA�L�[�t�@�C���ǂݍ��݁A�L�[�쐬.
bool CryptRSA::startRsaKeyFile()
{
	SECURITY_STATUS status;
	TCHAR szPubKeyNameBuf[] = TEXT(szPubKeyName);
	status = NCryptOpenStorageProvider(&hProv, MS_KEY_STORAGE_PROVIDER, 0);
	if (status != ERROR_SUCCESS)
	{
		return false;
	}

	return ImportKeyData(szPubKeyNameBuf, BCRYPT_RSAPUBLIC_BLOB);
}

//�Í���.
bool CryptRSA::encode(const BYTE *plainText, DWORD plainTextSize, std::vector<BYTE> *encodedText)
{
	SECURITY_STATUS status;
	std::vector<BYTE> plainTextBuff;
	DWORD encodedTextSize = 0;
	DWORD encodedResult = 0;
	bool result = false;
	plainTextBuff.resize(plainTextSize);
	memcpy(plainTextBuff.data(), plainText, plainTextSize);
	//size�m��.
	status = NCryptEncrypt(	hKey,
							plainTextBuff.data(),
							plainTextBuff.size(), 
							NULL,
							NULL,
							0, 
							&encodedTextSize,
							NCRYPT_PAD_PKCS1_FLAG);
	if (status == ERROR_SUCCESS)
	{
		encodedText->resize(encodedTextSize);
		// �Í���
		status = NCryptEncrypt( hKey,
								plainTextBuff.data(),
								plainTextBuff.size(),
								NULL,
								encodedText->data(),
								encodedText->size(),
								&encodedResult,
								NCRYPT_PAD_PKCS1_FLAG);
	}

	if (status != ERROR_SUCCESS)
	{
		result = false;
	}
	else
	{
		result = true;
	}

	return result;
}
//������.
bool CryptRSA::decode(const BYTE *encodedText, DWORD encodedTextSize, std::vector<BYTE> *decodedText)
{
	//����J�����������Ă��Ȃ����ߎg�p�s��.
	return false;
}
//�L�[�f�[�^�ǂݍ���.
BOOL CryptRSA::ImportKeyData(LPTSTR lpszFileName, LPCWSTR lpszType)
{
	HANDLE          hFile;
	DWORD           dwReadByte;
	DWORD           dwDataSize;
	LPBYTE          lpData;
	SECURITY_STATUS status;
	bool ret = false;

	// ���J���t�@�C���̃I�[�v��
	hFile = CreateFile(lpszFileName, FILE_SHARE_READ, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
	if (hFile == INVALID_HANDLE_VALUE)
	{
		return ret;
	}

	dwDataSize = GetFileSize(hFile, NULL);
	lpData = (LPBYTE)HeapAlloc(GetProcessHeap(), 0, dwDataSize);
	if (lpData && ReadFile(hFile, lpData, dwDataSize, &dwReadByte, NULL))
	{
		// ���J�����n���h���ɃZ�b�g
		status = NCryptImportKey(hProv, NULL, lpszType, NULL, &hKey, lpData, dwDataSize, 0);
		if (status == ERROR_SUCCESS)
		{
			ret = true;
		}
	}

	// ���������
	CloseHandle(hFile);
	BCRYPT_RSAFULLPRIVATE_MAGIC;
	HeapFree(GetProcessHeap(), 0, lpData);
	
	return ret;
}

//rsa�L�[���.
void CryptRSA::rsaEndObject()
{
	NCryptFreeObject(hKey);
	NCryptFreeObject(hProv);
}

